#' Pseudonyme durch die echten Werte ersetzen
#'
#' Macht \code{\link{anonymize_data}} rückgängig: Jeder Wert, der ein
#' Pseudonym der Schlüsseldatei ist, wird durch den echten Wert ersetzt.
#'
#' @details
#'
#' Durchsucht werden alle Text- und Faktorspalten, unabhängig vom
#' Spaltennamen. Eine Tabelle lässt sich deshalb auch dann zurückführen,
#' wenn ihre Spalten inzwischen umbenannt wurden. Faktorspalten, in denen ein
#' Pseudonym ersetzt wird, werden zu Textspalten.
#'
#' Die echten Werte kommen als Text zurück, in der zuerst gesehenen
#' Schreibweise. Die Zeilen bleiben in der Reihenfolge der Eingabe.
#'
#' **Falsche Schlüsseldatei**
#'
#' Jedes Pseudonym trägt die Kennung seiner Schlüsseldatei. Pseudonyme aus
#' einer anderen Schlüsseldatei werden deshalb nicht ersetzt; die Funktion
#' warnt und lässt sie unverändert stehen.
#'
#' @param data
#' Data Frame oder Liste von Data Frames mit Pseudonymen.
#'
#' @param key_path
#' Pfad der Schlüsseldatei, die \code{\link{anonymize_data}} geschrieben hat.
#'
#' @return
#' \code{data} in derselben Form, mit den echten Werten.
#'
#' @examples
#' \dontrun{
#'
#' key_path   <- "C:/D365_Schluessel/anonymization_key.xlsx"
#' anonymized <- anonymize_data(users, key_path)
#'
#' deanonymize_data(anonymized, key_path)
#'
#' }
#'
#' @seealso
#' \code{\link{anonymize_data}}
#' \code{\link{deanonymize_workbook}}
#'
#' @export
deanonymize_data <- function(data, key_path) {

  .check_key_path(key_path)

  key    <- .read_existing_key(key_path)
  tables <- .as_table_list(data)

  .warn_unknown_pseudonyms(tables, key)

  restored <- lapply(tables, .restore_originals, key = key)

  .restore_table_shape(restored, data)
}

.restore_originals <- function(table, key) {

  if (!is.data.frame(table)) {
    return(table)
  }

  for (index in which(vapply(table, .is_text_column, logical(1)))) {

    text     <- as.character(table[[index]])
    position <- match(text, key$PSEUDONYM)
    found    <- !is.na(position)

    if (any(found)) {
      text[found]    <- key$ORIGINAL[position[found]]
      table[[index]] <- text
    }
  }

  table
}

# Werte in der Form eines Pseudonyms, die der Schluessel nicht kennt. Die
# Kategorien sind beim Lesen des Schluessels geprueft und enthalten nur
# Grossbuchstaben und Ziffern.
.warn_unknown_pseudonyms <- function(tables, key) {

  categories <- unique(c(key$CATEGORY, names(default_anonymization_columns())))

  pseudonym_pattern <- paste0(
    "^(", paste(categories, collapse = "|"), ")_[A-Z2-9]{", .KEY_TAG_LENGTH,
    "}_[0-9]{", .PSEUDONYM_DIGITS, ",}$"
  )

  values <- unique(unlist(lapply(tables, function(table) {
    if (!is.data.frame(table)) {
      return(character())
    }
    unlist(lapply(table[vapply(table, .is_text_column, logical(1))], as.character))
  })))

  unknown <- setdiff(values[grepl(pseudonym_pattern, values)], key$PSEUDONYM)

  if (length(unknown) > 0L) {
    shown_limit <- 10L
    warning(
      length(unknown), " Pseudonym(e) stehen nicht in der Schlüsseldatei und ",
      "bleiben unverändert: ",
      paste(utils::head(unknown, shown_limit), collapse = ", "),
      if (length(unknown) > shown_limit) " ..." else "",
      ". Gehört die Schlüsseldatei zu diesen Daten?",
      call. = FALSE
    )
  }

  invisible(unknown)
}
