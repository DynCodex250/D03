
#' D365FO Privilege-XML-Struktur analysieren
#'
#' Analysiert die Struktur einer D365FO Privilege XML-Datei
#' anhand zuvor extrahierter XML-Knoten und ermittelt,
#' welche Arten von Security-Komponenten enthalten sind.
#'
#' Die Funktion arbeitet auf der XML-Struktur eines
#' Privileges und dient der Analyse vorhandener
#' Security-Artefakte innerhalb der XML-Datei.
#'
#' Die Analyse erfolgt direkt auf den aus der
#' XML-Datei extrahierten Knoten, nicht auf einem
#' geparsten D365Privilege-Modell.
#'
#' Typische Anwendungsfälle:
#' - Reverse Engineering
#' - XML-Strukturanalyse
#' - XML-Vergleiche
#' - Privilege Splitting
#' - XML-Generierung
#' - Analyse unbekannter Security-Objekte
#'
#' @param privilege_analysis Ergebnis von
#'        `analyze_privilege_entrypoints()`.
#'
#' @return Liste der Klasse `D365PrivilegeStructure`
#'         mit logischen Indikatoren für die in der
#'         XML-Datei enthaltenen Security-Komponenten.
#'
#' Enthaltene Elemente:
#'
#' \describe{
#'   \item{HasEntryPoints}{
#'   Gibt an, ob EntryPoints vorhanden sind.
#'   }
#'
#'   \item{HasForms}{
#'   Gibt an, ob Formularreferenzen vorhanden sind.
#'   }
#'
#'   \item{HasControls}{
#'   Gibt an, ob Formular-Controls vorhanden sind.
#'   }
#'
#'   \item{HasDataSources}{
#'   Gibt an, ob Form Data Sources vorhanden sind.
#'   }
#'
#'   \item{HasDataEntityPermissions}{
#'   Gibt an, ob Data Entity Permissions vorhanden sind.
#'   }
#'
#'   \item{HasDataEntityMethods}{
#'   Gibt an, ob Data Entity Method Permissions vorhanden sind.
#'   }
#'
#'   \item{HasDirectAccessPermissions}{
#'   Gibt an, ob Direct Access Permissions oder
#'   Direct Access Field Permissions vorhanden sind.
#'   }
#' }
#'
#' @details
#' Die Funktion analysiert die von
#' `analyze_privilege_entrypoints()`
#' extrahierten XML-Knoten und prüft,
#' welche D365FO Security-Artefakte in der
#' XML-Datei enthalten sind.
#'
#' Die Funktion liefert eine technische
#' Strukturübersicht der XML-Datei und eignet
#' sich insbesondere für XML-basierte Analysen.
#'
#' @examples
#' privilege_analysis <-
#'   analyze_privilege_entrypoints(
#'     "CustTableMaintain.xml"
#'   )
#'
#' xml_structure <-
#'   analyze_privilege_xml_structure(
#'     privilege_analysis
#'   )
#'
#' xml_structure
#'
#' xml_structure$HasEntryPoints
#'
#' @seealso
#' analyze_privilege_entrypoints()
#'
#' @export
analyze_privilege_xml_structure <- function(
    privilege_analysis
){

  xml_nodes <- unique(
    privilege_analysis$XmlNode
  )

  result <- list(

    HasEntryPoints =
      "AxSecurityEntryPointReference" %in% xml_nodes,

    HasForms =
      "AxSecurityEntryPointReferenceForm" %in% xml_nodes,

    HasControls =
      "AxSecurityEntryPointReferenceFormControl" %in% xml_nodes,

    HasDataSources =
      "AxSecurityEntryPointReferenceFormDataSource" %in% xml_nodes,

    HasDataEntityPermissions =
      "AxSecurityDataEntityPermission" %in% xml_nodes,

    HasDataEntityMethods =
      "AxSecurityDataEntityMethodPermission" %in% xml_nodes,

    HasDirectAccessPermissions =
      any(
        xml_nodes %in%
          c(
            "AxSecurityDataEntityReference",
            "AxSecurityDataEntityFieldReference"
          )
      )
  )

  class(result) <- "D365PrivilegeStructure"

  return(result)
}
