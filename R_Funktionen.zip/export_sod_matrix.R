#' Write the matrix of segregation of duties as deliverable D07
#'
#' Writes the result of \code{\link{build_sod_matrix}} as the Excel workbook of
#' the deliverable D07 (Funktionstrennungs-Matrix), in German and in the
#' layout of the other deliverables: a sheet \code{Anleitung}, data sheets
#' with a fixed header row, a sheet \code{Listen}; blue columns and sheets
#' are filled by the tool.
#'
#' @details
#'
#' **Sheets.** \code{Regeln} (the rules that apply, with the columns for the
#' decision of workshop 3), \code{Regeln_nicht_relevant} (with the reason),
#' \code{Funktionen}, \code{Funktionen_Aufgaben}, \code{Aufgaben_Rollen},
#' \code{Matrix}, \code{Konflikte_Rollen}, \code{Konflikte_Benutzer} (only
#' with assignments; it holds user ids), \code{D365_Regeln} (the pairs of
#' duties to enter in D365), \code{Ausnahmen} and \code{Listen}.
#'
#' **An earlier D07.** With \code{previous}, the decisions of the rules
#' (\code{Entscheidung (Workshop 3)}, \code{Entschieden von (Owner)},
#' \code{Abgestimmt mit Revision}, \code{Status}, \code{Bemerkung}) and the
#' rows of \code{Ausnahmen} carry over by \code{Regel-ID}. The function warns
#' about decisions of rules that no longer apply.
#'
#' @param matrix
#' Result of \code{\link{build_sod_matrix}}.
#'
#' @param path
#' Path of the workbook to write.
#'
#' @param previous
#' Optional path of an earlier D07 whose decisions and exceptions carry over.
#'
#' @param overwrite
#' \code{TRUE} = replace an existing file at \code{path}. Default \code{FALSE}:
#' an existing D07 holds decisions; pass it as \code{previous} and write a new
#' file.
#'
#' @param data_source
#' Optional text for the sheet \code{Anleitung}: where the license graph and
#' the assignments come from, for example \code{"Lizenzgraph ADN, 29.10.2026"}.
#'
#' @return
#' Invisibly \code{path}.
#'
#' @examples
#' \dontrun{
#'
#' sod <- build_sod_matrix(read_sod_catalog("SoD_Katalog.xlsx"), graph, role_pattern = "WIBU")
#' export_sod_matrix(sod, "Output/D07_Funktionstrennungs_Matrix.xlsx",
#'                   previous = "Output/D07_Funktionstrennungs_Matrix_alt.xlsx")
#'
#' }
#'
#' @seealso
#' \code{\link{build_sod_matrix}}
#' \code{\link{read_sod_catalog}}
#'
#' @export
export_sod_matrix <- function(matrix, path, previous = NULL, overwrite = FALSE, data_source = NULL) {

  .check_sod_export(matrix, path, previous, overwrite)
  earlier <- if (is.null(previous)) NULL else .read_previous_d07(previous, matrix$Rules)
  rules   <- .d07_rules(matrix, earlier)

  wb <- openxlsx::createWorkbook()
  .add_d07_instructions(wb, matrix$Check, data_source)
  .add_d07_sheet(wb, "Regeln", rules, it = c("Rollen im Konflikt", "Benutzer im Konflikt"))
  other <- .d07_other_rules(matrix, earlier)
  .add_d07_sheet(wb, "Regeln_nicht_relevant", other, it = setdiff(names(other), .D07_DECISIONS))
  .add_d07_sheet(wb, "Funktionen", .d07_functions(matrix$Functions), all_it = TRUE)
  .add_d07_sheet(wb, "Funktionen_Aufgaben", .d07_duties(matrix$Duties), all_it = TRUE)
  .add_d07_sheet(wb, "Aufgaben_Rollen", stats::setNames(
    as.data.frame(matrix$DutyRoles[, c("FUNCTION_ID", "DUTY", "ROLEIDENTIFIER", "ROLENAME")]),
    c("Funktions-ID", "Aufgabe (Systemname)", "Rolle (Systemname)", "Rolle (Bezeichnung)")), all_it = TRUE)
  .add_d07_sheet(wb, "Matrix", .d07_matrix(matrix$Matrix), all_it = TRUE, width = 9)
  .add_d07_sheet(wb, "Konflikte_Rollen", .d07_role_conflicts(matrix), all_it = TRUE)
  if (!is.na(matrix$Check$USERS)) {
    .add_d07_sheet(wb, "Konflikte_Benutzer", .d07_user_conflicts(matrix), all_it = TRUE)
  }
  .add_d07_sheet(wb, "D365_Regeln", .d07_d365_rules(matrix$D365Rules), all_it = TRUE)
  .add_d07_sheet(wb, "Ausnahmen", if (is.null(earlier)) .D07_EXCEPTIONS else earlier$exceptions)
  .add_d07_sheet(wb, "Listen", .d07_lists())
  .add_d07_validation(wb, rules)

  openxlsx::saveWorkbook(wb, path, overwrite = TRUE)
  message(sprintf("D07 written: %s (%d rules apply, %d roles and %s users in conflict).", path,
                  matrix$Check$RULES_RELEVANT, matrix$Check$ROLES_IN_CONFLICT,
                  if (is.na(matrix$Check$USERS)) "no" else matrix$Check$USERS_IN_CONFLICT))
  invisible(path)
}

.D07_DECISIONS <- c("Entscheidung (Workshop 3)", "Entschieden von (Owner)", "Abgestimmt mit Revision", "Status", "Bemerkung")

.D07_EXCEPTIONS <- data.frame(
  "Regel-ID" = character(), "Benutzer-ID" = character(), "Rollen" = character(), "Grund" = character(),
  "Ausgleichende Kontrolle" = character(), "Freigeber" = character(), "Ticket" = character(),
  "Gültig ab" = character(), "Gültig bis" = character(), check.names = FALSE
)

.D07_REASONS <- c(
  NO_DUTY_IN_CATALOG  = "Nicht prüfbar: Eine der Funktionen hat im Katalog keine Aufgabe. Aufgabe im Katalog nachtragen.",
  FUNCTION_1_INACTIVE = "Funktion 1 kommt in keiner geprüften Rolle vor.",
  FUNCTION_2_INACTIVE = "Funktion 2 kommt in keiner geprüften Rolle vor.",
  BOTH_INACTIVE       = "Beide Funktionen kommen in keiner geprüften Rolle vor."
)

.check_sod_export <- function(matrix, path, previous, overwrite) {
  parts <- c("Functions", "Duties", "DutyRoles", "Rules", "RoleConflicts", "UserConflicts", "D365Rules", "Matrix", "Check")
  if (!is.list(matrix) || !all(parts %in% names(matrix))) {
    stop("matrix must be the result of build_sod_matrix().", call. = FALSE)
  }
  if (!.is_single_string(path) || !dir.exists(dirname(path))) {
    stop("path must be a file in an existing folder: '", paste(path, collapse = ", "), "'.", call. = FALSE)
  }
  if (file.exists(path) && !isTRUE(overwrite)) {
    stop("'", path, "' exists. An existing D07 holds decisions: pass it as previous and write to another file, ",
         "or set overwrite = TRUE.", call. = FALSE)
  }
  if (!is.null(previous) && (!.is_single_string(previous) || !file.exists(previous))) {
    stop("previous '", paste(previous, collapse = ", "), "' was not found.", call. = FALSE)
  }
  invisible(TRUE)
}

# The decisions and exceptions of an earlier D07, by rule id.
.read_previous_d07 <- function(previous, rules) {
  sheets <- readxl::excel_sheets(previous)
  read   <- function(sheet) {
    if (!sheet %in% sheets) return(NULL)
    as.data.frame(readxl::read_excel(previous, sheet = sheet, col_types = "text"), check.names = FALSE)
  }
  decisions <- dplyr::bind_rows(read("Regeln"), read("Regeln_nicht_relevant"))
  if (!"Regel-ID" %in% names(decisions)) decisions <- data.frame("Regel-ID" = character(), check.names = FALSE)
  decisions <- decisions[!is.na(decisions$`Regel-ID`), intersect(c("Regel-ID", .D07_DECISIONS), names(decisions)), drop = FALSE]
  decided   <- rowSums(!is.na(decisions[, setdiff(names(decisions), c("Regel-ID", "Status")), drop = FALSE])) > 0L
  if ("Status" %in% names(decisions)) decided <- decided | (!is.na(decisions$Status) & decisions$Status != "Vorschlag")
  moved     <- intersect(decisions$`Regel-ID`[decided], rules$RULE_ID[!rules$RELEVANT])
  if (length(moved) > 0L) {
    warning("Decisions of rules that no longer apply moved to the sheet Regeln_nicht_relevant: ",
            paste(moved, collapse = .LIST_SEPARATOR), ".", call. = FALSE)
  }
  gone <- setdiff(decisions$`Regel-ID`[decided], rules$RULE_ID)
  if (length(gone) > 0L) {
    warning("Decisions of rules that are no longer in the catalog: ", paste(gone, collapse = .LIST_SEPARATOR),
            ". They are left out; the earlier D07 still holds them.", call. = FALSE)
  }
  exceptions <- read("Ausnahmen")
  exceptions <- if (is.null(exceptions)) .D07_EXCEPTIONS else
    dplyr::bind_rows(.D07_EXCEPTIONS, exceptions[, intersect(names(.D07_EXCEPTIONS), names(exceptions)), drop = FALSE])
  for (column in c("Gültig ab", "Gültig bis")) exceptions[[column]] <- .excel_date_text(exceptions[[column]])
  list(decisions = decisions, exceptions = exceptions)
}

# A date typed into Excel comes back as its serial number when read as text: 46331 is 05.11.2026.
.excel_date_text <- function(values) {
  serial <- !is.na(values) & grepl("^[0-9]+(\\.[0-9]+)?$", values)
  values[serial] <- format(as.Date(floor(as.numeric(values[serial])), origin = "1899-12-30"), "%d.%m.%Y")
  values
}

# The decision columns, filled from an earlier D07 by rule id.
.d07_with_decisions <- function(sheet, earlier, status) {
  for (column in .D07_DECISIONS) sheet[[column]] <- if (column == "Status") rep(status, nrow(sheet)) else rep(NA_character_, nrow(sheet))
  if (!is.null(earlier)) {
    at <- match(sheet$`Regel-ID`, earlier$decisions$`Regel-ID`)
    for (column in intersect(.D07_DECISIONS, names(earlier$decisions))) {
      carried <- earlier$decisions[[column]][at]
      sheet[[column]] <- ifelse(is.na(at) | is.na(carried), sheet[[column]], carried)
    }
  }
  sheet
}

.yes_no <- function(x) ifelse(x, "Ja", "Nein")

.d07_function_name <- function(matrix, ids) {
  ifelse(ids == .SOD_ALL, "alle Funktionen anderer Bereiche",
         matrix$Functions$FUNCTION[match(ids, matrix$Functions$FUNCTION_ID)])
}

.d07_rules <- function(matrix, earlier) {
  rules <- matrix$Rules[matrix$Rules$RELEVANT, ]
  sheet <- data.frame(
    "Regel-ID" = rules$RULE_ID, "Funktion 1 (ID)" = rules$FUNCTION_1, "Funktion 1" = .d07_function_name(matrix, rules$FUNCTION_1),
    "Funktion 2 (ID)" = rules$FUNCTION_2, "Funktion 2" = .d07_function_name(matrix, rules$FUNCTION_2),
    "Risiko" = rules$RISK, "Schwere" = rules$SEVERITY,
    "Rollen im Konflikt" = rules$ROLES_IN_CONFLICT, "Benutzer im Konflikt" = rules$USERS_IN_CONFLICT,
    "Behandlung (Vorschlag)" = rules$TREATMENT, "Ausgleichende Kontrolle (Vorschlag)" = rules$CONTROL,
    "Quelle" = rules$SOURCE, check.names = FALSE, stringsAsFactors = FALSE
  )
  .d07_with_decisions(sheet, earlier, status = "Vorschlag")
}

# The rules that do not apply, with the decisions they had while they applied.
.d07_other_rules <- function(matrix, earlier) {
  rules <- matrix$Rules[!matrix$Rules$RELEVANT, ]
  sheet <- data.frame(
    "Regel-ID" = rules$RULE_ID, "Funktion 1 (ID)" = rules$FUNCTION_1, "Funktion 1" = .d07_function_name(matrix, rules$FUNCTION_1),
    "Funktion 2 (ID)" = rules$FUNCTION_2, "Funktion 2" = .d07_function_name(matrix, rules$FUNCTION_2),
    "Schwere" = rules$SEVERITY, "Grund" = unname(.D07_REASONS[rules$REASON]),
    check.names = FALSE, stringsAsFactors = FALSE
  )
  .d07_with_decisions(sheet, earlier, status = NA_character_)
}

.d07_functions <- function(functions) {
  data.frame(
    "Funktions-ID" = functions$FUNCTION_ID, "Bereich" = functions$AREA, "Funktion" = functions$FUNCTION, "Art" = functions$KIND,
    "Aktiv" = .yes_no(functions$ACTIVE), "Aufgaben im Katalog" = functions$DUTIES,
    "Aufgaben in D365 gefunden" = functions$DUTIES_FOUND, "Aufgaben in geprüften Rollen" = functions$DUTIES_ACTIVE,
    "Rollen" = functions$ROLES, "Benutzer" = functions$USERS, check.names = FALSE, stringsAsFactors = FALSE
  )
}

.d07_duties <- function(duties) {
  data.frame(
    "Funktions-ID" = duties$FUNCTION_ID, "Bereich" = duties$AREA, "Funktion" = duties$FUNCTION,
    "Aufgabe (Systemname)" = duties$DUTY, "Aufgabe (Bezeichnung)" = duties$DUTY_NAME,
    "In D365 gefunden" = .yes_no(duties$FOUND), "Rollen" = duties$ROLES, check.names = FALSE, stringsAsFactors = FALSE
  )
}

.d07_matrix <- function(cells) {
  sheet <- as.data.frame(cells[, setdiff(names(cells), c("FUNCTION_ID", "FUNCTION"))], check.names = FALSE)
  cbind(data.frame("Funktion" = paste(cells$FUNCTION_ID, cells$FUNCTION), check.names = FALSE), sheet)
}

.d07_severity_of <- function(matrix, rule_ids) matrix$Rules$SEVERITY[match(rule_ids, matrix$Rules$RULE_ID)]

.d07_role_conflicts <- function(matrix) {
  conflicts <- matrix$RoleConflicts
  data.frame(
    "Regel-ID" = conflicts$RULE_ID, "Schwere" = .d07_severity_of(matrix, conflicts$RULE_ID),
    "Rolle (Systemname)" = conflicts$ROLEIDENTIFIER, "Rolle (Bezeichnung)" = conflicts$ROLENAME,
    "Aufgaben der Funktion 1" = conflicts$DUTIES_1, "Aufgaben der Funktion 2" = conflicts$DUTIES_2,
    check.names = FALSE, stringsAsFactors = FALSE
  )
}

.d07_user_conflicts <- function(matrix) {
  conflicts <- matrix$UserConflicts
  data.frame(
    "Regel-ID" = conflicts$RULE_ID, "Schwere" = .d07_severity_of(matrix, conflicts$RULE_ID), "Benutzer-ID" = conflicts$USERID,
    "Rollen mit Funktion 1" = conflicts$ROLES_1, "Rollen mit Funktion 2" = conflicts$ROLES_2,
    "In einer Rolle" = .yes_no(conflicts$SAME_ROLE), check.names = FALSE, stringsAsFactors = FALSE
  )
}

.d07_d365_rules <- function(rules) {
  data.frame(
    "Regel-ID" = rules$RULE_ID, "Erste Aufgabe" = rules$FIRST_DUTY, "Zweite Aufgabe" = rules$SECOND_DUTY,
    "Funktion 1 (ID)" = rules$FUNCTION_1, "Funktion 2 (ID)" = rules$FUNCTION_2, "Schwere (D365)" = rules$SEVERITY,
    "Risiko" = rules$RISK, "Gegenmaßnahme" = rules$MITIGATION, check.names = FALSE, stringsAsFactors = FALSE
  )
}

.d07_lists <- function() {
  lists <- list("Schwere" = .SOD_SEVERITIES, "Behandlung" = c("trennen", "mit Kontrolle erlauben", "Ausnahme mit Freigabe"),
                "Status" = c("Vorschlag", "aktiv", "aufgehoben"), "Ja/Nein" = c("Ja", "Nein"))
  as.data.frame(lapply(lists, function(x) c(x, rep("", max(lengths(lists)) - length(x)))), check.names = FALSE)
}

.D07_STYLES <- list(
  header  = list(fgFill = "#D9D9D9", textDecoration = "bold", wrapText = TRUE, valign = "top", border = "Bottom"),
  it_head = list(fgFill = "#BDD7EE", textDecoration = "bold", wrapText = TRUE, valign = "top", border = "Bottom"),
  it_body = list(fgFill = "#EEF4FA", wrapText = TRUE, valign = "top"),
  body    = list(wrapText = TRUE, valign = "top")
)

.d07_style <- function(name) do.call(openxlsx::createStyle, .D07_STYLES[[name]])

.add_d07_sheet <- function(wb, name, data, it = character(), all_it = FALSE, width = NULL) {
  openxlsx::addWorksheet(wb, name)
  openxlsx::writeData(wb, name, data, headerStyle = .d07_style(if (all_it) "it_head" else "header"))
  rows <- seq_len(max(nrow(data), 1L)) + 1L
  openxlsx::addStyle(wb, name, .d07_style(if (all_it) "it_body" else "body"), rows = rows, cols = seq_along(data), gridExpand = TRUE)
  it_cols <- which(names(data) %in% it)
  if (length(it_cols) > 0L && !all_it) {
    openxlsx::addStyle(wb, name, .d07_style("it_head"), rows = 1, cols = it_cols, gridExpand = TRUE)
    openxlsx::addStyle(wb, name, .d07_style("it_body"), rows = rows, cols = it_cols, gridExpand = TRUE)
  }
  widths <- if (is.null(width)) pmin(pmax(nchar(names(data)) + 2L, 12L), 45L) else c(45, rep(width, length(data) - 1L))
  openxlsx::setColWidths(wb, name, cols = seq_along(data), widths = widths)
  openxlsx::freezePane(wb, name, firstRow = TRUE)
  invisible(wb)
}

.add_d07_validation <- function(wb, rules) {
  lists <- .d07_lists()
  rows  <- seq_len(max(nrow(rules), 1L)) + 1L
  for (pair in list(c("Entscheidung (Workshop 3)", "Behandlung"), c("Abgestimmt mit Revision", "Ja/Nein"), c("Status", "Status"))) {
    list_col <- which(names(lists) == pair[[2]])
    letter   <- openxlsx::int2col(list_col)
    value    <- sprintf("'Listen'!$%s$2:$%s$%d", letter, letter, 1L + sum(nzchar(lists[[list_col]])))
    openxlsx::dataValidation(wb, "Regeln", cols = which(names(rules) == pair[[1]]), rows = rows, type = "list", value = value)
  }
  invisible(wb)
}

.add_d07_instructions <- function(wb, check, data_source) {
  users <- if (is.na(check$USERS)) "ohne Benutzerzuweisungen" else
    sprintf("%d Benutzer geprüft, %d davon mit mindestens einem Konflikt", check$USERS, check$USERS_IN_CONFLICT)
  text <- c(
    "D07 Funktionstrennungs-Matrix (SoD Rulebook)",
    paste0("Erzeugt am ", format(Sys.Date(), "%d.%m.%Y"), " aus dem Katalog der Funktionstrennung",
           if (.is_single_string(data_source)) paste0(" · Grundlage: ", data_source) else ""),
    "",
    "Was diese Datei zeigt",
    "Der Katalog nennt die Funktionen, die geprüft werden, ihre Aufgaben in D365 und die Regeln, welche zwei Funktionen nicht in einer Hand liegen sollen. Das Werkzeug hat ihn mit den Rollen der Umgebung abgeglichen: Eine Funktion ist aktiv, wenn eine geprüfte Rolle eine ihrer Aufgaben hat; eine Regel gilt, wenn beide Funktionen aktiv sind.",
    "",
    "Kennzahlen",
    sprintf("%d von %d Funktionen aktiv; %d von %d Aufgaben des Katalogs in D365 gefunden, %d davon in geprüften Rollen.",
            check$FUNCTIONS_ACTIVE, check$FUNCTIONS, check$DUTIES_FOUND, check$DUTIES, check$DUTIES_ACTIVE),
    sprintf("%d von %d Regeln gelten; %d von %d geprüften Rollen haben mindestens einen Konflikt; %s.",
            check$RULES_RELEVANT, check$RULES, check$ROLES_IN_CONFLICT, check$ROLES, users),
    sprintf("%d Regeln sind nicht prüfbar, weil eine ihrer Funktionen im Katalog keine Aufgabe hat (Blatt „Regeln_nicht_relevant“). Kein Konflikt heißt bei ihnen nicht kein Risiko.",
            check$RULES_NOT_CHECKABLE),
    if (is.na(check$ROLE_PATTERN)) "Geprüft wurden alle Rollen." else paste0("Geprüft wurden die Rollen, deren Name „", check$ROLE_PATTERN, "“ enthält."),
    "",
    "Was zu tun ist",
    "1. In Workshop 3 je Regel im Blatt „Regeln“ die Behandlung entscheiden: trennen, mit Kontrolle erlauben oder Ausnahme mit Freigabe; mit der Revision abstimmen.",
    "2. Konflikte in Rollen (Blatt „Konflikte_Rollen“) durch Trennen der Rolle lösen; Konflikte von Benutzern über mehrere Rollen (Blatt „Konflikte_Benutzer“) durch eine andere Zuweisung oder eine Ausnahme.",
    "3. Die Aufgabenpaare der geltenden Regeln (Blatt „D365_Regeln“) in D365 eintragen: System administration > Security > Segregation of duties > Segregation of duties rules; danach die bestehenden Rollen und Zuweisungen dort prüfen lassen.",
    "",
    "Grenzen",
    "Geprüft wird auf Ebene der Aufgaben, wie in D365. Ein Recht, das eine Rolle direkt oder über eine andere Aufgabe hat, sieht die Prüfung nicht.",
    "Schwere, Behandlung und Kontrolle sind Vorschläge des Katalogs. Die Quelle Q08 ist der allgemeine Prüfgrundsatz, keine veröffentlichte Quelle; Workshop 3 und die Revision bestätigen oder ändern die Einstufung.",
    "",
    "Hinweis für die Weiterverarbeitung",
    "Bitte Blätter nicht umbenennen und Kopfzeilen nicht ändern: Beim nächsten Lauf übernimmt das Werkzeug die Entscheidungen und Ausnahmen je Regel-ID. Blau markierte Spalten und Blätter füllt das Werkzeug. „Konflikte_Benutzer“ und „Ausnahmen“ enthalten Benutzer-IDs: nicht weitergeben."
  )
  openxlsx::addWorksheet(wb, "Anleitung")
  openxlsx::writeData(wb, "Anleitung", text, colNames = FALSE)
  openxlsx::setColWidths(wb, "Anleitung", cols = 1, widths = 120)
  openxlsx::addStyle(wb, "Anleitung", .d07_style("body"), rows = seq_along(text), cols = 1)
  openxlsx::addStyle(wb, "Anleitung", openxlsx::createStyle(textDecoration = "bold", fontSize = 14), rows = 1, cols = 1)
  headings <- which(text %in% c("Was diese Datei zeigt", "Kennzahlen", "Was zu tun ist", "Grenzen", "Hinweis für die Weiterverarbeitung"))
  openxlsx::addStyle(wb, "Anleitung", openxlsx::createStyle(textDecoration = "bold"), rows = headings, cols = 1)
  invisible(wb)
}
