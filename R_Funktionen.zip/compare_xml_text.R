#' D365FO XML-Dateien auf Textebene vergleichen
#'
#' Vergleicht zwei XML-Dateien zeilenweise als
#' Textdokumente und zeigt alle Unterschiede
#' zwischen beiden Dateien an.
#'
#' Die Funktion analysiert die tatsächliche
#' Textdarstellung der XML-Dateien.
#'
#' Dadurch werden auch Unterschiede erkannt,
#' die fachlich möglicherweise keine Auswirkung
#' haben, beispielsweise:
#'
#' - Tag-Reihenfolgen
#' - Einrückungen
#' - Leerzeilen
#' - Formatierungsunterschiede
#' - XML-Kommentare
#'
#' Die Funktion eignet sich insbesondere für:
#' - Roundtrip-Debugging
#' - XML-Generator-Tests
#' - Entwicklungszwecke
#' - Analyse von Formatierungsunterschieden
#'
#' @param original_xml Vollständiger Pfad zur
#'        Original-XML-Datei.
#'
#' @param generated_xml Vollständiger Pfad zur
#'        generierten XML-Datei.
#'
#' @return Ausgabe von `waldo::compare()`.
#'
#' @details
#' Beide XML-Dateien werden mittels
#' `readLines()` eingelesen und anschließend
#' zeilenweise verglichen.
#'
#' Die XML-Struktur wird dabei nicht interpretiert.
#'
#' Daher können auch Unterschiede gemeldet werden,
#' obwohl die fachliche XML-Struktur identisch ist.
#'
#' Die drei XML-Vergleiche des Pakets arbeiten auf
#' verschiedenen Ebenen:
#'
#' - `compare_xml_text()` vergleicht den Text und meldet
#'   auch reine Formatierung.
#' - `compare_xml_structure_notepad()` vergleicht den Inhalt
#'   ohne Formatierung: Werte, Reihenfolge, Knoten, Attribute.
#' - `compare_xml_structure()` prüft nur, welche Knotenarten
#'   vorkommen, und gibt das Ergebnis als Liste zurück.
#'
#' @seealso
#' compare_xml_structure_notepad()
#' compare_xml_structure()
#'
#' @examples
#' \dontrun{
#'
#' compare_xml_text(
#'   original_xml = "Original.xml",
#'   generated_xml = "Roundtrip.xml"
#' )
#'
#' }
#'
#' @export
compare_xml_text <- function(
    original_xml,
    generated_xml
)
{

  # XML-Dateien einlesen
  original_lines <-
    readLines(
      original_xml,
      warn = FALSE
    )

  generated_lines <-
    readLines(
      generated_xml,
      warn = FALSE
    )

  # Unterschiede anzeigen
  waldo::compare(
    original_lines,
    generated_lines
  )
}
