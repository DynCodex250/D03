# Meldung von libxml2 zu einem Namensraum, der keine vollständige Adresse ist.
# Beispiel: "xmlns: URI Microsoft.Dynamics.AX.Metadata.V6 is not absolute [100]"
RELATIVE_NAMESPACE_WARNING <- "xmlns: URI .* is not absolute"

#' D365FO Formular-XML einlesen
#'
#' Liest die XML-Datei eines D365FO Formulars ein, zum Beispiel
#' `CustTable.xml` aus dem AOT, und gibt das XML-Dokument zurück.
#'
#' Die Funktion arbeitet wie `xml2::read_xml()`, unterdrückt aber die
#' Warnung
#'
#' \preformatted{
#' xmlns: URI Microsoft.Dynamics.AX.Metadata.V6 is not absolute
#' }
#'
#' die `xml2` bei jeder Formular-XML aus dem AOT ausgibt.
#'
#' @section Warum die Warnung entsteht:
#'
#' Die Formulardateien nennen als Namensraum
#' `Microsoft.Dynamics.AX.Metadata.V6`. Das ist ein Name und keine
#' vollständige Adresse, wie der XML-Standard sie für Namensräume erwartet.
#' Die Meldung betrifft nur diese Schreibweise. Der Inhalt der Datei wird
#' vollständig und richtig eingelesen.
#'
#' Alle anderen Warnungen und alle Fehler bleiben sichtbar, zum Beispiel bei
#' einer beschädigten Datei.
#'
#' @param xml_file Pfad zur XML-Datei des Formulars.
#'
#' @return XML-Dokument der Klasse `xml_document`, wie von
#'   `xml2::read_xml()`.
#'
#' @seealso [analyze_form()], [generate_form_documentation()]
#'
#' @examples
#' \dontrun{
#'
#' xml_doc <- read_form_xml("CustTable.xml")
#'
#' form_model <- analyze_form(xml_doc)
#'
#' documentation <- generate_form_documentation(form_model)
#'
#' }
#'
#' @export
read_form_xml <- function(xml_file) {

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if (!is.character(xml_file) || length(xml_file) != 1) {
    stop("xml_file muss ein einzelner Dateipfad sein.")
  }

  # file.exists() ist auch für einen Ordner wahr.

  if (!file.exists(xml_file) || dir.exists(xml_file)) {
    stop("xml_file wurde nicht gefunden: ", xml_file)
  }

  # ================================
  # XML EINLESEN
  # ================================
  #
  # Nur die Warnung zum Namensraum wird unterdrückt. Jede andere
  # Warnung läuft weiter zum Aufrufer.

  withCallingHandlers(
    xml2::read_xml(xml_file),
    warning = function(w) {
      if (grepl(RELATIVE_NAMESPACE_WARNING, conditionMessage(w))) {
        invokeRestart("muffleWarning")
      }
    }
  )
}
