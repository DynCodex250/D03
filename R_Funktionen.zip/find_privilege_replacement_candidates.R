#' Ersatzkandidaten für lizenzkritische Privileges ermitteln
#'
#' Sucht für jedes Privilege, das von einer Lizenz nicht abgedeckt ist, nach
#' anderen Privileges, die denselben Entry Point freigeben und als Ersatz in
#' Frage kommen.
#'
#' Die Funktion ist der erste Schritt einer Lizenzoptimierung. Sie zeigt, wo
#' ein vorhandenes Privilege genügt (häufig ein View-Privilege von Microsoft)
#' und wo ein eigenes Security-Objekt gebaut werden muss.
#'
#' @section Vorgehen:
#'
#' 1. **Lizenzkritische Privileges bestimmen.** Das sind alle Zeilen mit
#'    `NOTENTITLED > 0`: Die Lizenz deckt den Entry Point über dieses
#'    Privilege nicht ab.
#' 2. **Mögliche Alternativen bestimmen.** Das sind alle Privileges mit
#'    `ACCESSLEVEL == 1` für einen Entry Point.
#' 3. **Über den Entry Point (`AOTNAME`) abgleichen.** Ein kritisches
#'    Privilege bekommt jede Alternative, die denselben Entry Point freigibt.
#' 4. **Das Privilege selbst zählt nicht als Alternative.** Ist ein kritisches
#'    Privilege für seinen Entry Point das einzige mit `ACCESSLEVEL == 1`,
#'    gibt es keinen Ersatz.
#' 5. **Empfehlung ableiten.** Mit Alternative `REPLACE`, ohne `CUSTOMIZE`.
#'
#' Jede Kombination steht nur einmal im Ergebnis, auch wenn sie in den
#' Eingabedaten mehrfach vorkommt.
#'
#' @section Nur eine Lizenz je Aufruf:
#'
#' `NOTENTITLED` bezieht sich immer auf die Lizenz der jeweiligen Zeile.
#' `licenses` muss deshalb die Zeilen genau einer Lizenz enthalten, sonst gilt
#' fast jedes Privilege als kritisch. Bei `get_license_requirements()` dazu
#' `sku_name` angeben. Enthält `licenses` eine Spalte `SKUNAME` mit mehr als
#' einer Lizenz, gibt die Funktion eine Warnung aus.
#'
#' @param licenses Data Frame oder Tibble mit Lizenzzeilen, wie
#'   [get_license_requirements()] sie liefert.
#'
#'   Erforderliche Spalten:
#'
#'   * `IDENTIFIER` Technischer Name des Privileges.
#'   * `AOTNAME` Name des Entry Points, den das Privilege freigibt.
#'   * `NOTENTITLED` Größer als 0, wenn die Lizenz den Entry Point über dieses
#'     Privilege nicht abdeckt.
#'   * `ACCESSLEVEL` Zugriffsstufe des Privileges auf den Entry Point.
#'
#'   Zeilen, in denen `NOTENTITLED` oder `ACCESSLEVEL` fehlt, zählen weder
#'   als kritisch noch als Alternative. Eine Spalte `SKUNAME` wird, wenn
#'   vorhanden, nur für die Warnung zu mehreren Lizenzen gelesen. Weitere
#'   Spalten werden nicht ausgewertet.
#'
#' @return Tibble mit einer Zeile je kritischem Privilege, Entry Point und
#'   Alternative. Ein kritisches Privilege ohne Alternative steht mit einer
#'   Zeile im Ergebnis.
#'
#' \describe{
#'   \item{ProblemPrivilege}{Lizenzkritisches Privilege.}
#'   \item{AOTNAME}{Entry Point, für den es kritisch ist.}
#'   \item{AlternativePrivilege}{Möglicher Ersatz, sonst `NA`.}
#'   \item{HasAlternative}{`TRUE`, wenn es einen Ersatz gibt.}
#'   \item{Action}{`REPLACE`: Das Privilege lässt sich durch die Alternative
#'     ersetzen. `CUSTOMIZE`: Es gibt keinen Ersatz, ein eigenes
#'     Security-Objekt ist nötig.}
#' }
#'
#' `HasAlternative` und `Action` sagen dasselbe in zwei Formen: `TRUE`
#' entspricht `REPLACE`, `FALSE` entspricht `CUSTOMIZE`.
#'
#' Das Ergebnis ist sortiert nach `Action`, `ProblemPrivilege`, `AOTNAME` und
#' `AlternativePrivilege`. Die Zeilen mit `CUSTOMIZE` stehen damit oben.
#'
#' @details
#' Die Funktion fasst die früheren Funktionen
#' `find_privilege_replacement_candidates()` und `find_license_alternatives()`
#' zusammen. Die eine führte ein Privilege als seinen eigenen Ersatz auf, bei
#' der anderen fehlte es in diesem Fall ganz. Jetzt steht es mit `CUSTOMIZE`
#' im Ergebnis.
#'
#' Ob eine vorgeschlagene Alternative fachlich passt, entscheidet die Funktion
#' nicht. Sie prüft nur, ob ein anderes Privilege denselben Entry Point mit
#' `ACCESSLEVEL == 1` freigibt.
#'
#' @examples
#' # Lizenzzeilen einer Lizenz. CustTableMaintain und VendTableMaintain sind
#' # nicht abgedeckt; für CustTable gibt es ein zweites Privilege.
#' licenses <- data.frame(
#'   IDENTIFIER  = c("CustTableMaintain", "CustTableView", "VendTableMaintain"),
#'   AOTNAME     = c("CustTable", "CustTable", "VendTable"),
#'   NOTENTITLED = c(1, 0, 1),
#'   ACCESSLEVEL = c(2, 1, 2)
#' )
#'
#' find_privilege_replacement_candidates(licenses)
#'
#' \dontrun{
#'
#' # Mit echten Daten: die Lizenz ausdrücklich angeben
#' licenses <- get_license_requirements(con, sku_name = "Operations - Activity")
#'
#' candidates <- find_privilege_replacement_candidates(licenses)
#'
#' # Privileges, für die ein eigenes Security-Objekt nötig ist
#' dplyr::filter(candidates, Action == "CUSTOMIZE")
#'
#' }
#'
#' @seealso [get_license_requirements()]
#'
#' @export
find_privilege_replacement_candidates <- function(
    licenses){

  # ==========================
  # VALIDIERUNG
  # ==========================
  #
  # Früh und mit den Spaltennamen abbrechen. Ohne diese Prüfung meldet erst
  # dplyr einen Fehler, aus dem nicht hervorgeht, was an der Eingabe fehlt.

  required_columns <-
    c(
      "IDENTIFIER",
      "AOTNAME",
      "NOTENTITLED",
      "ACCESSLEVEL"
    )

  missing_columns <-
    setdiff(
      required_columns,
      names(licenses)
    )

  if(length(missing_columns) > 0){
    stop(
      paste(
        "Folgende Spalten fehlen:",
        paste(
          missing_columns,
          collapse = ", "
        )
      )
    )
  }

  # NOTENTITLED gilt für die Lizenz der jeweiligen Zeile. Stehen mehrere
  # Lizenzen in der Tabelle, ist fast jedes Privilege für irgendeine davon
  # nicht berechtigt, und das Ergebnis sagt nichts mehr aus.

  if(
    "SKUNAME" %in% names(licenses) &&
    dplyr::n_distinct(licenses$SKUNAME, na.rm = TRUE) > 1
  ){
    warning(
      "licenses enthält Zeilen mehrerer Lizenzen (Spalte SKUNAME). ",
      "NOTENTITLED bezieht sich auf eine Lizenz: bei ",
      "get_license_requirements() sku_name angeben."
    )
  }

  # ==========================
  # LIZENZKRITISCHE PRIVILEGES
  # ==========================
  #
  # Ein Privilege ist für einen Entry Point kritisch, wenn die Lizenz ihn
  # über dieses Privilege nicht abdeckt. distinct(), weil die Lizenzsicht
  # dieselbe Kombination mehrfach liefern kann.

  problem_privileges <-
    licenses |>
    dplyr::filter(
      NOTENTITLED > 0
    ) |>
    dplyr::distinct(
      IDENTIFIER,
      AOTNAME
    ) |>
    dplyr::rename(
      ProblemPrivilege =
        IDENTIFIER
    )

  # ==========================
  # MÖGLICHE ALTERNATIVEN
  # ==========================
  #
  # Kandidat ist jedes Privilege, das einen Entry Point mit ACCESSLEVEL 1
  # freigibt. Ob es selbst von der Lizenz abgedeckt ist, wird hier nicht
  # geprüft.

  alternatives <-
    licenses |>
    dplyr::filter(
      ACCESSLEVEL == 1
    ) |>
    dplyr::distinct(
      AOTNAME,
      IDENTIFIER
    ) |>
    dplyr::rename(
      AlternativePrivilege =
        IDENTIFIER
    )

  # ==========================
  # ABGLEICH ÜBER DEN ENTRY POINT
  # ==========================
  #
  # Mehrere kritische Privileges können denselben Entry Point haben, und ein
  # Entry Point kann mehrere Alternativen haben. Die Beziehung ist deshalb
  # ausdrücklich "viele zu viele"; ohne die Angabe warnt dplyr.
  #
  # Das Privilege selbst wird schon hier aussortiert und nicht erst am Ende.
  # Bliebe es stehen, sähe ein Privilege ohne echten Ersatz so aus, als
  # hätte es einen, nämlich sich selbst.
  #
  # Ein fehlender Entry-Point-Name (NA) ist kein gemeinsamer Entry Point.
  # dplyr würde NA sonst mit NA zusammenführen.

  real_alternatives <-
    problem_privileges |>
    dplyr::inner_join(
      alternatives,
      by = "AOTNAME",
      relationship = "many-to-many",
      na_matches = "never"
    ) |>
    dplyr::filter(
      AlternativePrivilege != ProblemPrivilege
    )

  # ==========================
  # ERGEBNIS
  # ==========================
  #
  # Ausgangspunkt sind wieder alle kritischen Privileges. So stehen auch die
  # ohne Ersatz im Ergebnis: mit leerer Alternative und der Empfehlung
  # CUSTOMIZE.

  result <-
    problem_privileges |>
    dplyr::left_join(
      real_alternatives,
      by = c("ProblemPrivilege", "AOTNAME")
    ) |>
    dplyr::mutate(
      HasAlternative =
        !is.na(AlternativePrivilege),
      Action =
        dplyr::if_else(
          HasAlternative,
          "REPLACE",
          "CUSTOMIZE")
    ) |>
    dplyr::arrange(
      Action,
      ProblemPrivilege,
      AOTNAME,
      AlternativePrivilege
    )

  return(
    tibble::as_tibble(result)
  )
}
