#' Pseudonyme in einer Excel-Arbeitsmappe zurückführen
#'
#' Liest eine Excel-Arbeitsmappe mit pseudonymisierten Daten, ersetzt in
#' allen Arbeitsblättern die Pseudonyme durch die echten Werte und schreibt
#' das Ergebnis in eine neue Arbeitsmappe.
#'
#' @details
#'
#' Die Eingabedatei und die Schlüsseldatei werden nie verändert; keine von
#' beiden darf das Ziel sein. Eine vorhandene Zieldatei wird nur mit
#' \code{overwrite = TRUE} überschrieben.
#'
#' Die neue Datei enthält die echten Personendaten. \code{output_path} hat
#' deshalb keinen Standardwert: Den Ort bewusst wählen, nicht den Ordner, aus
#' dem die pseudonymisierte Datei weitergegeben wurde.
#'
#' Übernommen werden die Arbeitsblätter mit ihren Daten und Spaltennamen.
#' Formatierungen, Formeln und Kommentare der Eingabedatei gehen nicht in
#' die neue Datei über. Spalten, die nur Zeitpunkte um Mitternacht
#' enthalten, werden als Datum geschrieben.
#'
#' Pseudonyme aus einer anderen Schlüsseldatei bleiben unverändert; die
#' Funktion warnt in diesem Fall (siehe \code{\link{deanonymize_data}}).
#'
#' @param path
#' Pfad der Excel-Arbeitsmappe mit Pseudonymen, zum Beispiel das Ergebnis von
#' \code{\link{export_role_license_decision}}.
#'
#' @param key_path
#' Pfad der Schlüsseldatei, die \code{\link{anonymize_data}} geschrieben hat.
#'
#' @param output_path
#' Pfad der neuen Arbeitsmappe mit den echten Werten.
#'
#' @param overwrite
#' \code{TRUE} = eine vorhandene Zieldatei überschreiben.
#' Standard: \code{FALSE}.
#'
#' @return
#' Pfad der geschriebenen Arbeitsmappe.
#'
#' @examples
#' \dontrun{
#'
#' cnn      <- get_connection("PRJ", "db_credentials.xlsx")
#' role     <- "_WIBU_VERKAUF_INNENDIENST_MITARBEITER"
#' key_path <- "C:/D365_Schluessel/anonymization_key.xlsx"
#'
#' analysis <- analyze_role_license_decision(
#'   cnn, role,
#'   anonymize = TRUE, key_path = key_path
#' )
#' path <- export_role_license_decision(analysis, role)
#'
#' # Später, in der Umgebung mit der Schlüsseldatei:
#' deanonymize_workbook(
#'   path,
#'   key_path    = key_path,
#'   output_path = "C:/D365_Schluessel/License_Decision_Klartext.xlsx"
#' )
#'
#' }
#'
#' @seealso
#' \code{\link{anonymize_data}}
#' \code{\link{deanonymize_data}}
#' \code{\link{analyze_role_license_decision}}
#'
#' @export
deanonymize_workbook <- function(
  path,
  key_path,
  output_path,
  overwrite = FALSE
) {

  if (missing(output_path)) {
    stop("output_path angeben: der Pfad der neuen Arbeitsmappe mit den echten Werten.")
  }

  .check_workbook_path(path)
  .check_key_path(key_path)
  .check_deanonymized_output_path(path, key_path, output_path, overwrite)

  sheets <- readxl::excel_sheets(path)
  tables <- lapply(sheets, function(sheet) {
    # Alle Zeilen fuer den Spaltentyp ansehen: Sonst wird Text, der erst nach
    # den ersten 1000 Zeilen beginnt, als fehlend gelesen.
    readxl::read_excel(
      path, sheet = sheet,
      .name_repair = "minimal", guess_max = .EXCEL_MAX_ROWS
    )
  })
  names(tables) <- sheets

  restored <- deanonymize_data(tables, key_path)

  workbook <- openxlsx::createWorkbook(creator = .WORKBOOK_CREATOR)

  for (sheet in sheets) {
    .write_workbook_sheet(workbook, sheet, .midnight_as_date(restored[[sheet]]))
  }

  folder <- dirname(output_path)

  if (!dir.exists(folder)) {
    dir.create(folder, recursive = TRUE)
  }

  openxlsx::saveWorkbook(workbook, output_path, overwrite = isTRUE(overwrite))

  output_path
}

.EXCEL_MAX_ROWS <- 1048576L

.check_workbook_path <- function(path) {

  if (!.is_single_string(path)) {
    stop("path muss der Pfad genau einer Excel-Arbeitsmappe sein.")
  }

  if (!file.exists(path) || dir.exists(path)) {
    stop("Arbeitsmappe nicht gefunden: ", path)
  }

  invisible(path)
}

# Weder die Eingabedatei noch die Schluesseldatei darf das Ziel sein.
.check_deanonymized_output_path <- function(path, key_path, output_path, overwrite) {

  if (!.is_single_string(output_path)) {
    stop("output_path muss der Pfad genau einer Excel-Arbeitsmappe sein.")
  }

  if (.is_same_file(path, output_path)) {
    stop("output_path darf nicht die Eingabedatei sein: Sie bleibt unverändert.")
  }

  if (.is_same_file(key_path, output_path)) {
    stop("output_path darf nicht die Schlüsseldatei sein: Sie würde zerstört.")
  }

  if (file.exists(output_path) && !isTRUE(overwrite)) {
    stop(
      "Die Zieldatei existiert bereits: ", output_path,
      ". Anderen Pfad angeben oder overwrite = TRUE setzen."
    )
  }

  invisible(output_path)
}

# Windows unterscheidet bei Dateinamen keine Gross-/Kleinschreibung.
.is_same_file <- function(first, second) {

  normalized <- normalizePath(c(first, second), winslash = "/", mustWork = FALSE)

  if (.Platform$OS.type == "windows") {
    normalized <- tolower(normalized)
  }

  normalized[[1]] == normalized[[2]]
}

# Excel kennt nur Zeitpunkte. Spalten, die ausschliesslich Mitternacht
# enthalten, waren Datumsspalten und werden wieder als Datum geschrieben.
.midnight_as_date <- function(table) {

  for (index in seq_along(table)) {

    column <- table[[index]]

    if (!inherits(column, "POSIXct") || all(is.na(column))) {
      next
    }

    is_midnight <- format(column, "%H:%M:%S", tz = "UTC") == "00:00:00"

    if (all(is_midnight | is.na(column))) {
      table[[index]] <- as.Date(column, tz = "UTC")
    }
  }

  table
}

# write_report_sheet() ueberspringt leere Tabellen; hier bleibt jedes Blatt
# der Eingabedatei erhalten.
.write_workbook_sheet <- function(workbook, sheet, table) {

  if (nrow(table) > 0L) {
    return(write_report_sheet(workbook, sheet, table))
  }

  openxlsx::addWorksheet(workbook, sheet)

  if (ncol(table) > 0L) {
    openxlsx::writeData(workbook, sheet, table)
  }

  invisible(NULL)
}
