#' Fehlende Teile eines Formularmodells ergänzen
#'
#' Ersetzt Teile eines `D365FormModel`, die fehlen (`NULL`), durch die
#' leeren Standardstrukturen aus `empty_form_model()`. Vorhandene Teile
#' bleiben unverändert.
#'
#' Die Auswertungen eines Formulars setzen voraus, dass `Metadata`,
#' `DataSources`, `Controls` und `Parts` vorhanden sind. Ein Modell, in dem
#' ein Teil fehlt, würde sonst mit einer schwer verständlichen Meldung
#' abbrechen.
#'
#' @param form_model Objekt der Klasse `D365FormModel`.
#'
#' @return Das Formularmodell mit allen vier Teilen. Das übergebene Objekt
#'   wird nicht verändert.
#'
#' @keywords internal
complete_form_model <- function(form_model) {

  defaults <- empty_form_model()

  is_missing <- vapply(
    names(defaults),
    function(part) is.null(form_model[[part]]),
    logical(1)
  )

  missing_parts <- names(defaults)[is_missing]

  result <- form_model
  result[missing_parts] <- defaults[missing_parts]

  return(result)
}
