trace_role_dependencies <- function(
    role_file,
    duties_folder = NULL,
    privileges_folder = NULL) {

  role_doc <- xml2::read_xml(role_file)

  role_name  <- xml2::xml_text(xml2::xml_find_first(role_doc, "//Name"))
  role_label <- xml2::xml_text(xml2::xml_find_first(role_doc, "//Label"))

  duties <- xml2::xml_find_all(role_doc, "//Duties/AxSecurityDutyReference/Name") |>
    xml2::xml_text()

  duties_df <- tibble::tibble(DutyName = duties) |>
    dplyr::mutate(
      IsGUID = is_guid_name(DutyName),
      ExistsAsXML = ifelse(
        is.null(duties_folder),
        NA,
        file.exists(file.path(duties_folder, paste0(DutyName, ".xml")))
      )
    )

  all_privileges <- list()

  if (!is.null(duties_folder)) {
    for (duty_name in duties) {
      duty_file <- file.path(duties_folder, paste0(duty_name, ".xml"))

      if (file.exists(duty_file)) {
        duty_doc <- xml2::read_xml(duty_file)

        privilege_names <- xml2::xml_find_all(
          duty_doc,
          "//Privileges/AxSecurityPrivilegeReference/Name"
        ) |>
          xml2::xml_text()

        if (length(privilege_names) > 0) {
          all_privileges[[duty_name]] <- tibble::tibble(
            DutyName      = duty_name,
            PrivilegeName = privilege_names
          ) |>
            dplyr::mutate(
              IsGUID = is_guid_name(PrivilegeName),
              ExistsAsXML = ifelse(
                is.null(privileges_folder),
                NA,
                file.exists(file.path(privileges_folder, paste0(PrivilegeName, ".xml")))
              )
            )
        }
      }
    }
  }

  privileges_df <- dplyr::bind_rows(all_privileges)

  all_entrypoints <- list()

  if (!is.null(privileges_folder) && nrow(privileges_df) > 0) {
    for (privilege_name in privileges_df$PrivilegeName) {
      privilege_file <- file.path(privileges_folder, paste0(privilege_name, ".xml"))

      if (file.exists(privilege_file)) {
        privilege_doc <- xml2::read_xml(privilege_file)

        entrypoints <- xml2::xml_find_all(privilege_doc, "//EntryPoints/*/Name") |>
          xml2::xml_text()

        if (length(entrypoints) > 0) {
          all_entrypoints[[privilege_name]] <- tibble::tibble(
            PrivilegeName = privilege_name,
            EntryPoint    = entrypoints
          )
        }
      }
    }
  }

  entrypoints_df <- dplyr::bind_rows(all_entrypoints)

  list(
    role = tibble::tibble(
      RoleName  = role_name,
      RoleLabel = role_label,
      IsGUID    = is_guid_name(role_name)
    ),
    duties      = duties_df,
    privileges  = privileges_df,
    entrypoints = entrypoints_df
  )
}
