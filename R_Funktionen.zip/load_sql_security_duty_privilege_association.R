#' Lädt Duty-Privilege-Zuordnungen aus UserSecGovRelatedObjects
#'
#' Liest die Tabelle `UserSecGovRelatedObjects` aus der D365FO-Datenbank und
#' liefert die Beziehungen zwischen Duties, Privileges und den Ressourcen
#' (zum Beispiel Menu Items), die ein Privilege freigibt.
#'
#' Die Funktion wird als Grundlage für Security-Analysen verwendet, insbesondere
#' zur Rekonstruktion der Berechtigungshierarchie und zur Zuordnung von Formularen,
#' Menu Items und Entry Points zu den entsprechenden Privileges.
#'
#' Es werden ausschließlich Datensätze berücksichtigt, bei denen sowohl ein
#' Duty-Identifier als auch ein Privilege-Identifier vorhanden ist. Jede
#' Kombination aus Duty, Privilege und Ressource kommt nur einmal vor.
#'
#' Optional lässt sich das Ergebnis auf bestimmte Ressourcen und auf bestimmte
#' Privileges einschränken. Ohne Filter wird die ganze Tabelle geladen.
#'
#' Typische Einsatzgebiete:
#'
#' * Aufbau von Security-Hierarchien
#' * Analyse von Rollenabhängigkeiten
#' * Rekonstruktion von Duty-Privilege-Beziehungen
#' * Security Governance Reporting
#' * Berechtigungsdokumentationen
#'
#' @section Verwendete Verbindung:
#'
#' Abgefragt wird immer die Verbindung in der globalen Variable `cnn`.
#' Das Argument `connection` wird nicht ausgewertet: Auch wenn eine andere
#' Verbindung übergeben wird, geht die Abfrage an `cnn`. Die Funktion lässt
#' sich deshalb auch ohne Argument aufrufen. Gibt es kein `cnn`, bricht sie
#' mit einer Meldung ab.
#'
#' @param connection Wird nicht ausgewertet, siehe Abschnitt "Verwendete
#'   Verbindung". Das Argument bleibt bestehen, damit vorhandene Aufrufe der
#'   Form `load_sql_security_duty_privilege_association(cnn)` weiter laufen.
#'
#' @param resources Character-Vektor mit Ressourcennamen (Spalte `RESOURCE_`),
#'   zum Beispiel Namen von Menu Items. Leer (Standard): kein Filter.
#'
#' @param privilege_identifiers Character-Vektor mit technischen Namen von
#'   Privileges (Spalte `PRIVILEGEIDENTIFIER`). Leer (Standard): kein Filter.
#'
#' @return Tibble mit den Spalten:
#'
#' * `DUTYIDENTIFIER` Technischer Name des Duties.
#' * `DUTYNAME` Anzeigename des Duties.
#' * `PRIVILEGEIDENTIFIER` Technischer Name des zugeordneten Privileges.
#' * `PRIVILEGENAME` Anzeigename des Privileges.
#' * `RESOURCETYPE` Art der Ressource, zum Beispiel "Menu item display".
#' * `RESOURCE_` Name der Ressource.
#'
#' @details
#' Die Tabelle `UserSecGovRelatedObjects` enthält bereits aufbereitete
#' Beziehungen zwischen Security-Objekten. Im Gegensatz zum direkten Parsen von
#' XML-Dateien können dadurch Security-Zuordnungen schnell aus der Datenbank
#' geladen werden.
#'
#' Werden beide Filter angegeben, müssen beide zutreffen. Hochkommas in den
#' Filterwerten werden für SQL maskiert.
#'
#' @examples
#' \dontrun{
#'
#' # Die Funktion fragt die Verbindung in der globalen Variable cnn ab
#' cnn <- get_connection("PRJ", "db_credentials.xlsx")
#'
#' # Alle Zuordnungen
#' associations <-
#'   load_sql_security_duty_privilege_association(
#'     cnn
#'   )
#'
#' dplyr::count(
#'   associations,
#'   DUTYIDENTIFIER
#' )
#'
#' # Nur bestimmte Menu Items
#' load_sql_security_duty_privilege_association(
#'   cnn,
#'   resources = c("CustTable", "SalesTable")
#' )
#'
#' # Nur bestimmte Privileges
#' load_sql_security_duty_privilege_association(
#'   cnn,
#'   privilege_identifiers = "CustTableMaintain"
#' )
#'
#' }
#'
#' @seealso
#' get_sql_security_hierarchy
#' load_sql_security_hierarchy
#' get_privilege_mapping
#' get_duty_mapping
#'
#' @export
load_sql_security_duty_privilege_association <- function(
    connection,
    resources = character(),
    privilege_identifiers = character()
) {

  # ==========================
  # SQL
  # ==========================

  sql <- "
  SELECT DISTINCT
      USGRO.DUTYIDENTIFIER,
      USGRO.DUTYNAME,
      USGRO.PRIVILEGEIDENTIFIER,
      USGRO.PRIVILEGENAME,
      USGRO.RESOURCETYPE,
      USGRO.RESOURCE_
  FROM UserSecGovRelatedObjects USGRO
  WHERE
  (
    USGRO.DUTYIDENTIFIER != ''
    AND
    USGRO.PRIVILEGEIDENTIFIER != ''
  )
  "

  # ==========================
  # FILTER
  # ==========================

  if (length(resources) > 0) {

    resource_list <- paste0(
      "'",
      gsub("'", "''", resources),
      "'",
      collapse = ","
    )

    sql <- paste0(
      sql,
      "\nAND USGRO.RESOURCE_ IN (",
      resource_list,
      ")"
    )
  }

  if (length(privilege_identifiers) > 0) {

    privilege_list <- paste0(
      "'",
      gsub("'", "''", privilege_identifiers),
      "'",
      collapse = ","
    )

    sql <- paste0(
      sql,
      "\nAND USGRO.PRIVILEGEIDENTIFIER IN (",
      privilege_list,
      ")"
    )
  }

  # ==========================
  # AUSFÜHREN
  # ==========================
  #
  # Abgefragt wird die globale Variable cnn, nicht das Argument connection.
  # Das ist so gewollt: Die Funktion verhält sich damit wie vor dem
  # Zusammenführen mit der Fassung, die filtern kann.

  if (!exists("cnn")) {
    stop(
      "Keine Verbindung gefunden: Die globale Variable cnn fehlt. ",
      "Zuerst cnn <- get_connection(...) ausführen."
    )
  }

  result <- DBI::dbGetQuery(
    cnn,
    sql
  )

  # ==========================
  # TIBBLE
  # ==========================

  result <- tibble::as_tibble(
    result
  )

  return(result)
}
