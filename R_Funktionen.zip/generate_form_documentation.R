#' Formular-Dokumentation erzeugen
#'
#' Erstellt eine fachliche Dokumentation eines analysierten
#' D365FO-Formulars auf Basis eines `D365FormModel`.
#'
#' Die Funktion extrahiert die wichtigsten Struktur- und
#' Metadateninformationen eines Formulars und stellt diese
#' in einer standardisierten Dokumentationsstruktur bereit.
#'
#' Folgende Komponenten werden analysiert:
#'
#' - Formular-Metadaten
#' - Data Sources
#' - Grids
#' - Reference Groups
#' - Action Pane Buttons
#' - Tab-Strukturen
#' - Gruppen
#' - Static Text Controls
#' - Buttons
#' - Parts
#' - Felder
#' - Menu Items
#'
#' Das erzeugte Dokumentationsobjekt dient als Grundlage für:
#'
#' - Formularanalysen
#' - Formularvergleiche
#' - Sicherheitsanalysen
#' - Dokumentationsreports
#' - Suchfunktionen wie `search_form()`
#'
#' @param form_model Objekt der Klasse `D365FormModel`.
#'   Typischerweise das Ergebnis von `analyze_form()`.
#'
#' @return Objekt der Klasse `D365FormDocumentation`.
#'
#' \describe{
#'   \item{Metadata}{
#'     Metadaten des Formulars.
#'   }
#'
#'   \item{DataSources}{
#'     Beziehungen und Struktur der Data Sources.
#'   }
#'
#'   \item{Grids}{
#'     Alle Grid-Controls inklusive DataSource-Zuordnung.
#'   }
#'
#'   \item{ReferenceGroups}{
#'     Alle Reference Groups des Formulars.
#'   }
#'
#'   \item{ActionPaneButtons}{
#'     Alle Action Pane Buttons.
#'   }
#'
#'   \item{TabStructure}{
#'     Struktur der Tabs und TabPages.
#'   }
#'
#'   \item{Groups}{
#'     Gruppenstruktur des Formulars.
#'   }
#'
#'   \item{StaticTexts}{
#'     Enthaltene StaticText-Controls.
#'   }
#'
#'   \item{Buttons}{
#'     Enthaltene Button-Controls.
#'   }
#'
#'   \item{Parts}{
#'     Enthaltene Form Parts.
#'   }
#'
#'   \item{Fields}{
#'     Extrahierte Formularfelder.
#'   }
#'
#'   \item{MenuItems}{
#'     Verwendete Menu Items.
#'   }
#' }
#'
#' @details
#' Die Funktion dient als zentrale Aggregationsschicht für
#' formularbezogene Auswertungen.
#'
#' Sämtliche enthaltenen Komponenten werden über spezialisierte
#' Extraktionsfunktionen erzeugt und in einem gemeinsamen
#' Dokumentationsobjekt zusammengeführt.
#'
#' Das Ergebnis wird mit der Klasse
#' `D365FormDocumentation` versehen und kann anschließend
#' beispielsweise mit `search_form()` oder verschiedenen
#' Vergleichsfunktionen weiterverarbeitet werden.
#'
#' Die Funktion bricht nicht ab, wenn ein Formular einzelne
#' Bestandteile nicht hat, zum Beispiel keine Buttons, keine
#' Gruppen oder keine DataSources. Der zugehörige Abschnitt ist
#' dann eine leere Tabelle mit denselben Spalten wie im
#' gefüllten Fall. Das gilt auch für ein ganz leeres Formular
#' und für ein Modell, in dem `DataSources`, `Controls` oder
#' `Parts` fehlen.
#'
#' Fehlen dagegen in `Controls` oder `DataSources` einzelne
#' Spalten, bricht die Funktion mit einer Meldung ab, die die
#' fehlenden Spalten nennt.
#'
#' @examples
#' \dontrun{
#'
#' form_model <- analyze_form(
#'   read_form_xml("CustTable.xml")
#' )
#'
#' documentation <- generate_form_documentation(
#'   form_model
#' )
#'
#' documentation$Metadata
#' documentation$DataSources
#' documentation$Fields
#' documentation$Buttons
#'
#' }
#'
#' @export
generate_form_documentation <- function(form_model) {

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if (!inherits(form_model, "D365FormModel")) {

    stop(
      "form_model muss ein D365FormModel sein."
    )

  }

  # ================================
  # MODELL VERVOLLSTÄNDIGEN
  # ================================
  #
  # Fehlt ein Teil des Modells, wird er als leer behandelt.
  # Die Extraktionsfunktionen liefern dann leere Tabellen.

  form_model <- complete_form_model(form_model)

  # ================================
  # SPALTEN PRÜFEN
  # ================================
  #
  # Früh und mit den Spaltennamen abbrechen. Sonst meldet erst
  # eine der Extraktionsfunktionen einen Fehler, aus dem nicht
  # hervorgeht, was am Modell fehlt.

  .check_required_columns(
    form_model$Controls,
    c("Name", "Type", "Parent", "Path", "Properties"),
    "form_model$Controls"
  )

  # Level wird erst gebraucht, wenn es Controls gibt: Die
  # Feld-Auswertung sortiert danach. Ein von Hand gebautes
  # Modell ohne Controls muss die Spalte nicht haben.

  if (nrow(form_model$Controls) > 0) {

    .check_required_columns(
      form_model$Controls,
      "Level",
      "form_model$Controls"
    )

  }

  .check_required_columns(
    form_model$DataSources,
    c("Name", "Table", "JoinSource", "ParentDataSource"),
    "form_model$DataSources"
  )

  # ================================
  # DOKUMENTATION ERSTELLEN
  # ================================

  result <- list(

    Metadata =
      form_model$Metadata,

    DataSources =
      extract_form_datasource_relations(
        form_model
      ),

    Grids =
      extract_form_grid_datasources(
        form_model
      ),

    ReferenceGroups =
      extract_form_reference_group_relations(
        form_model
      ),

    ActionPaneButtons =
      extract_form_action_pane_buttons(
        form_model
      ),

    TabStructure =
      extract_form_tab_structure(
        form_model
      ),

    Groups =
      extract_form_groups(
        form_model
      ),

    StaticTexts =
      extract_form_static_texts(
        form_model
      ),

    Buttons =
      extract_form_buttons(
        form_model
      ),

    Parts =
      extract_form_parts(
        form_model
      ),

    Fields =
      extract_form_fields(
        form_model
      ),

    MenuItems =
      extract_form_menu_items(
        form_model
      )

  )

  # ================================
  # KLASSE SETZEN
  # ================================

  class(result) <- c(
    "D365FormDocumentation",
    class(result)
  )

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(result)

}
