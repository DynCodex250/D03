# The personal project plan up to the go-live: activities and milestones in one workbook
# (Data/Input/Projektplan/Projektplan.xlsx), read and drawn on every knit of
# Data/Documentation/Projektplan.Rmd. The Rmd sources this file alone; it needs openxlsx, graphics
# and grDevices, no other file of the package. The functions are internal (no export).

.PLAN_SHEETS <- c(activities = "Aktivitäten", milestones = "Meilensteine", lists = "Listen",
                  settings = "Einstellungen")
.PLAN_ACTIVITY_COLUMNS  <- c("ID", "Bahn", "Aktivität", "Start", "Ende", "Art", "Termin", "Status")
.PLAN_MILESTONE_COLUMNS <- c("ID", "Bahn", "Meilenstein", "Datum", "Art", "Termin", "Status")
.PLAN_LINE_COLUMN <- "Linie über alle Bahnen"
.PLAN_ACTIVITY    <- "Aktivität"
.PLAN_MILESTONE   <- "Meilenstein"
.PLAN_LANE_ROW    <- "Bahn"
.PLAN_VALUES <- list(
  Art    = c("eigene", "Projekt"),
  Termin = c("fest", "Annahme"),
  Status = c("geplant", "läuft", "erledigt", "verschoben", "entfällt"),
  Linie  = c("nein", "ja")
)
.PLAN_DONE    <- c("erledigt", "entfällt")
.PLAN_DROPPED <- "entfällt"
.PLAN_PREVIEW_DAYS <- 14
.PLAN_EXCEL_ORIGIN <- "1899-12-30"
.PLAN_EARLIEST     <- "2000-01-01"
.PLAN_SETTINGS     <- c("Plan von", "Plan bis", "Heute", "Vorschau (Tage)")
# Categorical order of the chart palette; a lane without a colour takes the next free one.
.PLAN_PALETTE <- c("#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948")
.PLAN_INK <- c(main = "#0b0b0b", second = "#52514e", muted = "#8c8b84", grid = "#e1e0d9",
               week = "#f0efec", band = "#f7f6f3", project = "#a9a89f", late = "#d03b3b")
.PLAN_MONTHS <- c("Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez")
.PLAN_LABEL_INCHES <- 4.1
.PLAN_ROW_INCHES   <- 0.22

#' Read the personal project plan
#'
#' Reads the workbook of the plan up to the go-live. Sheet \code{Aktivitäten}:
#' ID, Bahn, Aktivität, Start, Ende, Art, Termin, Status, optional
#' Verantwortlich, Deliverable, Bemerkung. Sheet \code{Meilensteine}: ID, Bahn,
#' Meilenstein, Datum, Art, Termin, Status, optional Linie über alle Bahnen,
#' Kriterium, Deliverable, Bemerkung. Sheet \code{Listen}: Bahn and Farbe, in
#' the order of the drawing. Sheet \code{Einstellungen} (optional): Feld and
#' Wert for Plan von, Plan bis, Heute and Vorschau (Tage).
#'
#' Dates as Excel dates, \code{TT.MM.JJJJ} or \code{JJJJ-MM-TT}; a row without
#' dates is a date still open. Empty fields mean: Art eigene, Termin fest,
#' Status geplant, Linie nein. Every wrong row is named in one error.
#'
#' @param path Path of the workbook.
#' @return A list: \code{Lanes} (LANE, COLOUR), \code{Items} (one row per
#'   activity or milestone: ID, KIND, LANE, TEXT, START, END, PROJECT, ASSUMED,
#'   STATUS, LINE, OWNER, DELIVERABLE, CRITERION, NOTE) and \code{Settings}
#'   (FROM, TO, TODAY, PREVIEW_DAYS).
#' @noRd
read_project_plan <- function(path) {
  if (!file.exists(path)) stop("Projektplan nicht gefunden: ", path, call. = FALSE)
  sheets  <- openxlsx::getSheetNames(path)
  missing <- setdiff(.PLAN_SHEETS[c("activities", "milestones", "lists")], sheets)
  if (length(missing) > 0L) {
    stop("Im Projektplan fehlt das Blatt ", paste(missing, collapse = ", "), ".", call. = FALSE)
  }
  lanes <- .plan_lanes(.plan_sheet(path, .PLAN_SHEETS[["lists"]], "Bahn"))
  raw   <- rbind(
    .plan_activities(.plan_sheet(path, .PLAN_SHEETS[["activities"]], .PLAN_ACTIVITY_COLUMNS)),
    .plan_milestones(.plan_sheet(path, .PLAN_SHEETS[["milestones"]], .PLAN_MILESTONE_COLUMNS))
  )
  items    <- .plan_check(raw, lanes$LANE)
  settings <- if (.PLAN_SHEETS[["settings"]] %in% sheets) {
    .plan_sheet(path, .PLAN_SHEETS[["settings"]], c("Feld", "Wert"))
  }
  list(Lanes = lanes, Items = items, Settings = .plan_settings(settings, items))
}

# One sheet as text: trimmed, empty cells as "", empty rows dropped.
.plan_sheet <- function(path, sheet, required) {
  # na.strings = character(): a cell with the text NA stays text; empty cells are NA anyway.
  data <- openxlsx::read.xlsx(path, sheet = sheet, sep.names = " ", detectDates = FALSE, skipEmptyRows = TRUE,
                              na.strings = character())
  if (is.null(data)) data <- .plan_header_only(path, sheet)
  names(data) <- trimws(names(data))
  missing <- setdiff(required, names(data))
  if (length(missing) > 0L) {
    stop("Im Blatt ", sheet, " fehlt die Spalte ", paste(missing, collapse = ", "), ".", call. = FALSE)
  }
  data[] <- lapply(data, function(x) {
    x <- trimws(as.character(x))
    x[is.na(x)] <- ""
    x
  })
  data[rowSums(data != "") > 0L, , drop = FALSE]
}

# A sheet with the header row only: read.xlsx gives NULL, the header row still names the columns.
.plan_header_only <- function(path, sheet) {
  header <- openxlsx::read.xlsx(path, sheet = sheet, colNames = FALSE, rows = 1)
  names  <- if (is.null(header)) character() else trimws(as.character(unlist(header[1, ])))
  as.data.frame(stats::setNames(rep(list(character()), length(names)), names),
                check.names = FALSE, stringsAsFactors = FALSE)
}

.plan_col <- function(data, name) if (name %in% names(data)) data[[name]] else rep("", nrow(data))

.plan_default <- function(values, default) {
  values[!nzchar(values)] <- default
  values
}

.plan_activities <- function(data) {
  none <- rep("", nrow(data))
  .plan_raw(data, .PLAN_ACTIVITY, data[[.PLAN_ACTIVITY]], data$Start, data$Ende, line = none,
            owner = .plan_col(data, "Verantwortlich"), criterion = none)
}

.plan_milestones <- function(data) {
  .plan_raw(data, .PLAN_MILESTONE, data$Meilenstein, data$Datum, data$Datum,
            line = .plan_col(data, .PLAN_LINE_COLUMN), owner = rep("", nrow(data)),
            criterion = .plan_col(data, "Kriterium"))
}

.plan_raw <- function(data, kind, text, start, end, line, owner, criterion) {
  data.frame(
    ID = data$ID, KIND = rep(kind, nrow(data)), LANE = data$Bahn, TEXT = text,
    START_TEXT = start, END_TEXT = end, TYPE = .plan_default(data$Art, "eigene"),
    DATING = .plan_default(data$Termin, "fest"), STATUS = .plan_default(data$Status, "geplant"),
    LINE_TEXT = .plan_default(line, "nein"), OWNER = owner, DELIVERABLE = .plan_col(data, "Deliverable"),
    CRITERION = criterion, NOTE = .plan_col(data, "Bemerkung"), stringsAsFactors = FALSE
  )
}

# Excel numbers, TT.MM.JJJJ and JJJJ-MM-TT; anything else, and days before 2000, become NA.
.plan_dates <- function(values) {
  dates  <- rep(as.Date(NA), length(values))
  serial <- grepl("^[0-9]{5}([.,][0-9]+)?$", values)
  dates[serial] <- as.Date(floor(as.numeric(sub(",", ".", values[serial], fixed = TRUE))),
                           origin = .PLAN_EXCEL_ORIGIN)
  german <- grepl("^[0-9]{1,2}\\.[0-9]{1,2}\\.[0-9]{4}$", values)
  dates[german] <- as.Date(values[german], format = "%d.%m.%Y")
  iso <- grepl("^[0-9]{4}-[0-9]{2}-[0-9]{2}$", values)
  dates[iso] <- as.Date(values[iso], format = "%Y-%m-%d")
  dates
}

# A day before 2000 is a typo rather than a date of the plan.
.plan_too_early <- function(dates) !is.na(dates) & dates < as.Date(.PLAN_EARLIEST)

.plan_date_problems <- function(raw, texts, dates, column, checked) {
  given <- checked & nzchar(texts)
  c(.plan_problem(raw, given & is.na(dates), sprintf("%s „%s“ ist kein Datum (TT.MM.JJJJ)", column, texts)),
    .plan_problem(raw, given & .plan_too_early(dates), sprintf("%s %s liegt vor 2000", column, texts)))
}

.plan_check <- function(raw, lanes) {
  start  <- .plan_dates(raw$START_TEXT)
  end    <- .plan_dates(raw$END_TEXT)
  is_act <- raw$KIND == .PLAN_ACTIVITY
  problems <- c(
    .plan_problem(raw, !nzchar(raw$ID), "ohne ID"),
    .plan_problem(raw, !nzchar(raw$TEXT), "ohne Text"),
    .plan_problem(raw, !raw$LANE %in% lanes, sprintf("Bahn „%s“ steht nicht im Blatt Listen", raw$LANE)),
    .plan_value_problems(raw),
    .plan_date_problems(raw, raw$START_TEXT, start, ifelse(is_act, "Start", "Datum"), rep(TRUE, nrow(raw))),
    .plan_date_problems(raw, raw$END_TEXT, end, "Ende", is_act),
    .plan_problem(raw, xor(nzchar(raw$START_TEXT), nzchar(raw$END_TEXT)),
                  "Start und Ende beide eintragen oder beide leer lassen"),
    .plan_problem(raw, !is.na(start) & !is.na(end) & end < start, "Ende vor Start")
  )
  doubled <- unique(raw$ID[duplicated(raw$ID) & nzchar(raw$ID)])
  if (length(doubled) > 0L) problems <- c(problems, paste0("ID doppelt: ", paste(doubled, collapse = ", ")))
  if (length(problems) > 0L) {
    stop("Der Projektplan hat Fehler:\n", paste0("- ", problems, collapse = "\n"), call. = FALSE)
  }
  data.frame(
    ID = raw$ID, KIND = raw$KIND, LANE = raw$LANE, TEXT = raw$TEXT, START = start, END = end,
    PROJECT = raw$TYPE == "Projekt", ASSUMED = raw$DATING == "Annahme", STATUS = raw$STATUS,
    LINE = raw$LINE_TEXT == "ja", OWNER = raw$OWNER, DELIVERABLE = raw$DELIVERABLE,
    CRITERION = raw$CRITERION, NOTE = raw$NOTE, stringsAsFactors = FALSE
  )
}

.plan_problem <- function(raw, wrong, message) {
  if (!any(wrong)) return(character())
  label <- ifelse(nzchar(raw$ID), raw$ID, paste0("(ohne ID) ", raw$TEXT))
  paste0(label[wrong], ": ", rep_len(message, nrow(raw))[wrong])
}

.plan_value_problems <- function(raw) {
  fields <- c(Art = "TYPE", Termin = "DATING", Status = "STATUS", Linie = "LINE_TEXT")
  unlist(lapply(names(fields), function(field) {
    values  <- raw[[fields[[field]]]]
    allowed <- .PLAN_VALUES[[field]]
    .plan_problem(raw, !values %in% allowed, sprintf("%s „%s“ ist nicht erlaubt (%s)", field, values,
                                                     paste(allowed, collapse = ", ")))
  }), use.names = FALSE)
}

.plan_lanes <- function(data) {
  data    <- data[nzchar(data$Bahn), , drop = FALSE]
  colours <- tolower(.plan_col(data, "Farbe"))
  if (nrow(data) == 0L) stop("Im Blatt Listen steht keine Bahn.", call. = FALSE)
  doubled <- unique(data$Bahn[duplicated(data$Bahn)])
  if (length(doubled) > 0L) stop("Bahn doppelt im Blatt Listen: ", paste(doubled, collapse = ", "), call. = FALSE)
  wrong <- nzchar(colours) & !grepl("^#[0-9a-f]{6}$", colours)
  if (any(wrong)) {
    stop("Farbe im Blatt Listen ist kein Hexwert wie #2a78d6: ", paste(data$Farbe[wrong], collapse = ", "),
         call. = FALSE)
  }
  open <- !nzchar(colours)
  free <- setdiff(.PLAN_PALETTE, colours[!open])
  if (length(free) == 0L) free <- .PLAN_PALETTE
  colours[open] <- rep_len(free, sum(open))
  data.frame(LANE = data$Bahn, COLOUR = colours, stringsAsFactors = FALSE)
}

.plan_settings <- function(data, items) {
  values <- .plan_setting_values(data)
  texts  <- values[c("Plan von", "Plan bis", "Heute")]
  dates  <- .plan_dates(texts)
  wrong  <- nzchar(texts) & (is.na(dates) | .plan_too_early(dates))
  if (any(wrong)) {
    stop("Im Blatt Einstellungen ist kein Datum ab 2000: ",
         paste0(names(texts)[wrong], " = ", texts[wrong], collapse = ", "), call. = FALSE)
  }
  preview <- suppressWarnings(as.numeric(sub(",", ".", values[["Vorschau (Tage)"]], fixed = TRUE)))
  if (nzchar(values[["Vorschau (Tage)"]]) && (is.na(preview) || preview < 0)) {
    stop("Im Blatt Einstellungen ist Vorschau (Tage) keine Zahl ab 0: ", values[["Vorschau (Tage)"]], call. = FALSE)
  }
  starts <- items$START[!is.na(items$START)]
  ends   <- items$END[!is.na(items$END)]
  from   <- if (!is.na(dates[[1]])) dates[[1]] else .plan_month_start(if (length(starts)) min(starts) else Sys.Date())
  to     <- if (!is.na(dates[[2]])) dates[[2]] else .plan_month_end(if (length(ends)) max(ends) else from)
  if (to <= from) stop("Im Blatt Einstellungen liegt Plan bis nicht nach Plan von.", call. = FALSE)
  list(FROM = from, TO = to, TODAY = dates[[3]],
       PREVIEW_DAYS = if (is.na(preview)) .PLAN_PREVIEW_DAYS else preview)
}

# The values of the sheet Einstellungen by field, "" when missing; an unknown field stops, so that a
# typo does not silently fall back to the default.
.plan_setting_values <- function(data) {
  values <- stats::setNames(rep("", length(.PLAN_SETTINGS)), .PLAN_SETTINGS)
  if (is.null(data)) return(values)
  unknown <- setdiff(data$Feld[nzchar(data$Feld)], .PLAN_SETTINGS)
  if (length(unknown) > 0L) {
    stop("Im Blatt Einstellungen ist das Feld unbekannt: ", paste(unknown, collapse = ", "),
         ". Erlaubt: ", paste(.PLAN_SETTINGS, collapse = ", "), ".", call. = FALSE)
  }
  found <- intersect(.PLAN_SETTINGS, data$Feld)
  values[found] <- vapply(found, function(field) data$Wert[data$Feld == field][[1]], character(1))
  values
}

.plan_month_start <- function(day) as.Date(format(day, "%Y-%m-01"))

.plan_month_end <- function(day) seq(.plan_month_start(day), by = "month", length.out = 2L)[[2]] - 1L

.plan_format <- function(days) {
  out <- format(days, "%d.%m.%Y")
  out[is.na(days)] <- ""
  out
}

#' The day the plan counts from
#'
#' @param plan The plan from \code{read_project_plan()}.
#' @param today A day; \code{NULL} = Heute from the settings, else the day of
#'   the run.
#' @noRd
project_plan_today <- function(plan, today = NULL) {
  if (length(today) == 1L && !is.na(today)) return(as.Date(today))
  if (!is.na(plan$Settings$TODAY)) plan$Settings$TODAY else Sys.Date()
}

#' Lists of the open work: overdue, upcoming and undated
#'
#' Overdue: not done and the end lies before today. Upcoming: not done, not
#' overdue, running today or starting within the preview of the settings.
#' Undated: not done and no date yet. Outside: not done, not overdue, dated
#' but outside Plan von and Plan bis, so missing in the drawing. Done and
#' dropped work stays out of all four lists.
#'
#' @inheritParams project_plan_today
#' @return A list: \code{Today}, and the tables \code{Overdue},
#'   \code{Upcoming}, \code{Undated} and \code{Outside} with German column
#'   names, sorted by date.
#' @noRd
project_plan_tables <- function(plan, today = NULL) {
  today    <- project_plan_today(plan, today)
  items    <- plan$Items
  open     <- !items$STATUS %in% .PLAN_DONE
  dated    <- !is.na(items$START)
  overdue  <- open & dated & items$END < today
  upcoming <- open & dated & !overdue & items$START <= today + plan$Settings$PREVIEW_DAYS & items$END >= today
  outside  <- open & dated & !overdue & !.plan_in_span(items, plan$Settings)
  pick     <- function(which) .plan_table(items[which, , drop = FALSE])
  list(Today = today, Overdue = pick(overdue), Upcoming = pick(upcoming), Undated = pick(open & !dated),
       Outside = pick(outside))
}

# Dated items that overlap the range of the drawing.
.plan_in_span <- function(items, settings) {
  !is.na(items$START) & items$END >= settings$FROM & items$START <= settings$TO
}

.plan_table <- function(items) {
  items <- items[order(items$START, items$END, items$ID, na.last = TRUE), , drop = FALSE]
  data.frame(
    ID = items$ID, Bahn = items$LANE, Was = items$TEXT, Art = items$KIND,
    Von = .plan_format(items$START), Bis = .plan_format(items$END), Status = items$STATUS,
    Termin = c("fest", "Annahme")[items$ASSUMED + 1L], Deliverable = items$DELIVERABLE,
    Bemerkung = items$NOTE, check.names = FALSE, stringsAsFactors = FALSE, row.names = NULL
  )
}

# The rows of the drawing: per lane in the order of the sheet Listen a header row, then its dated
# items by date. Dropped items, items without a date and items outside Plan von and Plan bis stay
# out, so that no row stays empty.
.plan_rows <- function(plan) {
  keep  <- .plan_in_span(plan$Items, plan$Settings) & plan$Items$STATUS != .PLAN_DROPPED
  items <- plan$Items[keep, , drop = FALSE]
  items <- items[order(items$START, items$END, items$ID), , drop = FALSE]
  parts <- lapply(plan$Lanes$LANE, function(lane) {
    own <- items[items$LANE == lane, , drop = FALSE]
    if (nrow(own) == 0L) return(NULL)
    rbind(.plan_lane_row(own, lane), own)
  })
  rows <- do.call(rbind, c(list(items[0, , drop = FALSE]), parts))
  rownames(rows) <- NULL
  rows$ROW <- seq_len(nrow(rows))
  rows
}

.plan_lane_row <- function(items, lane) {
  row <- items[NA_integer_, , drop = FALSE]
  row$ID <- ""
  row$KIND <- .PLAN_LANE_ROW
  row$LANE <- lane
  row$TEXT <- lane
  row$PROJECT <- FALSE
  row$ASSUMED <- FALSE
  row$STATUS <- ""
  row$DELIVERABLE <- ""
  row
}

#' Height of the drawing in inches
#' @inheritParams project_plan_today
#' @noRd
project_plan_height <- function(plan) 1.7 + .PLAN_ROW_INCHES * nrow(.plan_rows(plan))

#' Draw the plan with lanes, bars, milestones and the line of today
#'
#' One row per dated activity or milestone, grouped by lane. Own work in the
#' colour of its lane, work of the project in grey; an assumed date is hatched
#' (bars) or hollow (milestones), done work pale, overdue work marked with
#' \code{!}. Milestones with Linie über alle Bahnen = ja draw a line through
#' all lanes. Draws on the open device; size it with
#' \code{project_plan_height()} and a width of about 13 inches.
#'
#' @inheritParams project_plan_today
#' @return Invisibly the rows drawn.
#' @noRd
plot_project_plan <- function(plan, today = NULL) {
  rows <- .plan_rows(plan)
  if (nrow(rows) == 0L) stop("Der Projektplan hat keine Zeile mit Termin.", call. = FALSE)
  today    <- project_plan_today(plan, today)
  span     <- c(plan$Settings$FROM, plan$Settings$TO + 1L)
  colour   <- plan$Lanes$COLOUR[match(rows$LANE, plan$Lanes$LANE)]
  colour[rows$PROJECT %in% TRUE] <- .PLAN_INK[["project"]]
  previous <- graphics::par(mai = c(0.9, .PLAN_LABEL_INCHES, 0.75, 0.3), xaxs = "i", yaxs = "i")
  on.exit(graphics::par(previous))
  graphics::plot.new()
  graphics::plot.window(xlim = as.numeric(span), ylim = c(nrow(rows) + 0.5, 0.5))
  .plan_draw_bands(rows, plan$Lanes)
  .plan_draw_calendar(span)
  .plan_draw_lines(plan, span, today)
  .plan_draw_marks(rows, colour, span)
  .plan_draw_labels(rows, today)
  .plan_draw_legend()
  invisible(rows)
}

.plan_inch_x <- function(inches) graphics::grconvertX(inches, from = "inches", to = "user")

.plan_draw_bands <- function(rows, lanes) {
  right  <- graphics::par("usr")[[2]]
  starts <- which(rows$KIND == .PLAN_LANE_ROW)
  ends   <- c(starts[-1] - 1L, nrow(rows))
  for (i in seq_along(starts)) {
    top    <- starts[[i]] - 0.5
    bottom <- ends[[i]] + 0.5
    if (i %% 2L == 0L) {
      graphics::rect(.plan_inch_x(0.05), bottom, right, top, col = .PLAN_INK[["band"]], border = NA, xpd = NA)
    }
    strip <- lanes$COLOUR[lanes$LANE == rows$LANE[[starts[[i]]]]]
    graphics::rect(.plan_inch_x(0.05), bottom, .plan_inch_x(0.11), top, col = strip, border = NA, xpd = NA)
    graphics::segments(.plan_inch_x(0.05), top, right, top, col = .PLAN_INK[["grid"]], xpd = NA)
  }
}

.plan_draw_calendar <- function(span) {
  days    <- seq(span[[1]], span[[2]] - 1L, by = "day")
  months  <- days[format(days, "%d") == "01"]
  mondays <- days[format(days, "%u") == "1"]
  graphics::abline(v = as.numeric(mondays), col = .PLAN_INK[["week"]], lwd = 0.8)
  graphics::abline(v = as.numeric(months), col = .PLAN_INK[["grid"]], lwd = 1)
  bounds <- unique(c(as.numeric(span[[1]]), as.numeric(months), as.numeric(span[[2]])))
  starts <- as.Date(utils::head(bounds, -1L), origin = "1970-01-01")
  labels <- paste(.PLAN_MONTHS[as.integer(format(starts, "%m"))], format(starts, "%Y"))
  mids   <- (utils::head(bounds, -1L) + utils::tail(bounds, -1L)) / 2
  graphics::mtext(labels, side = 3, line = 1.5, at = mids, cex = 0.75, col = .PLAN_INK[["main"]])
  weeks <- mondays[as.numeric(mondays) + 7 <= as.numeric(span[[2]])]
  graphics::mtext(format(weeks, "%V"), side = 3, line = 0.35, at = as.numeric(weeks) + 3.5, cex = 0.5,
                  col = .PLAN_INK[["muted"]])
  graphics::mtext("KW", side = 3, line = 0.35, at = graphics::par("usr")[[1]], adj = 1.4, cex = 0.5,
                  col = .PLAN_INK[["muted"]])
}

.plan_draw_lines <- function(plan, span, today) {
  inside <- function(day) day >= span[[1]] & day < span[[2]]
  items  <- plan$Items
  lines  <- items[items$LINE & !is.na(items$START) & items$STATUS != .PLAN_DROPPED, , drop = FALSE]
  lines  <- lines[inside(lines$START), , drop = FALSE]
  if (nrow(lines) > 0L) {
    x <- as.numeric(lines$START) + 0.5
    graphics::abline(v = x, col = .PLAN_INK[["main"]], lwd = 1.6)
    graphics::mtext(paste(lines$TEXT, .plan_format(lines$START)), side = 1, line = 0.3, at = x, cex = 0.68,
                    font = 2, col = .PLAN_INK[["main"]])
  }
  if (inside(today)) {
    graphics::abline(v = as.numeric(today) + 0.5, col = .PLAN_INK[["main"]], lty = 2, lwd = 1.2)
    graphics::mtext(paste("Heute", .plan_format(today)), side = 1, line = 0.3, at = as.numeric(today) + 0.5,
                    cex = 0.68, col = .PLAN_INK[["main"]])
  }
}

.plan_draw_marks <- function(rows, colour, span) {
  items    <- rows$KIND != .PLAN_LANE_ROW & rows$END >= span[[1]] & rows$START < span[[2]]
  items    <- items %in% TRUE
  is_bar   <- items & rows$KIND == .PLAN_ACTIVITY
  is_stone <- items & rows$KIND == .PLAN_MILESTONE
  .plan_draw_bars(rows[is_bar, , drop = FALSE], colour[is_bar])
  .plan_draw_stones(rows[is_stone, , drop = FALSE], colour[is_stone])
  .plan_draw_tags(rows[items, , drop = FALSE], span)
}

.plan_draw_bars <- function(bars, colour) {
  if (nrow(bars) == 0L) return(invisible(NULL))
  pale  <- bars$STATUS == "erledigt" | bars$ASSUMED
  fill  <- ifelse(pale, grDevices::adjustcolor(colour, alpha.f = 0.35), colour)
  x0    <- as.numeric(bars$START)
  x1    <- as.numeric(bars$END) + 1
  half  <- 0.3
  graphics::rect(x0, bars$ROW + half, x1, bars$ROW - half, col = fill, border = NA)
  hatch <- bars$ASSUMED & bars$STATUS != "erledigt"
  if (any(hatch)) {
    graphics::rect(x0[hatch], bars$ROW[hatch] + half, x1[hatch], bars$ROW[hatch] - half, density = 22, angle = 45,
                   col = colour[hatch], border = colour[hatch], lwd = 0.8)
  }
}

.plan_draw_stones <- function(stones, colour) {
  if (nrow(stones) == 0L) return(invisible(NULL))
  fill <- ifelse(stones$STATUS == "erledigt", grDevices::adjustcolor(colour, alpha.f = 0.35), colour)
  fill[stones$ASSUMED & stones$STATUS != "erledigt"] <- "#ffffff"
  graphics::points(as.numeric(stones$START) + 0.5, stones$ROW, pch = 23, cex = 1.5, bg = fill, col = colour,
                   lwd = 1.6)
}

# Dates and deliverable beside each mark; near the right edge on the left of the mark.
.plan_draw_tags <- function(items, span) {
  if (nrow(items) == 0L) return(invisible(NULL))
  stone <- items$KIND == .PLAN_MILESTONE
  when  <- ifelse(stone, format(items$START, "%d.%m."),
                  paste0(format(items$START, "%d.%m."), "-", format(items$END, "%d.%m.")))
  tag   <- ifelse(nzchar(items$DELIVERABLE), paste0(when, "  ", items$DELIVERABLE), when)
  right <- as.numeric(items$END) + ifelse(stone, 4.5, 3)
  flip  <- right + 45 > as.numeric(span[[2]])
  style <- list(cex = 0.6, col = .PLAN_INK[["second"]], xpd = NA)
  if (any(!flip)) do.call(graphics::text, c(list(right[!flip], items$ROW[!flip], tag[!flip], adj = c(0, 0.5)), style))
  if (any(flip)) {
    left <- as.numeric(items$START[flip]) - ifelse(stone[flip], 4, 2)
    do.call(graphics::text, c(list(left, items$ROW[flip], tag[flip], adj = c(1, 0.5)), style))
  }
}

.plan_draw_labels <- function(rows, today) {
  lane <- rows$KIND == .PLAN_LANE_ROW
  graphics::text(.plan_inch_x(0.18), rows$ROW[lane], rows$TEXT[lane], adj = c(0, 0.5), font = 2, cex = 0.8,
                 col = .PLAN_INK[["main"]], xpd = NA)
  items <- rows[!lane, , drop = FALSE]
  if (nrow(items) == 0L) return(invisible(NULL))
  late  <- !items$STATUS %in% .PLAN_DONE & items$END < today
  label <- paste(items$ID, items$TEXT)
  label <- ifelse(items$STATUS %in% c("erledigt", "verschoben"), paste0(label, " (", items$STATUS, ")"), label)
  label <- ifelse(late, paste("!", label), label)
  ink   <- ifelse(items$PROJECT, .PLAN_INK[["second"]], .PLAN_INK[["main"]])
  ink[items$STATUS == "erledigt"] <- .PLAN_INK[["muted"]]
  ink[late] <- .PLAN_INK[["late"]]
  width <- .PLAN_LABEL_INCHES - 0.3 - 0.15
  graphics::text(.plan_inch_x(0.3), items$ROW, .plan_fit(label, width, 0.66), adj = c(0, 0.5), cex = 0.66,
                 col = ink, font = ifelse(items$PROJECT, 3, 1), xpd = NA)
}

# Shortens labels to the width in inches, ending in "...".
.plan_fit <- function(labels, width, cex) {
  vapply(labels, function(label) {
    if (graphics::strwidth(label, units = "inches", cex = cex) <= width) return(label)
    while (nchar(label) > 4L && graphics::strwidth(paste0(label, "..."), units = "inches", cex = cex) > width) {
      label <- substr(label, 1L, nchar(label) - 1L)
    }
    paste0(trimws(label), "...")
  }, character(1), USE.NAMES = FALSE)
}

# One row of keys in the bottom margin, from the left edge of the device.
.plan_draw_legend <- function() {
  ink  <- .PLAN_INK[["second"]]
  y    <- graphics::grconvertY(0.22, from = "inches", to = "user")
  half <- abs(graphics::grconvertY(0.27, from = "inches", to = "user") - y)
  box  <- function(...) function(x0, x1) graphics::rect(x0, y - half, x1, y + half, border = NA, xpd = NA, ...)
  line <- function(lty, lwd) function(x0, x1) graphics::segments(x0, y, x1, y, lty = lty, lwd = lwd,
                                                                col = .PLAN_INK[["main"]], xpd = NA)
  stone <- function(fill) function(x0, x1) graphics::points((x0 + x1) / 2, y, pch = 23, cex = 1.2, bg = fill,
                                                           col = ink, lwd = 1.4, xpd = NA)
  keys <- list(
    "Aktivität" = box(col = ink),
    "Termin ist Annahme" = function(x0, x1) {
      box(col = grDevices::adjustcolor(ink, alpha.f = 0.35))(x0, x1)
      graphics::rect(x0, y - half, x1, y + half, density = 22, angle = 45, col = ink, border = ink, xpd = NA)
    },
    "erledigt" = box(col = grDevices::adjustcolor(ink, alpha.f = 0.35)),
    "Projekt" = box(col = .PLAN_INK[["project"]]),
    "Meilenstein" = stone(ink),
    "Meilenstein (Annahme)" = stone("#ffffff"),
    "Heute" = line(2, 1.2),
    "Linie über alle Bahnen" = line(1, 1.6),
    "überfällig" = function(x0, x1) graphics::text((x0 + x1) / 2, y, "!", font = 2, cex = 0.9,
                                                            col = .PLAN_INK[["late"]], xpd = NA)
  )
  x <- 0.18
  for (name in names(keys)) {
    keys[[name]](.plan_inch_x(x), .plan_inch_x(x + 0.22))
    graphics::text(.plan_inch_x(x + 0.3), y, name, adj = c(0, 0.5), cex = 0.7, col = ink, xpd = NA)
    x <- x + 0.3 + graphics::strwidth(name, units = "inches", cex = 0.7) + 0.3
  }
}
