# [JIRA] Dokumentation: Aufteilung der Rolle _WIBU_VERKAUF_INNENDIENST_MITARBEITER nach Lizenztypen (SCM / COM / FIN)

**Ticket-Typ:** Task / Security Change  
**Komponente:** D365FO Security & Licensing / User Security Governance  
**Betroffene Rolle (Ausgangsbasis):** `_WIBU_VERKAUF_INNENDIENST_MITARBEITER`  
**Beteiligte:** Cedric Kameni (Security / Lizenzoptimierung), Daniel Ryterski (Fachbereich Verkauf Innendienst)  
**Datum:** 02. November 2026  

---

## 1. Zusammenfassung & Zielsetzung

Die bisherige monolithische Rolle **`_WIBU_VERKAUF_INNENDIENST_MITARBEITER`** bündelte Berechtigungen aus drei verschiedenen Microsoft-Lizenzbereichen (**Supply Chain Management**, **Commerce** und **Finance**). Dadurch löste jeder zugewiesene Vertriebsmitarbeiter automatisch teure Mehrfach- und Attach-Lizenzen aus.

Im Rahmen der Lizenzoptimierung wurde die Rolle analysiert und modular in **drei lizenztrennte Rollen** aufgeteilt:
1. **Basisrolle (SCM):** Deckt den regulären operativen Auftragsprozess ab.
2. **Zusatzrolle (Commerce):** Bündelt Einzelhandels-/Rabattfunktionen.
3. **Zusatzrolle (Finance):** Bündelt manuelle Rechnungs- und Fakturierungsberechtigungen für Sonderfälle.

---

## 2. Ausgangslage & Problemstellung im Testbetrieb

Nach der initialen Reduzierung auf die reine SCM-Basis traten im Fachbereich (Rückmeldung Daniel Ryterski) Berechtigungsblockaden bei folgenden Geschäftsprozessen auf:
- **Proforma- und Vorkasserechnungen:** Werden im regulären Vertriebsprozess von mehreren Mitarbeitern benötigt.
- **Manuelle Fakturierung von Aufträgen:** Erforderlich, wenn der nächtliche Batch-Lauf fehlschlägt oder Rechnungen hängen bleiben.
- **Gutschriften bei Rücklieferungen:** Korrektur- und Retourenprozesse.

### Lizenztreiber-Analyse aus dem Lizenzbericht:
* **Finance-Treiber (direkte Rechte):**
  * `SalesFormLetter_InvoiceMaintain` (*Debitorenrechnungen verwalten*) -> Lizenz: **Nur Finance**
  * `CredManForceHoldProcess` (*Kreditsperre erzwingen*) -> Lizenz: **Nur Finance**
* **Commerce-Treiber (Aufgabe/Duty):**
  * `RetailDiscountOfferMaintain` (*Maintain retail campaign discounts* / *33 Rechte, 94 Objekte*) -> Lizenz: **Nur Commerce**

---

## 3. Neue Rollenstruktur (Die 3 Zielrollen)

### 1️⃣ Basis-Rolle: `_WIBU VERKAUF INNENDIENST MITARBEITER SCM`
* **Lizenzstufe:** Dynamics 365 Supply Chain Management (Base)
* **Zielgruppe:** Alle regulären Mitarbeiter im Vertriebsinnendienst (Breitenrolle).
* **Umfang:** Vollständige operative Auftragsabwicklung, Kundenstamm, Angebotserstellung, Standard-Verkaufsprozesse ohne Rechnungsbuchung/Commerce.

### 2️⃣ Zusatz-Rolle: `_WIBU VERKAUF INNENDIENST MITARBEITER ZUSATZ COM`
* **Lizenzstufe:** Dynamics 365 Commerce (Attach)
* **Zielgruppe:** Nur Mitarbeiter, die Kampagnenrabatte und Preisnachlässe im System einrichten/pflegen.
* **Enthaltene Aufgaben (Duties):**
  * `RetailDiscountOfferMaintain` (*Maintain retail campaign discounts*)

### 3️⃣ Zusatz-Rolle: `_WIBU VERKAUF INNENDIENSTMITARBEITER ZUSATZ FIN`
* **Lizenzstufe:** Dynamics 365 Finance (Attach)
* **Zielgruppe:** Dedizierte Key User / Teilkreis im Innendienst, die manuelle Rechnungskorrekturen, Proforma-Rechnungen und Gutschriften durchführen.
* **Enthaltene Rechte (Privileges):**
  * `SalesFormLetter_InvoiceMaintain` (*Debitorenrechnungen verwalten*)
  * `CredManForceHoldProcess` (*Kreditsperre erzwingen*)
* **Technischer Aufbau:** Als isolierte Einzelrechte direkt in der Zusatzrolle verankert (ohne Vererbung überflüssiger Finanz-Duties).

---

## 4. Bereitgestellte Security-Artefakte

Die Rollen wurden generiert und stehen in allen 3 D365FO-Formaten bereit:
* **AOT XML (Visual Studio Modell):**
  * `AxSecurityRole/_WIBU_VERKAUF_INNENDIENST_MITARBEITER_SCM.xml`
  * `AxSecurityRole/_WIBU_VERKAUF_INNENDIENST_MITARBEITER_ZUSATZ_COM.xml`
  * `AxSecurityRole/_WIBU_VERKAUF_INNENDIENSTMITARBEITER_ZUSATZ_FIN.xml`
* **Browser-Import (User Security Governance):**
  * `SecurityGovernance/...`
* **Browser-Import (Sicherheitskonfiguration):**
  * `SecurityConfiguration/...`
* **Visual Studio Deployment:**
  * ZIP-Archive für das Anwendungsmodell.

---

## 5. Akzeptanz- und Testkriterien (für Fachbereich / Daniel Ryterski)

Folgende Testfälle sind mit zugewiesener Zusatzrolle `_WIBU VERKAUF INNENDIENSTMITARBEITER ZUSATZ FIN` erfolgreich zu validieren:

| Testfall-ID | Testfall-Beschreibung | Erwartetes Ergebnis | Status |
| :--- | :--- | :--- | :--- |
| **TC-01** | Erstellung einer Proforma-Rechnung im Auftrag | Proforma-Rechnung wird ohne Berechtigungsfehler generiert und gedruckt. | ⬜ Offen |
| **TC-02** | Manuelle Fakturierung eines Auftrags nach Batch-Abbruch | Rechnung kann manuell gebucht und der Beleg erzeugt werden. | ⬜ Offen |
| **TC-03** | Erstellung einer Gutschrift bei Rücklieferung | Gutschriftsbeleg kann gebucht und gebunden werden. | ⬜ Offen |
| **TC-04** | Prüfung Kreditsperre bei gesperrten Debitoren | Kreditsperre kann eingesehen / nach Prozessfreigabe bearbeitet werden. | ⬜ Offen |

---

## 6. Business Value & Lizenz-Auswirkung

* **Vorher:** 100 % der Innendienstmitarbeiter verursachten **SCM (Base) + Finance (Attach) + Commerce (Attach)** (~227,00 € pro Nutzer/Monat).
* **Nachher:** 
  * Der Großteil der Mitarbeiter benötigt künftig ausschließlich die **SCM-Basislizenz** (~168,50 €).
  * Finance- und Commerce-Attach-Lizenzen fallen nur noch selektiv für diejenigen Nutzer an, denen die Zusatzrollen zugewiesen werden.
* **Ergebnis:** Nachhaltige Senkung der monatlichen Lizenzkosten bei gleichzeitig sauber getrennten Berechtigungen (SoD-Konformität).
