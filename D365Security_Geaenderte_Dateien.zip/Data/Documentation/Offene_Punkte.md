# Offene Punkte – Berechtigungs- und Lizenzstrategie

Stand: 31.10.2026. Erledigte Punkte abhaken oder löschen, neue unten im passenden Abschnitt ergänzen.
Frage an Claude: „Was ist noch offen?“ – dann werden diese Themen wiedergegeben.

## A. Berechtigungskonzept der WiBU-IT anpassen

Quelle: `Input/Excel/Strategie/Abteilung_Tätigkeit_Mitarbeitende.xlsx`, Blatt „Berechtingungskonzept“.

- [ ] **Tätigkeit ist eine Aufgabe, keine Rolle.** Eine Aufgabe enthält mehrere Rechte, eine Rolle ist eine Sammlung von Aufgaben, eine Stelle ist eine Sammlung von Rollen. Rollen werden von unten aus Aufgaben gebaut, nicht von oben.
  Nächster Schritt: Text schreiben, der zeigt, welche Stellen im Konzept wie geändert werden müssen.
- [ ] **Namensregel:** `WIBU_<Bereich>_<Funktion>_<Lizenz>`, z. B. `WIBU_Einkauf_Sachbearbeiter_Act`, statt `<Gesellschaft>.<Abteilung>.<Tätigkeit>`.
- [ ] **Keine Gesellschaft im Rollennamen:** eine Rolle für alle Gesellschaften, kein Duplizieren je Gesellschaft. Die Dokumentation hält je Gesellschaft fest, wer Owner der Rolle ist.
- [ ] **Lizenz und Funktionstrennung** als Pflichtangaben einer Tätigkeit aufnehmen, damit der Freigeber sieht, welche Lizenz er auslöst und welche Kombinationen unzulässig sind.
- [ ] **Sperrliste als Regel:** Rechte, Aufgaben und Rollen mit Funktionen, die nur kontrolliert eingesetzt werden (z. B. Stammdatenpflege), kommen auf eine Sperrliste. Jede Standardrolle, die eine solche Aufgabe enthält, kommt ebenfalls darauf. Vergabe nur bewusst. Ein Anfang steht im Blatt „Tabelle2“ (Ersatzobjekt, Grund, Ticket).

## B. Strategiedokument (`D01_Berechtigungskonzept_Strategie.Rmd`, bis 30.10.2026 `D365FO_Berechtigungskonzept_Strategie.Rmd`)

- [ ] Auf das WiBU-Konzept verweisen und die Begriffe angleichen: so schreiben, als sei „Tätigkeit = Aufgabe“ im Konzept schon geklärt; Ansatz von unten (Aufgaben → Rollen).
- [ ] Sperrliste als Prinzip oder eigenen Abschnitt aufnehmen.
- [ ] **Neuen Stand für D17 erfassen:** Kapitel 10 der Strategie fasst seit 31.10.2026 nur noch zusammen; alle Zahlen stehen in D17 (Eingabe nach `Data/Input/PPAC`, siehe Abschnitt G). D17 startet mit dem Stand vom 20.10.2026 aus dem früheren Kapitel 10. Die folgenden Punkte sind neuer und noch nicht erfasst:
  - 698 GB Kontingent; Erweiterung 3-mal in 365 Tagen; Fenster 1 vom 30.09. bis 14.11.2026.
  - Größen laut Admin Center: Prod 212, PRJ 177, INT 136, TST 70 GB.
  - Strategie 1/2 statt S1/S2/S3; Maßnahmen wirken ab 15.11.2026; einfachere Kennzahlen-Tabelle.
  - Migrationsumgebung DMG mit 177 GB ab Oktober 2026; die beiden Verfahren der Datenmigration als neuer Abschnitt; Erweiterungen wie geplant (15.11.–12.02.), danach Zukauf je Monat.
  - Das Admin Center zeigt mit Erweiterung 1,4 TB, also eher eine Verdopplung als plus zwei Drittel.
- [ ] Kapitel 4, 9 und 11: Für die neue Gesellschaft startet die Vorlage mit der Logistik; die Servicetechniker kommen erst, wenn ihre Aufgaben feststehen.
- [ ] Autor in der Kopfzeile ersetzen (heute „Lead D365 Security & Licensing Architect“); Firmenname „WIBU-Gruppe“ bestätigen.
- [ ] Die gerenderten `.docx`/`.html` unter `Data/Documentation` durch die neuen ersetzen.

## C. Einkaufs-Pilot

Quelle: Blätter „Einkauf_Tätigkeit“ (39 Tätigkeiten, 11 Gruppen) und „Gruppenmitglieder“ (24 Personen in 9 Kombinationen).

- [ ] T1–T39 den D365-Menüpunkten zuordnen (Aufgabenaufzeichnung und Sicherheitsdiagnose).
- [ ] Daraus Aufgaben und je Stelle eine Rolle bauen; Lizenz je Rolle mit `report_role_license()` bestimmen.
- [ ] Funktionstrennung in Workshop 3 klären:
  - 3 Personen (AB-Pfleger + Rechnungsteam + Import) können Bestellung anlegen, Zugang buchen und Rechnung buchen.
  - Das Rechnungsteam bucht Zugänge (T22) und Rechnungen (T11).
  - Leitung, Teamleitung und KeyUser haben alle 39 Tätigkeiten.
- [ ] Gruppe „Ext. Asien“ (nur Ansicht): reicht Team Member?
- [ ] Brauchen Leitung und KeyUser in Prod wirklich alle Tätigkeiten?

## D. Neue Gesellschaft

- [ ] Vorlage für die vier Gruppen ausfüllen lassen; **Start mit der Logistik**, Servicetechniker später.
- [ ] **Logistik:** Die alte Liste des Fachbereichs (`D365_Abteilung_Tätigkeit_Mitarbeitende_Vertrieb_Logistik.xlsx`) hat nur 6 Tätigkeiten auf der Fläche; der Leitstand ist leer. In Workshop 1 ergänzen. Bestandskorrektur ist gesperrt (Sperrliste).
- [ ] **Vertrieb:** Die Liste (12 Tätigkeiten, 5 Stellen IDV, IDV.TL, KAM, KAM.TL, AD.TL) liegt vor. Fragen an den Fachbereich:
  - Warum hat IDV.TL keine Preisfindung?
  - Braucht nur IDV Commerce (Preisfindung mit Unified Pricing)?
  - Die Vertretungsregel für die Recherche im Debitorenstamm mit dem Betriebsrat abstimmen.
- [ ] Lizenzprognose von unten: Person → Tätigkeiten → teuerste Lizenz.
- [ ] Wer von den 185 Benutzern hat schon eine Lizenz in einer anderen Gesellschaft?
- [ ] Preise 195,80 € und 227,00 € gegen das Angebot prüfen (Basis plus Attach).
- [ ] **Go-Live klären (05.11.2026):** D01, D01C und der persönliche Plan (`Data/Input/Projektplan/Projektplan.xlsx`) nennen Mitte Juni 2027 (15.06.2027); die Kapazitätsdatei `Data/Input/PPAC/Capacity_2026-11-02.xlsx` nennt den 01.05.2027 mit der Quelle „Projektplan“. Daran hängen D17 (Fehlmenge vor dem Go-Live, Zukauf) und alle Termine von Strang B.
- [ ] **Termine des Einführungsprojekts in den persönlichen Plan eintragen:** Integrationstests mit Datenübernahme (P-01 bis P-03), UAT (P-04, bisher Annahme April bis Mai 2027), Generalprobe und Cutover (P-05, P-06), Termine 1 bis 4 aus D01C (G-M01 bis G-M04). Danach `Data/Documentation/Projektplan.Rmd` knitten; Ausgabe in `Data/Reports`.

## E. Datenbankkapazität

- [ ] PRJ und Migrationsumgebung (DMG) bis 14.11.2026 bereinigen (Strategie 1). DMG ohne Buchungsdaten (Strategie 2) geht laut Functional Architect nur, wenn die Migration nicht mehr über den Datenbanktausch läuft.
- [ ] **Verfahren der Datenmigration entscheiden:** Datenbanktausch DMG → PRJ (DMG in voller Größe, heute 177 GB) oder Zeitblock in PRJ wie beim Cutover (DMG nur für das Migrationsteam, ohne Buchungsdaten). Mit Projektleitung, Functional Architect und Fachbereich.
- [ ] **Lage der Erweiterungen entscheiden (Geschäftsführung):** Grundlage ist `Entscheidungsvorlage_Datenbankkapazitaet.Rmd/.docx`. Mit 177 GB je Testumgebung: Plan A (Erweiterungen sofort, Zukauf 11.02.–14.06.2027) rund 42.900 €, Plan B (Erweiterungen vor dem Go-Live, Zukauf 13.11.2026–16.03.2027) rund 37.600 €; bleibt TST bei 70 GB: 28.600 € bzw. 23.000 €. Jeweils mit 10 % Puffer.
- [ ] **Christian und Lars die Entscheidungsvorlage schicken;** sie ersetzt die Zahlen aus der früheren E-Mail (22.000–26.000 €).
- [ ] **Prod als Golden Config:** Wer gibt die Einstellungen der neuen Gesellschaft vor dem Go-Live in Prod ein, mit welchen Rollen? Als Sonderrechte mit Laufzeit dokumentieren (WiBU-Konzept).
- [ ] Fragen an Microsoft:
  - Bringt Team Member Kapazität?
  - Dürfen Erweiterungen direkt aufeinander folgen?
  - Was wird bei Überschreitung gesperrt, z. B. das Kopieren von Umgebungen?
  - Lässt sich Kapazität monatlich zukaufen und wieder reduzieren?
- [ ] Unterschied klären: 630 GB belegt laut Planung, die vier Umgebungen im Admin Center ergeben 596 GB.
- [ ] Wird die Migrationssandbox vor der Generalprobe erneut aus Prod kopiert? Wann genau wird PRJ gelöscht?
- [ ] Long-Term Data Retention prüfen: Einsparung, Kosten, Aufbewahrungsfristen.
- [ ] Prüfen, ob die Lizenztabellen in der transaktionslosen TST vollständig sind.

## F. Werkzeug (R-Paket D365Security)

- [ ] Sperrliste automatisch auswerten: alle Rollen finden, die eine gesperrte Aufgabe oder ein gesperrtes Recht enthalten, und die Benutzer mit gesperrten Objekten auflisten.
- [ ] Funktionstrennung: `read_sod_catalog()`, `build_sod_matrix()` und `export_sod_matrix()` prüfen Rollen und Benutzer über alle ihre Rollen (Ebene der Aufgaben). Offen: Ausnahmen aus D07 bei der Prüfung abziehen; Prüfung auch auf Ebene der Rechte (gleiches Recht in anderer Aufgabe). Beschrieben in `Dokumentation.Rmd`, Use case 15 (am 29.10.2026 vereinbart).
- [ ] Lizenzprognose aus dem Tätigkeitskatalog berechnen (siehe D).
- [x] `master` am 29.10.2026 per fast-forward auf `feat/role-license-decision-tool` nachgezogen (58 Commits, Stand `ca4f67b`); beide Zweige stehen gleich.
- [ ] Übersetzungsdatei für die deutschen Namen der Sicherheitsobjekte liefern.
- [ ] SQL auf `LicensingDutyRequirementsSummaryView` für die vier Aufgaben ohne lizenzrelevantes Objekt; danach evtl. Beschriftung „keine Lizenz nötig“.
- [ ] Datenquelle für den Lizenzpool finden: gekauft, vergeben und frei je Lizenzart.
- [ ] **Später: `UserSecGovRelatedObjects` mit dem Lizenzgraph verknüpfen** (zurückgestellt am 24.10.2026; die Vergleichsfunktionen werden vorerst nicht vereinigt). Die Tabelle zeigt den ganzen Aufbau einer Rolle: auch direkte Zugriffsberechtigungen, Tabellen, Felder, Steuerelemente und die sechs Einzelrechte. Ihre Lizenzspalten passen aber nicht zum Lizenzgraph: Die 34 Commerce-Objekte der Rolle Mitarbeiter stehen dort als None, Universal oder Activity. Möglicher Weg: Aufbau und Rechte aus der Tabelle, Lizenz aus dem Graph, verbunden über Objekttyp und Name (bei Entitäten die Vorsilbe `Data services\` bzw. `Data Management\` entfernen). Exporte: `Input/Excel/UserSecGovRelatedObjects/`.
- [ ] `.SECURABLE_TYPE_NAMES` in `R/load_role_license_graph.R` prüfen: Laut `UserSecGovRelatedObjects` ist Typ 44 eine Tabelle und 42 ein Tabellenfeld; das Paket nennt 44 „TableField“ und kennt 42 nicht.
- [ ] **Import im Browser** (Entscheidung 24.10.2026: beide Wege; Cedric will drei Dateien: AOT, Security governance, Sicherheitskonfiguration). Zwei Beispielexporte aus der ADN: `Input/Sicherheitsprozesserollen/` (Security governance, Typ „Sicherheitskonfiguration“, Testrolle `_WIBU_VERKAUF_Test_Role`) und `Input/Sicherheitskonfiguration/SecurityDatabaseCustomizations.xml` (ganze Sicherheitskonfiguration). Beide haben dieselbe Hülle; die Governance schreibt leere Elemente als `<x />`, die Sicherheitskonfiguration als `<x/>`. Entscheidung: neue Rollen und Rechte behalten ihren lesbaren Namen (Variante B, keine GUID). Erledigt: `export_role_xml()` und `build_license_roles()` schreiben je eine Datei in `SecurityGovernance/` und `SecurityConfiguration/`; eine AOT-Rolle unter eigenem Namen kommt in die Liste „geändert“ (ganze Rolle, wie im Export von D365), Kopien, UI-Rollen und Lizenzrollen in „neu“. Offen:
  - In der ADN testen, ob der Import lesbare Namen für neue Rollen und Rechte annimmt (D365 selbst vergibt neuen Objekten immer eine GUID).
  - Falls mit „Sicherheit-Governance-Rolle“ die Prozessdefinition gemeint ist: Beispielexport der Testrolle mit Typ „Governance der Benutzersicherheit“.
- [ ] **16 AOT-Rollen sind in der ADN über die Oberfläche geändert** (Liste „geändert“ im Export der Sicherheitskonfiguration, u. a. Verkauf Innendienst Leitung und Mitarbeiter, Einkauf Disposition und Mitarbeiter, Logistik Leitstand). Bei späteren Änderungen dieser Rollen in Visual Studio beachten, dass die Änderung aus der Oberfläche darüber liegt.
- [x] **Regeln von `build_license_roles()` bestätigt (25.10.2026):** Ein Recht kommt ganz hinein, sobald eines seiner Formulare genutzt wurde (auch nie geöffnete Formulare desselben Rechts). Rechte ohne Formular kommen mit ihrer genutzten Aufgabe; direkt an der Rolle bleiben sie als „nicht messbar“.
- [x] **Direkte Tabellenzugriffe in den Lizenzrollen bestätigt (25.10.2026):** Jede neue Rolle bekommt alle direkten Tabellenzugriffe der Rolle und ihrer Subrollen, weil die neuen Rollen keine Subrollen mehr haben (keine Lizenz nötig, nicht nach Nutzung gefiltert; Rolle Mitarbeiter: 8 Tabellen).
- [ ] Neue Rechte lassen Formularsteuerelemente und Services weg (Warnung); in der ADN prüfen, ob das vorkommt.
- [ ] **ADN-Test** der Schritte 10 und 11 des Playbooks und des Analyse-Rmd (`Analyse_Rolle_Lizenzen.Rmd`, beide Fassungen).
- [ ] **AOT-Rolle Verkauf Innendienst Leitung** enthält die UI-Rolle `53fae280` (Verkaufsleiter) als Subrolle; vor einem Import über Visual Studio muss diese Rolle als AOT-Rolle existieren.
- [ ] **Bereinigungsplan D04 (`plan_role_license_cleanup()`, 28.10.2026):** Lizenzgraph aus der Produktion exportieren und den Plan neu rechnen. Der Graph vom 28.10. stammt aus ADN, und dort sind die oben genannten 16 AOT-Rollen über die Oberfläche geändert (u. a. Verkauf Innendienst Mitarbeiter, Einkauf Mitarbeiter). Stand mit Graph ADN, Telemetrie Prod: 2.075,10 €/Monat belegt.
- [ ] **Unabhängiges Review von Commit `c140b56`** (PPAC hat Vorrang vor dem Graphen) nachholen: Der Reviewer brach am 28.10.2026 am Ausgabenlimit ab. Eigenprüfung und Invarianten auf den echten Daten waren ohne Befund.
- [ ] **Entscheidung: Rangliste D04 (Kapitel 11) aus dem Graphen rechnen**, wenn ein Graph übergeben wird. Mit PPAC allein ist „nur wegen der Rolle“ zu hoch, weil PPAC jede Lizenz nur einer Rolle zuordnet. Zahlen vom 28.10.: Summe 16.557,50 € (PPAC) gegen 5.026,50 € (Graph), 35 gegen 13 Rollen mit Kosten, Einkauf Mitarbeiter von Platz 1 (4.036,70 €) auf Platz 5 (464,10 €).
- [ ] **Telemetrie monatlich sichern**, damit Arbeit sichtbar wird, die nur einmal im Jahr anfällt (Jahresabschluss, Inventur); der Export vom 28.10. deckt 90 Tage ab. Das ist ein Thema für Datenschutz und Betriebsrat (D02, Abschnitt 5): In D01 Phase 7 und D03 steht deshalb seit 31.10.2026 nur noch das kontinuierliche Monitoring.

## G. Deliverables (besprechen, sobald die Strategie angepasst ist)

- [ ] Aufbau aller Excel-Deliverables festlegen, damit das Werkzeug sie einlesen kann: Blatt „Dokumentation“ (Text), Datenblätter mit fester Kopfzeile, Blatt „Listen“ (Auswahlwerte).
- [ ] Sperrliste als eigenes Deliverable aufnehmen; Start mit Blatt „Tabelle2“ der Strategie-Excel.
- [ ] Tätigkeitsmatrix je Abteilung als Excel (Ergebnis von Workshop 1, vor oder nach der Aufgabenaufzeichnung): zuerst Einkauf, dann Logistik.
- [ ] Kapitel 6 der Strategie-Rmd um diese Deliverables ergänzen.
- [ ] **D02 RACI- & Governance-Steckbrief** (erster Entwurf 29.10.2026, `D02_RACI_Governance_Steckbrief.Rmd/.docx`): Namen und Vertretungen eintragen; Berechtigungsrunde einrichten; Auswertung der Nutzungsdaten mit Datenschutz und Betriebsrat abstimmen; Freigeber für Gesellschaften ohne Benennung; Sonderrechte in Prod vor dem Go-Live; Takt der Rezertifizierung; Abnahme im Lenkungskreis. Die Zuständigkeiten in der Matrix sind ein Vorschlag der IT.
- [ ] **D07 Funktionstrennungs-Matrix** (seit 29.10.2026 aus Code): Der allgemeine Katalog `SoD_Katalog.xlsx` (101 Funktionen, 125 Standardaufgaben, 103 Regeln, Quellen) liegt in `Data/Input/Stakeholder`; das Rmd gleicht ihn mit dem Lizenzgraphen ab und schreibt D07 (Excel) und eine Kurzfassung (Word). Probe 29.10. mit Graph ADN und Zuweisungen Prod: 74 von 103 Regeln gelten, 11 sind nicht prüfbar (Funktion ohne Aufgabe im Katalog), 30 von 64 WIBU-Rollen und 159 von 187 Benutzern im Konflikt. Offen: Graph aus der Produktion exportieren und D07 damit erzeugen; in Workshop 3 je Regel die Behandlung entscheiden und mit der Revision abstimmen; die 11 Funktionen ohne Standardaufgabe und eigene Aufgaben mit denselben Rechten im Katalog nachtragen; klären, ob die Aufgabenpaare (Blatt „D365_Regeln“) in D365 als Regeln zur Aufgabentrennung eingetragen werden. Der Entwurf `D07_Funktionstrennungs_Matrix.xlsx` vom 29.10. (20 Regeln, Skript) ist damit überholt.
- [ ] **D20 Rollenkonsolidierung** (seit 29.10.2026 aus Code, `D20_Rollenkonsolidierung.Rmd`): AOT-Rollen und ihre Kopien aus der Oberfläche werden zusammengeführt, bevor eine Rolle geändert wird (Strategie: Bekannte Probleme, Prinzip 11, Phase 1 Schritt 1, Kapitel 6, 8, 11). Je Paar eine Zeile mit Ergebnis („Keine Unterschiede“ = nicht anfassen, „Unterschiede“ = Merge-Rolle `<AOT-Name>_MERGED`, „Nicht geladen“), Arbeitsgrundlage, Änderung des Werkzeugs und Spalten für Entscheidung, Import, bereinigte Rolle, Umstellung der Benutzer und Entfernen der alten Versionen. **Festgelegt 30.10.2026:** Das Mergen ist ein Arbeitsschritt der IT, damit nur mit einer Rolle gearbeitet wird; die Merge-Rolle wird niemandem zugewiesen. Analyse, Bereinigung und Funktionstrennung laufen auf ihr; die Benutzer erhalten erst die bereinigte Rolle (D02 Abschnitt 4.1: Security Architect A/R, IT-Leitung und Owner informiert; Spielregel 9). Bisher nur mit Testdaten geprüft. Die Merge-Rollen werden als Arbeitsgrundlage in INT importiert (festgelegt 30.10.2026). Offen: erster Lauf in ADN (Laufzeit mit Lizenzvergleich etwa eine halbe Minute je Paar).
- [ ] **D21 Lizenzprofil je Benutzer** (seit 30.10.2026 aus Code, `D21_Lizenzprofil_Benutzer.Rmd`): je Benutzer die Lizenzen, die seine Arbeit laut Telemetrie braucht, gegen das, was PPAC erwartet, schon zugewiesen und noch nicht zugewiesen hat; wer eine Lizenz verlieren könnte, welche fehlenden Lizenzen nicht gekauft werden müssen (Strategie Phase 1 Schritt 3, Phase 7, Kapitel 6, 11; D02 Abschnitt 4 und 5). Bisher nur mit Testdaten geprüft. Offen: erster Lauf mit den Berichten vom 27./28.10. (Bericht je Benutzer, Detailbericht Prod, Telemetrie, Graph); Graph aus Prod statt ADN; mit Datenschutz und Betriebsrat klären, wer das Blatt „Benutzer“ sehen darf.
- [ ] **D22 UI-Aufgaben, D23 UI-Rechte, D24 Inventur der UI-Objekte** (seit 30.10.2026 aus Code, `D22_UI_Aufgaben.Rmd`, `D23_UI_Rechte.Rmd`, `D24_UI_Inventur.Rmd`): UI-Objekte (Bezeichner GUID) sollen überall durch ihr AOT-Pendant gleichen Namens ersetzt werden. D22/D23 vergleichen je UI-Aufgabe die Rechte bzw. je UI-Recht die Einstiegspunkte mit Zugriffsrechten (gleich, Unterschiede, kein Pendant, mehrere, nicht lesbar); D24 listet je UI-Objekt jede Fundstelle (UI-Rolle als Unterrolle, UI-Aufgabe in Rolle, UI-Recht in Aufgabe oder Rolle). Bisher nur mit Testdaten geprüft. Offen: erster Lauf in ADN (laut Export vom 25.10.: 99 UI-Rollen, 30 UI-Aufgaben, 27 UI-Rechte); prüfen, ob `UserSecGovRelatedObjects` die GUIDs der UI-Aufgaben und UI-Rechte so schreibt wie `SECURITYDUTY`/`SECURITYPRIVILEGE` und ob `SYSTEMSECURITYSUBROLEENTITY` nur direkte Unterrollen enthält (sonst stünden in D24 auch mittelbare Fundstellen). **Festgelegt 30.10.2026:** Ein Verbot, Objekte in der Oberfläche anzulegen, ist nicht machbar: Schnelle Rollenanpassungen in Prod erfolgen in der Oberfläche, weil die AOT-Fassung (Deployment INT, Test INT, Deployment Prod) Wochen braucht; sie werden im AOT nachgezogen und danach entfernt (D02 Spielregel 10 und Zeile in 4.2, Strategie Phase 7). D24 läuft deshalb auch im Betrieb. Offen: Geänderte AOT-Rollen (Liste „geändert“ im Export der Sicherheitskonfiguration) erfasst D24 nicht, weil sie keine GUID haben; prüfen, ob die Datenbank solche Änderungen erkennbar macht, damit das Werkzeug sie mitlisten kann.
- [ ] Deliverable-Dateien tragen die Nummer als Präfix (`D05_…`, `D19_…`). Seit 30.10.2026 auch die Strategie: `D01_Berechtigungskonzept_Strategie.Rmd`. Nummern D18 (Sperrliste) und D19 (Prozess-Rollen-Matrix) sind vorläufig und kommen in Kapitel 6.
- [ ] **Projektstruktur (festgelegt 31.10.2026):** `R/` Code, `Data/Documentation/` Rmd-Dateien, `Data/Deliverables/` alle Deliverables (Excel und Word, feste Namen `D<nn>_…`), `Data/SecurityObjects/` Sicherheitsobjekte (`AxSecurityRole/`, `AxSecurityDuty/`, `AxSecurityPrivilege/` wie im Visual-Studio-Modell, `SecurityConfiguration/`, `SecurityGovernance/`), `Data/Reports/` Berichte; alles wird committet außer `Data/Reports/Klartext/` (Berichte mit echten Benutzerkennungen aus der Datenbank, `.gitignore`). Dateien aus pseudonymisierten Eingaben (PPAC, Telemetrie) werden committet. Keine vollen Pfade: Die Rmds finden das Projekt selbst, leere Pfadparameter nehmen den Platz im Projekt; ein Deliverable wird gelesen, die Einträge des Teams übernommen, dann ersetzt (frühere Stände in Git). D03 schreibt seit 31.10. auch seine Excel-Datei und D04 (Ranglisten nach PPAC und nach dem Lizenzgraphen, Bereinigungsplan). Offen: (1) Die Berichte Analyse_Rolle_Lizenzen und Vorschlag_Rolle_SCM schreiben ihre Lizenzrollen (XML) noch zusammen mit den Arbeitsmappen nach `Data/Reports/Klartext/…`; damit die XML nach `Data/SecurityObjects` kommen, muss `build_license_roles()` die Arbeitsmappe mit Benutzern getrennt ablegen. (2) Erledigt 31.10.2026: Die älteren Anleitungen nehmen ihre Pfade aus `inst/config/config.yml`. (3) `Entscheidungsvorlage_Datenbankkapazitaet` (passt zu D17) und `Bericht_Funktionsduplikate.html` liegen ohne D-Nummer und nicht committet in `Data/Documentation`.
- [ ] **Entwürfe vom 26.10.2026 prüfen und abstimmen** (sie liegen seit 31.10.2026 in `Data/Deliverables`, davor in `Data/Documentation` und `Input/Excel/Strategie`; seit 30.10.2026 im Repository):
  - `Data/Deliverables/D05_Rollenkatalog.xlsx`: 21 Rollen (9 neue Gesellschaft, 8 Vorschläge Vertrieb, 4 Bestand); maßgebliche Liste, D19 ist nur die Arbeitskopie. Die Herkunft heißt dort noch „Neue Gesellschaft“, in D06 seit 30.10.2026 „Service+“: angleichen.
  - `Data/Deliverables/D06_Stellen_Rollen.xlsx` (Stand 30.10.2026): 11 Stellen, 2 in der Logistik (Service+) und 9 im Vertrieb (Pflege+). Die Sammelstelle IDV (STE-003) wird fachlich abgelöst durch STE-008 Kundendaten- und Konditionsmanagement (3 Personen), STE-009 Angebots- und Ausschreibungsmanagement (6), STE-010 Sales Operations (11) und STE-011 Reklamations- und Retourenmanagement (8), mit den Rollen ROL-010 bis ROL-015. Offen: Abkürzungen IDV.TL und AD.TL mit der Personalabteilung abgleichen; STE-003 hat im Blatt „Stellen_Rollen“ noch seine fünf Rollen ohne „Gültig bis“; STE-009 und STE-010 haben dieselben Rollen (ROL-010, ROL-011, ROL-012), im Workshop klären, worin sie sich unterscheiden; Rollen für STE-001 und STE-002 in Workshop 1 festlegen; Textil+ steht in der Auswahlliste, hat aber noch keine Stelle.
  - `Data/Deliverables/D18_Sperrliste.xlsx`: 7 aktive Objekte aus „Tabelle2“, 3 Vorschläge (Stammdaten); Systemnamen ergänzen.
  - `Data/Documentation/D08_Workshop_Paket.Rmd`, Word in `Data/Deliverables`: Workshops 1–4, seit 31.10.2026 jeder mit Ziel, Teilnehmern, Vorbereitung, Ablauf, Regeln, Nachbereitung, Abnahmekriterium und eigener Einladung; dazu die Protokollvorlage.
  - `Data/Documentation/D09_Leitfaden_Aufgabenaufzeichnungen.Rmd`, Word in `Data/Deliverables`: Ablageort der Aufzeichnungen festlegen; Menüpfade in D365 gegenprüfen.
- [ ] **D19 Prozess-Rollen-Matrix** (Entwurf erstellt am 26.10.2026: `Data/Deliverables/D19_Prozess_Rollen_Matrix.xlsx`; enthält auch die Entwürfe für D05 und D06): mit den Key-Usern füllen, als Deliverable in Kapitel 6 aufnehmen, Einlesefunktion fürs Paket bauen (beim Einlesen `sep.names = " "` setzen, sonst werden Leerzeichen in Spaltennamen zu Punkten).
- [ ] **Prozessdokumentation:** Spalte „Verantwortung“ trennen in „Verantwortlich (Rolle)“ und „Ausführende Rolle(n)“, nur mit Namen aus dem Rollenkatalog (Beispiel „Angebotserstellung S+“, dort heute „IDM“).
- [ ] **Strang A (Stand 31.10.2026):** läuft mit hoher Priorität, weil Microsoft im Oktober 2026 Kollegen ohne Lizenz den Zugriff verweigert hat. Bereitstellung je Strang: Strang A in Wellen, sobald der Test bestanden ist (D01, Phase 1); Strang B in Phase 6. Getestet werden Prozesse mit den vorhandenen Testfällen, nicht die Rollen. Fehlt eine Funktion: Ticket und Nachbesserung; ohne Lizenzänderung in die Rolle, sonst Zusatzrolle. Steht in D01, D02 (Spielregeln 11, 12 und zwei neue Zeilen in 4.1), D03, D08, D11 und im Testticket. Offen:
  - Die Tests der drei auf SCM reduzierten Rollen abschließen (`_WIBU Verkauf Innendienst Mitarbeiter`, `_WIBU Einkauf Mitarbeiter`, `_WIBU Stammdaten Kunden Manager`) und Go-Live Mitte November 2026 entscheiden; die bisherigen Rollen sind der Rückfallweg.
  - Rückfall: Die bisherigen Rollen verlangen wieder die höheren Lizenzen. Prüfen, wer dann ohne passende Lizenz wäre.
  - D02: Die neuen Zeilen und Spielregeln sind ein Vorschlag der IT.
- [ ] **D17 Kapazitätsprognose** (seit 31.10.2026 aus Code, `D17_Kapazitaetsprognose.Rmd`, Excel und Word in `Data/Deliverables`): Blatt „Überblick“ mit dem aktuellen Stand, je Stand ein Blatt mit dem Datum als Namen. Eingaben ohne Personendaten in `Data/Input/PPAC/Capacity_JJJJ-MM-TT.xlsx`, die neueste als erster Eintrag der Liste `staende`. Die `.xlsx` wird aus allen Eingaben neu geschrieben; fehlt eine Eingabe, bricht der Lauf ab, damit die Historie erhalten bleibt. Offen: neuen Stand erfassen (siehe Abschnitt B).
- [ ] **Zentrale Konfiguration (31.10.2026, `inst/config/config.yml`, `R/project_config.R`):** Die Rmds nehmen ihre Pfade aus der Konfiguration; ein Parameter geht vor. Die Wurzeln sind relativ (`.`, `../Input`, `../Output`, `../Keys`). Beschrieben in `Dokumentation.Rmd`, „The configuration", Mapping in `Protokoll_RMD_Config_Pfade.md`. D03, D07, D17 und D21 ergeben damit dieselben Excel-Inhalte. Offen:
  - D20, D22, D23, D24, Analyse, Vorschlag und Rollenvergleich laden Daten aus der Datenbank: Sie sind nur auf Syntax geprüft, ein Lauf in ADN steht aus.
  - `packages_local_dir` ist der einzige volle Pfad in der Konfiguration (Rechner CKAM, Version 10.0.2645.90).
  - Das Zip für ADN muss `inst/config/config.yml` enthalten; `Keys` und die Rohdaten nicht.
  - **Zwei Stufen (02.11.2026):** Stufe 1 `pseudonymize_license_data()` schreibt nach `Data/Input/PPAC/pseudonymized`, Stufe 2 liest nur von dort. Die Telemetrie für Analyse und Vorschlag kommt deshalb aus der pseudonymisierten Datei; sie brauchen dafür `Keys/anonymization_key.xlsx`. Der Schlüssel liegt bisher in ADN unter `RProjects/Keys` und muss nach `Keys` im Projekt, sonst brechen beide mit einer Meldung ab.
  - `.gitignore` hält `Keys/`, die Rohdaten und `PPAC/pseudonymized/` aus dem Repository, ebenso die Listen in `Stakeholder`: `Abteilung_Tätigkeit_Mitarbeitende.xlsx` nennt echte Namen. Zu klären: Sollen die pseudonymisierten Eingaben ins Repository?
  - Der Lizenzgraph bleibt außerhalb des Projekts in `RProjects/Input/Excel/Database`.
  - Telemetrie läuft überall über `read_usage_telemetry()` (`insights`, xlsx, rds, RData). Der Schlüssel `anonymization_key.xlsx` in `keys_root` wird gebraucht, sobald Pseudonyme zurückgeführt oder echte Kennungen pseudonymisiert werden; in ADN prüfen, ob er zu den PPAC-Berichten passt.
  - Die Beispiele in `Dokumentation.Rmd` nennen weiter Pfade wie `C:/Input/...`; es sind Nachschlage-Beispiele, kein laufender Code.
- [x] **D11 Testdaten (festgelegt 31.10.2026):** Die Kollegen sind frei, wie sie testen: Sie können Daten anlegen oder vorhandene Daten nehmen. Steht in D11 Abschnitt 2 und D01 Kapitel 5 und 8.
