# The workbook of the personal project plan (Data/Input/Projektplan/Projektplan.xlsx) in small:
# two lanes, a few activities and milestones. Arguments replace whole sheets; leave_out names
# sheets to leave out.

plan_activities <- function() {
  data.frame(
    ID = c("A-01", "A-02", "B-01", "P-01"),
    Bahn = c("Strang A", "Strang A", "Strang B", "Strang B"),
    "Aktivität" = c("Rollen testen", "Rangliste rechnen", "Workshop 1", "Integrationstest"),
    Start = c("02.11.2026", "2026-11-09", "46357", ""),
    Ende = c("13.11.2026", "2026-11-27", "46367", ""),
    Art = c("eigene", "eigene", "", "Projekt"),
    Termin = c("fest", "Annahme", "", "Annahme"),
    Status = c("läuft", "geplant", "", "geplant"),
    Verantwortlich = c("IT D365", "IT D365", "IT D365", "Projektleitung"),
    Deliverable = c("D11", "D04", "D08", ""),
    Bemerkung = "",
    check.names = FALSE, stringsAsFactors = FALSE
  )
}

plan_milestones <- function() {
  data.frame(
    ID = c("A-M01", "P-M01"),
    Bahn = c("Strang A", "Strang B"),
    Meilenstein = c("Welle 1 in Prod", "Go-Live"),
    Datum = c("16.11.2026", "15.06.2027"),
    Art = c("eigene", "Projekt"),
    Termin = c("Annahme", "Annahme"),
    Status = c("geplant", "geplant"),
    "Linie über alle Bahnen" = c("nein", "ja"),
    Kriterium = c("Test bestanden", ""),
    Deliverable = c("D11", ""),
    Bemerkung = "",
    check.names = FALSE, stringsAsFactors = FALSE
  )
}

plan_lanes <- function() {
  data.frame(Bahn = c("Strang A", "Strang B"), Farbe = c("#2a78d6", ""), stringsAsFactors = FALSE)
}

plan_settings <- function() {
  data.frame(Feld = c("Plan von", "Plan bis", "Heute", "Vorschau (Tage)"),
             Wert = c("01.10.2026", "31.08.2027", "10.11.2026", "14"), stringsAsFactors = FALSE)
}

project_plan_file <- function(path, activities = plan_activities(), milestones = plan_milestones(),
                              lanes = plan_lanes(), settings = plan_settings(), leave_out = character()) {
  sheets <- list("Aktivitäten" = activities, "Meilensteine" = milestones, "Listen" = lanes,
                 "Einstellungen" = settings)
  wb <- openxlsx::createWorkbook()
  for (name in setdiff(names(sheets), leave_out)) {
    openxlsx::addWorksheet(wb, name)
    openxlsx::writeData(wb, name, sheets[[name]])
  }
  openxlsx::saveWorkbook(wb, path, overwrite = TRUE)
  path
}

project_plan_of <- function(..., env = parent.frame()) {
  folder <- withr::local_tempdir(.local_envir = env)
  read_project_plan(project_plan_file(file.path(folder, "Projektplan.xlsx"), ...))
}
