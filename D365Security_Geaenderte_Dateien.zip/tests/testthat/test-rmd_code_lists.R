# The Rmds load the code without the package (code_laden = "dateien", the zip for ADN) from the list
# `files <- c(...)` (the playbook) or `dateien <- c(...)`. A file missing in that list breaks a report
# only on a machine without the package.

# The open bracket ends the line: a one-line c("...") of an example is no code list.
LIST_START <- "^ *(files|dateien|code_dateien) *<- *c[(] *$"

rmd_code_list <- function(rmd) {
  text  <- readLines(rmd, encoding = "UTF-8", warn = FALSE)
  first <- grep(LIST_START, text)
  if (length(first) == 0L) return(NULL)
  last  <- first[[1]] + which(grepl("^ *[)]", text[(first[[1]] + 1):length(text)]))[[1]]
  eval(parse(text = sub("^ *[A-Za-z_]+ *<- *", "", paste(text[first[[1]]:last], collapse = "\n"))))
}

project_root <- function() testthat::test_path("..", "..")

code_lists <- function() {
  docs <- file.path(project_root(), "Data", "Documentation")
  rmds <- list.files(docs, "[.]Rmd$", full.names = TRUE)
  Filter(Negate(is.null), stats::setNames(lapply(rmds, rmd_code_list), basename(rmds)))
}

test_that("the code-file lists of the Rmds are equal and name files of R/", {
  skip_if_not(dir.exists(file.path(project_root(), "Data", "Documentation")), "Data/Documentation not present")
  lists <- code_lists()
  reference <- lists[["Playbook_Role_License_Report_Acceptance_ADN.Rmd"]]

  expect_gte(length(lists), 12L)
  expect_true(all(vapply(lists, identical, logical(1), reference)))
  expect_equal(setdiff(reference, list.files(file.path(project_root(), "R"))), character(0))
})

# The names every file of R/ defines at the top level, with or without the list.
project_definitions <- function() {
  lines <- unlist(lapply(list.files(file.path(project_root(), "R"), "[.]R$", full.names = TRUE),
                         readLines, encoding = "UTF-8", warn = FALSE))
  defined <- regmatches(lines, regexpr("^[.A-Za-z][.A-Za-z0-9_]* *(<-|=)", lines))
  unique(sub(" *(<-|=)$", "", defined))
}

test_that("the files of the lists define every function they call", {
  skip_if_not(dir.exists(file.path(project_root(), "Data", "Documentation")), "Data/Documentation not present")
  skip_if_not_installed("codetools")
  skip_if_not("package:stats" %in% search(), "package:stats not attached")
  files <- code_lists()[["Playbook_Role_License_Report_Acceptance_ADN.Rmd"]]
  # Only the standard packages around it: the loaded package must not hide a missing file.
  env <- new.env(parent = as.environment("package:stats"))
  for (file in files) source(file.path(project_root(), "R", file), local = env, encoding = "UTF-8")
  project <- project_definitions()

  # := belongs to the syntax of dplyr; analyze_role_license_decision() needs further files, as the playbook says.
  known <- c(":=")
  unresolved <- character(0)
  for (name in setdiff(ls(env, all.names = TRUE), "analyze_role_license_decision")) {
    fun <- get(name, envir = env)
    if (!is.function(fun)) next
    globals <- codetools::findGlobals(fun, merge = FALSE)
    # A function handed over as a value, as in lapply(x, .helper), is a variable to findGlobals.
    used    <- setdiff(c(globals$functions, intersect(globals$variables, project)), known)
    missing <- used[!vapply(used, exists, logical(1), envir = env)]
    if (length(missing) > 0L) unresolved <- c(unresolved, paste0(name, " -> ", missing))
  }

  expect_equal(unresolved, character(0))
})
