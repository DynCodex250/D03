# The central configuration of the Rmd files (inst/config/config.yml).

config_lines <- c(
  "default:",
  "  connection:",
  '    credentials_path: "db_credentials.xlsx"',
  "  base_paths:",
  '    project_root: "."',
  '    input_root: "../Input"',
  '    keys_root: "C:/Schluessel"',
  "    subdirs_input:",
  '      ppac: "Excel/PPAC"'
)

local_project <- function(lines = config_lines, env = parent.frame()) {
  base    <- withr::local_tempdir(.local_envir = env)
  project <- file.path(base, "Projekt")
  dir.create(file.path(project, "inst", "config"), recursive = TRUE)
  dir.create(file.path(project, "Data", "Documentation"), recursive = TRUE)
  dir.create(file.path(base, "Input"))
  writeLines(lines, file.path(project, "inst", "config", "config.yml"))
  normalizePath(project, winslash = "/")
}

test_that("load_project_config turns relative roots into full paths from the project", {
  project <- local_project()

  cfg <- load_project_config(project)

  expect_equal(cfg$base_paths$project_root, project)
  expect_equal(cfg$base_paths$input_root, file.path(dirname(project), "Input"))
  expect_equal(cfg$base_paths$keys_root, "C:/Schluessel")
  expect_equal(cfg$base_paths$subdirs_input$ppac, "Excel/PPAC")
  expect_equal(cfg$connection$credentials_path, "db_credentials.xlsx")
})

test_that("load_project_config finds the project from the project folder and from Data/Documentation", {
  project <- local_project()

  from_root <- withr::with_dir(project, load_project_config())
  from_rmds <- withr::with_dir(file.path(project, "Data", "Documentation"), load_project_config())

  expect_equal(from_root$base_paths$project_root, project)
  expect_equal(from_rmds$base_paths$project_root, project)
})

test_that("load_project_config warns and gives the default folders when the file is missing", {
  project <- normalizePath(withr::local_tempdir(), winslash = "/")

  expect_warning(cfg <- load_project_config(project), "config.yml")

  expect_equal(cfg$base_paths$project_root, project)
  expect_match(cfg$base_paths$input_root, "Input$")
  expect_match(cfg$base_paths$output_root, "Output$")
  expect_match(cfg$base_paths$keys_root, "Keys$")
  expect_equal(cfg$connection$credentials_path, "db_credentials.xlsx")
})

test_that("load_project_config stops on a file without the section default", {
  project <- local_project(c("anders:", '  a: "b"'))

  expect_error(load_project_config(project), "default")
})

test_that("resolve_path prefers the parameter, then the configuration, then the fallback", {
  project <- local_project()
  input   <- file.path(dirname(project), "Input")

  expect_equal(resolve_path("D:/Eigen/x.csv", "a.csv", input, project, "b.csv"), "D:/Eigen/x.csv")
  expect_equal(resolve_path("", "Excel", input, project, "b.csv"), file.path(input, "Excel"))
  expect_equal(resolve_path("", "", input, project, "Data"), file.path(project, "Data"))
  expect_equal(resolve_path("", NULL, input, project, "Data"), file.path(project, "Data"))
})

test_that("resolve_path counts a relative parameter from the project, not from the input root", {
  project <- local_project()

  expect_equal(resolve_path("Data", "a.csv", file.path(dirname(project), "Input"), project), file.path(project, "Data"))
})

test_that("resolve_path gives an empty path when nothing is set, so that optional inputs stay off", {
  project <- local_project()

  expect_equal(resolve_path("", "", project), "")
  expect_equal(resolve_path(NULL, NULL, NULL), "")
  expect_equal(resolve_path("  ", "  ", project, project, "  "), "")
})

test_that("the parameter none switches an input off, whatever the configuration says", {
  project <- local_project()

  expect_equal(resolve_path("none", "Data", project, project), "")
  expect_equal(resolve_path(" None ", "Data", project, project, "Data"), "")
})

test_that("an optional input from the configuration that does not exist stays off, with a warning", {
  project <- local_project()

  expect_warning(path <- resolve_path("", "fehlt.csv", project, project, optional = TRUE), "fehlt.csv")
  expect_equal(path, "")
})

test_that("an optional input that exists is used, and a required one is left for the caller to report", {
  project <- local_project()

  expect_equal(resolve_path("", "Data", project, project, optional = TRUE), file.path(project, "Data"))
  expect_no_warning(path <- resolve_path("", "fehlt.csv", project, project))
  expect_match(path, "fehlt.csv$")
})

test_that("a parameter is never switched off because its file is missing: the error must show", {
  project <- local_project()

  expect_no_warning(path <- resolve_path("D:/Eigen/fehlt.csv", "Data", project, project, optional = TRUE))
  expect_equal(path, "D:/Eigen/fehlt.csv")
})

test_that("resolve_telemetry keeps the keyword insights and resolves everything else as a path", {
  project <- local_project()

  expect_equal(resolve_telemetry("insights", "Data", project, project), "insights")
  expect_equal(resolve_telemetry("", " Insights ", project, project), "insights")
  expect_equal(resolve_telemetry("", "", project, project, fallback = "insights"), "insights")
  expect_equal(resolve_telemetry("Data", "insights", project, project), file.path(project, "Data"))
  expect_equal(resolve_telemetry("", "Data", project, project), file.path(project, "Data"))
  expect_equal(resolve_telemetry("none", "insights", project, project), "")
  expect_equal(resolve_telemetry("", "", project, project), "")
})

test_that("resolve_telemetry passes optional on to resolve_path", {
  project <- local_project()

  expect_warning(path <- resolve_telemetry("", "fehlt.xlsx", project, project, optional = TRUE), "fehlt.xlsx")
  expect_equal(path, "")
})

test_that("resolve_path takes a full path from the configuration as it stands", {
  project <- local_project()

  expect_equal(resolve_path("", "K:/AosService/PackagesLocalDirectory", project), "K:/AosService/PackagesLocalDirectory")
})

test_that("resolve_path works without a base root, as when the configuration is missing", {
  project <- local_project()

  expect_equal(resolve_path("", "Data", NULL, project), file.path(project, "Data"))
})

# ---- the file of the project ------------------------------------------------------------------------

project_config_path <- function() test_path("..", "..", "inst", "config", "config.yml")

test_that("the roots of the project configuration hold no full path, so that it works on every machine", {
  skip_if_not(file.exists(project_config_path()))
  roots <- yaml::yaml.load_file(project_config_path())$default$base_paths

  expect_equal(roots$project_root, ".")
  expect_equal(roots$input_root, "Data/Input")
  expect_equal(roots$output_root, "../Output")
  expect_equal(roots$keys_root, "Keys")
  expect_equal(roots$legacy_input_root, "../Input")
  expect_false(any(grepl("repo_path|data_path", readLines(project_config_path(), encoding = "UTF-8"))))
})

test_that("the analysis deliverables read pseudonymized data only", {
  skip_if_not(file.exists(project_config_path()))
  cfg <- yaml::yaml.load_file(project_config_path())$default

  for (section in list(cfg$d03_bestands_und_lizenzanalyse$inputs, cfg$d21_lizenzprofil_benutzer$inputs)) {
    expect_match(section$ppac_detail, "^PPAC/pseudonymized/")
    expect_match(section$ppac_bericht, "^PPAC/pseudonymized/")
    expect_match(section$telemetrie, "^PPAC/pseudonymized/")
  }
  expect_match(cfg$d07_funktionstrennungs_matrix$inputs$ppac_detail, "^PPAC/pseudonymized/")
})

test_that("the graph lies outside the project, next to it", {
  skip_if_not(file.exists(project_config_path()))
  cfg <- yaml::yaml.load_file(project_config_path())$default

  expect_equal(cfg$d03_bestands_und_lizenzanalyse$inputs$graph_ordner, "../../../Input/Excel/Database")
  expect_equal(cfg$d07_funktionstrennungs_matrix$inputs$graph_ordner, "../../../Input/Excel/Database")
  expect_equal(cfg$d21_lizenzprofil_benutzer$inputs$graph_ordner, "../../../Input/Excel/Database")
})

test_that("the catalog of segregation of duties comes from the stakeholders", {
  skip_if_not(file.exists(project_config_path()))
  cfg <- yaml::yaml.load_file(project_config_path())$default

  expect_equal(cfg$d07_funktionstrennungs_matrix$inputs$katalog, "Data/Input/Stakeholder/SoD_Katalog.xlsx")
})

test_that("the credentials stand in one place of the project configuration", {
  skip_if_not(file.exists(project_config_path()))
  lines <- readLines(project_config_path(), encoding = "UTF-8")

  expect_false(any(grepl("^ +cred_path:", lines)))
  expect_equal(yaml::yaml.load_file(project_config_path())$default$connection$credentials_path, "db_credentials.xlsx")
})

test_that("reports with real user ids stay in the folder Git leaves out", {
  skip_if_not(file.exists(project_config_path()))
  cfg <- yaml::yaml.load_file(project_config_path())$default

  expect_match(cfg$analyse_rolle_lizenzen$params$export_ordner, "^Data/Reports/Klartext/")
  expect_match(cfg$vorschlag_rolle_scm$params$export_ordner, "^Data/Reports/Klartext/")
  expect_match(cfg$rollen_vergleich_und_merge_szenarien$params$ausgabe, "^Data/Reports/Klartext/")
})

test_that("the role reports read the pseudonymized telemetry by default", {
  skip_if_not(file.exists(project_config_path()))
  cfg <- yaml::yaml.load_file(project_config_path())$default

  expect_equal(cfg$analyse_rolle_lizenzen$params$telemetrie, "PPAC/pseudonymized/Telemetrie_pseudonymized.xlsx")
  expect_equal(cfg$vorschlag_rolle_scm$params$telemetrie, "PPAC/pseudonymized/Telemetrie_pseudonymized.xlsx")
})

test_that("the configuration names one key file, the price list in Input and the graph of ADN", {
  skip_if_not(file.exists(project_config_path()))
  cfg <- yaml::yaml.load_file(project_config_path())$default

  expect_equal(cfg$pseudonymization$key_file, "anonymization_key.xlsx")
  expect_null(cfg$playbook_role_license_report_acceptance_adn$inputs$anonymization_key)
  expect_equal(cfg$d03_bestands_und_lizenzanalyse$inputs$preise, "PPAC/skuPrices.xlsx")
  expect_equal(cfg$d21_lizenzprofil_benutzer$inputs$preise, "PPAC/skuPrices.xlsx")
  expect_equal(cfg$d07_funktionstrennungs_matrix$params$graph_umgebung, "ADN")
})

test_that("without the file the key file has its default name", {
  project <- normalizePath(withr::local_tempdir(), winslash = "/")

  cfg <- suppressWarnings(load_project_config(project))

  expect_equal(cfg$pseudonymization$key_file, "anonymization_key.xlsx")
})
