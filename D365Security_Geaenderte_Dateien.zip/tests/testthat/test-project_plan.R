# The personal project plan up to the go-live: one workbook, read on every knit of
# Data/Documentation/Projektplan.Rmd and drawn as a plan with lanes.

test_that("read_project_plan reads activities and milestones as one list of items", {
  plan <- project_plan_of()

  expect_equal(plan$Items$ID, c("A-01", "A-02", "B-01", "P-01", "A-M01", "P-M01"))
  expect_equal(plan$Items$KIND, c(rep("Aktivität", 4), rep("Meilenstein", 2)))
  expect_equal(plan$Items$TEXT[[5]], "Welle 1 in Prod")
  milestone <- plan$Items[plan$Items$ID == "P-M01", ]
  expect_equal(milestone$START, as.Date("2027-06-15"))
  expect_equal(milestone$END, as.Date("2027-06-15"))
  expect_true(milestone$LINE)
  expect_true(milestone$PROJECT)
  expect_true(milestone$ASSUMED)
})

test_that("read_project_plan takes dates as Excel numbers, as TT.MM.JJJJ and as JJJJ-MM-TT", {
  items <- project_plan_of()$Items

  expect_equal(items$START[1:3], as.Date(c("2026-11-02", "2026-11-09", "2026-12-01")))
  expect_equal(items$END[1:3], as.Date(c("2026-11-13", "2026-11-27", "2026-12-11")))
  expect_true(is.na(items$START[[4]]) && is.na(items$END[[4]]))
})

test_that("empty fields take their defaults: own work, fixed date, planned, no line", {
  item <- project_plan_of()$Items
  item <- item[item$ID == "B-01", ]

  expect_false(item$PROJECT)
  expect_false(item$ASSUMED)
  expect_equal(item$STATUS, "geplant")
  expect_false(item$LINE)
})

test_that("read_project_plan reads the settings and fills what is empty", {
  plan <- project_plan_of()
  expect_equal(plan$Settings$FROM, as.Date("2026-10-01"))
  expect_equal(plan$Settings$TO, as.Date("2027-08-31"))
  expect_equal(plan$Settings$TODAY, as.Date("2026-11-10"))
  expect_equal(plan$Settings$PREVIEW_DAYS, 14)

  open <- project_plan_of(leave_out = "Einstellungen")$Settings
  expect_equal(open$FROM, as.Date("2026-11-01"))
  expect_equal(open$TO, as.Date("2027-06-30"))
  expect_true(is.na(open$TODAY))
  expect_equal(open$PREVIEW_DAYS, 14)
})

test_that("lanes keep their order and colour; an empty colour takes the next one of the palette", {
  lanes <- project_plan_of()$Lanes
  expect_equal(lanes$LANE, c("Strang A", "Strang B"))
  expect_equal(lanes$COLOUR, c("#2a78d6", "#eb6834"))
})

test_that("read_project_plan names every wrong row at once", {
  activities <- plan_activities()
  activities$Ende[[1]]   <- "01.11.2026"
  activities$Bahn[[2]]   <- "Strang C"
  activities$Status[[3]] <- "fertig"
  milestones <- plan_milestones()
  milestones$ID[[2]] <- "A-01"

  error <- tryCatch(project_plan_of(activities = activities, milestones = milestones), error = conditionMessage)
  expect_match(error, "A-01: Ende vor Start")
  expect_match(error, "A-02: Bahn .Strang C.")
  expect_match(error, "B-01: Status .fertig.")
  expect_match(error, "doppelt: A-01")
})

test_that("an activity needs both dates or none, and a date must be one", {
  activities <- plan_activities()
  activities$Ende[[1]]  <- ""
  activities$Start[[2]] <- "31.02.2026"

  activities$Ende[[3]]  <- "01.01.1999"
  milestones <- plan_milestones()
  milestones$Datum[[1]] <- "16.13.2026"

  error <- tryCatch(project_plan_of(activities = activities, milestones = milestones), error = conditionMessage)
  expect_match(error, "A-01: Start und Ende")
  expect_match(error, "A-02: Start .31.02.2026. ist kein Datum")
  expect_match(error, "B-01: Ende 01.01.1999 liegt vor 2000")
  expect_match(error, "A-M01: Datum .16.13.2026. ist kein Datum")
})

test_that("a cell with the text NA stays text", {
  activities <- plan_activities()
  activities[["Aktivität"]][[1]] <- "NA"
  expect_equal(project_plan_of(activities = activities)$Items$TEXT[[1]], "NA")
})

test_that("a typo in the settings stops instead of being ignored", {
  settings <- plan_settings()
  settings$Feld[[3]] <- "heute"
  expect_error(project_plan_of(settings = settings), "heute")

  settings <- plan_settings()
  settings$Wert[[4]] <- "zwei"
  expect_error(project_plan_of(settings = settings), "Vorschau")
})

test_that("items outside the range of the drawing get their own list instead of an empty row", {
  settings <- plan_settings()
  settings$Wert[[2]] <- "31.03.2027"
  plan <- project_plan_of(settings = settings)
  grDevices::pdf(NULL, width = 13, height = project_plan_height(plan))
  on.exit(grDevices::dev.off())

  rows <- plot_project_plan(plan, today = as.Date("2026-11-16"))
  expect_false("P-M01" %in% rows$ID)
  expect_equal(project_plan_tables(plan, today = as.Date("2026-11-16"))$Outside$ID, "P-M01")
})

test_that("read_project_plan names a missing file, sheet and column and a wrong colour", {
  folder <- withr::local_tempdir()
  expect_error(read_project_plan(file.path(folder, "fehlt.xlsx")), "nicht gefunden")
  expect_error(project_plan_of(leave_out = "Meilensteine"), "Meilensteine")

  activities <- plan_activities()
  activities$Status <- NULL
  expect_error(project_plan_of(activities = activities), "Status")

  lanes <- plan_lanes()
  lanes$Farbe[[1]] <- "blau"
  expect_error(project_plan_of(lanes = lanes), "blau")
})

test_that("a sheet with headers only is a plan without such rows", {
  plan <- project_plan_of(milestones = plan_milestones()[0, ])
  expect_equal(sum(plan$Items$KIND == "Meilenstein"), 0)
  expect_equal(nrow(plan$Items), 4)
})

test_that("project_plan_tables sorts open work into overdue, upcoming and undated", {
  tables <- project_plan_tables(project_plan_of(), today = as.Date("2026-11-16"))

  expect_equal(tables$Overdue$ID, "A-01")
  expect_equal(tables$Upcoming$ID, c("A-02", "A-M01"))
  expect_equal(tables$Undated$ID, "P-01")
  expect_equal(tables$Upcoming$Von[[1]], "09.11.2026")
})

test_that("done and dropped work is neither overdue nor upcoming", {
  activities <- plan_activities()
  activities$Status[1:2] <- c("erledigt", "entfällt")
  tables <- project_plan_tables(project_plan_of(activities = activities), today = as.Date("2026-11-16"))

  expect_equal(nrow(tables$Overdue), 0)
  expect_false(any(c("A-01", "A-02") %in% tables$Upcoming$ID))

  activities$Status[[4]] <- "erledigt"
  expect_equal(nrow(project_plan_tables(project_plan_of(activities = activities))$Undated), 0)
})

test_that("project_plan_tables takes today from the settings when no day is given", {
  tables <- project_plan_tables(project_plan_of())
  expect_equal(tables$Today, as.Date("2026-11-10"))
  expect_equal(tables$Overdue$ID, character())
})

test_that("plot_project_plan draws a header per lane and one row per dated item", {
  plan <- project_plan_of()
  grDevices::pdf(NULL, width = 13, height = project_plan_height(plan))
  on.exit(grDevices::dev.off())

  rows <- plot_project_plan(plan, today = as.Date("2026-11-16"))
  expect_equal(rows$TEXT[rows$KIND == "Bahn"], c("Strang A", "Strang B"))
  expect_equal(rows$ID[rows$KIND != "Bahn"], c("A-01", "A-02", "A-M01", "B-01", "P-M01"))
})

test_that("project_plan_height grows with the rows of the plan", {
  plan  <- project_plan_of()
  small <- project_plan_of(activities = plan_activities()[1, ], milestones = plan_milestones()[0, ])
  expect_gt(project_plan_height(plan), project_plan_height(small))
})
