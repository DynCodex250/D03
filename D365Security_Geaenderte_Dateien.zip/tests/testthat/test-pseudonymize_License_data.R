# Stage 1: the raw files become the pseudonymized inputs of the deliverables.

raw_report <- function() {
  data.frame(UserEmail = c("anna.beispiel@example.com", "bert.muster@example.com"), UserId = c("id-1", "id-2"),
             TenantId = "tenant-1", "RequiredLicense(s)" = c("Commerce", "Finance"),
             "AssignedLicense(s)" = c("Commerce", "Finance"), "MissingLicense(s)" = "", RefreshedOn = "2026-10-27",
             check.names = FALSE, stringsAsFactors = FALSE)
}

raw_detail <- function() {
  data.frame(UserEmail = c("anna.beispiel@example.com", "bert.muster@example.com"), UserId = c("id-1", "id-2"),
             TenantId = "tenant-1", EnvironmentId = "env-1", EnvironmentName = "wibu-produktiv", EnvironmentType = "Production",
             SecurityRole = c("_WIBU Verkauf", "_WIBU Einkauf"), RequiredLicense = c("Commerce", "Finance"),
             "AssignedLicense(s)" = c("Commerce", "Finance"), RefreshedOn = "2026-10-27",
             check.names = FALSE, stringsAsFactors = FALSE)
}

raw_employees <- function() {
  data.frame(Personalnummer = c("1001", "1002"), "E-Mail" = c("anna.beispiel@example.com", "bert.muster@example.com"),
             Name = c("Beispiel", "Muster"), Vorname = c("Anna", "Bert"), "Voller Name" = c("Anna Beispiel", "Bert Muster"),
             "Name des Vorgesetzten" = c("Clara Chef", "Clara Chef"), "Gesellschaft\nName" = c("Service+", "Pflege+"),
             "Gesellschaft\nID" = c("0100", "0200"), "Name der Organisationseinheit" = c("Innendienst", "Einkauf"),
             check.names = FALSE, stringsAsFactors = FALSE)
}

raw_telemetry <- function() {
  tibble::tibble(user_Id = c("anna.beispiel", "bert.muster"), name = c("SalesTableListPage", "CustTableListPage"),
                 last_seen = c("2026-10-01", "2026-10-02"), touches = c(3, 4))
}

local_raw_files <- function(env = parent.frame()) {
  folder <- withr::local_tempdir(.local_envir = env)
  utils::write.csv(raw_report(), file.path(folder, "Report_20261027.csv"), row.names = FALSE)
  utils::write.csv(raw_detail(), file.path(folder, "Detailed_Report_20261027.csv"), row.names = FALSE)
  wb <- openxlsx::createWorkbook()
  openxlsx::addWorksheet(wb, "Mitarbeiter")
  openxlsx::writeData(wb, "Mitarbeiter", "Export vom 17.03.2026", startRow = 1, colNames = FALSE)
  openxlsx::writeData(wb, "Mitarbeiter", raw_employees(), startRow = 2)
  openxlsx::saveWorkbook(wb, file.path(folder, "Mitarbeiter_20260317.xlsx"))
  saveRDS(raw_telemetry(), file.path(folder, "telemetrie.rds"))
  writexl::write_xlsx(raw_telemetry(), file.path(folder, "telemetrie.xlsx"))
  list(folder = folder, output = file.path(folder, "pseudonymized"), key = file.path(folder, "Keys", "anonymization_key.xlsx"),
       report = file.path(folder, "Report_20261027.csv"), detail = file.path(folder, "Detailed_Report_20261027.csv"),
       employees = file.path(folder, "Mitarbeiter_20260317.xlsx"), rds = file.path(folder, "telemetrie.rds"),
       xlsx = file.path(folder, "telemetrie.xlsx"))
}

run_stage_1 <- function(raw, ...) {
  dir.create(dirname(raw$key), showWarnings = FALSE)
  suppressMessages(pseudonymize_license_data(raw$report, raw$detail, raw$output, raw$key, ...))
}

test_that("the reports lose the ids of Microsoft and every user id becomes a pseudonym", {
  raw    <- local_raw_files()
  result <- run_stage_1(raw)

  report <- utils::read.csv(result$report, check.names = FALSE)
  detail <- utils::read.csv(result$detail, check.names = FALSE)

  expect_false(any(c("UserId", "TenantId") %in% names(report)))
  expect_false(any(c("UserId", "TenantId", "EnvironmentId") %in% names(detail)))
  expect_match(report$USERID, "^USER_")
  expect_match(detail$USERID, "^USER_")
  expect_setequal(detail$SecurityRole, c("_WIBU Verkauf", "_WIBU Einkauf"))
  expect_setequal(report[["RequiredLicense(s)"]], c("Commerce", "Finance"))
  expect_false(any(grepl("example.com|anna|bert", readLines(result$report), ignore.case = TRUE)))
  expect_false(any(grepl("example.com|anna|bert", readLines(result$detail), ignore.case = TRUE)))
})

test_that("the files are named after the raw file and lie in the output folder", {
  raw    <- local_raw_files()
  result <- run_stage_1(raw)

  expect_equal(result$report, file.path(raw$output, "Report_20261027_pseudonymized.csv"))
  expect_equal(result$detail, file.path(raw$output, "Detailed_Report_20261027_pseudonymized.csv"))
  expect_equal(names(result), c("report", "detail"))
})

test_that("a user keeps one pseudonym across the files, so that they still match", {
  raw    <- local_raw_files()
  result <- run_stage_1(raw, employees_path = raw$employees, telemetry = raw$rds)

  report    <- utils::read.csv(result$report, check.names = FALSE)
  detail    <- utils::read.csv(result$detail, check.names = FALSE)
  employees <- readxl::read_excel(result$employees)
  telemetry <- readxl::read_excel(result$telemetry)

  expect_setequal(report$USERID, detail$USERID)
  expect_setequal(report$USERID, employees$USERID)
  expect_setequal(report$USERID, telemetry$user_Id)
})

test_that("the employee list keeps no name of a person, company or unit", {
  raw    <- local_raw_files()
  result <- run_stage_1(raw, employees_path = raw$employees)

  employees <- readxl::read_excel(result$employees)
  text      <- as.character(unlist(employees))

  expect_equal(basename(result$employees), "Mitarbeiter_20260317_pseudonymized.xlsx")
  expect_false(any(grepl("example.com|Anna|Bert|Beispiel|Muster|Clara|Service[+]|Innendienst|^1001$|^0100$", text)))
})

test_that("a column stage 1 does not know stops the run: it could hold personal data", {
  raw <- local_raw_files()
  utils::write.csv(cbind(raw_report(), UserDisplayName = c("Anna Beispiel", "Bert Muster")), raw$report, row.names = FALSE)

  expect_error(run_stage_1(raw), "UserDisplayName")
  expect_false(file.exists(raw$key))
  expect_false(dir.exists(raw$output))
})

test_that("an employee list with an unknown column stops the run as well", {
  raw <- local_raw_files()
  wb  <- openxlsx::createWorkbook()
  openxlsx::addWorksheet(wb, "Mitarbeiter")
  openxlsx::writeData(wb, "Mitarbeiter", cbind(raw_employees(), Geburtsdatum = "1980-01-01"), startRow = 2)
  openxlsx::saveWorkbook(wb, raw$employees, overwrite = TRUE)

  expect_error(run_stage_1(raw, employees_path = raw$employees), "Geburtsdatum")
  expect_false(file.exists(raw$key))
})

test_that("a line break in any header of the employee list does not let a name through", {
  raw       <- local_raw_files()
  employees <- raw_employees()
  names(employees) <- sub("Voller Name", "Voller\nName", names(employees), fixed = TRUE)
  names(employees) <- sub("Name der Organisationseinheit", "Name der\nOrganisationseinheit", names(employees), fixed = TRUE)
  names(employees) <- sub("Name des Vorgesetzten", "Name des\nVorgesetzten", names(employees), fixed = TRUE)
  wb <- openxlsx::createWorkbook()
  openxlsx::addWorksheet(wb, "Mitarbeiter")
  openxlsx::writeData(wb, "Mitarbeiter", employees, startRow = 2)
  openxlsx::saveWorkbook(wb, raw$employees, overwrite = TRUE)

  result <- run_stage_1(raw, employees_path = raw$employees)
  text   <- as.character(unlist(readxl::read_excel(result$employees)))

  expect_false(any(grepl("Anna|Bert|Clara|Innendienst", text)))
})

test_that("telemetry with an unknown column stops the run: it could hold personal data", {
  raw <- local_raw_files()
  saveRDS(cbind(raw_telemetry(), Anmeldename = "anna.beispiel"), raw$rds)

  expect_error(run_stage_1(raw, telemetry = raw$rds), "Anmeldename")
  expect_false(file.exists(raw$key))
})

test_that("an empty answer from Insights stops the run, so that it replaces no good file", {
  raw <- local_raw_files()
  run_stage_1(raw, telemetry = raw$rds)
  good <- readxl::read_excel(file.path(raw$output, "Telemetrie_pseudonymized.xlsx"))
  local_mocked_bindings(.load_insights_telemetry = function() data.frame())

  expect_error(run_stage_1(raw, telemetry = "insights", overwrite = TRUE), "no rows")
  expect_equal(nrow(readxl::read_excel(file.path(raw$output, "Telemetrie_pseudonymized.xlsx"))), nrow(good))
})

test_that("the known columns of the telemetry pass, also the duration", {
  raw <- local_raw_files()
  saveRDS(cbind(raw_telemetry(), duration_seconds = c(10, 20)), raw$rds)

  usage <- readxl::read_excel(run_stage_1(raw, telemetry = raw$rds)$telemetry)

  expect_setequal(names(usage), c("user_Id", "name", "last_seen", "touches", "duration_seconds"))
})

test_that("an empty column without a header, as the admin center writes it, falls away", {
  raw <- local_raw_files()
  writeLines(sub("^", ",", readLines(raw$report)), raw$report)

  report <- utils::read.csv(run_stage_1(raw)$report, check.names = FALSE)

  expect_false("" %in% names(report))
  expect_match(report$USERID, "^USER_")
})

test_that("a new key is refused while pseudonymized files of an older one lie in the folder", {
  raw <- local_raw_files()
  run_stage_1(raw)
  unlink(raw$key)

  expect_error(run_stage_1(raw, overwrite = TRUE), "key file")
  expect_false(file.exists(raw$key))
})

test_that("the telemetry is pseudonymized from every source and keeps its entry points", {
  raw <- local_raw_files()

  from_rds <- run_stage_1(raw, telemetry = raw$rds)
  usage    <- readxl::read_excel(from_rds$telemetry)
  expect_equal(basename(from_rds$telemetry), "Telemetrie_pseudonymized.xlsx")
  expect_match(usage$user_Id, "^USER_")
  expect_setequal(usage$name, c("SalesTableListPage", "CustTableListPage"))

  from_xlsx <- run_stage_1(raw, telemetry = raw$xlsx, overwrite = TRUE)
  expect_setequal(readxl::read_excel(from_xlsx$telemetry)$user_Id, usage$user_Id)

  local_mocked_bindings(.load_insights_telemetry = function() raw_telemetry())
  from_insights <- run_stage_1(raw, telemetry = "insights", overwrite = TRUE)
  expect_setequal(readxl::read_excel(from_insights$telemetry)$user_Id, usage$user_Id)
})

test_that("the key file must not travel with the pseudonymized files", {
  raw <- local_raw_files()

  expect_error(pseudonymize_license_data(raw$report, raw$detail, raw$output, file.path(raw$output, "anonymization_key.xlsx")),
               "key_path")
  expect_false(file.exists(file.path(raw$output, "anonymization_key.xlsx")))
})

test_that("nothing is written when a raw file is missing or lacks the mail column", {
  raw <- local_raw_files()

  expect_error(run_stage_1(raw, employees_path = file.path(raw$folder, "fehlt.xlsx")), "not found")
  expect_false(file.exists(raw$key))
  expect_false(dir.exists(raw$output))

  utils::write.csv(data.frame(UserId = "id-1"), raw$report, row.names = FALSE)
  expect_error(run_stage_1(raw), "UserEmail")
  expect_false(file.exists(raw$key))
})

test_that("an existing file stays unless overwrite is asked for", {
  raw <- local_raw_files()
  run_stage_1(raw)

  expect_error(run_stage_1(raw), "exists")
  expect_no_error(run_stage_1(raw, overwrite = TRUE))
})
