# D17: one state of the capacity forecast. The expected values come from the code of chapter 10 of the
# strategy, which these functions replace (status 2026-10-20).

status_of <- function(...) {
  read_capacity_status(capacity_status_file(file.path(withr::local_tempdir(.local_envir = parent.frame()), "stand.xlsx"), ...))
}

test_that("read_capacity_status reads the fields and the environments", {
  status <- status_of()

  expect_equal(status$Facts$STATUS_DATE, as.Date("2026-10-20"))
  expect_equal(status$Facts$QUOTA_GB, 705)
  expect_equal(status$Facts$GO_LIVE, as.Date("2027-06-15"))
  expect_equal(status$Facts$OPTION_SHARE, 2 / 3)
  expect_equal(status$Environments$ENVIRONMENT, c("Prod", "INT", "TST", "PRJ"))
  expect_equal(status$Environments$GB, c(200, 136, 70, 200))
})

test_that("read_capacity_status takes dates and numbers as Excel writes or a person types them", {
  status <- status_of(fields = c("Stichtag" = "20.10.2026", "Go-Live" = "46553", "Option: Anteil am Kontingent" = "0,5"))

  expect_equal(status$Facts$STATUS_DATE, as.Date("2026-10-20"))
  expect_equal(status$Facts$GO_LIVE, as.Date("2027-06-15"))
  expect_equal(status$Facts$OPTION_SHARE, 0.5)
})

test_that("read_capacity_status names what is missing or wrong", {
  folder <- withr::local_tempdir()
  path   <- capacity_status_file(file.path(folder, "a.xlsx"), fields = c("Go-Live" = ""))
  expect_error(read_capacity_status(path), "Go-Live")
  path <- capacity_status_file(file.path(folder, "b.xlsx"), fields = c("Kontingent (GB)" = "viel"))
  expect_error(read_capacity_status(path), "Kontingent")
  path <- capacity_status_file(file.path(folder, "c.xlsx"), leave_out = "Umgebungen")
  expect_error(read_capacity_status(path), "Umgebungen")
  path <- capacity_status_file(file.path(folder, "d.xlsx"), environments = capacity_environments()[-1, ])
  expect_error(read_capacity_status(path), "Prod")
  expect_error(read_capacity_status(file.path(folder, "fehlt.xlsx")), "not found")
})

test_that("read_capacity_status stops on values that cannot be right", {
  read_with <- function(...) {
    read_capacity_status(capacity_status_file(tempfile(fileext = ".xlsx", tmpdir = withr::local_tempdir(.local_envir = parent.frame())), ...))
  }
  expect_error(read_with(fields = c("Belegt (GB)" = "-5")), "negative")
  expect_error(read_with(fields = c("Option: Anteil am Kontingent" = "20")), "share")
  expect_error(read_with(fields = c("Option: Tage je Fenster" = "0")), "Tage je Fenster")
  expect_error(read_with(fields = c("Option: Fenster je Kalenderjahr" = "2,5")), "whole")
  expect_error(read_with(fields = c("Löschung PRJ und Migrationssandbox" = "2027-06-01")), "Löschung")
  expect_error(read_with(fields = c("Go-Live" = "2026")), "no date")
  expect_error(read_with(fields = c("Belegt (GB)" = "400")), "add up")
  expect_error(read_with(fields = c("Prognose bis" = "2027-03-01")), "Prognose bis")

  no_prod <- capacity_environments()
  no_prod$GB[[1]] <- 0
  expect_error(read_with(environments = no_prod), "Prod")
  expect_error(read_with(environments = capacity_environments()[c(1, 1, 2, 3, 4), ]), "twice")
})

test_that("the forecast starts at the reported usage or stops", {
  folder <- withr::local_tempdir()
  forecast_with <- function(name, ...) {
    forecast_capacity(read_capacity_status(capacity_status_file(file.path(folder, name), ...)))
  }
  sandbox <- rbind(capacity_environments(), data.frame(Umgebung = "Migrationssandbox", GB = 180, Datenstand = ""))

  # the sandbox is due, but the state does not report it: a copy of Prod would be added out of nothing
  expect_error(forecast_with("a.xlsx", fields = c("Stichtag" = "2026-12-01")), "Migrationssandbox")
  # the sandbox is reported, but is not due yet
  expect_error(forecast_with("b.xlsx", fields = c("Belegt (GB)" = "810"), environments = sandbox), "Belegt")
  # PRJ is deleted by the date, but the state still reports it
  expect_error(forecast_with("c.xlsx", fields = c("Stichtag" = "2027-08-01")), "Belegt")
})

test_that("the forecast gives the key figures of the strategy", {
  forecast <- capacity_forecast_of()
  figures  <- forecast$Figures

  expect_equal(figures$ID, c("S1", "S2", "S3"))
  expect_equal(figures$MISSING_BEFORE_GO_LIVE, c(332.0471429, 203.7728571, 137.49), tolerance = 1e-6)
  expect_equal(figures$DAYS_UNCOVERED, c(30L, 30L, 24L))
  expect_equal(figures$GAP_MAX, c(214.5971429, 86.32285714, 20.04), tolerance = 1e-6)
  expect_equal(figures$PURCHASE_MONTH, c(6437.914286, 2589.685714, 601.2), tolerance = 1e-6)
  expect_equal(figures$RESERVE_GO_LIVE, c(132.0828571, 260.3571429, 326.64), tolerance = 1e-6)
  expect_equal(figures$RESERVE_AFTER_DELETION, rep(498.14, 3), tolerance = 1e-6)
  expect_equal(figures$EXHAUSTED_ACTIVITY, rep(as.Date("2028-09-17"), 3))
  expect_equal(figures$MISSING_TEAM_MEMBER, c(16.55714286, 0, 0), tolerance = 1e-6)
  expect_equal(figures$EXHAUSTED_TEAM_MEMBER, rep(as.Date("2028-06-10"), 3))
})

test_that("the windows of the option lie gaplessly before the go-live", {
  windows <- capacity_forecast_of()$Windows

  expect_equal(windows$WINDOW, 1:3)
  expect_equal(windows$FROM, as.Date(c("2027-01-31", "2027-03-17", "2027-05-01")))
  expect_equal(windows$TO, as.Date(c("2027-03-16", "2027-04-30", "2027-06-14")))
})

test_that("the milestones show consumption and quota", {
  milestones <- capacity_forecast_of()$Milestones

  expect_equal(milestones$DATE, as.Date(c("2026-10-20", "2026-10-22", "2027-01-01", "2027-06-14", "2027-06-15",
                                          "2027-07-15", "2027-12-31")))
  expect_equal(milestones$S1, c(630, 832.5971429, 894.3671429, 1037.047143, 1037.917143, 671.86, 867.9), tolerance = 1e-6)
  expect_equal(milestones$S3[[3]], 699.81, tolerance = 1e-6)
  expect_equal(milestones$QUOTA, c(705, 705, 705, 705, 1170, 1170, 1170))
  expect_equal(milestones$QUOTA_OPTION, c(1175, 1175, 705, 1175, 1170, 1170, 1170))
})

test_that("the environments show what no environment explains", {
  environments <- capacity_forecast_of()$Environments

  expect_equal(environments$ENVIRONMENT, c("Prod", "INT", "TST", "PRJ", "Nicht zugeordnet"))
  expect_equal(environments$GB[[5]], 24)
})

test_that("a migration sandbox that already exists counts with its reported size", {
  environments <- rbind(capacity_environments(),
                        data.frame(Umgebung = "Migrationssandbox", GB = 180, Datenstand = "Kopie von Prod"))
  forecast <- capacity_forecast_of(fields = c("Stichtag" = "2026-12-01", "Belegt (GB)" = "810"), environments = environments)

  expect_equal(forecast$Environments$GB[forecast$Environments$ENVIRONMENT == "Migrationssandbox"], 180)
  expect_equal(forecast$Environments$GB[forecast$Environments$ENVIRONMENT == "Nicht zugeordnet"], 24)
  expect_equal(forecast$Days$S1[[1]], 810, tolerance = 1e-6)
})

test_that("days before the turn of the year count as uncovered when the option ends earlier", {
  covered <- capacity_forecast_of()$Figures$DAYS_UNCOVERED[[1]]
  earlier <- capacity_forecast_of(fields = c("Option läuft bis" = "2026-11-14"))$Figures$DAYS_UNCOVERED[[1]]

  expect_equal(earlier - covered, 47L)
})

test_that("a state after the go-live gives no error and leaves the figures of the past empty", {
  deleted <- capacity_environments()
  deleted$GB[deleted$Umgebung == "PRJ"] <- 0
  forecast <- capacity_forecast_of(fields = c("Stichtag" = "2027-08-01", "Belegt (GB)" = "430"), environments = deleted)

  expect_true(is.na(forecast$Figures$MISSING_BEFORE_GO_LIVE[[1]]))
  expect_true(is.na(forecast$Figures$RESERVE_GO_LIVE[[1]]))
  expect_equal(nrow(forecast$Windows), 0L)
})

test_that("capacity_tables gives the tables in German", {
  tables <- capacity_tables(capacity_forecast_of())

  expect_equal(names(tables), c("Figures", "Milestones", "Environments", "Assumptions", "Windows"))
  expect_equal(names(tables$Figures), c("Kennzahl", "S1", "S2", "S3"))
  expect_true("Reserve nach Löschung von PRJ und Migrationssandbox (GB)" %in% tables$Figures$Kennzahl)
  expect_equal(tables$Figures$S1[tables$Figures$Kennzahl == "Kontingent erschöpft ab (Techniker mit Activity)"], "09/2028")
  expect_equal(names(tables$Milestones)[1:2], c("Datum", "Ereignis"))
  expect_equal(tables$Milestones$Datum[[1]], "20.10.2026")
  expect_equal(tables$Windows$Beginn, c("laufend", "31.01.2027", "17.03.2027", "01.05.2027"))
  expect_equal(tables$Windows$Ende[[1]], "31.12.2026")
})

test_that("a window that has begun before the state is marked as running", {
  environments <- rbind(capacity_environments(), data.frame(Umgebung = "Migrationssandbox", GB = 180, Datenstand = ""))
  forecast <- capacity_forecast_of(fields = c("Stichtag" = "2027-02-10", "Belegt (GB)" = "810"), environments = environments)

  expect_equal(capacity_tables(forecast)$Windows$Beginn, c("31.01.2027 (läuft)", "17.03.2027", "01.05.2027"))
})

test_that("capacity_texts states the shortage and the reserve of the first state", {
  texts <- capacity_texts(capacity_forecast_of())

  expect_match(texts$BEFORE_GO_LIVE, "332 GB in S1, 204 GB in S2 und 137 GB in S3", fixed = TRUE)
  expect_match(texts$AT_GO_LIVE, "465 GB", fixed = TRUE)
  expect_match(texts$AT_GO_LIVE, "132 bis 327 GB", fixed = TRUE)
  expect_match(texts$AFTER_DELETION, "498 GB", fixed = TRUE)
  expect_match(texts$AFTER_DELETION, "bis 09/2028", fixed = TRUE)
  expect_match(texts$AFTER_DELETION, "bis 06/2028", fixed = TRUE)
  expect_match(texts$WINDOWS, "Die Spitze vor dem Go-Live ist gedeckt", fixed = TRUE)
  expect_match(texts$WINDOWS, "30 Tage", fixed = TRUE)
  expect_length(texts$WAYS, 2L)
  expect_match(texts$WAYS[[1]], "215 auf 86 bzw. 20 GB", fixed = TRUE)
  expect_match(texts$WAYS[[2]], "6.438 €", fixed = TRUE)
  expect_match(texts$POSTPONED, "kein Fenster mehr frei", fixed = TRUE)
})

test_that("capacity_texts says that the quota is enough when it is", {
  texts <- capacity_texts(capacity_forecast_of(fields = c("Kontingent (GB)" = "5000")))

  expect_match(texts$BEFORE_GO_LIVE, "reicht", fixed = TRUE)
  expect_false(grepl("Es fehlen", texts$BEFORE_GO_LIVE, fixed = TRUE))
  expect_match(texts$WINDOWS, "gedeckt", fixed = TRUE)
  expect_false(grepl("Spitze", texts$WINDOWS, fixed = TRUE))
  expect_length(texts$WAYS, 0L)
})

test_that("capacity_texts shows no negative shortage", {
  texts <- capacity_texts(capacity_forecast_of(fields = c("Kontingent (GB)" = "950")))

  expect_match(texts$BEFORE_GO_LIVE, "87 GB in S1", fixed = TRUE)
  expect_match(texts$BEFORE_GO_LIVE, "nichts in S2 und nichts in S3", fixed = TRUE)
  expect_false(grepl("-[0-9]", texts$BEFORE_GO_LIVE))
})

test_that("capacity_texts names a shortage at the go-live and after the deletion", {
  texts <- capacity_texts(capacity_forecast_of(fields = c("Kontingent (GB)" = "600", "Neue Lizenzen ab Go-Live (GB)" = "0")))

  expect_match(texts$AT_GO_LIVE, "Es fehlen", fixed = TRUE)
  expect_false(grepl("Reserve", texts$AT_GO_LIVE, fixed = TRUE))
  expect_match(texts$AFTER_DELETION, "Es fehlen", fixed = TRUE)
})

test_that("capacity_texts leaves out what lies before the state", {
  deleted <- capacity_environments()
  deleted$GB[deleted$Umgebung == "PRJ"] <- 0
  texts <- capacity_texts(capacity_forecast_of(fields = c("Stichtag" = "2027-08-01", "Belegt (GB)" = "430"), environments = deleted))

  expect_match(texts$BEFORE_GO_LIVE, "liegt vor diesem Stand", fixed = TRUE)
  expect_match(texts$AFTER_DELETION, "liegt vor diesem Stand", fixed = TRUE)
  expect_match(texts$WINDOWS, "liegt vor diesem Stand", fixed = TRUE)
  expect_length(texts$WAYS, 0L)
  expect_equal(texts$POSTPONED, "")
})

test_that("capacity_texts warns of a later go-live only when no window is left in that year", {
  texts <- capacity_texts(capacity_forecast_of(fields = c("Go-Live" = "2027-02-01", "Löschung PRJ und Migrationssandbox" = "2027-03-01")))

  expect_equal(texts$POSTPONED, "")
})

test_that("capacity_texts does not speak of a last window when there are no windows", {
  texts <- capacity_texts(capacity_forecast_of(fields = c("Option: Fenster je Kalenderjahr" = "0")))

  expect_equal(texts$POSTPONED, "")
})

test_that("measures before the state count as done: the reported sizes hold them", {
  environments <- rbind(capacity_environments(), data.frame(Umgebung = "Migrationssandbox", GB = 180, Datenstand = ""))
  forecast <- capacity_forecast_of(fields = c("Stichtag" = "2026-12-01", "Belegt (GB)" = "810"), environments = environments)
  texts    <- capacity_texts(forecast)
  tables   <- capacity_tables(forecast)

  expect_equal(forecast$Days$S2, forecast$Days$S1)
  expect_equal(forecast$Days$S3, forecast$Days$S1)
  expect_length(texts$WAYS, 1L)
  expect_false(grepl("S2 oder S3", texts$WAYS, fixed = TRUE))
  expect_true(any(grepl("in den Größen dieses Stands enthalten", unlist(tables$Assumptions), fixed = TRUE)))
})

test_that("capacity_texts needs a forecast", {
  expect_error(capacity_texts(list()), "forecast_capacity")
})

test_that("plot_capacity_forecast draws", {
  path <- file.path(withr::local_tempdir(), "bild.png")
  grDevices::png(path, width = 800, height = 480)
  plot_capacity_forecast(capacity_forecast_of())
  grDevices::dev.off()

  expect_gt(file.size(path), 1000)
})

test_that("configurable Option aktiviert ab computes consecutive windows and S1/S2 reduction", {
  fields <- c(
    "Option aktiviert ab" = "2026-09-29",
    "Maßnahmen wirken ab" = "2026-11-15"
  )
  forecast <- capacity_forecast_of(fields = fields)
  facts    <- forecast$Facts

  expect_equal(facts$OPTION_START, as.Date("2026-09-29"))

  # 3 consecutive windows of 45 days
  expect_equal(forecast$Windows$WINDOW, 1:3)
  expect_equal(forecast$Windows$FROM, as.Date(c("2026-09-29", "2026-11-13", "2026-12-28")))
  expect_equal(forecast$Windows$TO, as.Date(c("2026-11-12", "2026-12-27", "2027-02-10")))

  # Quota drops to 705 on 2027-02-11
  day_active <- forecast$Days[forecast$Days$DATE == as.Date("2027-02-10"), ]
  day_gap    <- forecast$Days[forecast$Days$DATE == as.Date("2027-02-11"), ]
  expect_equal(day_active$QUOTA_OPTION, 705 * (1 + 2/3))
  expect_equal(day_gap$QUOTA_OPTION, 705)

  # Cleanup S1 (-1/4 = 0.75) and S2 (-2/3 = 1/3) after measures date
  day_measures <- forecast$Days[forecast$Days$DATE == as.Date("2026-11-15"), ]
  expect_lt(day_measures$S2, day_measures$S1)
  expect_lt(day_measures$S1, day_measures$S3)

  # Check that plot draws with new mode
  path2 <- file.path(withr::local_tempdir(), "bild2.png")
  grDevices::png(path2, width = 800, height = 480)
  plot_capacity_forecast(forecast)
  grDevices::dev.off()
  expect_gt(file.size(path2), 1000)
})

