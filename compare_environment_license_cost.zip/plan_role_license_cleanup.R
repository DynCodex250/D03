#' Plan the cleanup of roles by the licenses their users do not use
#'
#' The cleanup plan of the most expensive roles (D04 of the strategy): which
#' license each user needs for the work the telemetry shows, which duties of
#' which roles must go for it, and in which order the roles are best changed.
#' Every saving rests on the telemetry.
#'
#' @details
#'
#' **Three costs per user.** \code{COST_NOW} is the billing of today, from
#' the licenses of \code{licenses} (PPAC). \code{COST_GRAPH} is the cheapest
#' set of licenses that covers every object of all roles of the user, from the
#' license graph: it should equal \code{COST_NOW}. \code{COST_BY_USAGE} covers
#' only the duties the user keeps by the telemetry. All three follow the
#' billing of \code{\link{rank_roles_by_license_cost}}: of Supply Chain
#' Management, Finance and Commerce the first counts at its base price, every
#' further one at its attach price.
#'
#' **PPAC has priority** (decided 2026-10-28). Where the graph wants more for
#' an object than the licenses PPAC bills the user, PPAC knows a rule the graph
#' does not (for example which light license covers Human Resources Self
#' Service): those licenses count as covering the object, and none where PPAC
#' bills none. \code{COST_GRAPH} is therefore at most \code{COST_NOW};
#' \code{Differences} lists those objects.
#'
#' **Why the graph.** The PPAC report names each license of a user at one of
#' his roles only; another role that needs the same license shows
#' \code{None}. What a user would need without a role therefore cannot be read
#' from the licenses of his other roles in PPAC, only from the objects of his
#' roles in the graph.
#'
#' **The rule of the telemetry** (the duty level of
#' \code{\link{analyze_user_duty_usage}}). A duty, or a privilege outside any
#' duty, is used when the user opened one of its display menu items in the
#' telemetry; its actions, outputs and data entities count with it. A duty
#' without a display menu item cannot be measured and is kept. A duty that is
#' not used goes; the user then needs the cheapest licenses that cover the
#' objects of the duties he keeps. \code{COST_IF_CONFIRMED} drops the duties
#' that cannot be measured too: what the business may confirm as unused.
#'
#' **Classes of users.**
#' \describe{
#'   \item{\code{SAVES}}{The telemetry proves a saving (\code{SAVING > 0}).}
#'   \item{\code{REVIEW}}{No proven saving, but one if the business confirms
#'     that the duties that cannot be measured are not used.}
#'   \item{\code{KEEPS}}{The user uses what triggers his licenses.}
#'   \item{\code{NO_TELEMETRY}}{The user opened nothing in the telemetry. He
#'     is listed for a check (\code{NoUsage}), not counted as a saving: he
#'     may work with the warehouse app or through an integration.}
#'   \item{\code{NO_USE}}{The user opened only what needs no license, for
#'     example the dashboard: by the telemetry he would need no license at
#'     all. Listed for a check like \code{NO_TELEMETRY}, not counted as a
#'     saving.}
#'   \item{\code{GRAPH_DIFFERS}}{\code{COST_GRAPH} is below \code{COST_NOW}:
#'     PPAC bills a license the graph does not explain, for example a role
#'     missing from the graph or a graph of another environment. No saving is
#'     counted.}
#' }
#'
#' **Actions and waves.** For a user who saves, every role that holds a duty
#' he does not use and that needs a license he would no longer have must
#' change: \code{REMOVE_ROLE} when he opened nothing of the role and all its
#' duties can be measured, else \code{VARIANT} (a version of the role without
#' those duties, see \code{\link{plan_single_license_role}}). A user saves only
#' when all his roles have changed. \code{Plan} therefore orders the roles so
#' that each step completes the most savings (\code{GAIN}). Wave 1 holds the
#' roles with proven savings, in that order; wave 2 the users without
#' telemetry or without licensed use, after a check (\code{NoUsage}); wave 3
#' the roles whose saving needs the business to confirm duties that cannot be
#' measured (actions \code{REVIEW}). \code{Actions$SAVING} is the saving of
#' the user, the same at each of his roles: add it up per user, not over the
#' rows.
#'
#' The telemetry covers only its period (\code{Check$TELEMETRY_FROM} to
#' \code{TELEMETRY_TO}); work done once a year, such as the closing of the
#' year, may not show in it.
#'
#' @param licenses
#' The license rows of one environment, for example
#' \code{read_ppac_license_detail(path, environment = "wibu-produktiv")}, or
#' \code{get_user_licenses_by_role(con)}. Roles are found in the graph by
#' their AOT name, else by their name.
#'
#' @param graph
#' The license graph, \code{\link{read_license_graph}}.
#'
#' @param usage
#' The telemetry: one row per user and entry point, in the columns of
#' \code{D365Licensing::load_telemetry_touches()} (\code{user_Id},
#' \code{name}, \code{touches}, \code{last_seen}), for example read with
#' \code{readxl::read_excel()}. User ids and entry points are matched without
#' regard to case.
#'
#' @param prices
#' Prices per user and month, see \code{\link{read_license_prices}};
#' \code{NULL} = the estimates of the strategy paper, with a warning.
#'
#' @param export_path
#' Path of an \code{.xlsx} file for the plan; \code{NULL} = no file. The
#' sheets of users hold user ids.
#'
#' @param language
#' Language of the workbook: \code{"de"} or \code{"en"}.
#'
#' @return
#' List:
#' \describe{
#'   \item{\code{Check}}{\code{CREATED}, \code{SOURCE}, \code{GRAPH_ROWS},
#'     \code{GRAPH_ROLES}, \code{GRAPH_ROWS_WITHOUT_ROLE},
#'     \code{TELEMETRY_FROM}, \code{TELEMETRY_TO}, \code{USERS},
#'     \code{USERS_WITH_TELEMETRY}, \code{USERS_WITHOUT_TELEMETRY},
#'     \code{USERS_WITHOUT_LICENSED_USE}, \code{TELEMETRY_USERS_NOT_IN_LICENSES},
#'     \code{USERS_GRAPH_DIFFERS}, \code{ROLES_NOT_IN_GRAPH}, \code{COST_NOW}
#'     (all users, per month), \code{SAVING} (proven),
#'     \code{SAVING_IF_CONFIRMED}, \code{COST_WITHOUT_TELEMETRY},
#'     \code{COST_WITHOUT_USE} (the users of \code{NoUsage}),
#'     \code{PRICES_ESTIMATED}.}
#'   \item{\code{Plan}}{One row per role to change: \code{WAVE}, \code{STEP},
#'     \code{ROLE}, \code{USERS} (users with the role), \code{USERS_TO_CHANGE},
#'     \code{REMOVE_ROLE} and \code{VARIANT} (users per action),
#'     \code{DUTIES} (to drop), \code{GAIN} (savings this step completes),
#'     \code{SAVING_CUMULATIVE}, \code{USERS_REVIEW}, \code{REVIEW_DUTIES},
#'     \code{SAVING_REVIEW}.}
#'   \item{\code{Actions}}{One row per user, role and action: \code{USERID},
#'     \code{ROLE}, \code{ACTION}, \code{WAVE}, \code{DUTIES}, \code{LICENSES}
#'     (the licenses of the objects that make the duties go), \code{SAVING}
#'     (of the user, proven or after review; repeated at each of his roles).}
#'   \item{\code{Users}}{One row per user: \code{USERID}, \code{ROLES},
#'     \code{BILLED_NOW}, \code{COST_NOW}, \code{BILLED_GRAPH},
#'     \code{COST_GRAPH}, \code{BILLED_BY_USAGE}, \code{COST_BY_USAGE},
#'     \code{SAVING}, \code{BILLED_IF_CONFIRMED}, \code{COST_IF_CONFIRMED},
#'     \code{SAVING_IF_CONFIRMED}, \code{CLASS}, \code{ENTRY_POINTS} (opened),
#'     \code{LAST_SEEN}.}
#'   \item{\code{Duties}}{One row per role and duty that makes a license go:
#'     \code{ROLE}, \code{DUTY}, \code{DUTY_NAME}, \code{LICENSE},
#'     \code{MEASURABLE}, \code{USERS_WITH_ROLE}, \code{USERS_OPENED},
#'     \code{USERS_TO_DROP}, \code{USERS_REVIEW}.}
#'   \item{\code{NoUsage}}{The users of wave 2, without telemetry or without
#'     licensed use: \code{USERID}, \code{ROLES}, \code{BILLED_NOW},
#'     \code{COST_NOW}, \code{CLASS}.}
#'   \item{\code{Differences}}{Where PPAC decided: per role and license of the
#'     graph the objects for which the graph wants more than PPAC bills
#'     \code{ROLE}, \code{LICENSE}, \code{BILLED_NOW} (the billings of PPAC
#'     that cover them), \code{USERS}, \code{OBJECTS}, \code{EXAMPLES}.}
#'   \item{\code{Prices}}{The prices used.}
#' }
#'
#' @examples
#' \dontrun{
#'
#' licenses <- read_ppac_license_detail("Input/Finance_And_Operations_Licensing_Detailed_Report.csv",
#'                                      environment = "wibu-produktiv")
#' graph    <- read_license_graph(list.files("../Input/Excel/Database", "EXPLODEDGAPH_.*[.]xlsx$", full.names = TRUE))
#' usage    <- read_usage_telemetry("Data/Input/PPAC/pseudonymized/Telemetrie_pseudonymized.xlsx")
#'
#' plan <- plan_role_license_cleanup(licenses, graph, usage, prices = "Input/Lizenzpreise.xlsx",
#'                                   export_path = "Data/Deliverables/D04_Bereinigungsplan.xlsx")
#' plan$Plan
#' plan$Check$SAVING
#'
#' }
#'
#' @seealso
#' \code{\link{read_license_graph}}
#' \code{\link{read_ppac_license_detail}}
#' \code{\link{rank_roles_by_license_cost}}
#' \code{\link{analyze_user_duty_usage}}
#' \code{\link{plan_single_license_role}}
#'
#' @export
plan_role_license_cleanup <- function(licenses, graph, usage, prices = NULL, export_path = NULL, language = "de") {

  language <- .check_report_language(language)
  if (!is.null(export_path)) .check_xlsx_path(export_path)
  base    <- .telemetry_license_need(licenses, graph, usage, prices)
  need    <- base$need
  actions <- .cleanup_actions(need)
  result  <- list(
    Check       = .cleanup_check(need, base$source, base$price_table$estimated),
    Plan        = .cleanup_plan(actions, need),
    Actions     = dplyr::select(actions, USERID, ROLE, ACTION, WAVE, DUTIES, LICENSES, SAVING),
    Users       = .cleanup_users(need$users),
    Duties      = .cleanup_duties(need),
    NoUsage     = need$users |>
      dplyr::filter(CLASS %in% c(.CLEANUP_NO_TELEMETRY, .CLEANUP_NO_USE)) |>
      dplyr::arrange(dplyr::desc(COST_NOW), USERID) |>
      dplyr::select(USERID, ROLES, BILLED_NOW, COST_NOW, CLASS),
    Differences = .cleanup_differences(need),
    Prices      = base$price_table$prices
  )

  if (!is.null(export_path)) {
    .export_role_license_cleanup(result, export_path, language)
  }
  message(.cleanup_message(result))
  result
}

.CLEANUP_SAVES         <- "SAVES"
.CLEANUP_REVIEW        <- "REVIEW"
.CLEANUP_KEEPS         <- "KEEPS"
.CLEANUP_NO_TELEMETRY  <- "NO_TELEMETRY"
.CLEANUP_NO_USE        <- "NO_USE"
.CLEANUP_GRAPH_DIFFERS <- "GRAPH_DIFFERS"

# Amounts are in cents; below half a cent two costs are equal.
.CENT <- 0.005

# The license need of every user by the telemetry, from the license rows of one environment
# (PPAC), the graph and the prices; shared by plan_role_license_cleanup() and
# build_user_license_profile().
.telemetry_license_need <- function(licenses, graph, usage, prices) {
  if (!is.data.frame(licenses)) {
    stop("licenses must be the license rows of one environment, for example ",
         "read_ppac_license_detail(path, environment = \"wibu-produktiv\").", call. = FALSE)
  }
  .check_required_columns(graph, .GRAPH_COLUMNS, "graph")
  price_table <- .license_prices(prices)
  input <- .ranking_input(NULL, licenses)
  rows  <- .cost_rows(input$licenses, NULL)
  .check_usage_matches_users(usage, rows$USERID)
  .check_prices_cover(price_table$prices, rows$SKUNAME)
  cost_of <- .license_cost_function(price_table$prices, .standard_base_licenses())
  list(need = .cleanup_need(rows, graph, .normalize_usage(usage), price_table$prices, cost_of),
       source = input$source, price_table = price_table, cost_of = cost_of)
}

# The duties of every user with what the telemetry says about them, and the licenses he
# needs now, by the graph, by the telemetry and after review.
.cleanup_need <- function(rows, graph, touches, prices, cost_of) {

  skus     <- .graph_license_skus()
  priced   <- skus$SKUNAME[.identifier_key(skus$SKUNAME) %in% .identifier_key(prices$LICENSE)]
  licenses <- .license_cover_function(skus, priced, cost_of)

  rows       <- dplyr::mutate(rows, ROLE_SHOWN = dplyr::coalesce(ROLENAME, ROLE))
  roles      <- .graph_roles_of(dplyr::distinct(rows, ROLE = ROLE_SHOWN, ROLE_KEY), graph)
  user_roles <- dplyr::distinct(rows, USER_KEY, USERID, ROLE = ROLE_SHOWN)
  units      <- .graph_units(graph, skus) |>
    dplyr::inner_join(roles$map, by = "GRAPH_ROLE_KEY", relationship = "many-to-many") |>
    dplyr::distinct(ROLE, UNIT, UNIT_ID, UNIT_NAME, OBJECT, DISPLAY, LICENSE, MASK)
  .check_usage_names(touches, units)
  .warn_on_unpriced_licenses(units, licenses$unpriced)

  user_units <- .user_units(user_roles, units, touches)
  now        <- .current_billing(rows, skus, cost_of)
  user_masks <- .user_masks(user_units, units, now, licenses$needed, skus)
  users      <- .user_license_costs(now, user_masks, touches, licenses)

  list(
    users = users, user_roles = user_roles, user_units = user_units, user_masks = user_masks, units = units,
    drivers = .cleanup_drivers(user_masks, users, licenses$needed), needed = licenses$needed,
    roles_missing = roles$missing, graph_rows = nrow(graph),
    graph_roles = dplyr::n_distinct(graph$ROLEIDENTIFIER[!is.na(graph$ROLEIDENTIFIER)]),
    rows_without_role = sum(is.na(graph$ROLEIDENTIFIER)),
    telemetry_only = length(setdiff(unique(touches$USER_KEY), rows$USER_KEY)),
    from = .min_date(touches$LAST_SEEN), to = .max_date(touches$LAST_SEEN)
  )
}

# Telemetry that names no display menu item of the graph does not fit it: every user
# would look as if he used nothing.
.check_usage_names <- function(touches, units) {
  if (nrow(touches) == 0L || !any(touches$ENTRYPOINT_KEY %in% units$OBJECT[units$DISPLAY])) {
    stop("None of the entry points in usage is a display menu item of the license graph. usage must hold the names ",
         "of the menu items, as D365Licensing::load_telemetry_touches() returns them (column name).", call. = FALSE)
  }
  invisible(touches)
}

# Objects that only an unpriced license covers (Human Resources), or whose license the graph
# does not name or the license list does not know, drop out of every cost.
.warn_on_unpriced_licenses <- function(units, unpriced) {
  rows <- units[unpriced(units$MASK), ]
  if (nrow(rows) == 0L) {
    return(invisible(NULL))
  }
  objects <- dplyr::n_distinct(rows$OBJECT)
  one     <- objects == 1L
  warning(sprintf(paste("%d object%s of the roles need%s a license without a price (%s). %s left out of the license",
                        "need; where a used duty holds %s, the saving of its users may be too high."),
                  objects, if (one) "" else "s", if (one) "s" else "",
                  .sorted_list(dplyr::coalesce(rows$LICENSE, "no license named")), if (one) "It is" else "They are",
                  if (one) "it" else "them"), call. = FALSE)
  invisible(NULL)
}

# One row per user, role and unit: OPENED when the user opened a display menu item of it;
# a unit without one is kept by the telemetry, and only after review it may go.
.user_units <- function(user_roles, units, touches) {
  opened <- dplyr::distinct(touches, USER_KEY, OBJECT = ENTRYPOINT_KEY) |>
    dplyr::inner_join(dplyr::distinct(units[units$DISPLAY, ], ROLE, UNIT, OBJECT), by = "OBJECT",
                      relationship = "many-to-many") |>
    dplyr::semi_join(user_roles, by = c("USER_KEY", "ROLE")) |>
    dplyr::distinct(USER_KEY, ROLE, UNIT) |>
    dplyr::mutate(OPENED = TRUE)
  info <- units |>
    dplyr::group_by(ROLE, UNIT) |>
    dplyr::summarise(UNIT_ID = dplyr::first(UNIT_ID), UNIT_NAME = dplyr::first(UNIT_NAME), MEASURABLE = any(DISPLAY),
                     .groups = "drop")

  user_roles |>
    dplyr::select(USER_KEY, ROLE) |>
    dplyr::inner_join(info, by = "ROLE", relationship = "many-to-many") |>
    dplyr::left_join(opened, by = c("USER_KEY", "ROLE", "UNIT")) |>
    dplyr::mutate(OPENED = dplyr::coalesce(OPENED, FALSE), KEEP_USAGE = OPENED | !MEASURABLE, KEEP_CONFIRMED = OPENED)
}
