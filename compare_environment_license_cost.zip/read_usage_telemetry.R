#' Read the telemetry, wherever it comes from
#'
#' One way to get the telemetry that \code{\link{analyze_role_license_report}},
#' \code{\link{plan_role_license_cleanup}} and
#' \code{\link{build_user_license_profile}} take: from Application Insights or
#' from a file, with the user ids as the caller needs them.
#'
#' @details
#'
#' **Which user ids.** Telemetry only helps when its user ids match the other
#' side, so \code{user_ids} says which form the caller needs.
#' \itemize{
#'   \item \code{"pseudonyms"}: for the pseudonymized PPAC reports. Real user
#'     ids are replaced with \code{\link{anonymize_data}}; the entry points in
#'     \code{name} stay. A file that holds only pseudonyms stays as it is and
#'     needs no key.
#'   \item \code{"real"}: for the comparison with the database, which holds
#'     real user ids. Pseudonyms come back with
#'     \code{\link{deanonymize_data}}. Without their key the function stops:
#'     otherwise no user would match, and every user would look unused.
#'   \item \code{"as_read"}: as the source holds them.
#' }
#'
#' **Two keys.** Pseudonyms of another key stop the function, because they
#' would be replaced a second time or could not come back. The functions that
#' take the telemetry stop as well when it shares no user id with their users
#' and pseudonyms are the reason.
#'
#' @param source
#' \code{"insights"} loads it with
#' \code{D365Licensing::load_telemetry_touches()}. Otherwise the path of an
#' \code{.xlsx}, \code{.rds} or \code{.RData} file; an \code{.RData} file holds
#' one data frame. The columns \code{user_Id}, \code{name}, \code{touches} and
#' \code{last_seen} are needed. An empty answer from Insights, as when the
#' connection fails, passes.
#'
#' @param user_ids
#' \code{"as_read"}, \code{"pseudonyms"} or \code{"real"}; see above.
#'
#' @param key_path
#' The key file of \code{\link{anonymize_data}}. It lies outside the folders
#' that are passed on.
#'
#' @param new_key
#' With \code{user_ids = "pseudonyms"}: \code{FALSE} stops when the key file
#' does not exist yet, because the pseudonyms of a new key match no other file.
#' An existing key file still takes user ids it does not know. Default
#' \code{TRUE}.
#'
#' @return
#' A data frame, one row per user and entry point.
#'
#' @examples
#' \dontrun{
#'
#' # For the comparison with the database, from any source
#' usage <- read_usage_telemetry("insights", user_ids = "real")
#' usage <- read_usage_telemetry("Telemetrie_pseudonymized.xlsx", user_ids = "real", key_path = key_path)
#'
#' # For the pseudonymized PPAC reports
#' usage <- read_usage_telemetry("telemetrie.rds", user_ids = "pseudonyms", key_path = key_path, new_key = FALSE)
#'
#' }
#'
#' @seealso
#' \code{\link{anonymize_data}}
#' \code{\link{deanonymize_data}}
#' \code{\link{resolve_telemetry}}
#'
#' @export
read_usage_telemetry <- function(source = "insights", user_ids = c("as_read", "pseudonyms", "real"), key_path = NULL, new_key = TRUE) {

  user_ids <- match.arg(user_ids)
  usage    <- .read_telemetry_source(source)
  switch(user_ids,
         as_read    = usage,
         pseudonyms = .pseudonymize_telemetry(usage, key_path, new_key),
         real       = .restore_telemetry_users(usage, key_path))
}

.TELEMETRY_COLUMNS <- c("user_Id", "name", "touches", "last_seen")

.read_telemetry_source <- function(source) {
  if (!.is_single_string(source)) {
    stop("source must be 'insights' or the path of an .xlsx, .rds or .RData file.", call. = FALSE)
  }
  if (tolower(source) == "insights") {
    usage <- .load_insights_telemetry()
    return(if (nrow(usage) == 0L) usage else .check_telemetry_columns(usage, source))
  }
  if (!file.exists(source)) stop("Telemetry: file not found: ", source, call. = FALSE)
  .check_telemetry_columns(.read_telemetry_file(source), source)
}

.load_insights_telemetry <- function() {
  if (!requireNamespace("D365Licensing", quietly = TRUE)) {
    stop("Telemetry from Insights needs the package D365Licensing; give the path of a file instead.", call. = FALSE)
  }
  D365Licensing::load_telemetry_touches(D365Licensing::load_config())
}

.read_telemetry_file <- function(path) {
  if (grepl("[.]xlsx$", path, ignore.case = TRUE)) return(readxl::read_excel(path))
  if (grepl("[.]rds$", path, ignore.case = TRUE)) return(readRDS(path))
  if (!grepl("[.]r(data|da)$", path, ignore.case = TRUE)) {
    stop("Telemetry: ", path, " must be an .xlsx, .rds or .RData file.", call. = FALSE)
  }
  holder <- new.env()
  found  <- load(path, envir = holder)
  if (length(found) != 1L) {
    stop("Telemetry: ", path, " holds ", length(found), " objects (", paste(found, collapse = .LIST_SEPARATOR),
         "); it must hold exactly one data frame.", call. = FALSE)
  }
  holder[[found]]
}

.check_telemetry_columns <- function(usage, source) {
  if (!is.data.frame(usage)) stop("Telemetry: ", source, " must hold a data frame.", call. = FALSE)
  missing_columns <- setdiff(.TELEMETRY_COLUMNS, names(usage))
  if (length(missing_columns) > 0L) {
    stop("Telemetry: ", source, " lacks the column(s) ", paste(missing_columns, collapse = .LIST_SEPARATOR), ".", call. = FALSE)
  }
  usage
}

.telemetry_user_ids <- function(usage) {
  ids <- as.character(usage$user_Id)
  ids[!is.na(ids) & nzchar(ids)]
}

.pseudonymize_telemetry <- function(usage, key_path, new_key) {
  ids        <- .telemetry_user_ids(usage)
  shaped     <- grepl(.PSEUDONYM_PATTERN, ids)
  pseudonyms <- all(shaped)
  if (pseudonyms && !(.is_single_string(key_path) && file.exists(key_path))) return(usage)

  if (!pseudonyms) {
    .check_key_path(key_path)
    if (!new_key && !file.exists(key_path)) {
      stop("The key file '", key_path, "' does not exist: pseudonyms of a new key would match no other file.", call. = FALSE)
    }
  }
  foreign <- setdiff(ids[shaped], .read_anonymization_key(key_path)$PSEUDONYM)
  if (length(foreign) > 0L) {
    stop("The telemetry holds ", length(foreign), " pseudonym(s) of another key; '", key_path, "' does not know them.", call. = FALSE)
  }
  if (pseudonyms) usage else anonymize_data(usage, key_path, columns = list(USER = "^USER_?ID$"))
}

.restore_telemetry_users <- function(usage, key_path) {
  if (!any(grepl(.PSEUDONYM_PATTERN, .telemetry_user_ids(usage)))) return(usage)

  if (!.is_single_string(key_path) || !file.exists(key_path)) {
    stop("The telemetry holds pseudonyms, the database real user ids, so no user would match. ",
         "Give key_path, the key file of these pseudonyms.", call. = FALSE)
  }
  restored <- suppressWarnings(deanonymize_data(usage, key_path))
  if (any(grepl(.PSEUDONYM_PATTERN, .telemetry_user_ids(restored)))) {
    stop("The telemetry holds pseudonyms of another key; '", key_path, "' cannot restore them.", call. = FALSE)
  }
  restored
}

# Pseudonyms on one side, or of two keys: no user would match, and every user would look unused.
# Real user ids on both sides may simply not overlap. It reads the user ids only: everything else
# about usage is for the caller to demand, with its own messages.
.check_usage_matches_users <- function(usage, user_ids) {
  column <- if (is.data.frame(usage)) intersect(c("USERID", "user_Id"), names(usage)) else character()
  if (length(column) == 0L) return(invisible(NULL))

  used  <- unique(tolower(stats::na.omit(as.character(usage[[column[[1]]]]))))
  users <- unique(tolower(stats::na.omit(as.character(user_ids))))
  if (length(used) == 0L || length(users) == 0L || length(intersect(used, users)) > 0L) return(invisible(NULL))
  if (any(grepl(.PSEUDONYM_PATTERN, toupper(c(used, users))))) {
    stop("The telemetry and the users share no user id: pseudonyms on one side, or of another key. ",
         "Read the telemetry with read_usage_telemetry() and the key file of the other side.", call. = FALSE)
  }
  invisible(NULL)
}
