#' Export a security role from a license graph into 3 XML formats
#'
#' Takes a license graph table (e.g. from \code{\link{read_license_graph}},
#' \code{\link{find_menu_item_security}} or \code{LicensingSecurityObjectExplodedGraph})
#' and exports a security role into the 3 standard D365FO formats without requiring
#' a direct database connection:
#' \enumerate{
#'   \item \strong{AOT role file}: \code{<output_folder>/AxSecurityRole/<name>.xml}
#'         for Visual Studio / version control models.
#'   \item \strong{Security Governance}: \code{<output_folder>/SecurityGovernance/<name>.xml}
#'         for browser import via User Security Governance.
#'   \item \strong{Security Configuration}: \code{<output_folder>/SecurityConfiguration/<name>.xml}
#'         for browser import via System administration > Security configuration.
#' }
#' Optionally bundles the AOT file into a zip archive (\code{<output_folder>/<name>.zip}).
#'
#' @details
#' The role structure is extracted directly from the graph rows:
#' \itemize{
#'   \item \strong{Duties}: Unique values from \code{DUTYIDENTIFIER} that belong
#'         directly to the role (i.e. where \code{SUBROLEIDENTIFIER} is empty/NA).
#'   \item \strong{Privileges}: Unique values from \code{PRIVILEGEIDENTIFIER} that belong
#'         directly to the role without a duty (where \code{SUBROLEIDENTIFIER} and
#'         \code{DUTYIDENTIFIER} are empty/NA).
#'   \item \strong{Sub-roles}: Unique values from \code{SUBROLEIDENTIFIER}.
#' }
#' What is held through a sub-role stays inside that sub-role.
#'
#' @param graph
#' A data frame or tibble containing the graph columns (\code{ROLEIDENTIFIER},
#' \code{ROLENAME}, \code{SUBROLEIDENTIFIER}, \code{DUTYIDENTIFIER},
#' \code{PRIVILEGEIDENTIFIER}, etc.), or paths of Excel files readable by
#' \code{\link{read_license_graph}}. Spalten-Aliase wie \code{ROLE_ID}, \code{ROLE_NAME},
#' \code{DUTY_ID}, \code{PRIVILEGE_ID}, \code{SUBROLE_ID} und \code{MENU_ITEM}
#' werden automatisch erkannt und unterstützt.
#'
#' @param role_identifier
#' Identifier or name of the role to export. If \code{NULL} and \code{graph}
#' contains exactly one role, that role is used automatically.
#'
#' @param output_folder
#' Target directory where the folders \code{AxSecurityRole}, \code{SecurityGovernance},
#' \code{SecurityConfiguration} and the zip file will be written. Created if missing.
#'
#' @param name
#' Optional AOT name of the written role. Default is \code{NULL} (derived from
#' the graph metadata).
#'
#' @param label
#' Optional label of the written role. Default is \code{NULL} (derived from
#' the graph metadata).
#'
#' @param zip
#' \code{TRUE} (default) = also build the zip archive for Visual Studio import.
#'
#' @param browser_files
#' \code{TRUE} (default) = also write the SecurityGovernance and SecurityConfiguration
#' XML files for browser import.
#'
#' @param as_change
#' Logical indicating whether the role should be treated as a changed role
#' (\code{TRUE}) or a new role (\code{FALSE}) in the browser XML exports. Default
#' is \code{NULL} (automatically detected: existing AOT roles are treated as changed,
#' new names or GUID roles as new).
#'
#' @return
#' Invisibly a list with paths of the generated files:
#' \itemize{
#'   \item \code{xml}: Path of the AOT XML file.
#'   \item \code{zip}: Path of the zip archive (\code{NA} if \code{zip = FALSE}).
#'   \item \code{security_governance}: Path of the Security Governance XML file.
#'   \item \code{security_configuration}: Path of the Security Configuration XML file.
#'   \item \code{role}: The structured role object passed to the XML generators.
#'   \item \code{subroles}: Vector of sub-role identifiers.
#' }
#'
#' @examples
#' \dontrun{
#' # Aus find_menu_item_security nahtlos in export_role_from_graph_xml:
#' t <- find_menu_item_security(
#'   PRIVILEGEIDENTIFIER = c("SalesFormLetter_InvoiceMaintain", "CredManForceHoldProcess"),
#'   ROLEIDENTIFIER = c("CollectionLetterCollectionsManager", "CustInvoiceAccountsReceivableClerk")
#' ) |>
#'   dplyr::mutate(
#'     ROLEIDENTIFIER    = "_WIBU_VERKAUF_INNENDIENSTMITARBEITER_ZUSATZ_FIN",
#'     ROLENAME          = "_WIBU Verkauf Innendienstmitarbeiter Zusatz Fin",
#'     SUBROLEIDENTIFIER = NA_character_,
#'     DUTYIDENTIFIER    = NA_character_,
#'     DUTYNAME          = NA_character_
#'   )
#'
#' export_role_from_graph_xml(
#'   graph         = t,
#'   output_folder = "Data/SecurityObjects"
#' )
#' }
#'
#' @export
export_role_from_graph_xml <- function(graph,
                                       role_identifier = NULL,
                                       output_folder,
                                       name = NULL,
                                       label = NULL,
                                       zip = TRUE,
                                       browser_files = TRUE,
                                       as_change = NULL) {

  if (!is.character(graph) && !is.data.frame(graph)) {
    stop("graph must be a data frame / tibble or a file path to graph Excel exports.", call. = FALSE)
  }

  if (is.character(graph)) {
    graph <- read_license_graph(path = graph)
  }

  if (!.is_single_string(output_folder)) {
    stop("output_folder must be the path of one folder.", call. = FALSE)
  }

  names(graph) <- toupper(names(graph))

  # Alias-Normalisierung (unterstützt beide Schemata nahtlos)
  if (!"ROLEIDENTIFIER" %in% names(graph)) {
    if ("ROLE_ID" %in% names(graph)) graph$ROLEIDENTIFIER <- graph$ROLE_ID
    else if ("ROLE" %in% names(graph)) graph$ROLEIDENTIFIER <- graph$ROLE
  }
  if (!"ROLENAME" %in% names(graph)) {
    if ("ROLE_NAME" %in% names(graph)) graph$ROLENAME <- graph$ROLE_NAME
    else if ("ROLELABEL" %in% names(graph)) graph$ROLENAME <- graph$ROLELABEL
    else if ("ROLEIDENTIFIER" %in% names(graph)) graph$ROLENAME <- graph$ROLEIDENTIFIER
  }
  if (!"SUBROLEIDENTIFIER" %in% names(graph)) {
    if ("SUBROLE_ID" %in% names(graph)) graph$SUBROLEIDENTIFIER <- graph$SUBROLE_ID
    else if ("SUBROLE" %in% names(graph)) graph$SUBROLEIDENTIFIER <- graph$SUBROLE
  }
  if (!"DUTYIDENTIFIER" %in% names(graph)) {
    if ("DUTY_ID" %in% names(graph)) graph$DUTYIDENTIFIER <- graph$DUTY_ID
    else if ("DUTY" %in% names(graph)) graph$DUTYIDENTIFIER <- graph$DUTY
  }
  if (!"DUTYNAME" %in% names(graph)) {
    if ("DUTY_NAME" %in% names(graph)) graph$DUTYNAME <- graph$DUTY_NAME
  }
  if (!"PRIVILEGEIDENTIFIER" %in% names(graph)) {
    if ("PRIVILEGE_ID" %in% names(graph)) graph$PRIVILEGEIDENTIFIER <- graph$PRIVILEGE_ID
    else if ("PRIVILEGE" %in% names(graph)) graph$PRIVILEGEIDENTIFIER <- graph$PRIVILEGE
  }
  if (!"PRIVILEGENAME" %in% names(graph)) {
    if ("PRIVILEGE_NAME" %in% names(graph)) graph$PRIVILEGENAME <- graph$PRIVILEGE_NAME
  }
  if (!"SECURABLENAME" %in% names(graph)) {
    if ("MENU_ITEM" %in% names(graph)) graph$SECURABLENAME <- graph$MENU_ITEM
    else if ("RESOURCE_" %in% names(graph)) graph$SECURABLENAME <- graph$RESOURCE_
  }

  required_cols <- c("ROLEIDENTIFIER", "ROLENAME")
  missing_cols <- setdiff(required_cols, names(graph))
  if (length(missing_cols) > 0L) {
    stop("graph is missing required columns: ", paste(missing_cols, collapse = ", "), call. = FALSE)
  }

  # Identify available roles in graph
  valid_roles <- unique(graph$ROLEIDENTIFIER[!.is_blank(graph$ROLEIDENTIFIER)])

  if (is.null(role_identifier)) {
    if (length(valid_roles) == 1L) {
      role_identifier <- valid_roles[[1]]
    } else if (length(valid_roles) == 0L) {
      stop("The graph contains no roles (ROLEIDENTIFIER is empty).", call. = FALSE)
    } else {
      stop("The graph contains multiple roles: ",
           paste(head(valid_roles, 5), collapse = ", "),
           if (length(valid_roles) > 5) "..." else "",
           ". Please specify 'role_identifier'.", call. = FALSE)
    }
  }

  if (!.is_single_string(role_identifier)) {
    stop("role_identifier must name exactly one role: the AOT name or GUID.", call. = FALSE)
  }

  # Filter matching rows for role
  match_id   <- .identifier_key(graph$ROLEIDENTIFIER) == .identifier_key(role_identifier)
  match_name <- .identifier_key(graph$ROLENAME) == .identifier_key(role_identifier)
  role_rows  <- graph[match_id | match_name, , drop = FALSE]

  if (nrow(role_rows) == 0L) {
    stop("Role '", role_identifier, "' was not found in graph.", call. = FALSE)
  }

  # Resolve role name and label
  stored_id   <- as.character(role_rows$ROLEIDENTIFIER[1])
  stored_name <- as.character(role_rows$ROLENAME[1])
  role_names  <- .role_xml_names(stored_id, stored_name)

  final_name  <- if (is.null(name)) role_names$name else name
  final_label <- if (is.null(label)) role_names$label else label

  # Intelligenter Tausch, falls Identifier Leerzeichen hat, aber Label ein gueltiger AOT-Identifier ohne Leerzeichen ist
  if (is.null(name) && grepl("\\s", final_name) && !grepl("\\s", final_label) && grepl("^[A-Za-z0-9_][A-Za-z0-9_-]*$", final_label)) {
    tmp <- final_name
    final_name <- final_label
    final_label <- tmp
  }

  .check_aot_name(final_name)

  # Extract components: what role holds directly vs via subroles
  has_subrole <- "SUBROLEIDENTIFIER" %in% names(role_rows)
  has_duty    <- "DUTYIDENTIFIER" %in% names(role_rows)
  has_priv    <- "PRIVILEGEIDENTIFIER" %in% names(role_rows)

  own          <- if (has_subrole) .is_blank(role_rows$SUBROLEIDENTIFIER) else rep(TRUE, nrow(role_rows))
  no_duty      <- if (has_duty) .is_blank(role_rows$DUTYIDENTIFIER) else rep(TRUE, nrow(role_rows))
  no_privilege <- if (has_priv) .is_blank(role_rows$PRIVILEGEIDENTIFIER) else rep(TRUE, nrow(role_rows))

  duties <- if (has_duty) {
    unique(as.character(role_rows$DUTYIDENTIFIER[own & !no_duty]))
  } else {
    character()
  }

  privileges <- if (has_priv) {
    unique(as.character(role_rows$PRIVILEGEIDENTIFIER[own & no_duty & !no_privilege]))
  } else {
    character()
  }

  subroles <- if (has_subrole) {
    unique(as.character(role_rows$SUBROLEIDENTIFIER[!own]))
  } else {
    character()
  }

  duties     <- duties[!.is_blank(duties)]
  privileges <- privileges[!.is_blank(privileges)]
  subroles   <- subroles[!.is_blank(subroles)]

  # Direct access permissions (if present in graph, e.g. direct securable access without duty/priv)
  direct_access_permissions <- data.frame(
    ObjektTyp  = character(),
    Objektname = character(),
    Ebene      = character(),
    Feldname   = character(),
    Create     = character(),
    Correct    = character(),
    Delete     = character(),
    Invoke     = character(),
    Read       = character(),
    Update     = character(),
    stringsAsFactors = FALSE
  )

  role_data <- list(
    role_name = final_name,
    role_description = "",
    role_label = final_label,
    duties = duties,
    privileges = privileges,
    subroles = subroles,
    duty_count = length(duties),
    privilege_count = length(privileges),
    subrole_count = length(subroles),
    has_direct_access_permissions = nrow(direct_access_permissions) > 0,
    direct_access_permissions = direct_access_permissions
  )

  # Check self-subrole and remove duplicate subroles
  role_data$subroles      <- .unique_subroles(role_data$subroles)
  role_data$subrole_count <- length(role_data$subroles)
  .stop_on_self_subrole(role_data)

  # Prepare output folder
  dir.create(output_folder, recursive = TRUE, showWarnings = FALSE)

  # 1. AOT role XML
  aot_folder <- file.path(output_folder, .AOT_ROLE_FOLDER)
  dir.create(aot_folder, recursive = TRUE, showWarnings = FALSE)
  xml_file <- file.path(.AOT_ROLE_FOLDER, paste0(role_data$role_name, ".xml"))
  xml_path <- file.path(output_folder, xml_file)
  create_d365fo_role_xml(role_data, xml_path)

  # 2. Zip archive
  zip_path <- if (isTRUE(zip)) {
    .zip_metadata(output_folder, xml_file, role_data$role_name)
  } else {
    NA_character_
  }

  # 3. Browser files (SecurityGovernance and SecurityConfiguration)
  browser_res <- if (isTRUE(browser_files)) {
    change_flag <- if (is.null(as_change)) {
      .identifier_key(role_data$role_name) == .identifier_key(stored_name) && !is_guid_name(role_data$role_name)
    } else {
      isTRUE(as_change)
    }
    roles <- list(role_data)
    .write_browser_files(
      output_folder,
      role_data$role_name,
      new_roles     = if (change_flag) list() else roles,
      changed_roles = if (change_flag) roles else list()
    )
  } else {
    .NO_BROWSER_FILES
  }

  message(sprintf(
    "Role %s exported from graph into 3 XML formats: %d duties, %d privileges, %d sub-roles.",
    role_data$role_name,
    length(role_data$duties),
    length(role_data$privileges),
    length(role_data$subroles)
  ))

  invisible(list(
    xml                    = xml_path,
    zip                    = zip_path,
    security_governance    = browser_res[["governance"]],
    security_configuration = browser_res[["configuration"]],
    role                   = role_data,
    subroles               = role_data$subroles
  ))
}
