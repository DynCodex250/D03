#' Read the catalog of segregation of duties
#'
#' Reads the catalog of segregation of duties (SoD) from an Excel workbook in
#' the layout of \code{SoD_Katalog.xlsx}: the functions that are checked, the
#' D365 duties that carry each function, and the rules, each a pair of
#' functions that must not be in one hand. The catalog does not belong to a
#' project; \code{\link{build_sod_matrix}} applies it to the roles of an
#' environment.
#'
#' @details
#'
#' **Sheets.** The workbook needs three sheets with these header rows (German,
#' as the catalog writes them; further columns are left out):
#' \describe{
#'   \item{\code{Funktionen}}{\code{Funktions-ID}, \code{Bereich},
#'     \code{Funktion}; optional \code{Function (EN)}, \code{Art},
#'     \code{Beschreibung}.}
#'   \item{\code{Funktionen_Aufgaben}}{\code{Funktions-ID},
#'     \code{Aufgabe (Systemname)}; optional \code{Aufgabe (Bezeichnung)}.
#'     A row with an empty system name stands for a function no standard duty
#'     carries yet.}
#'   \item{\code{Regeln}}{\code{Regel-ID}, \code{Funktion 1 (ID)},
#'     \code{Funktion 2 (ID)}, \code{Risiko}, \code{Schwere}; optional
#'     \code{Behandlung (Vorschlag)},
#'     \code{Ausgleichende Kontrolle (Vorschlag)}, \code{Quelle}.}
#' }
#'
#' **Checks.** The function stops when an id is empty or appears twice, when a
#' duty or rule names a function the catalog lacks, when a rule pairs a
#' function with itself or names a pair another rule names already (in either
#' order), and when the severity is not \code{hoch}, \code{mittel} or
#' \code{niedrig}. \code{ALLE} as second function stands for every function
#' of another area; it is not allowed as first function.
#'
#' @param path
#' Path of the catalog workbook.
#'
#' @return
#' A list of three tibbles:
#' \describe{
#'   \item{\code{Functions}}{\code{FUNCTION_ID}, \code{AREA}, \code{FUNCTION},
#'     \code{FUNCTION_EN}, \code{KIND}, \code{DESCRIPTION}.}
#'   \item{\code{Duties}}{\code{FUNCTION_ID}, \code{DUTY},
#'     \code{DUTY_NAME}: one row per duty of a function; functions without a
#'     duty have no row.}
#'   \item{\code{Rules}}{\code{RULE_ID}, \code{FUNCTION_1}, \code{FUNCTION_2},
#'     \code{RISK}, \code{SEVERITY} (lower case), \code{TREATMENT},
#'     \code{CONTROL}, \code{SOURCE}.}
#' }
#'
#' @examples
#' \dontrun{
#'
#' catalog <- read_sod_catalog("Data/Input/Stakeholder/SoD_Katalog.xlsx")
#' table(catalog$Functions$AREA)
#'
#' }
#'
#' @seealso
#' \code{\link{build_sod_matrix}}
#' \code{\link{export_sod_matrix}}
#'
#' @export
read_sod_catalog <- function(path) {

  if (!.is_single_string(path) || !file.exists(path)) {
    stop("The catalog '", paste(path, collapse = ", "), "' was not found.", call. = FALSE)
  }
  sheets  <- readxl::excel_sheets(path)
  missing <- setdiff(names(.SOD_CATALOG_SHEETS), sheets)
  if (length(missing) > 0L) {
    stop("The catalog lacks the sheet", if (length(missing) == 1L) "" else "s", " ", paste(missing, collapse = .LIST_SEPARATOR),
         ".", call. = FALSE)
  }

  tables  <- Map(function(sheet, columns) .read_sod_sheet(path, sheet, columns), names(.SOD_CATALOG_SHEETS), .SOD_CATALOG_SHEETS)
  catalog <- list(
    Functions = tables$Funktionen,
    Duties    = tables$Funktionen_Aufgaben[!.is_blank(tables$Funktionen_Aufgaben$DUTY), ],
    Rules     = dplyr::mutate(tables$Regeln, SEVERITY = tolower(SEVERITY))
  )
  .check_sod_catalog(catalog, tables$Funktionen_Aufgaben)

  without <- sum(!catalog$Functions$FUNCTION_ID %in% catalog$Duties$FUNCTION_ID)
  message(sprintf("SoD catalog: %d functions (%d without duty), %d duties, %d rules.",
                  nrow(catalog$Functions), without, nrow(catalog$Duties), nrow(catalog$Rules)))
  catalog
}

# The columns of each sheet: English name = German header; a trailing "?" marks an optional column.
.SOD_CATALOG_SHEETS <- list(
  Funktionen = c(FUNCTION_ID = "Funktions-ID", AREA = "Bereich", FUNCTION = "Funktion",
                 FUNCTION_EN = "Function (EN)?", KIND = "Art?", DESCRIPTION = "Beschreibung?"),
  Funktionen_Aufgaben = c(FUNCTION_ID = "Funktions-ID", DUTY = "Aufgabe (Systemname)", DUTY_NAME = "Aufgabe (Bezeichnung)?"),
  Regeln = c(RULE_ID = "Regel-ID", FUNCTION_1 = "Funktion 1 (ID)", FUNCTION_2 = "Funktion 2 (ID)", RISK = "Risiko",
             SEVERITY = "Schwere", TREATMENT = "Behandlung (Vorschlag)?", CONTROL = "Ausgleichende Kontrolle (Vorschlag)?",
             SOURCE = "Quelle?")
)

.SOD_SEVERITIES <- c("hoch", "mittel", "niedrig")
.SOD_ALL        <- "ALLE"

.read_sod_sheet <- function(path, sheet, columns) {
  table    <- readxl::read_excel(path, sheet = sheet, col_types = "text")
  optional <- endsWith(columns, "?")
  headers  <- sub("\\?$", "", columns)
  missing  <- headers[!optional & !headers %in% names(table)]
  if (length(missing) > 0L) {
    stop("The sheet ", sheet, " of the catalog lacks the column", if (length(missing) == 1L) "" else "s", " ",
         paste(missing, collapse = .LIST_SEPARATOR), ".", call. = FALSE)
  }
  values <- lapply(headers, function(header) {
    column <- if (header %in% names(table)) trimws(as.character(table[[header]])) else rep(NA_character_, nrow(table))
    ifelse(is.na(column) | !nzchar(column), NA_character_, column)
  })
  tibble::as_tibble(stats::setNames(values, names(columns)))
}

.check_sod_catalog <- function(catalog, duty_rows) {
  functions <- catalog$Functions
  rules     <- catalog$Rules
  .stop_on_bad_ids(functions$FUNCTION_ID, "Funktionen", "Funktions-ID")
  .stop_on_bad_ids(rules$RULE_ID, "Regeln", "Regel-ID")
  if (any(functions$FUNCTION_ID == .SOD_ALL)) {
    stop("ALLE stands for every function of another area and cannot be a Funktions-ID.", call. = FALSE)
  }
  if (any(is.na(functions$AREA))) {
    stop("The sheet Funktionen has functions without Bereich: ", paste(functions$FUNCTION_ID[is.na(functions$AREA)],
         collapse = .LIST_SEPARATOR), ". ALLE needs the area of each function.", call. = FALSE)
  }

  if (any(rules$FUNCTION_1 %in% .SOD_ALL)) {
    stop("ALLE stands only as Funktion 2 (ID): rule ", paste(rules$RULE_ID[rules$FUNCTION_1 %in% .SOD_ALL], collapse = .LIST_SEPARATOR),
         ".", call. = FALSE)
  }
  unknown_duty <- setdiff(stats::na.omit(duty_rows$FUNCTION_ID), functions$FUNCTION_ID)
  unknown_rule <- setdiff(c(rules$FUNCTION_1, setdiff(rules$FUNCTION_2, .SOD_ALL)), functions$FUNCTION_ID)
  if (length(c(unknown_duty, unknown_rule)) > 0L) {
    stop("The catalog names functions that the sheet Funktionen lacks: ",
         paste(unique(c(unknown_duty, unknown_rule)), collapse = .LIST_SEPARATOR), ".", call. = FALSE)
  }

  itself <- rules$FUNCTION_1 == rules$FUNCTION_2
  if (any(itself)) {
    stop("A rule pairs a function with itself: ", paste(rules$RULE_ID[itself], collapse = .LIST_SEPARATOR), ".", call. = FALSE)
  }
  pair  <- ifelse(rules$FUNCTION_1 < rules$FUNCTION_2, paste(rules$FUNCTION_1, rules$FUNCTION_2), paste(rules$FUNCTION_2, rules$FUNCTION_1))
  twice <- pair[duplicated(pair)]
  if (length(twice) > 0L) {
    names_twice <- vapply(unique(twice), function(p) paste(rules$RULE_ID[pair == p], collapse = " and "), character(1))
    stop("Rules name the same pair of functions: ", paste(names_twice, collapse = .LIST_SEPARATOR), ".", call. = FALSE)
  }
  bad <- unique(rules$SEVERITY[!rules$SEVERITY %in% .SOD_SEVERITIES])
  if (length(bad) > 0L) {
    stop("Schwere must be hoch, mittel or niedrig, not: ", paste(bad, collapse = .LIST_SEPARATOR), ".", call. = FALSE)
  }
  .warn_on_shared_duties(catalog$Duties)
  .warn_on_covered_rules(functions, rules)
  invisible(catalog)
}

# A duty in two functions: a role that holds only this duty holds both, but is no conflict.
.warn_on_shared_duties <- function(duties) {
  key    <- .identifier_key(duties$DUTY)
  shared <- unique(key[duplicated(key)])
  if (length(shared) > 0L) {
    which_functions <- vapply(shared, function(k) paste0(duties$DUTY[key == k][[1]], " (",
                                                         paste(unique(duties$FUNCTION_ID[key == k]), collapse = .LIST_SEPARATOR), ")"),
                              character(1))
    warning("Duties in more than one function: ", paste(which_functions, collapse = "; "),
            ". A role that holds only such a duty is no conflict of a rule between these functions.", call. = FALSE)
  }
  invisible(shared)
}

# A rule between two areas that an ALLE rule of the same first function covers already.
.warn_on_covered_rules <- function(functions, rules) {
  area_of <- stats::setNames(functions$AREA, functions$FUNCTION_ID)
  all     <- which(rules$FUNCTION_2 == .SOD_ALL)
  covered <- character()
  for (i in which(rules$FUNCTION_2 != .SOD_ALL)) {
    for (j in all) {
      first <- rules$FUNCTION_1[[j]]
      other <- setdiff(c(rules$FUNCTION_1[[i]], rules$FUNCTION_2[[i]]), first)
      if (first %in% c(rules$FUNCTION_1[[i]], rules$FUNCTION_2[[i]]) && length(other) == 1L &&
          !identical(area_of[[other]], area_of[[first]])) {
        covered <- c(covered, sprintf("%s by %s", rules$RULE_ID[[i]], rules$RULE_ID[[j]]))
      }
    }
  }
  if (length(covered) > 0L) {
    warning("Rules that an ALLE rule covers already: ", paste(covered, collapse = .LIST_SEPARATOR),
            ". Their pairs of duties appear twice.", call. = FALSE)
  }
  invisible(covered)
}

.stop_on_bad_ids <- function(ids, sheet, column) {
  if (any(is.na(ids))) {
    stop("The sheet ", sheet, " has rows without ", column, ".", call. = FALSE)
  }
  twice <- unique(ids[duplicated(ids)])
  if (length(twice) > 0L) {
    stop("The sheet ", sheet, " has the ", column, " ", paste(twice, collapse = .LIST_SEPARATOR), " more than once.", call. = FALSE)
  }
  invisible(ids)
}
