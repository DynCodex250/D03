#' Pseudonymize the raw license data (stage 1)
#'
#' The first of two stages: before a deliverable is rendered, the raw exports
#' become the pseudonymized files in \code{Data/Input/PPAC/pseudonymized}, from
#' which the deliverables read. Real user data thus reaches neither the
#' deliverables nor the repository.
#'
#' @details
#'
#' **One key.** All files are pseudonymized with the same key file, so a user
#' keeps one pseudonym across them and the files still match.
#'
#' **What changes.** The user id is taken from the mail address, the part
#' before the \code{@}, so that it matches the telemetry and the database. The
#' reports lose the ids of Microsoft (\code{UserId}, \code{TenantId},
#' \code{EnvironmentId}). The employee list also loses names, companies and
#' units. In the telemetry only the user ids change.
#'
#' **Only known columns.** The result holds the columns the analyses use. A raw
#' file with any other column stops the function and names that column: it
#' could hold personal data under a name no pattern knows. Then decide about
#' the column and add it to the lists in this file.
#'
#' **One key, also over time.** While \code{output_folder} holds pseudonymized
#' files, a missing key file stops the function: a new key would give other
#' pseudonyms, and the old and the new files would no longer match.
#'
#' **Checked first.** All raw files are read and checked before anything is
#' written. Should writing fail later, the raw files are untouched: run it again
#' with \code{overwrite = TRUE}.
#'
#' @param report_path
#' The license report per user of the Power Platform admin center (\code{.csv}
#' with the column \code{UserEmail}).
#'
#' @param detail_path
#' The detailed license report (\code{.csv} with the column \code{UserEmail}).
#'
#' @param output_folder
#' The folder of the pseudonymized files, as a rule
#' \code{Data/Input/PPAC/pseudonymized}. Created when missing.
#'
#' @param key_path
#' The key file of \code{\link{anonymize_data}}, created or extended. It must
#' not lie in \code{output_folder}.
#'
#' @param employees_path
#' The employee list (\code{.xlsx}, sheet \code{Mitarbeiter}, the headers in
#' the second row, with the column \code{E-Mail}); \code{NULL} = none.
#'
#' @param telemetry
#' The telemetry, any source of \code{\link{read_usage_telemetry}}, for example
#' \code{"insights"}; \code{NULL} = none.
#'
#' @param overwrite
#' \code{TRUE} = replace existing files. Default \code{FALSE}.
#'
#' @return
#' Invisibly a list with the paths written: \code{report}, \code{detail} and,
#' when given, \code{employees} and \code{telemetry}. A raw file keeps its name
#' with \code{_pseudonymized} added; the telemetry becomes
#' \code{Telemetrie_pseudonymized.xlsx}.
#'
#' @examples
#' \dontrun{
#'
#' cfg   <- load_project_config()
#' input <- cfg$base_paths$input_root
#' pseudonymize_license_data(
#'   report_path    = file.path(input, "PPAC", "Finance_And_Operations_Licensing_Report_20261027.csv"),
#'   detail_path    = file.path(input, "PPAC", "Finance_And_Operations_Licensing_Detailed_Report_20261027.csv"),
#'   output_folder  = file.path(input, cfg$base_paths$subdirs_input$ppac_pseudonymized),
#'   key_path       = file.path(cfg$base_paths$keys_root, cfg$pseudonymization$key_file),
#'   employees_path = file.path(input, "PPAC", "MitarbeiterListe_20260317.xlsx"),
#'   telemetry      = "insights"
#' )
#'
#' }
#'
#' @seealso
#' \code{\link{anonymize_data}}
#' \code{\link{read_usage_telemetry}}
#'
#' @export
pseudonymize_license_data <- function(report_path, detail_path, output_folder, key_path,
                                      employees_path = NULL, telemetry = NULL, overwrite = FALSE) {

  .check_key_path(key_path)
  .check_key_outside_export(TRUE, key_path, output_folder)
  if (!file.exists(key_path) && length(list.files(output_folder, "_pseudonymized")) > 0L) {
    stop("'", output_folder, "' holds pseudonymized files, but the key file '", key_path, "' is missing: a new key would give ",
         "other pseudonyms, and the files would no longer match. Put the key file in place, or empty the folder.", call. = FALSE)
  }

  targets <- c(report = .pseudonymized_path(report_path, output_folder), detail = .pseudonymized_path(detail_path, output_folder))
  if (!is.null(employees_path)) targets[["employees"]] <- .pseudonymized_path(employees_path, output_folder)
  if (!is.null(telemetry)) targets[["telemetry"]] <- file.path(output_folder, "Telemetrie_pseudonymized.xlsx")
  taken <- targets[file.exists(targets)]
  if (length(taken) > 0L && !overwrite) {
    stop("'", taken[[1]], "' exists. Give overwrite = TRUE to replace it.", call. = FALSE)
  }

  report    <- .read_raw_license_csv(report_path, .RAW_REPORT_COLUMNS, "License report")
  detail    <- .read_raw_license_csv(detail_path, .RAW_DETAIL_COLUMNS, "Detailed license report")
  employees <- if (!is.null(employees_path)) .read_raw_employees(employees_path)
  usage     <- if (!is.null(telemetry)) .read_telemetry_source(telemetry)
  if (!is.null(usage)) {
    if (nrow(usage) == 0L) {
      stop("The telemetry from '", telemetry, "' holds no rows. Nothing is written, so that an earlier file stays.", call. = FALSE)
    }
    .check_known_columns(names(usage), .RAW_TELEMETRY_COLUMNS, telemetry)
  }

  dir.create(dirname(key_path), recursive = TRUE, showWarnings = FALSE)
  dir.create(output_folder, recursive = TRUE, showWarnings = FALSE)

  .write_pseudonymized_csv(anonymize_data(report, key_path), targets[["report"]])
  .write_pseudonymized_csv(anonymize_data(detail, key_path), targets[["detail"]])
  if (!is.null(employees)) {
    writexl::write_xlsx(anonymize_data(employees, key_path, columns = .employee_columns()), targets[["employees"]])
  }
  if (!is.null(usage)) {
    writexl::write_xlsx(.pseudonymize_telemetry(usage, key_path, new_key = TRUE), targets[["telemetry"]])
  }

  message(sprintf("Stage 1: %d pseudonymized files in %s.", length(targets), output_folder))
  invisible(as.list(targets))
}

# The columns that hold no person and go into the result, besides the mail address. New columns
# are decided here on purpose: a name no pattern knows could hold personal data.
.RAW_REPORT_COLUMNS <- c("RequiredLicense(s)", "AssignedLicense(s)", "MissingLicense(s)", "RefreshedOn")
.RAW_DETAIL_COLUMNS <- c("EnvironmentName", "EnvironmentType", "SecurityRole", "RequiredLicense", "AssignedLicense(s)", "RefreshedOn")
# The ids of Microsoft, left out of the result.
.RAW_ID_COLUMNS     <- c("UserId", "TenantId", "EnvironmentId")
# Every column of the employee list is pseudonymized.
.RAW_EMPLOYEE_COLUMNS <- c("Personalnummer", "Name", "Vorname", "Voller Name", "E-Mail", "Gesellschaft Name", "Gesellschaft ID",
                           "Name der Organisationseinheit", "Name des Vorgesetzten")

# The telemetry: only user_Id holds a person.
.RAW_TELEMETRY_COLUMNS <- c("user_Id", "name", "touches", "last_seen", "duration_seconds")

# Headers may hold a line break, written differently by Excel and the readers.
.normalized_headers <- function(columns) trimws(gsub("[[:space:]]+", " ", columns))

.check_known_columns <- function(columns, known, path) {
  headers <- .normalized_headers(columns)
  unknown <- setdiff(headers[nzchar(headers)], known)
  if (length(unknown) > 0L) {
    stop("'", path, "' holds columns stage 1 does not know: ", paste(unknown, collapse = .LIST_SEPARATOR),
         ". They could hold personal data: decide about them in R/pseudonymize_License_data.R.", call. = FALSE)
  }
  invisible(columns)
}

.pseudonymized_path <- function(path, folder) {
  if (!.is_single_string(path)) stop("The path of a raw file must be one path.", call. = FALSE)
  extension <- sub("^.*([.][^.]+)$", "\\1", basename(path))
  file.path(folder, paste0(sub("[.][^.]+$", "", basename(path)), "_pseudonymized", extension))
}

.user_id_of_mail <- function(mail) sub("@.*$", "", mail)

# .read_ppac_csv() checks the file and gives the columns it is asked for: the known ones of this file.
.read_raw_license_csv <- function(path, known, what) {
  .read_ppac_csv(path, "UserEmail", what)
  columns <- names(utils::read.csv(path, nrows = 1L, check.names = FALSE, fileEncoding = "UTF-8-BOM"))
  .check_known_columns(columns, c("UserEmail", known, .RAW_ID_COLUMNS), path)
  table <- .read_ppac_csv(path, c("UserEmail", intersect(known, columns)), what)
  table$USERID <- .user_id_of_mail(table$UserEmail)
  table
}

.read_raw_employees <- function(path) {
  if (!file.exists(path)) stop("Employee list: file not found: ", path, call. = FALSE)
  employees <- readxl::read_excel(path, sheet = "Mitarbeiter", skip = 1)
  # Before the check and the patterns of .employee_columns(), which know the headers in this form.
  names(employees) <- .normalized_headers(names(employees))
  .check_required_columns(employees, "E-Mail", "employees")
  .check_known_columns(names(employees), .RAW_EMPLOYEE_COLUMNS, path)
  employees$USERID <- .user_id_of_mail(employees$`E-Mail`)
  employees
}

.employee_columns <- function() {
  standard <- default_anonymization_columns()
  utils::modifyList(standard, list(
    EMAIL  = c(standard$EMAIL, "^E-Mail$", "^Gesellschaft", "Name der Organisationseinheit"),
    PERSON = c(standard$PERSON, "^Name$", "^Name des Vorgese", "^Vorname", "Voller Name")
  ))
}

.write_pseudonymized_csv <- function(table, path) {
  utils::write.csv(table, path, row.names = FALSE, na = "", fileEncoding = "UTF-8")
}
