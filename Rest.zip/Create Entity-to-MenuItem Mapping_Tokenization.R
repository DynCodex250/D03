# ============================================================
# MENU ITEM <-> ENTITY MATCHING GEGEN REFERENZ-TABELLE
# ============================================================
#
# Ausgangslage:
# - Mapping-Tabelle: Menu Item Name, Menu Path, Product, Module,
#   "Included in entity" (kommagetrennte Liste von Entities, aber
#   EINZELNE Entity-Namen können selbst Kommas enthalten!)
# - Results-Tabelle: führende Referenzquelle für gültige,
#   tatsächlich existierende Entity-Namen
#
# Ziel:
# - "Included in entity" korrekt in einzelne Entities zerlegen
#   (NICHT durch blindes Splitten an jedem Komma)
# - Für jede erkannte Entity eine eigene Zeile ("Target")
# - Alle Original-Spalten bleiben erhalten
# - Abgleich gegen Results-Tabelle: existiert das Target wirklich?
# - Liste aller nicht gefundenen/unbekannten Entities ausgeben
#
# ============================================================

library(dplyr)
library(tidyr)
library(stringr)
library(purrr)

# ------------------------------------------------------------
# WARUM EIN EINFACHES SPLITTEN PER KOMMA NICHT FUNKTIONIERT
# ------------------------------------------------------------
#
# Beispiel:
#   Included in entity = "Customers, prospects, Vendor accounts"
#
# Ist das:
#   (a) drei einzelne Entities: "Customers", "prospects", "Vendor accounts"
#   (b) zwei Entities: "Customers, prospects" (ein einziger, offizieller
#       Entity-Name mit Komma) und "Vendor accounts"
#
# Ohne Kenntnis der tatsächlich existierenden Entity-Namen ist das
# NICHT eindeutig entscheidbar. Ein naives str_split(",") würde
# IMMER Variante (a) erzeugen - und im Fall (b) fälschlicherweise
# einen gültigen Entity-Namen zerstören und zwei ungültige
# Fragmente erzeugen.
#
# Deshalb wird die Results-Tabelle als Wörterbuch benutzt:
# Wir versuchen am Textanfang IMMER zuerst den LÄNGSTEN bekannten,
# gültigen Namen zu matchen (Longest-Match-Tokenisierung, ähnlich
# der Worttrennung in Sprachen ohne Leerzeichen). Nur wenn gar
# kein bekannter Name passt, wird als Fallback bis zum nächsten
# Komma geschnitten und der Abschnitt als "UNMATCHED" markiert.


#' Einen "Included in entity"-Text anhand bekannter, gültiger
#' Entity-Namen in einzelne Tokens zerlegen (Longest-Match).
#'
#' @param text Einzelner String, z.B. "A, B and C, D".
#' @param valid_entities Character-Vektor aller gültigen,
#'   bekannten Entity-Namen (aus der Results-Tabelle).
#'
#' @return Character-Vektor mit den erkannten Entities. Nicht
#'   erkannte Textabschnitte werden mit Prefix "UNMATCHED: "
#'   zurückgegeben, damit sie später als Datenqualitätsproblem
#'   sichtbar bleiben (statt still verworfen zu werden).
tokenize_entities <- function(text, valid_entities) {

  text <- stringr::str_squish(text %||% "")

  if (text == "") {
    return(character(0))
  }

  # Längste Namen zuerst probieren, damit z.B. "Customers, prospects"
  # Vorrang vor dem kürzeren "Customers" hat, falls beides existiert.

  candidates <- valid_entities[order(-nchar(valid_entities))]
  candidates <- stringr::str_remove(stringr::str_squish(candidates), "[+;:]+$")


  found <- character(0)
  remaining <- text

  # Sicherheitszähler gegen Endlosschleifen bei unerwarteten Eingaben
  max_iterations <- 200
  iteration <- 0

  while (nchar(remaining) > 0 && iteration < max_iterations) {
    iteration <- iteration + 1

    remaining <- stringr::str_squish(remaining)
    remaining <- sub("^,\\s*", "", remaining)
    remaining <- stringr::str_squish(remaining)

    if (nchar(remaining) == 0) break

    match_found <- FALSE

    for (cand in candidates) {
      if (nchar(cand) == 0) next
      if (startsWith(remaining, cand)) {
        after <- stringr::str_squish(substring(remaining, nchar(cand) + 1))

        # Nur gültig, wenn direkt danach Textende ODER ein Komma folgt
        # (verhindert Teiltreffer wie "Cust" innerhalb "Customers")
        if (after == "" || startsWith(after, ",")) {
          found <- c(found, cand)
          remaining <- after
          match_found <- TRUE
          break
        }
      }
    }

    if (!match_found) {
      # Kein bekannter Name passt -> bis zum nächsten Komma als
      # unbekannten Abschnitt markieren, damit die Schleife weiterläuft
      comma_pos <- regexpr(",", remaining, fixed = TRUE)

      if (comma_pos == -1) {
        found <- c(found, paste0("UNMATCHED: ", remaining))
        remaining <- ""
      } else {
        chunk <- stringr::str_squish(substring(remaining, 1, comma_pos - 1))
        found <- c(found, paste0("UNMATCHED: ", chunk))
        remaining <- substring(remaining, comma_pos + 1)
      }
    }
  }

  return(found)
}


#' Mapping-Tabelle normalisieren und gegen Results-Tabelle(EntityMonitoringResults siehe SQL Skript) validieren
#'
#' @param mapping_data Tibble mit mind. der Spalte source_col.
#' @param dmfEntity_data Tibble/Referenztabelle mit den gültigen
#'   Entity-Namen in Spalte valid_entity_col.
#' @param source_col Spalte mit dem Rohtext (Standard:
#'   "Included in entity").
#' @param valid_entity_col Spalte in dmfEntity_data, die die
#'   gültigen Entity-Namen enthält (Standard: "ENTITYNAME").
#' @param target_col Name der neu erzeugten Spalte (Standard:
#'   "Target").
#'
#' @return Liste mit zwei Elementen:
#'   - normalized: Mapping-Tabelle, 1 Entity pro Zeile, plus
#'     Spalte FoundInResults (TRUE/FALSE)
#'   - invalid: eindeutige Liste aller nicht gefundenen /
#'     unbekannten Targets (Datenqualitätsreport)
match_menuitems_to_entities <- function(
    mapping_data,
    dmfEntity_data,
    source_col = "Included in entity",
    valid_entity_col = "ENTITYNAME",
    target_col = "Target") {

  if (!source_col %in% names(mapping_data)) {
    stop(paste0("Spalte '", source_col, "' nicht in mapping_data gefunden."))
  }

  if (!valid_entity_col %in% names(dmfEntity_data)) {
    stop(paste0("Spalte '", valid_entity_col, "' nicht in dmfEntity_data gefunden."))
  }

  valid_entities <- dmfEntity_data[[valid_entity_col]] |>
    unique() |>
    stringr::str_squish()

  # ----------------------------------------
  # TOKENISIERUNG PRO ZEILE
  # ----------------------------------------
  normalized <- mapping_data |>
    dplyr::mutate(
      .row_id = dplyr::row_number(),
      .tokens = purrr::map(
        .data[[source_col]],
        tokenize_entities,
        valid_entities = valid_entities
      )
    ) |>
    tidyr::unnest(.tokens, keep_empty = TRUE) |>
    dplyr::rename(!!target_col := .tokens) |>
    dplyr::select(-.row_id)

  # ----------------------------------------
  # ABGLEICH GEGEN RESULTS-TABELLE
  # ----------------------------------------
  valid_lookup <- tibble::tibble(
    !!target_col := valid_entities,
    FoundInResults = TRUE
  ) |>
    dplyr::distinct()

  normalized <- normalized |>
    dplyr::left_join(valid_lookup, by = target_col) |>
    dplyr::mutate(
      FoundInResults = dplyr::coalesce(FoundInResults, FALSE),
      IsUnmatchedFragment = stringr::str_starts(.data[[target_col]], "UNMATCHED: ")
    )

  # ----------------------------------------
  # DATENQUALITÄTSREPORT: NICHT GEFUNDENE ENTITIES
  # ----------------------------------------
  invalid <- normalized |>
    dplyr::filter(!FoundInResults) |>
    dplyr::distinct(.data[[target_col]], .data[[source_col]]) |>
    dplyr::arrange(.data[[target_col]])

  list(
    normalized = normalized,
    invalid    = invalid
  )
}


# ============================================================
# ANWENDUNG AUF DEINE ECHTEN DATEN
# ============================================================

source("C:/Users/ckam_admin/Documents/RProjects/Funktionen_SQLConnection.R")
cred <- "C:\\Users\\ckam_admin\\Documents\\RProjects\\D365_Admin\\db_credentials.xlsx"
cnn_T <- get_connection("TST", cred)

dmf_data  <- dbGetQuery(cnn_T, "SELECT LOWER(ENTITYNAME) AS ENTITYNAME, LOWER(TARGETENTITY) AS TARGETENTITY FROM DMFENTITY") #readxl::read_excel("results_tabelle.xlsx")
# bzw. direkt aus SQL: DBI::dbGetQuery(connection, "SELECT DISTINCT ENTITYNAME FROM ...")



result <- match_menuitems_to_entities(
  mapping_data,
  dmf_data,
  source_col       = "Included in entity",
  valid_entity_col = "ENTITYNAME",
  target_col       = "Target"
)



writexl::write_xlsx(
  list(
    normalized_table  = normalized_table,
    invalid_entities  = invalid_entities
    ),
    paste0(p,"data//mapping_normalized.xlsx"))

# ============================================================
# BEISPIEL ZUR VERIFIKATION
# ============================================================

example_mapping <- tibble::tibble(
  `Menu Item Name`      = c("Asset Management", "Customer Setup"),
  `Included in entity`  = c("Asset management manufacturers, 
                            Asset management models",
                            "Customers, prospects, Vendor accounts"))

# Angenommen, "Customers, prospects" ist selbst EIN gültiger,
# offizieller Entity-Name (mit Komma!) in der Results-Tabelle:
example_results <- tibble::tibble(
  ENTITYNAME = c(
    "Asset management manufacturers",
    "Asset management models",
    "Customers, prospects",
    "Vendor accounts"
  )
)

test_result <- match_menuitems_to_entities(
  example_mapping,
  example_results,
  valid_entity_col = "ENTITYNAME"
)

print(test_result$normalized)

# -> "Customers, prospects, Vendor accounts" wird korrekt in
#    EXAKT ZWEI Zeilen aufgeteilt ("Customers, prospects" und
#    "Vendor accounts"), NICHT in drei falsche Fragmente.

print(test_result$invalid)

