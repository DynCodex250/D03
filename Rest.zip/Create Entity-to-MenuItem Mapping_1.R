#' Create Entity-to-MenuItem Mapping from Business Process Catalog Data
#'
#' Creates a normalized mapping table between Dynamics 365 Finance & Operations
#' menu items and data entities based on the Microsoft Business Process Catalog
#' (BPC) files. The function expands the semantically overloaded
#' "Included in entity" column into a one-entity-per-row structure and optionally
#' validates the resulting entities against a technical entity inventory.
#'
#' @description
#' The Microsoft BPC files contain menu item to entity mappings in which multiple
#' entities may be stored within the same field ("Included in entity").
#'
#' This function:
#' \enumerate{
#'   \item Preserves the original mapping table.
#'   \item Creates a new column called \code{Target}.
#'   \item Expands multiple entities into separate rows.
#'   \item Retains all original business metadata.
#'   \item Optionally validates the resulting entities against a reference table.
#' }
#'
#' @param mapping_df Data frame containing the Business Process Catalog mapping.
#' @param entity_col Name of the column containing the source entities.
#'   Default: \code{"Included in entity"}.
#' @param validation_df Optional reference table containing valid entities.
#' @param validation_col Column in the validation table containing entity names.
#' @param separator Separator used between entity names.
#'   Default: \code{",\\s*"}.
#'
#' @return
#' A list containing:
#' \describe{
#'   \item{mapping}{Normalized mapping table.}
#'   \item{invalid_entities}{Entities not found in the validation dataset.}
#'   \item{summary}{Summary statistics.}
#' }
#'
#' @examples
#' mapping_result <- create_entity_mapping(
#'   mapping_df = df_all,
#'   validation_df = entity_inventory,
#'   validation_col = "EntityName"
#' )
#'
#' mapping_result$mapping
#' mapping_result$invalid_entities
#'
#' @export
create_entity_mapping <- function(mapping_df,
                                  entity_col = "Included in entity",
                                  validation_df = NULL,
                                  validation_col = NULL,
                                  separator = ",\\s*") {

  library(dplyr)
  library(tidyr)

  mapping_normalized <- mapping_df %>%
    mutate(Target = .data[[entity_col]]) %>%
    separate_rows(Target, sep = separator) %>%
    mutate(Target = trimws(Target))


  invalid_entities <- NULL

  if (!is.null(validation_df) &&
      !is.null(validation_col)) {

    invalid_entities <- mapping_normalized %>%
      anti_join(
        validation_df,
        by = setNames(validation_col, "Target")
      ) %>%
      distinct(Target)

    mapping_normalized <- mapping_normalized %>%
      left_join(
        validation_df,
        by = setNames(validation_col, "Target"),
        keep =T
      ) %>%
      mutate(
        Entity_Found = !is.na(.data[[validation_col]])
      )
  }

  summary_tbl <- tibble(
    Source_Rows = nrow(mapping_df),
    Mapping_Rows = nrow(mapping_normalized),
    Distinct_Targets = dplyr::n_distinct(mapping_normalized$Target),
    Invalid_Targets = ifelse(
      is.null(invalid_entities),
      NA,
      nrow(invalid_entities)
    )
  )

  list(
    mapping = mapping_normalized,
    invalid_entities = invalid_entities,
    summary = summary_tbl
  )
}


source("C:/Users/ckam_admin/Documents/RProjects/Funktionen_SQLConnection.R")
cred <- "C:\\Users\\ckam_admin\\Documents\\RProjects\\D365_Admin\\db_credentials.xlsx"
cnn_T <- get_connection("TST", cred)


results <- dbGetQuery(cnn_T, "SELECT LOWER(ENTITYNAME) AS ENTITYNAME, LOWER(TARGETENTITY) 
                      AS TARGETENTITY FROM DMFENTITY")

mapping_result <- create_entity_mapping(
  mapping_df = df_all,
  validation_df = results,
  validation_col = "ENTITYNAME"
)

dim(mapping_result$mapping)

mapping_expanded <- mapping_result$mapping
invalid_entities <- mapping_result$invalid_entities
summary_tbl <- mapping_result$summary
