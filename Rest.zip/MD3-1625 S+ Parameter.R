

#==================================================
# This code show case how i create a mapping table between data entities and menu items
#==================================================

#0 preparation

## libraries
library(readxl)
library(dplyr)
library(rlang)
library(writexl)
library(tidyr)

## paths
p <-"C:\\Users\\ckam_admin\\Documents\\RProjects\\D365_Admin\\Data\\MD3-1625 S+ Parameter\\"
folder <-"BPM"

# 1 Load old business process catalog files -  1 file per end-to-end process

col_old <-c("Work Item Type", "Title 4", "Menu Path", "Application Family",
       "Product", "Module","Menu Item Name","Included in entity")

# files <- list.files(path = paste0(p,folder), pattern = "xlsx", full.names = T)
# 
# bpc_list <- lapply(files, function(x){
#   read_xlsx(x, col_types = "text") #|> mutate(name = basename(x))
# 
# })
# 
# 
# bpc_df <- bind_rows(bpc_list)

#Daten wurden zusammengef�hrt, manuell angereichert und in data abgelegt

# write_xlsx(bpc_df, paste0(p,"data\\","Deliverables prior JUL 2026_Test.xlsx"))

# bpc_prior_JUL_2026 <- bpc_df |>
#   filter(
#     !is.na(`Included in entity`)#,grepl("Finance and operations apps",`Application Family`)
#   ) |>
#   select(all_of(col_old)); dim(bpc_prior_JUL_2026)


# 1

bpc_prior_JUL_2026 <- read_excel(
  paste0(p, "data\\", "Deliverables prior JUL 2026.xlsx"),
  col_types = "text") |>
  select(
    all_of(col_old)
  ) |>
  filter(
    !is.na(`Included in entity`)
  ) 

#2 load New Business process Catalog file -  all in one

col_new <- c("Work item type", "Title 4", "Menu path",
"Application family", "Products","Module","Menu item name", "Target data entity")

bpc_JUL_2026 <- read_excel(
  paste0(p, "data\\", "Deliverables JUL 2026.xlsx"), 
  col_types = "text",
  skip = 1) |>
  select(
    all_of(col_new)
  ) |>
  filter(
    !is.na(`Target data entity`)
  ) |>
  set_names(
    col_old
  )


## Merge old and new data
df_all <- bind_rows(
  bpc_prior_JUL_2026,
  bpc_JUL_2026
  
 ) |>
  mutate(
    `Included in entity` = tolower(`Included in entity`),
    `Included in entity` = gsub("\\+", "", `Included in entity`)
 )



write_xlsx(
  list(
    bpc_prior_JUL_2026 = bpc_prior_JUL_2026,
    bpc_JUL_2026 = bpc_JUL_2026,
    df_all = df_all
  )
  ,paste0(p,"data\\Business_Process_catalog_edited_.xlsx")
)




# jede Entit�t soll nur einmal vorkommen
# df_unique <- df_all |>
#   distinct(
#     `Included in entity`, .keep_all = TRUE
#   ); dim(bpc_unique)  
