
library(dplyr)
library(stringr)
source("C:/Users/ckam_admin/Documents/RProjects/Funktionen_SQLConnection.R")

p <-"C:\\Users\\ckam_admin\\Documents\\RProjects\\D365_Admin\\Data\\MD3-1625 S+ Parameter\\"
folder <-"BPM"

cred <- "C:\\Users\\ckam_admin\\Documents\\RProjects\\D365_Admin\\db_credentials.xlsx"

cnn_T <- get_connection("TST", cred)

dmf_data  <- dbGetQuery(
                cnn_T, 
                "SELECT 
                  LOWER(ENTITYNAME) AS ENTITYNAME,
                  LOWER(TARGETENTITY) AS TARGETENTITY 
                FROM DMFENTITY") #readxl::read_excel("results_tabelle.xlsx")

monitoring <- dbGetQuery(
                cnn_T, 
                "SELECT
                  LOWER(TargetEntity) AS TARGETENTITY,
                  LOWER(EntityName) AS ENTITYNAME,
                  RunDate, DataAreaId,
                  RecordCount
                FROM EntityMonitoringResults
                WHERE DataAreaId in ('0800','0700')"); head(monitoring)


monitoring_pivot <- monitoring |>
  pivot_wider(
    names_from = DataAreaId,
    values_from = RecordCount,
    names_prefix = "TST_",
    values_fill = 0
  ) |>
  mutate(
    Compare = TST_0700==TST_0800
  )

  mapping_data  <- readxl::read_excel(
    paste0(p, "Data\\Business_Process_catalog_edited.xlsx"),
    sheet = "df_all"
  ) %>%
    mutate(
      ENTITYNAME = tolower(`Included in entity`),
      MenuItem = case_when(
        # Dataverse/CRM Entity-Links verwerfen
        str_detect(`Menu Item Name`, "^&pagetype=entitylist") ~ NA_character_,
        TRUE ~ `Menu Item Name`
      ),

      # Menüeintrag aus URL oder &mi= extrahieren
      MenuItem = str_extract(MenuItem, "(?<=&mi=).*|^[^/]+$"),

      # D365-Präfixe entfernen
      MenuItem = str_remove(MenuItem, "^(Display:)") #"^(Display:|Action:)"
      #,MenuItem = paste0(base_url, MenuItem)
    ) |>
    select(
      Module,
      MenuItem,
      ENTITYNAME
    )



  ###1
  
  menu_item_to_find <- "XXX"
  
 s<-  mapping_data |>
    dplyr::group_by(ENTITYNAME) |>
    dplyr::filter(
      dplyr::n() > 1,
      any(MenuItem == menu_item_to_find)
    ) |>
    dplyr::ungroup()
 ### 2 
 
 t <- mapping_data |>
   dplyr::group_by(ENTITYNAME) |>
   dplyr::filter(
     
     # ENTITYNAME kommt mehrfach vor
     dplyr::n() > 1,
     
     # mindestens ein xxx vorhanden
     any(MenuItem == menu_item_to_find, na.rm = TRUE),
     
     # mindestens ein weiterer nicht-leerer Wert
     any(
       !is.na(MenuItem) &
         trimws(MenuItem) != "" &
         MenuItem != menu_item_to_find
     )
     
   ) |>
   dplyr::ungroup()
 
 
   u <- mapping_data|> filter(MenuItem=="XXX")
  
 writexl::write_xlsx(
   list(
     s = s,
     t = t,
     u = u
     ), paste0(p,"Data//se.xlsx"))
 
 
  mapping_data |>
    dplyr::group_by(MenuItem) |>
    dplyr::filter(
      dplyr::n_distinct(ENTITYNAME) > 1
    ) |>
    dplyr::ungroup() |>
    dplyr::arrange(
      MenuItem,
      ENTITYNAME)
  
  
  mapping_data_unique <- mapping_data |>
    dplyr::distinct(
      MenuItem,
      ENTITYNAME,
      .keep_all = TRUE)
  
  
  mapping_data_unique|>filter(ENTITYNAME =="calendar")
  writexl::write_xlsx(mapping_data_unique, paste0(p, "Data//mapping_data_unique.xlsx"))  
  
  
  monitoring_joined <- 
    monitoring_pivot |>
      left_join(
        mapping_data_unique,
          by = "ENTITYNAME")


  library(openxlsx)

  export_d365_comparison <- function(data, file_name, base_url) {

    wb <- createWorkbook()
    addWorksheet(wb, "Comparison")

    writeData(wb, "Comparison", data)

    col_0700 <- which(names(data) == "TST_0700")
    col_0800 <- which(names(data) == "TST_0800")

    for (i in seq_len(nrow(data))) {

      menuitem <- data$MenuItem[i]

      if (is.na(menuitem) || menuitem == "")
        next

      # Link für Company 0700
      link0700 <- paste0(
        base_url,
        "/?cmp=0700&mi=",
        menuitem
      )

      writeFormula(
        wb,
        sheet = "Comparison",
        x = sprintf(
          '=HYPERLINK("%s","%s")',
          link0700,
          data$TST_0700[i]
        ),
        startCol = col_0700,
        startRow = i + 1
      )

      # Link für Company 0800
      link0800 <- paste0(
        base_url,
        "/?cmp=0800&mi=",
        menuitem
      )

      writeFormula(
        wb,
        sheet = "Comparison",
        x = sprintf(
          '=HYPERLINK("%s","%s")',
          link0800,
          data$TST_0800[i]
        ),
        startCol = col_0800,
        startRow = i + 1
      )
    }
    saveWorkbook(wb, file_name, overwrite = TRUE)
  }


  export_d365_comparison(
    data      = monitoring_joined,
    file_name = paste0(p, "Data//FINAL_D365_Comparison_new_.xlsx"),
    base_url  = "https://wibu-prj.sandbox.operations.eu.dynamics.com"
  )


  