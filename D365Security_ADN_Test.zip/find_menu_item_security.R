#' Suche nach einem Menu Item in der Security-Hierarchie und Ermittlung der Lizenz
#'
#' Findet für ein oder mehrere D365FO Menu Items (Securable Objects) alle übergeordneten
#' Privilegien (Rechte), Duties (Aufgaben) und Rollen sowie die jeweils ausgelöste
#' Lizenz (SKU / Tier), differenziert nach Lese- und Schreibzugriff (Access Level).
#'
#' @details
#' Die Funktion unterstützt zwei Betriebsmodi:
#' \enumerate{
#'   \item \strong{Online / Datenbank:} Über eine aktive Datenbankverbindung (\code{con}).
#'     Es wird vorrangig die Tabelle \code{LicensingSecurityObjectExplodedGraph} abgefragt.
#'     Sollte diese nicht vorhanden sein, erfolgt ein Fallback über
#'     \code{UserSecGovRelatedObjects} und die Lizenz-Views.
#'   \item \strong{Offline / Excel & Graph:} Ohne Datenbankverbindung über einen
#'     übergebenen Lizenzgraphen (\code{graph}), eine Datei (\code{path}) oder
#'     automatische Erkennung lokaler Excel-Exporte im Projekt.
#' }
#'
#' @param menu_item
#' Character-Vektor mit einem oder mehreren Namen von Menu Items (z. B. \code{"CustTable"},
#' \code{"SalesTableListPage"}). Die Suche erfolgt standardmäßig ohne Berücksichtigung
#' von Groß-/Kleinschreibung.
#'
#' @param con
#' Optionale Datenbankverbindung (Ergebnis von \code{get_connection()}).
#'
#' @param graph
#' Optionales Tibble eines bereits geladenen Lizenzgraphen (Ergebnis von \code{read_license_graph()}).
#'
#' @param secgov
#' Optionales Tibble mit Daten aus \code{UserSecGovRelatedObjects}.
#'
#' @param path
#' Optionaler Pfad zu einer Excel-Exportdatei oder einem Ordner mit
#' \code{LICENSINGSECURITYOBJECTEXPLODEDGRAPH_*.xlsx}-Dateien. Wird weder \code{con},
#' \code{graph} noch \code{path} angegeben, sucht die Funktion automatisch nach
#' vorhandenen Graph-Dateien in den bekannten Projektordnern.
#'
#' @param exact
#' Logical. \code{TRUE} (Standard) für exakte Übereinstimmung des Objektnamens (case-insensitive);
#' \code{FALSE} für Teilstring- bzw. Regex-Suche.
#'
#' @param quiet
#' Logical. Wenn \code{FALSE} (Standard), wird eine kurze Zusammenfassung auf der
#' Konsole ausgegeben.
#'
#' @return
#' Ein Tibble mit folgenden Spalten:
#' \describe{
#'   \item{MENU_ITEM}{Name des Menu Items / Securable Objects.}
#'   \item{ACCESS_LEVEL}{Zugriffsstufe (\code{"Read"} oder \code{"Write"}).}
#'   \item{LICENSE}{Ausgelöste Lizenz (z. B. \code{"Finance or Supply Chain Management"}, \code{"Operations - Activity"}).}
#'   \item{PRIVILEGE_ID}{Technischer Identifier des Privilegs.}
#'   \item{PRIVILEGE_NAME}{Anzeigename des Privilegs.}
#'   \item{DUTY_ID}{Technischer Identifier der Duty.}
#'   \item{DUTY_NAME}{Anzeigename der Duty.}
#'   \item{ROLE_ID}{Technischer Identifier der Rolle (AOT-Name oder GUID).}
#'   \item{ROLE_NAME}{Anzeigename der Rolle.}
#'   \item{SUBROLE_ID}{Optionaler Identifier einer untergeordneten Rolle (falls vorhanden).}
#' }
#'
#' @examples
#' \dontrun{
#' # 1. Direkt mit Datenbankverbindung:
#' con <- get_connection("ADN")
#' find_menu_item_security("SalesTable", con = con)
#'
#' # 2. Mit geladenem Graph:
#' graph <- read_license_graph("Input/Excel/Database")
#' find_menu_item_security("CustTable", graph = graph)
#'
#' # 3. Teilstring-Suche nach allen Rechnungs-Menüpunkten:
#' find_menu_item_security("CustInvoice", exact = FALSE)
#' }
#'
#' @export
find_menu_item_security <- function(menu_item,
                                    con = NULL,
                                    graph = NULL,
                                    secgov = NULL,
                                    path = NULL,
                                    exact = TRUE,
                                    quiet = FALSE) {

  if (missing(menu_item) || length(menu_item) == 0L || !is.character(menu_item)) {
    stop("Bitte mindestens ein Menu Item als Zeichenkette angeben.", call. = FALSE)
  }

  target_items <- trimws(menu_item)
  raw_res <- NULL

  # ===========================================================================
  # STRATEGIE 1: In-Memory Lizenzgraph (übergeben)
  # ===========================================================================
  if (!is.null(graph) && is.data.frame(graph) && nrow(graph) > 0L) {
    if (!quiet) message(">> Durchsuche übergebenen Lizenzgraphen...")
    raw_res <- .filter_license_graph(graph, target_items, exact)
  }

  # ===========================================================================
  # STRATEGIE 2: Datenbankverbindung
  # ===========================================================================
  if (is.null(raw_res) && !is.null(con)) {
    if (!quiet) message(">> Frage D365FO-Datenbank ab...")
    raw_res <- .query_db_for_menu_item(con, target_items, exact)
  }

  # ===========================================================================
  # STRATEGIE 3: Expliziter Pfad oder automatische Dateisuche
  # ===========================================================================
  if (is.null(raw_res)) {
    graph_files <- character()

    if (!is.null(path) && length(path) > 0L) {
      if (all(dir.exists(path))) {
        graph_files <- list.files(path, pattern = "EXPLODEDG.*[.]xlsx$", full.names = TRUE, ignore.case = TRUE)
      } else if (all(file.exists(path))) {
        graph_files <- path
      }
    }

    # Automatische Ordnersuche
    if (length(graph_files) == 0L) {
      search_dirs <- c(
        "Data/Input",
        "Data/Input/PPAC",
        "../Input/Excel/Database",
        "../Input/Excel",
        "Input/Excel/Database",
        "Input/Excel"
      )
      for (d in search_dirs) {
        if (dir.exists(d)) {
          found <- list.files(d, pattern = "EXPLODEDG.*[.]xlsx$", full.names = TRUE, ignore.case = TRUE)
          if (length(found) > 0L) {
            graph_files <- found
            break
          }
        }
      }
    }

    if (length(graph_files) > 0L) {
      if (!quiet) message(">> Lese lokale Lizenzgraph-Dateien: ", paste(basename(graph_files), collapse = ", "))
      loaded_graph <- .read_graph_files_internal(graph_files)
      raw_res <- .filter_license_graph(loaded_graph, target_items, exact)
    }
  }

  # ===========================================================================
  # STRATEGIE 4: Fallback über UserSecGovRelatedObjects (ohne Voll-Graph)
  # ===========================================================================
  if (is.null(raw_res) && !is.null(secgov) && is.data.frame(secgov)) {
    if (!quiet) message(">> Nutze UserSecGovRelatedObjects...")
    raw_res <- .filter_secgov_objects(secgov, target_items, exact)
  }

  # ===========================================================================
  # ERGEBNIS-AUFBEREITUNG
  # ===========================================================================
  if (is.null(raw_res) || nrow(raw_res) == 0L) {
    if (!quiet) {
      message("Keine Treffer für Menu Item(s): ", paste(target_items, collapse = ", "))
      message("Hinweis: Bitte Verbindung (con) oder Lizenzgraph (graph / Pfad) bereitstellen.")
    }
    return(.empty_menu_item_result())
  }

  res <- raw_res |>
    dplyr::distinct() |>
    dplyr::arrange(MENU_ITEM, ACCESS_LEVEL, ROLE_NAME, DUTY_NAME, PRIVILEGE_NAME)

  if (!quiet) {
    .print_menu_item_summary(res, target_items)
  }

  tibble::as_tibble(res)
}

# =============================================================================
# INTERNE HILFSFUNKTIONEN
# =============================================================================

.filter_license_graph <- function(df, target_items, exact) {
  cols <- toupper(names(df))
  names(df) <- cols

  sec_col <- if ("SECURABLENAME" %in% cols) "SECURABLENAME" else if ("RESOURCE_" %in% cols) "RESOURCE_" else NULL
  if (is.null(sec_col)) return(NULL)

  sec_vals <- df[[sec_col]]

  matched_rows <- if (exact) {
    tolower(trimws(sec_vals)) %in% tolower(target_items)
  } else {
    pattern <- paste(target_items, collapse = "|")
    grepl(pattern, sec_vals, ignore.case = TRUE)
  }

  matched <- df[matched_rows, , drop = FALSE]
  if (nrow(matched) == 0L) return(NULL)

  # Spalten normalisieren
  acc_lvl <- if ("ACCESSLEVEL" %in% cols) {
    val <- as.character(matched$ACCESSLEVEL)
    ifelse(val == "1", "Read", ifelse(val == "2", "Write", val))
  } else {
    "Unknown"
  }

  lic <- if ("LICENSE" %in% cols) as.character(matched$LICENSE) else "Unbekannt"
  priv_id <- if ("PRIVILEGEIDENTIFIER" %in% cols) as.character(matched$PRIVILEGEIDENTIFIER) else NA_character_
  priv_nm <- if ("PRIVILEGENAME" %in% cols) as.character(matched$PRIVILEGENAME) else priv_id
  duty_id <- if ("DUTYIDENTIFIER" %in% cols) as.character(matched$DUTYIDENTIFIER) else NA_character_
  duty_nm <- if ("DUTYNAME" %in% cols) as.character(matched$DUTYNAME) else duty_id
  role_id <- if ("ROLEIDENTIFIER" %in% cols) as.character(matched$ROLEIDENTIFIER) else NA_character_
  role_nm <- if ("ROLENAME" %in% cols) as.character(matched$ROLENAME) else role_id
  sub_id  <- if ("SUBROLEIDENTIFIER" %in% cols) as.character(matched$SUBROLEIDENTIFIER) else NA_character_

  data.frame(
    MENU_ITEM      = as.character(matched[[sec_col]]),
    ACCESS_LEVEL   = acc_lvl,
    LICENSE        = lic,
    PRIVILEGE_ID   = priv_id,
    PRIVILEGE_NAME = priv_nm,
    DUTY_ID        = duty_id,
    DUTY_NAME      = duty_nm,
    ROLE_ID        = role_id,
    ROLE_NAME      = role_nm,
    SUBROLE_ID     = sub_id,
    stringsAsFactors = FALSE
  )
}

.query_db_for_menu_item <- function(con, target_items, exact) {
  # 1. Versuch: Direkte Abfrage auf LicensingSecurityObjectExplodedGraph
  tbl_check <- tryCatch({
    DBI::dbGetQuery(con, "SELECT TOP 1 * FROM LicensingSecurityObjectExplodedGraph")
    TRUE
  }, error = function(e) FALSE)

  if (tbl_check) {
    op <- if (exact) "=" else "LIKE"
    val_clause <- if (exact) {
      placeholders <- paste0("'", target_items, "'", collapse = ", ")
      paste0("LOWER(SECURABLENAME) IN (", tolower(placeholders), ")")
    } else {
      paste(sprintf("LOWER(SECURABLENAME) LIKE '%%%s%%'", tolower(target_items)), collapse = " OR ")
    }

    sql <- paste0("
      SELECT
          SECURABLENAME         AS MENU_ITEM,
          CASE ACCESSLEVEL
              WHEN 1 THEN 'Read'
              WHEN 2 THEN 'Write'
              ELSE CAST(ACCESSLEVEL AS VARCHAR)
          END                   AS ACCESS_LEVEL,
          LICENSE               AS LICENSE,
          PRIVILEGEIDENTIFIER   AS PRIVILEGE_ID,
          PRIVILEGENAME         AS PRIVILEGE_NAME,
          DUTYIDENTIFIER        AS DUTY_ID,
          DUTYNAME              AS DUTY_NAME,
          ROLEIDENTIFIER        AS ROLE_ID,
          ROLENAME              AS ROLE_NAME,
          SUBROLEIDENTIFIER     AS SUBROLE_ID
      FROM LicensingSecurityObjectExplodedGraph
      WHERE ", val_clause, "
    ")

    res <- tryCatch(DBI::dbGetQuery(con, sql), error = function(e) NULL)
    if (!is.null(res) && nrow(res) > 0L) return(res)
  }

  # 2. Versuch: Fallback über UserSecGovRelatedObjects + Licensing-Tabellen
  secgov_check <- tryCatch({
    DBI::dbGetQuery(con, "SELECT TOP 1 * FROM UserSecGovRelatedObjects")
    TRUE
  }, error = function(e) FALSE)

  if (secgov_check) {
    val_clause <- if (exact) {
      paste0("LOWER(sec.RESOURCE_) IN (", paste0("'", tolower(target_items), "'", collapse = ", "), ")")
    } else {
      paste(sprintf("LOWER(sec.RESOURCE_) LIKE '%%%s%%'", tolower(target_items)), collapse = " OR ")
    }

    sql <- paste0("
      SELECT
          sec.RESOURCE_                 AS MENU_ITEM,
          CASE COALESCE(laep.ACCESSLEVEL, 1)
              WHEN 1 THEN 'Read'
              WHEN 2 THEN 'Write'
              ELSE CAST(laep.ACCESSLEVEL AS VARCHAR)
          END                           AS ACCESS_LEVEL,
          COALESCE(lsku.SKUNAME, 'None') AS LICENSE,
          sec.PRIVILEGEIDENTIFIER       AS PRIVILEGE_ID,
          sec.PRIVILEGENAME             AS PRIVILEGE_NAME,
          sec.DUTYIDENTIFIER            AS DUTY_ID,
          sec.DUTYNAME                  AS DUTY_NAME,
          sec.ROLEIDENTIFIER            AS ROLE_ID,
          sec.ROLENAME                  AS ROLE_NAME,
          CAST(NULL AS VARCHAR(255))    AS SUBROLE_ID
      FROM UserSecGovRelatedObjects sec
      LEFT JOIN LicensingEntitlementObjects obj
          ON LOWER(obj.AOTNAME) = LOWER(sec.RESOURCE_)
      LEFT JOIN LicensingAllEntitledPermissions laep
          ON laep.ENTITLEMENTOBJECT = obj.RECID
      LEFT JOIN LicensingAllSKUs lsku
          ON lsku.RECID = laep.SKURECID
      WHERE ", val_clause, "
    ")
    return(tryCatch(DBI::dbGetQuery(con, sql), error = function(e) NULL))
  }

  NULL
}

.read_graph_files_internal <- function(files) {
  cols_to_keep <- c("ROLEIDENTIFIER", "ROLENAME", "SUBROLEIDENTIFIER", "SUBROLENAME",
                    "DUTYIDENTIFIER", "DUTYNAME", "PRIVILEGEIDENTIFIER", "PRIVILEGENAME",
                    "SECURABLETYPE", "SECURABLENAME", "SECURABLECHILDNAME", "ACCESSLEVEL", "LICENSE")
  rows <- lapply(files, function(f) {
    tryCatch({
      df <- readxl::read_excel(f, col_types = "text")
      names(df) <- toupper(trimws(names(df)))
      present <- intersect(cols_to_keep, names(df))
      df[, present, drop = FALSE]
    }, error = function(e) NULL)
  })
  rows <- rows[!vapply(rows, is.null, logical(1))]
  if (length(rows) == 0L) return(data.frame())
  dplyr::bind_rows(rows)
}

.empty_menu_item_result <- function() {
  tibble::tibble(
    MENU_ITEM      = character(),
    ACCESS_LEVEL   = character(),
    LICENSE        = character(),
    PRIVILEGE_ID   = character(),
    PRIVILEGE_NAME = character(),
    DUTY_ID        = character(),
    DUTY_NAME      = character(),
    ROLE_ID        = character(),
    ROLE_NAME      = character(),
    SUBROLE_ID     = character()
  )
}

.print_menu_item_summary <- function(df, target_items) {
  cat("\n===================================================================\n")
  cat("  SICHERHEITS- UND LIZENZANALYSE: MENU ITEM(S)\n")
  cat("===================================================================\n")
  cat("Geprüfte(s) Menu Item(s):", paste(target_items, collapse = ", "), "\n")
  cat("Gefundene Treffer-Zeilen:", nrow(df), "\n\n")

  for (item in unique(df$MENU_ITEM)) {
    sub_df <- df[df$MENU_ITEM == item, ]
    cat(sprintf("▶ MENU ITEM: %s\n", item))

    # Lizenzen je Access Level
    lics <- unique(paste0(sub_df$ACCESS_LEVEL, ": ", sub_df$LICENSE))
    cat("  • Ausgelöste Lizenz(en):", paste(lics, collapse = " | "), "\n")

    # Privileges
    privs <- unique(na.omit(sub_df$PRIVILEGE_NAME))
    cat("  • Enthalten in", length(privs), "Privileg(ien):", paste(head(privs, 3), collapse = ", "))
    if (length(privs) > 3) cat(" ... (+", length(privs) - 3, "weitere)")
    cat("\n")

    # Duties
    duties <- unique(na.omit(sub_df$DUTY_NAME))
    cat("  • Enthalten in", length(duties), "Aufgabe(n)/Duty:", paste(head(duties, 3), collapse = ", "))
    if (length(duties) > 3) cat(" ... (+", length(duties) - 3, "weitere)")
    cat("\n")

    # Roles
    roles <- unique(na.omit(sub_df$ROLE_NAME))
    cat("  • Enthalten in", length(roles), "Rolle(n):", paste(head(roles, 3), collapse = ", "))
    if (length(roles) > 3) cat(" ... (+", length(roles) - 3, "weitere)")
    cat("\n\n")
  }
  cat("===================================================================\n\n")
}
