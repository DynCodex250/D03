# Arbeitsanweisung / Prompt für Claude Code: Umstellung der RMD-Dateien auf zentrale `config.yml`

Kopiere den folgenden Prompt und übergib ihn direkt an Claude (Claude Code):

---

```markdown
Hallo Claude,

in diesem Repository (`D365Security`) wurde eine zentrale Konfigurationsdatei nach dem Vorbild von D365Licensing etabliert:
* **Konfigurationsdatei:** `inst/config/config.yml`
* **Zentraler R-Config-Loader:** `R/project_config.R` (stellt `load_project_config()` und `resolve_path()` bereit)
* **Dokumentation & Pfad-Mapping:** `Data/Documentation/Protokoll_RMD_Config_Pfade.md`

---

### 1. Architektur & Zweck der neuen Ordnerstruktur (`Data/Input/`)

Die Ordnerstruktur des Projekts wurde lokalisiert und folgt einer strikten Trennung nach **Datenquelle**, **Fachbereich** und **Datenschutz (DSGVO / Betriebsrat)**:

```text
Data/Input/
├── PPAC/                       <-- System- & Administrationsdaten aus Microsoft (PPAC)
│   ├── Capacity_*.xlsx         <-- Speicherkapazitätsdaten aus PPAC (ehemals dt. "Kapazität", jetzt engl. "Capacity")
│   ├── skuPrices.xlsx          <-- Lizenz- und Preistabellen (Base- & Attach-Preise)
│   ├── [Roh-Exporte]           <-- Rohe Admin-Center Exporte (z. B. Licensing Reports)
│   └── pseudonymized/          <-- PFLICHT-ORDNER für alle Analyse-Deliverables!
│       ├── Finance_And_Operations_Licensing_Detailed_Report_*_pseudonymized.csv
│       ├── Finance_And_Operations_Licensing_Report_*_pseudonymized.csv
│       ├── Telemetrie_pseudonymized.xlsx
│       └── MitarbeiterListe_*_pseudonymized.xlsx
│
└── Stakeholder/                <-- Zulieferungen der Fachbereiche & Governance
    ├── Abteilung_Tätigkeit_Mitarbeitende.xlsx
    ├── D365_Abteilung_Tätigkeit_Mitarbeitende_Vertrieb_Logistik.xlsx
    └── SoD_Katalog.xlsx        <-- Funktionstrennungsmatrix & Rollenvorgaben der Fachbereiche
```

#### Der zweistufige Prozessablauf (WICHTIG):
1. **Stufe 1 (Vorgelagert / Ingestion & Pseudonymisierung):**
   * Bevor Deliverables erstellt oder gerendert werden, **muss** der Ordner `Data/Input/PPAC/pseudonymized/` befüllt sein!
   * Ein Vorbereitungs-Skript (wie `R/pseudonymize_License_data.R`) liest die sensiblen Rohdaten (PPAC-Reports, Telemetriedaten, Mitarbeiterlisten), verschlüsselt die Personendaten mit dem Schlüssel aus `Keys/anonymization_key.xlsx` und legt die bereinigten Dateien in `Data/Input/PPAC/pseudonymized/` ab.
   * **Ziel:** Es dürfen niemals Klartext-Personendaten in den Deliverables oder im Git-Repository landen.
2. **Stufe 2 (Deliverables & Analysen):**
   * Die RMD-Dateien (D03, D04, D07, D17, D21 etc.) greifen **ausschließlich** auf die pseudonymisierten Daten in `Data/Input/PPAC/pseudonymized/`, die Stammdaten in `Data/Input/PPAC/` sowie die Fachbereichsdaten in `Data/Input/Stakeholder/` zu.

---

### 2. Deine Aufgabe
Passe die RMD-Dateien im Ordner `Data/Documentation/` so an, dass:
1. Keine harten absoluten Pfade (wie `C:/Users/CKAM/...`, `C:/Users/Cedric/...`, `C:/Input/...`, `../Input/...` etc.) mehr im R-Code stehen.
2. Alle Pfade und Parameter dynamisch über `load_project_config()` und `resolve_path()` aus `inst/config/config.yml` bezogen werden.
3. Abwärtskompatibilität erhalten bleibt: Wenn beim Rendern (`rmarkdown::render(params = ...)`) explizite Parameter übergeben werden, überschreiben diese die Config-Werte (Standardverhalten von `resolve_path()`).

---

### 3. Standard-Muster für den Setup-Chunk in den RMDs

Verwende in den RMD-Dateien (welche typischerweise in `Data/Documentation/` liegen) zu Beginn im `einstellungen` / `code-laden` Chunk folgendes einheitliche Muster:

```r
# --- Konfiguration laden & Pfade auflösen ---
# project_config.R bereitstellen (falls Package noch nicht geladen ist)
if (!exists("load_project_config", mode = "function")) {
  kandidaten <- c(
    file.path("R", "project_config.R"),
    file.path("..", "..", "R", "project_config.R"),
    file.path("..", "R", "project_config.R")
  )
  cfg_script <- kandidaten[file.exists(kandidaten)][1]
  if (!is.na(cfg_script)) source(cfg_script, encoding = "UTF-8")
}

cfg <- load_project_config()
```

Mit `resolve_path()` werden Parameter aufgelöst:
```r
# Syntax: resolve_path(param_val, config_rel_path, base_root, optional = FALSE)

# Beispiel für PPAC Detail Report (aus pseudonymized/):
ppac_detail_pfad <- resolve_path(
  params$ppac_detail,
  cfg$d03_bestands_und_lizenzanalyse$inputs$ppac_detail,
  cfg$base_paths$input_root
)

# Beispiel für Datenbank-Credentials:
cred_pfad <- resolve_path(
  params$cred_path,
  cfg$connection$credentials_path,
  cfg$base_paths$project_root
)
```

---

### 4. Konkrete Anpassungen nach Dokumentengruppen

#### Gruppe A: Haupt-Deliverables mit YAML-Parametern
Passe die entsprechenden RMDs so an, dass Standardwerte aus der jeweiligen Sektion in `config.yml` bezogen werden:

1. **`Data/Documentation/D03_Bestands_und_Lizenzanalyse.Rmd`** (Sektion: `d03_bestands_und_lizenzanalyse`):
   * Ersetze harte Dateipfade über `resolve_path()`:
     * `ppac_detail` $\rightarrow$ `resolve_path(params$ppac_detail, cfg$d03_bestands_und_lizenzanalyse$inputs$ppac_detail, cfg$base_paths$input_root)`
     * `ppac_bericht` $\rightarrow$ `resolve_path(params$ppac_bericht, cfg$d03_bestands_und_lizenzanalyse$inputs$ppac_bericht, cfg$base_paths$input_root)`
     * `preise` $\rightarrow$ `resolve_path(params$preise, cfg$d03_bestands_und_lizenzanalyse$inputs$preise, cfg$base_paths$input_root)`
     * `telemetrie` $\rightarrow$ `resolve_path(params$telemetrie, cfg$d03_bestands_und_lizenzanalyse$inputs$telemetrie, cfg$base_paths$input_root)`
     * `graph_ordner` $\rightarrow$ `resolve_path(params$graph_ordner, cfg$d03_bestands_und_lizenzanalyse$inputs$graph_ordner, cfg$base_paths$input_root, optional = TRUE)`

2. **`Data/Documentation/D07_Funktionstrennungs_Matrix.Rmd`** (Sektion: `d07_funktionstrennungs_matrix`):
   * `katalog` $\rightarrow$ `resolve_path(params$katalog, cfg$d07_funktionstrennungs_matrix$inputs$katalog, cfg$base_paths$project_root)`
   * `graph_ordner` $\rightarrow$ `resolve_path(params$graph_ordner, cfg$d07_funktionstrennungs_matrix$inputs$graph_ordner, cfg$base_paths$input_root, optional = TRUE)`
   * `ppac_detail` $\rightarrow$ `resolve_path(params$ppac_detail, cfg$d07_funktionstrennungs_matrix$inputs$ppac_detail, cfg$base_paths$input_root)`
   * `cred_path` $\rightarrow$ `resolve_path(params$cred_path, cfg$connection$credentials_path, cfg$base_paths$project_root)`

3. **`Data/Documentation/D17_Kapazitaetsprognose.Rmd`** (Sektion: `d17_kapazitaetsprognose`):
   * `kapazitaet_xlsx` $\rightarrow$ Greift auf `Capacity_2026-10-20.xlsx` bzw. `Kapazitaet_2026-10-20.xlsx` im Ordner `PPAC/` (oder `Kapazitaet/`) zu:
     `resolve_path(params$datei, cfg$d17_kapazitaetsprognose$inputs$kapazitaet_xlsx, cfg$base_paths$input_root)`

4. **`Data/Documentation/D20_Rollenkonsolidierung.Rmd`** (Sektion: `d20_rollenkonsolidierung`):
   * `cred_path`, `export_ordner`, `repo_path` aus `cfg` auflösen.
   * `merge_ordner` und `bisherige_d20` als optionale Fallbacks aus `cfg$d20_rollenkonsolidierung$params` beziehen.

5. **`Data/Documentation/D21_Lizenzprofil_Benutzer.Rmd`** (Sektion: `d21_lizenzprofil_benutzer`):
   * Pfade für `ppac_bericht`, `ppac_detail`, `telemetrie`, `preise`, `graph_ordner` aus `cfg$d21_lizenzprofil_benutzer$inputs` laden (verweisen auf `PPAC/pseudonymized/`).

6. **`Data/Documentation/D22_UI_Aufgaben.Rmd`**, **`D23_UI_Rechte.Rmd`**, **`D24_UI_Inventur.Rmd`**:
   * Standardmäßig `cred_path`, `repo_path` und `export_ordner` aus `cfg` initialisieren.

---

#### Gruppe B: Playbooks & Rollenanalysen
1. **`Data/Documentation/Analyse_Rolle_Lizenzen.Rmd`** & **`Vorschlag_Rolle_SCM.Rmd`**:
   * Ersetze `cred_path = ""` und `repo_path = ""` durch Fallback auf `cfg$base_paths$project_root` und `cfg$connection$credentials_path`.
   * Telemetrie-Pfad aus `cfg$base_paths$input_root` zusammensetzen.

2. **`Data/Documentation/Rollen_Vergleich_und_Merge_Szenarien.Rmd`**:
   * `cred_path` und `repo_path` standardmäßig aus `cfg` auflösen.

3. **`Data/Documentation/Playbook_Role_License_Report_Acceptance_ADN.Rmd`**:
   * Ersetze harte Pfade wie `C:/Users/CKAM/...` durch `file.path(cfg$base_paths$input_root, cfg$base_paths$subdirs_input$exported)` bzw. `cfg$base_paths$keys_root`.

4. **`Data/Documentation/Playbook_Duty_Zentralisierung.Rmd`** & **`Playbook_Rollenteilung_Lizenzoptimierung.Rmd`**:
   * Datenbank-Credentials und Projektpfade über `cfg` ansteuern.

---

#### Gruppe C: HowTos (Bereinigung harter Entwicklerpfade)
In folgenden HowTo-Dateien finden sich veraltete Pfade wie `C:/Users/CKAM/...` oder `C:/Users/cedric/...`:
* `HowTo_Benutzerberechtigungsvergleich.Rmd`
* `HowTo_Button_Zugang.Rmd`
* `HowTo_Duty_Zentralisierung_Detail.Rmd`
* `HowTo_General_Detail.Rmd`
* `HowTo_General_Kompakt.Rmd`
* `HowTo_OrgAssignment_Korrektur.Rmd`
* `HowTo_Rollenmapping_Detail.Rmd`
* `HowTo_Rollenmapping_Kompakt.Rmd`

**Vorgehen bei den HowTos:**
* Binde `load_project_config()` ein.
* Ersetze `db_credentials.xlsx`-Pfade durch `file.path(cfg$base_paths$project_root, cfg$connection$credentials_path)`.
* Ersetze `Output/...`-Pfade durch `file.path(cfg$base_paths$output_root, ...)`.

---

### 5. Qualitätsanforderungen
1. **Keine Logikänderungen:** Es dürfen nur die Pfadauflösungen und Variableninitialisierungen angepasst werden. Berechnungen, Tabellenstrukturen und Knitr-Optionen bleiben unangetastet.
2. **Datenschutz strikt einhalten:** Niemals Pfade zu unverschlüsselten Rohdaten in die Render-Logik einbinden; immer `PPAC/pseudonymized/` als Quelle nutzen!
3. **Robustheit:** Wenn ein Pfad in `config.yml` nicht gesetzt oder leer ist (`""`), soll das Skript nicht abstürzen, sondern mit einer verständlichen Meldung darauf hinweisen oder einen Fallback nutzen.
4. **Validierung:** Führe nach den Anpassungen einen Syntax-Check durch (z. B. mit `knitr::knit(..., tangle = TRUE)` oder Test-Render), um sicherzustellen, dass keine Syntaxfehler entstanden sind.
```

---

## Kurzanleitung zur Verwendung

1. Öffne Claude Code in deinem Terminal.
2. Kopiere den obigen Markdown-Block (ab `Hallo Claude,`).
3. Claude Code wird daraufhin die RMD-Dateien im Ordner `Data/Documentation/` systematisch durchgehen und die Pfade mit `inst/config/config.yml` verknüpfen.
