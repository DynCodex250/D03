# Protokoll & Dokumentation: RMD-Pfade und Konfigurationsdatei (`config.yml`)

**Stand:** 31. Oktober 2026  
**Ziel-Konfigurationsdatei:** [`inst/config/config.yml`](file:///c:/Users/Cedric/Documents/RProjects/D365Security/inst/config/config.yml)  
**Vorlage/Referenz:** `C:/Users/Cedric/Documents/RProjects/D365Licensing/inst/config/config.yml`  

---

## 1. Architektur & Pfad-Konzept (Zusammensetzbare Pfade)

Um absolute Pfade in den einzelnen RMD-Dateien zu vermeiden und das Projekt portabel zu halten, wurde eine zweistufige Pfad-Struktur etabliert:

### 1.1 Basis-Verzeichnisse (`base_paths`)
Die Wurzeln sind relativ zum Projektordner, damit dieselbe Datei auf jedem Rechner mit derselben Ordnerstruktur gilt. `load_project_config()` macht daraus volle Pfade.

* **`project_root`**: Hauptverzeichnis dieses R-Projekts (`.`)
* **`input_root`**: Zentrales Input-Verzeichnis im Projekt (`Data/Input`)
* **`output_root`**: Zentrales Export-/Ablageverzeichnis (`../Output`)
* **`keys_root`**: Ablage für Kryptoschlüssel/Anonymisierung im Projekt (`Keys`)
* **`legacy_input_root`**: Fallback für ältere/externe Input-Dateien (`../Input`)
* **`packages_local_dir`**: Visual-Studio-Verzeichnis `PackagesLocalDirectory`; als einziger Wert ein voller Pfad, weil er vom Rechner und der D365-Version abhängt

### 1.2 Standardisierte Unterordner (`subdirs_project` / `subdirs_input`)
* Innerhalb des Projekts: `data`, `deliverables`, `documentation`, `input`, `reports`, `security_objects`, `keys`
* Innerhalb des Input-Verzeichnisses (`Data/Input`): `ppac`, `ppac/pseudonymized`, `stakeholder` (sowie Legacy-Ordner `excel`, `database`, `roles`, etc.)

### 1.3 Auflösung in R-Skripten
In R-Skripten und RMD-Code-Chunks werden Pfade über `load_project_config()` und `resolve_path()` flexibel aufgelöst:
```r
# Laden der Konfiguration: aus dem Projektordner oder aus Data/Documentation
cfg <- load_project_config()

# Beispiel: Zusammenbau des PPAC-Detailpfads für D03 / D04
ppac_detail_pfad <- resolve_path(
  params$ppac_detail,
  cfg$d03_bestands_und_lizenzanalyse$inputs$ppac_detail,
  cfg$base_paths$input_root
)

# Beispiel: Ausgabeordner für Deliverables
deliverables_ordner <- file.path(
  cfg$base_paths$project_root,
  cfg$base_paths$subdirs_project$deliverables
)
```

---

## 2. Detaillierte Analyse aller 34 RMD-Dateien

### A. Deliverables (D01 bis D24)

#### 1. D01 – Berechtigungskonzept Strategie
* **Datei:** `Data/Documentation/D01_Berechtigungskonzept_Strategie.Rmd`
* **Zweck:** Strategisches Hauptdokument (Word/Docx Deliverable)
* **Parameter im YAML:** Keine formalen YAML-Parameter.
* **Config-Eintrag:** `d01_berechtigungskonzept_strategie`
  * `rmd_file`: `Data/Documentation/D01_Berechtigungskonzept_Strategie.Rmd` (gefunden)
  * `output_docx`: `Data/Deliverables/D01_Berechtigungskonzept_Strategie.docx` (gefunden)

#### 2. D02 – RACI Governance Steckbrief
* **Datei:** `Data/Documentation/D02_RACI_Governance_Steckbrief.Rmd`
* **Zweck:** Governance-Rollen und RACI-Matrix
* **Parameter im YAML:** Keine formalen YAML-Parameter.
* **Config-Eintrag:** `d02_raci_governance_steckbrief`
  * `rmd_file`: `Data/Documentation/D02_RACI_Governance_Steckbrief.Rmd` (gefunden)
  * `output_docx`: `Data/Deliverables/D02_RACI_Governance_Steckbrief.docx` (gefunden)

#### 3. D03 – Bestands- und Lizenzanalyse
* **Datei:** `Data/Documentation/D03_Bestands_und_Lizenzanalyse.Rmd`
* **Zweck:** Analyse der Bestandsgesellschaften (Strang A), Lizenzmengen und Ranglisten
* **Parameter im YAML:** `repo_path`, `export_ordner`, `code_laden`, `ppac_detail`, `ppac_bericht`, `preise`, `umgebung`, `vergleich`, `graph_ordner`, `graph_umgebung`, `telemetrie`
* **Config-Eintrag:** `d03_bestands_und_lizenzanalyse`
  * `export_ordner`: `Data/Deliverables` (gefunden)
  * `code_laden`: `load_all`
  * `umgebung`: `wibu-produktiv`
  * `vergleich`: `wibu-int, wibu-prj`
  * `graph_umgebung`: `ADN`
  * `inputs.ppac_detail`: `Excel/PPAC/Finance_And_Operations_Licensing_Detailed_Report_20261027_pseudonymized.csv` (gefunden auf Festplatte)
  * `inputs.ppac_bericht`: `Excel/PPAC/Finance_And_Operations_Licensing_Report_20261027_pseudonymized.csv` (gefunden auf Festplatte)
  * `inputs.preise`: `Excel/PPAC/skuPrices.xlsx` (relativ zu `input_root`)
  * `inputs.graph_ordner`: `Excel/Database` (gefunden auf Festplatte)
  * `inputs.telemetrie`: `Excel/Database/Telemetrie_pseudonymized.xlsx` (gefunden auf Festplatte)

#### 4. D04 – Rangliste & Bereinigungsplan
* **Quelle:** Aus `D03_Bestands_und_Lizenzanalyse.Rmd` generierte Erzeugnisse
* **Zweck:** Lizenz-Ranglisten und Bereinigungspläne für CFO / IT-Leitung
* **Config-Eintrag:** `d04_rangliste_und_bereinigungsplan`
  * `outputs.rangliste_ppac_xlsx`: `Data/Deliverables/D04_Rangliste_PPAC.xlsx` (gefunden)
  * `outputs.rangliste_lizenzgraph_xlsx`: `Data/Deliverables/D04_Rangliste_Lizenzgraph.xlsx` (gefunden)
  * `outputs.bereinigungsplan_xlsx`: `Data/Deliverables/D04_Bereinigungsplan.xlsx` (gefunden)
  * `outputs.reports_rangliste_xlsx`: `Data/Reports/Klartext/D04_Rangliste.xlsx` (Referenz im Code)
  * `inputs`: Identisch mit D03 (`ppac_detail`, `graph_ordner`, `telemetrie`, `preise`)

#### 5. D05 – Rollenkatalog & D06 – Stellen- und Rollenmatrix
* **Dateien:** `Data/Deliverables/D05_Rollenkatalog.xlsx` & `Data/Deliverables/D06_Stellen_Rollen.xlsx`
* **Config-Eintrag:** `d05_rollenkatalog` & `d06_stellen_rollen` (jeweils mit direktem relativen Pfad).

#### 6. D07 – Funktionstrennungs-Matrix (SoD)
* **Datei:** `Data/Documentation/D07_Funktionstrennungs_Matrix.Rmd`
* **Zweck:** Prüfung von Segregation of Duties (SoD) Konflikten
* **Parameter im YAML:** `katalog`, `graph_ordner`, `graph_umgebung`, `ppac_detail`, `ppac_umgebung`, `rollen_muster`, `bisherige_d07`, `export_ordner`, `datei`, `cred_path`, `repo_path`, `code_laden`
* **Config-Eintrag:** `d07_funktionstrennungs_matrix`
  * `katalog`: `Data/Input/Stakeholder/SoD_Katalog.xlsx` (gefunden)
  * `graph_ordner`: `Excel/Database` (gefunden)
  * `ppac_detail`: `Excel/PPAC/Finance_And_Operations_Licensing_Detailed_Report_20261027_pseudonymized.csv` (gefunden)
  * `cred_path`: `db_credentials.xlsx` (gefunden)
  * `datei`: `D07_Funktionstrennungs_Matrix.xlsx` (gefunden)
  * `bisherige_d07`: `""` *(OFFEN: leer gelassen zur manuellen Angabe einer Vorversion für Deltaprüfungen)*

#### 7. D08, D09, D11, D18, D19
* **D08:** `Data/Documentation/D08_Workshop_Paket.Rmd` $\rightarrow$ `Data/Deliverables/D08_Workshop_Paket.docx`
* **D09:** `Data/Documentation/D09_Leitfaden_Aufgabenaufzeichnungen.Rmd` $\rightarrow$ `Data/Deliverables/D09_Leitfaden_Aufgabenaufzeichnungen.docx`
* **D11:** `Data/Documentation/D11_Testkonzept_Berechtigungen.Rmd` $\rightarrow$ `Data/Deliverables/D11_Testkonzept_Berechtigungen.docx`
* **D18:** `Data/Deliverables/D18_Sperrliste.xlsx`
* **D19:** `Data/Deliverables/D19_Prozess_Rollen_Matrix.xlsx`

#### 8. D20 – Rollenkonsolidierung
* **Datei:** `Data/Documentation/D20_Rollenkonsolidierung.Rmd`
* **Zweck:** Zusammenführung und Bereinigung von redundanten AOT- und UI-Rollen
* **Parameter im YAML:** `umgebung`, `merge`, `merge_ordner`, `lizenzvergleich`, `bisherige_d20`, `export_ordner`, `datei`, `cred_path`, `repo_path`, `code_laden`
* **Config-Eintrag:** `d20_rollenkonsolidierung`
  * `datei`: `D20_Rollenkonsolidierung.xlsx` (gefunden)
  * `merge_ordner`: `""` *(OFFEN: Optionaler Export-Ordner für zusammengeführte XMLs)*
  * `bisherige_d20`: `""` *(OFFEN: Vorheriger Versionsstand für Delta-Vergleich)*

#### 9. D21 – Lizenzprofil Benutzer
* **Datei:** `Data/Documentation/D21_Lizenzprofil_Benutzer.Rmd`
* **Zweck:** Ermittlung des optimalen Lizenzbedarfs je Benutzer (PPAC + Telemetrie)
* **Parameter im YAML:** `ppac_bericht`, `ppac_detail`, `ppac_umgebung`, `telemetrie`, `preise`, `graph_ordner`, `graph_umgebung`, `bisherige_d21`, `export_ordner`, `datei`, `cred_path`, `repo_path`, `code_laden`
* **Config-Eintrag:** `d21_lizenzprofil_benutzer`
  * `datei`: `D21_Lizenzprofil_Benutzer.xlsx`
  * `bisherige_d21`: `""` *(OFFEN: Vorheriger Versionsstand für Delta-Vergleich)*
  * `inputs`: Verknüpft mit PPAC-, Telemetrie-, Lizenzpreis- und Graph-Dateien.

#### 10. D22, D23, D24 – UI-Sicherheitsanalysen
* **D22 (Aufgaben):** `Data/Documentation/D22_UI_Aufgaben.Rmd` $\rightarrow$ `D22_UI_Aufgaben.xlsx`
* **D23 (Rechte):** `Data/Documentation/D23_UI_Rechte.Rmd` $\rightarrow$ `D23_UI_Rechte.xlsx`
* **D24 (Inventur):** `Data/Documentation/D24_UI_Inventur.Rmd` $\rightarrow$ `D24_UI_Inventur.xlsx`
* Alle drei besitzen den offenen Parameter `bisherige_d22/d23/d24` für Vorversionen.

#### 11. D365FO Benutzerberechtigungsvergleich
* **Datei:** `Data/Documentation/D365FO_Benutzerberechtigungsvergleich.Rmd`
* **Inputs:** `D365FO_Benutzerberechtigungsvergleich.xlsx`, `db_credentials.xlsx`

---

### B. Playbooks & Rollenanalysen

#### 1. Analyse Rolle Lizenzen & Vorschlag Rolle SCM
* **Dateien:** `Data/Documentation/Analyse_Rolle_Lizenzen.Rmd` & `Data/Documentation/Vorschlag_Rolle_SCM.Rmd`
* **Zweck:** Fachbereichs-Bauplan und Lizenzsenkung für z. B. Vertriebs-Innendienst (`_WIBU_VERKAUF_INNENDIENST_MITARBEITER`)
* **Outputs:** `Vorschlag_Fachbereich.docx`, `Bauplan.xlsx`, `Rollenversionen.xlsx`
* **Parameter:** `rolle`, `ui_rolle`, `ziel_lizenz`, `ziel_rolle`, `telemetrie`, etc.

#### 2. Rollen Vergleich und Merge Szenarien
* **Datei:** `Data/Documentation/Rollen_Vergleich_und_Merge_Szenarien.Rmd`
* **Zweck:** 3 Szenarien für Rollenvergleich & Zusammenführung mit Generierung von 3 XML-Formaten
* **Outputs:** `Versionsvergleich_AOT_UI.xlsx`, `Szenario3_Benutzer_auf_Merge_Rolle.xlsx`, `AxSecurityRole/_WIBU_...xml`

#### 3. Playbook Role License Report Acceptance ADN
* **Datei:** `Data/Documentation/Playbook_Role_License_Report_Acceptance_ADN.Rmd`
* **Im Code gefundene Pfade:**
  * `db_credentials.xlsx` (gefunden)
  * `Excel/Exported` (gefunden)
  * `pseudonymization.key_file` in `keys_root` (liegt nicht im Git)
  * `Excel/Exported_by_role` in `input_root`

#### 4. Playbook Rollenteilung Lizenzoptimierung
* **Datei:** `Data/Documentation/Playbook_Rollenteilung_Lizenzoptimierung.Rmd`
* **Im Code gefundene Pfade:**
  * `packages_local_dir`: zentral in `base_paths`
  * `import_rollenzuweisungen`: `""` *(OFFEN: Excel-Importdatei für neue Rollenzuweisungen)*

#### 5. Playbook Duty Zentralisierung
* **Datei:** `Data/Documentation/Playbook_Duty_Zentralisierung.Rmd`
* **Inputs:** `db_credentials.xlsx`, `project_root`

---

### C. HowTos (Schritt-für-Schritt Dokumentationen)

* **`HowTo_Benutzerberechtigungsvergleich.Rmd`**: Nutzt `Output/BenutzerVergleich` und `D365FO_Benutzerberechtigungsvergleich.xlsx`.
* **`HowTo_OrgAssignment_Korrektur.Rmd`**: Nutzt `Output/OrgFix/System security user role organization assignment_FIXED.xlsx` und `Data/MD3-1176/RolleLagermitarbeiter.xlsx`.
* **`HowTo_Duty_Zentralisierung_Detail.Rmd`**: Nutzt `PackagesLocalDirectory` (offen).
* **`HowTo_Lizenzentscheidung_Detail.Rmd`**: Erfordert `pageviews_export.csv` aus Application Insights (offen).
* **`HowTo_General_Detail.Rmd` & `HowTo_General_Kompakt.Rmd`**: Nutzen `Output/Roles/RoleComparison.xlsx` und Mock-Dateien.
* **`HowTo_Rollenmapping_Detail.Rmd` & `HowTo_Rollenmapping_Kompakt.Rmd`**: Nutzen `Output` und Referenz-XMLs.
* **`HowTo_Button_Zugang.Rmd`**: Nutzt `db_credentials.xlsx`.

---

### D. Übergreifende Dokumente & Testanleitungen

* **`Dokumentation.Rmd`**: Hauptdokumentation des Packages; referenziert die Preisliste `skuPrices.xlsx`, `db_credentials.xlsx`, `SoD_Katalog.xlsx`.
* **`security_customizer_testanleitung.Rmd`**: Pfade `K:/AosService/PackagesLocalDirectory` bzw. `C:/AosService/PackagesLocalDirectory`.
* **`Projektantrag_PPAC_Governance.Rmd`**: Projektcharter; erzeugt `Projektantrag_PPAC_Governance.docx`.
* **`Entscheidungsvorlage_Datenbankkapazitaet.Rmd`**: Erzeugt `Entscheidungsvorlage_Datenbankkapazitaet_V0.docx`.
* **`D365FO_Security_Documentation_Find.Rmd` & `D365FO_Security_Form_FrameworkZielbild.Rmd`**: Root-RMDs für Framework-Dokumentation.

---

## 3. Übersicht aller offenen Parameter (für manuelle Ergänzung)

Folgende Parameter wurden in `config.yml` bewusst als Leerstring `""` oder `null` belassen, da es sich um benutzer- oder umgebungsspezifische Laufzeit-Pfade handelt:

| Sektion in `config.yml` | Variable | Zweck / Was hier eingetragen werden kann |
|---|---|---|
| `d07_funktionstrennungs_matrix` | `bisherige_d07` | Pfad zu einer früheren `D07_Funktionstrennungs_Matrix.xlsx` für Vorher/Nachher-Deltavergleich |
| `d20_rollenkonsolidierung` | `bisherige_d20` | Pfad zu einer früheren `D20_Rollenkonsolidierung.xlsx` |
| `d20_rollenkonsolidierung` | `merge_ordner` | Zielordner, falls zusammengeführte Rollen als AOT-XML exportiert werden sollen |
| `d21_lizenzprofil_benutzer` | `bisherige_d21` | Pfad zu einer früheren `D21_Lizenzprofil_Benutzer.xlsx` |
| `d22_ui_aufgaben` | `bisherige_d22` | Pfad zu einer früheren `D22_UI_Aufgaben.xlsx` |
| `d23_ui_rechte` | `bisherige_d23` | Pfad zu einer früheren `D23_UI_Rechte.xlsx` |
| `d24_ui_inventur` | `bisherige_d24` | Pfad zu einer früheren `D24_UI_Inventur.xlsx` |
| `playbook_rollenteilung_lizenzoptimierung` | `import_rollenzuweisungen` | Pfad zu `Import_Neue_Rollenzuweisungen.xlsx` |
| `howto_lizenzentscheidung_detail` | `telemetrie_pageviews` | Export-Datei `pageviews_export.csv` aus Azure Application Insights |
