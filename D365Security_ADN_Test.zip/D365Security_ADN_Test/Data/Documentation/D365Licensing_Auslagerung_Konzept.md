# Architektur- und Migrationskonzept: Auslagerung der Lizenzfunktionen von D365Security nach D365Licensing

**Dokument-ID:** D365-LIC-MIG-01  
**Datum:** 01. November 2026  
**Autor:** Cedric Kameni / Lead Architect  
**Status:** Genehmigungsreif & Umsetzungs-Blueprint  
**Ziel-Repository:** `c:\Users\Cedric\Documents\RProjects\D365Licensing`  
**Quell-Repository:** `c:\Users\Cedric\Documents\RProjects\D365Security`  

---

## Executive Summary

Im Projekt `D365Security` wurden historisch sowohl Sicherheitsrollen, Berechtigungskonzepte (SoD, RACI, Privilegien-Zentralisierung, XML-Generierung) als auch umfassende Lizenzermittlungen, PPAC-Abstimmungen, Telemetrie-Auswertungen und Kostenoptimierungen gemeinsam entwickelt. 

Um eine saubere Trennung von **Sicherheits-Governance** und **Lizenz- & Kostenoptimierung** zu gewährleisten, werden alle lizenzbezogenen Funktionen in das dedizierte R-Package **`D365Licensing`** ausgelagert. 

Dieses Dokument bildet die vollständige, methodische und technische Grundlage für die Umsetzung in `D365Licensing`. Es analysiert den Ist-Zustand beider Repositories, definiert die 6 Kern-Pfeiler der Lizenzlogik, dokumentiert Datenmodelle und mathematische Berechnungsformeln und stellt einen phasierten Implementierungsplan für Entwickler bereit.

---

## 1. Systemübersicht & Ist-Zustand-Vergleich

### 1.1 Quell-Projekt: D365Security
- **Fokus:** Sicherheitsarchitektur, Rollendesign, SoD (Segregation of Duties), AOT/UI-Mapping, Berechtigungsbereinigung.
- **Enthaltene Lizenzkomponenten:** Über 60 R-Skripte im Ordner `R/`, die SKU-Preiskataloge, marginale Rollenkosten, PPAC-Soll/Ist-Vergleiche, Exploded Security Graphs, Einzel-Lizenzrollen (D10), Telemetrie-Benutzerprofile (D21) und Dataverse-Kapazitätsprognosen (D17) berechnen.
- **Herausforderung:** Hohe Kopplung von Sicherheitsartefakten mit Lizenzkosten-Engines; redundante Abhängigkeiten.

### 1.2 Ziel-Projekt: D365Licensing
- **Fokus:** Reproduzierbare, reine Lese-Pipeline (`read-only`), evidenzbasierte D365FO-Lizenz- und Sicherheitsanalyse.
- **Bestehende Architektur:**
  - `run_analysis()`: Zentraler Orchestrator mit Transaktions- und Telemetrielauf.
  - `inst/sql/`: SQL-Queries für Benutzer, Rollen, Duties, Privilegien und Entry Points.
  - `R/connection.R`: Read-Only Datenbankverbindung (`DBI`).
  - `R/data_telemetry.R`: Application Insights KQL-Anbindung via `httr2`.
  - `R/findings_engine.R` & `inst/config/findings_rules.yml`: Regelbasierte Findings mit Konfidenzniveaus (`HIGH`, `MEDIUM`, `LOW`).
  - `R/reporting_excel.R` & `R/reporting_markdown.R`: Export nach Excel und Markdown.
- **Aktuelle Lücke:**
  - Es fehlt die **dynamische SKU-Preislogik (Base/Attach-Kombinatorik)**.
  - Es fehlt der Import und die Reconciliation mit **Power Platform Admin Center (PPAC) Lizenzberichten**.
  - Es fehlt die **Exploded Graph Dekonstruktion** zur exakten Ermittlung von Duty-/Privilege-Treibern.
  - Es fehlt das **User Footprint Matching** (D21) zur Identifikation von Downgrade-Potenzialen.
  - Es fehlt der **Planer für Single-License-Rollen** (D10).
  - Es fehlt die **Dataverse-Speicherkapazitätsprognose** (D17).

---

## 2. Die 6 Kern-Pfeiler der Lizenzfunktionen aus D365Security

```mermaid
graph TD
    subgraph "D365Licensing Pipeline Neu"
        P1[1. SKU Pricing & Cost Engine<br/>Base/Attach Kombinatorik]
        P2[2. PPAC Reconciliation<br/>Soll vs. Ist vs. Missing]
        P3[3. Exploded Graph & Drivers<br/>Duty/Privilege Treiberanalyse]
        P4[4. Telemetry Footprint Profiler<br/>D21 Downgrade Engine]
        P5[5. Single-License Planner<br/>D10 Rollen-Entflechtung]
        P6[6. Capacity & Storage Forecast<br/>D17 Dataverse Prognose]
    end

    InputDB[(D365 Database<br/>ReadOnly)] --> P1
    InputDB --> P3
    InputPPAC[PPAC CSV Exports<br/>Detail & Summary] --> P2
    InputAppInsights[App Insights<br/>KQL Touches] --> P4
    InputPrices[Data/skuprice.xlsx] --> P1
    InputKap[Kapazitaet.xlsx] --> P6

    P1 --> CoreEngine[Konsolidierte Lizenzanalyse & Findings Engine]
    P2 --> CoreEngine
    P3 --> CoreEngine
    P4 --> CoreEngine
    P5 --> CoreEngine
    P6 --> CoreEngine

    CoreEngine --> ExcelRep[Excel Executive Report]
    CoreEngine --> MDRep[Markdown / HTML Audit Report]
```

---

### Pfeiler 1: Microsoft SKU Pricing Engine & Marginale Rollenkosten

#### Relevante Dateien in D365Security:
- `R/license_prices.R`
- `R/rank_roles_by_license_cost.R`
- `R/export_license_cost_ranking.R`
- `R/compare_role_license_skus.R`

#### Fachliche & Mathematische Logik:
1. **Microsoft Base/Attach Modell:**
   - Ein Benutzer mit mehreren Base-Lizenzen zahlt für die primäre Base-Lizenz den vollen Preis (Base Price), für jede weitere Base-Lizenz lediglich den reduzierten Preis (Attach Price).
   - Kanonische Priorisierung der Base-Lizenzen:
     $$\text{Priorität:} \quad \text{Supply Chain Management (SCM)} \longrightarrow \text{Finance} \longrightarrow \text{Commerce} \longrightarrow \text{Project Operations / Premium}$$
   - *Light Licenses:* `Operations - Activity` (~46,80 €) schließt `Team Members` (~7,50 €) ein.
   - *Inklusionsregel:* Besitzt ein Benutzer mindestens eine Base-Lizenz, sind Activity und Team Member vollständig abgedeckt und verursachen **0,00 €** Zusatzkosten.
2. **Marginale Kosten einer Rolle (Kosten nur wegen einer Rolle):**
   - Das Einsparpotenzial einer Rolle darf **nicht isoliert** betrachtet werden, da Benutzer meist mehrere Rollen besitzen, die dieselbe SKU bedingen.
   - Sei $U(R)$ die Menge aller aktiven Benutzer mit Rolle $R$.
   - Sei $\text{Roles}(u)$ die Menge der dem Benutzer $u$ zugewiesenen Rollen.
   - Sei $\text{Cost}(S)$ die monatliche Lizenzgebühr für die minimale SKU-Kombination, die die Rollenmenge $S$ abdeckt.
   - Die marginalen Kosten der Rolle $R$ betragen:
     $$\Delta \text{Cost}(R) = \sum_{u \in U(R)} \left[ \text{Cost}(\text{Roles}(u)) - \text{Cost}(\text{Roles}(u) \setminus \{R\}) \right]$$
   - Nur wenn $\Delta \text{Cost}(R) > 0$, führt der Entzug von $R$ zu echten Einsparungen!
3. **Datenmodell SKU-Preise (`skuPrices`):**
   - Tabelle mit Spalten: `SKU`, `BasePrice`, `AttachPrice`, `Tier` (`Base`, `Light`, `None`), `Priority`.

---

### Pfeiler 2: PPAC Ingestion & Cross-Environment Reconciliation

#### Relevante Dateien in D365Security:
- `R/read_ppac_license_reports.R`
- `R/compare_assigned_license_cost.R`
- `R/compare_environment_license_cost.R`
- `R/export_license_cost_comparison.R`

#### Fachliche & Mathematische Logik:
1. **Dualer Import von PPAC-Exporten:**
   - **Detaillierter Bericht (`Finance_And_Operations_Licensing_Detailed_Report_*.csv`):**
     - Enthält zeilenweise: `EnvironmentName`, `EnvironmentType`, `UserEmail`, `SecurityRole`, `RequiredLicense`, `RefreshedOn`.
     - *Sandbox-Besonderheit:* In Sandboxes steht `Not Applicable (<SKU>)`. Der Parser muss die tatsächliche SKU extrahieren (`<SKU>`) und das Flag `COUNTED = FALSE` setzen.
   - **Zusammenfassender Bericht (`Finance_And_Operations_Licensing_Report_*.csv`):**
     - Enthält je Benutzer: `RequiredLicense(s)`, `AssignedLicense(s)`, `MissingLicense(s)`.
     - Mehrfachzeilen pro Benutzer (z.B. durch unterschiedliche Zuweisungsquellen) werden aggregiert und dedupliziert.
2. **Reconciliation-Status je Benutzer:**
   - **`MISSING` (Unterlizensiert):** Benutzer benötigt durch seine Rollen eine Lizenz, die im M365 Admin Center nicht zugewiesen ist. **Kritisches Risiko für Microsoft Lizenz-Enforcement (Oktober 2026)!**
     $$\text{MissingCost} = \text{Cost}(\text{Required}) - \text{Cost}(\text{Assigned})$$
   - **`MORE_THAN_NEEDED` (Überlizensiert):** Zugewiesene Lizenzen sind teurer als der tatsächliche Rollenbedarf $\rightarrow$ Einsparpotenzial durch Lizenz-Rückgabe.
   - **`OK`:** Zuweisung entspricht exakt dem Bedarf.
3. **Cross-Environment Vergleich:**
   - Abgleich zwischen Testumgebungen (z.B. `INT`, `TST`) und `PROD`. Identifiziert Rollen- und Lizenz-Drift vor dem Go-Live.

---

### Pfeiler 3: Exploded Security Graph & Lizenztreiber-Dekonstruktion

#### Relevante Dateien in D365Security:
- `R/read_license_graph.R`
- `R/load_role_license_graph.R`
- `R/build_role_license_drivers.R`
- `R/summarize_duty_license_drivers.R`
- `R/summarize_privilege_license_drivers.R`
- `R/get_object_license_class.R`

#### Fachliche & Mathematische Logik:
1. **Hierarchischer Graph (`LicensingSecurityObjectExplodedGraph`):**
   - Ab D365FO 10.0.47 generiert der Standard-Job die vollständige Hierarchie:
     $$\text{Role} \longrightarrow \text{SubRole} \longrightarrow \text{Duty} \longrightarrow \text{Privilege} \longrightarrow \text{Securable Object (Menu Item)} \longrightarrow \text{Access Level (1=Read, 2=Write)} \longrightarrow \text{SKU}$$
2. **Treiber-Rollup (Bottom-Up Ermittlung):**
   - Für jeden Entry Point wird die günstigste deckende SKU bestimmt (`MIN_SKU`).
   - Die teuerste Mindestanforderung wird auf das Privilege (`PRIVILEGE_SKU`) und weiter auf die Duty (`DUTY_SKU`) hochgezogen.
   - Das Flag `DRIVES_DUTY = TRUE` identifiziert exakt die Entry Points, die eine Duty von Activity/Team Member auf Finance oder Commerce hochstufen.
3. **Status-Klassifikation:**
   - `LICENSED`: Entry Point ist durch Standard-SKUs gedeckt.
   - `NOT_ENTITLED`: Entry Point gelistet, aber keine SKU deckt ihn ab.
   - `NOT_LISTED`: Technischer Entry Point ohne Lizenzrelevanz.
   - `UNKNOWN_PRIVILEGE`: Kundenspezifisches Privilege (z.B. WIBU-Custom), das manuell bewertet werden muss.

---

### Pfeiler 4: Telemetrie-Benutzerprofile & Downgrade-Engine (D21)

#### Relevante Dateien in D365Security:
- `R/build_user_license_profile.R`
- `R/recommend_user_license_target.R`
- `R/plan_role_license_cleanup.R`
- `R/plan_role_license_cleanup_parts.R`
- `R/export_user_license_profile.R`

#### Fachliche & Mathematische Logik:
1. **Evidenzbasierter Lizenz-Footprint:**
   - Kombination von Application Insights PageViews/Touches (aus `data_telemetry.R`) mit dem Exploded Graph.
   - Eine Duty gilt als **genutzt**, wenn der Benutzer innerhalb des Beobachtungsfensters (z.B. 700 Tage) mindestens einen zugeordneten Menüpunkt aufgerufen hat.
   - *Nicht messbare Duties:* Duties ohne Display Menu Items (z.B. reine Hintergrund- oder Datenverarbeitungsrechte) können telemetrisch nicht gemessen werden.
     - Modus `BY_USAGE`: Behält unmessbare Duties sicherheitshalber bei.
     - Modus `IF_CONFIRMED`: Kennzeichnet unmessbare Duties zur fachlichen Bestätigung durch die Fachbereiche.
2. **Klassifikation der Benutzer-Profile:**
   - `SAVES`: Der tatsächliche Arbeits-Footprint benötigt nachweislich eine günstigere Lizenz als zugewiesen (z.B. Activity statt SCM/Commerce Base).
   - `REVIEW`: Einsparung nur möglich, wenn unmessbare Duties fachlich abgewählt werden.
   - `KEEPS`: Telemetrie bestätigt die hohe Lizenzstufe.
   - `NO_TELEMETRY`: Inaktiver Benutzer ohne Aufrufe im Analysezeitraum.
   - `GRAPH_DIFFERS` / `REPORTS_DIFFER`: Dateninkonsistenzen zwischen Graph und PPAC.
3. **Berechnung von Real-Einsparungen:**
   - Ersparnis durch Rollenbereinigung:
     $$\text{Saving} = \text{RequiredCost}(\text{Aktuelle Rollen}) - \text{CostByUsage}(\text{Genutzter Footprint})$$
   - Vermiedene Zukäufe (`Purchase Avoided`): Geplante Nachkäufe für Lizenzen mit Status `MISSING`, die telemetrisch gar nicht gebraucht werden!

---

### Pfeiler 5: Single-License Rollen-Entflechtung (D10)

#### Relevante Dateien in D365Security:
- `R/plan_single_license_role.R`
- `R/plan_single_license_texts.R`
- `R/build_license_roles.R`
- `R/export_single_license_plan.R`

#### Fachliche & Mathematische Logik:
1. **Zielsetzung:**
   - Verhindern, dass Standardrollen mehrere Base-Lizenzen (z.B. SCM **und** Commerce) gleichzeitig verlangen.
   - Bereitstellung von modularen Rollen: Eine "Basis-Rolle" (z.B. rein SCM) und getrennte "Zusatz-Rollen" (z.B. Commerce-Zusatz).
2. **Objekt-Kategorisierung je Ziel-SKU:**
   - `ONLY`: Objekt wird ausschließlich durch die Ziel-SKU abgedeckt.
   - `SHARED`: Objekt wird von der Ziel-SKU und weiteren Base-SKUs gedeckt.
   - `ACTIVITY`: Objekt benötigt lediglich Operations - Activity.
   - `TEAM_MEMBERS`: Objekt benötigt Team Members oder keine Lizenz.
   - `OUTSIDE`: Objekt erfordert eine fremde, teurere Lizenz $\rightarrow$ **muss aus der Rolle herausgelöst werden**.
3. **Duty-Baukasten:**
   - `WHOLE`: Die gesamte Duty passt zur Ziel-SKU.
   - `PARTLY`: Die Duty enthält privilegienübergreifende Vermischungen und muss in zwei Teil-Duties aufgespalten werden.
   - `NONE`: Die Duty gehört vollständig in eine separate Zusatzrolle.

---

### Pfeiler 6: Dataverse-Speicherkapazitätsprognose (D17)

#### Relevante Dateien in D365Security:
- `R/forecast_capacity.R`
- `R/export_capacity_forecast.R`

#### Fachliche & Mathematische Logik:
1. **Kopplung von Lizenzen und Speicherkontingent:**
   - Bei Microsoft Dynamics 365 / Dataverse wächst das tenantweite Datenbankkontingent mit den lizenzierten Benutzern:
     - Jeder **Full User (Base)** steuert **5 GB** Datenbankkapazität bei.
     - Jeder **Activity User** steuert **1 GB** Datenbankkapazität bei.
     - Team Member steuern **0 GB** Datenbankkapazität bei.
2. **Kapazitäts- und Kostenmodellierung:**
   - Modellierung der Belegung je Umgebung (`Prod`, `INT`, `TST`, `PRJ`, Migrationssandbox).
   - Wöchentliche Wachstumsraten vor und nach dem Go-Live.
   - Automatische Erkennung des Defizit-Zeitpunkts (Monat/Jahr, in dem der Speicherverbrauch das Kontingent übersteigt).
   - Zukaufkosten: Berechnung der monatlichen Mehrkosten bei Zukauf von Kapazitäts-Add-ons (~40 $ bzw. ~37 € je GB/Monat) versus Bereinigung/Archivierung.

---

## 3. Ziel-Architektur in D365Licensing

### 3.1 Paketstruktur von D365Licensing nach der Migration

```text
D365Licensing/
├── DESCRIPTION                        # Paket-Metadaten & erweiterte Imports (readxl, etc.)
├── NAMESPACE                          # Exportierte Funktionen
├── inst/
│   ├── config/
│   │   ├── config.yml                 # Pfade zu SKU-Preisen, PPAC-Dateien, Kapazitätsdaten
│   │   ├── config.local.yml           # Lokale Pfad- & Secret-Overrides
│   │   └── findings_rules.yml         # Erweiterte Lizenz- & Reconciliation-Regeln
│   └── sql/                           # Bestehende & optimierte SQL-Skripte
├── R/
│   ├── 00_utils_logging.R             # Logging & Fehlerbehandlung
│   ├── 01_connection.R                # Read-Only DB Verbindung (DBI)
│   ├── 02_pricing_engine.R            # [NEU] SKU-Preise, Base/Attach, Kostenermittlung
│   ├── 03_ppac_reconciliation.R       # [NEU] PPAC Detail/Report Ingestion & Soll/Ist
│   ├── 04_data_roles_licensing.R      # Bestehende DB-Extraktion & Graph-Verbindung
│   ├── 05_license_graph_drivers.R     # [NEU] Exploded Graph & Duty/Privilege Treiber
│   ├── 06_data_telemetry.R            # App Insights KQL Queries & Telemetrie
│   ├── 07_user_license_profile.R      # [NEU] D21 Telemetrie-Footprint & Downgrade-Engine
│   ├── 08_single_license_planner.R    # [NEU] D10 Single-License Rollenentflechtung
│   ├── 09_capacity_forecast.R         # [NEU] D17 Dataverse Kapazitätsprognose
│   ├── 10_findings_engine.R           # Erweiterte Findings & Konfidenzbewertung
│   ├── 11_reporting_excel.R           # Umfassender Multi-Tab Executive Excel Report
│   ├── 12_reporting_markdown.R        # Audit-fähiger Markdown/HTML Report
│   └── run_analysis.R                 # Zentraler Orchestrator
└── tests/
    └── testthat/                      # Unit- und Integrationstests je Modul
```

### 3.2 Schnittstellen- & Datenvertragsdefinitionen (Data Contracts)

#### Kontrakt 1: `sku_prices_df`
```r
tibble(
  SKU         = character(),  # z.B. "Finance", "Supply Chain Management", "Commerce", "Operations - Activity"
  BASE_PRICE  = numeric(),    # z.B. 168.50
  ATTACH_PRICE= numeric(),    # z.B. 27.30
  TIER        = character(),  # "Base", "Light", "None"
  PRIORITY    = integer()     # 1 (SCM), 2 (Finance), 3 (Commerce), etc.
)
```

#### Kontrakt 2: `ppac_reconciliation_df`
```r
tibble(
  USERID        = character(),
  USEREMAIL     = character(),
  REQUIRED_SKUS = list(),      # Vektor der geforderten SKUs
  ASSIGNED_SKUS = list(),      # Vektor der zugewiesenen SKUs
  MISSING_SKUS  = list(),      # Vektor der fehlenden SKUs
  REQUIRED_COST = numeric(),
  ASSIGNED_COST = numeric(),
  DELTA_COST    = numeric(),   # Positiv = Unterlizensiert; Negativ = Überlizensiert
  STATUS        = character()  # "OK", "MISSING", "MORE_THAN_NEEDED"
)
```

#### Kontrakt 3: `role_marginal_cost_df`
```r
tibble(
  RANK          = integer(),
  ROLE          = character(),
  ROLENAME      = character(),
  ACTIVE_USERS  = integer(),
  TOTAL_USER_COST = numeric(),
  AFFECTED_USERS  = integer(), # Benutzer, die ohne die Rolle tatsächlich weniger zahlen
  MARGINAL_COST   = numeric(), # Monatliche Kosten NUR wegen dieser Rolle
  COST_PER_USER   = numeric(),
  TRIGGERED_SKUS  = character()
)
```

#### Kontrakt 4: `user_footprint_profile_df` (D21)
```r
tibble(
  USERID          = character(),
  ASSIGNED_ROLES  = list(),
  PPAC_REQUIRED   = character(),
  PPAC_ASSIGNED   = character(),
  USAGE_FOOTPRINT = character(), # Minimal benötigte SKU laut tatsächlicher Telemetrie
  TARGET_SKU      = character(), # Empfohlene Ziel-Lizenz
  SAVING_POTENTIAL= numeric(),
  PROFILE_CLASS   = character()  # "SAVES", "REVIEW", "KEEPS", "NO_TELEMETRY", "NO_USE"
)
```

---

### 3.3 SQL-Architektur: Microsoft Standard-Views (Detailed vs. Summary)

Ein zentraler Architektur-Grundsatz für `D365Licensing` lautet: **Standard-First vor individuellen SQL-Aggregationen**.

#### 3.3.1 Analyse der bisherigen Redundanz
Bisher existierten in `D365Licensing/inst/sql/` Skripte, die manuell mit `GROUP BY` und Aggregationen (`SUM(ENTITLED)`, `SUM(NOTENTITLED)`, `AVG(PRIORITY)`) auf den detaillierten Entitlement-Views rechneten (z.B. in `13_license_usage_summary_duties.sql`). 

Diese manuelle Aggregation bildet jedoch lediglich nach, was Microsoft im D365FO-Standard bereits als optimierte und gewartete Summary-Views zur Verfügung stellt:
- `LicensingRoleRequirementsSummaryView`
- `LicensingDutyRequirementsSummaryView`
- `LicensingPrivilegeRequirementsSummaryView`

#### 3.3.2 Die 2-Wege-Architektur je Sicherheitsebene
Für jede der drei Kern-Ebenen der Sicherheitsarchitektur (**Rollen**, **Duties**, **Privilegien**) werden in `inst/sql/` genau **zwei klar getrennte, standardisierte Abfragen** bereitgestellt:
1. **Detailed View:** Basiert auf der Microsoft Detailed View (`LICENSING*REQUIREMENTSDETAILEDVIEW`) und liefert die feingranularen Entitlements je Securable Object / Entry Point.
2. **Summary View:** Basiert auf der Microsoft Summary View (`Licensing*RequirementsSummaryView`) und liefert die aggregierte SKU-Übersicht je Sicherheitsobjekt direkt aus dem Standard.

#### 3.3.3 Übersicht der Abfrage-Paare in `inst/sql/`

| Ebene | Detailed Query (Entry-Point Granularität) | Zukünftige Summary Query (Aggregierte SKU-Zusammenfassung) | Bisheriges manuelles Skript (wird ersetzt) |
| :--- | :--- | :--- | :--- |
| **Duties** | `07_licensing_duty_requirements.sql`<br>*(nutzt `LICENSINGDUTYREQUIREMENTSDETAILEDVIEW`)* | `13_licensing_duty_requirements_summary.sql`<br>*(nutzt `LicensingDutyRequirementsSummaryView`)* | `13_license_usage_summary_duties.sql`<br>*(GROUP BY entfernt)* |
| **Privileges** | `08_licensing_privilege_requirements.sql`<br>*(nutzt `LICENSINGPRIVILEGEREQUIREMENTSDETAILEDVIEW`)* | `14_licensing_privilege_requirements_summary.sql`<br>*(nutzt `LicensingPrivilegeRequirementsSummaryView`)* | `14_license_usage_summary_privileges.sql`<br>*(GROUP BY entfernt)* |
| **Roles** | `06_licensing_role_requirements.sql`<br>*(nutzt `LICENSINGROLEREQUIREMENTSDETAILEDVIEW`)* | `12_licensing_role_requirements_summary.sql`<br>*(nutzt `LicensingRoleRequirementsSummaryView`)* | `12_license_usage_summary_roles.sql`<br>*(GROUP BY entfernt)* |

#### 3.3.4 Gegenüberstellung am konkreten Beispiel: Duty Licenses

**Bisherige manuelle Aggregation (Nicht mehr verwenden):**
```sql
-- 13_license_usage_summary_duties.sql (ALT: Manuelle Aggregation)
SELECT
    D.IDENTIFIER             AS DUTYIDENTIFIER,
    D.NAME                   AS DUTYNAME_DISPLAY,
    T.SKUNAME,
    T.GROUPNAME,
    AVG(T.PRIORITY)          AS Priority,
    SUM(T.ENTITLED)          AS Entitled,
    SUM(T.ENTITLEDYESNO)     AS EntitledYesNo,
    SUM(T.NOTENTITLED)       AS NotEntitled,
    SUM(T.NOTREQUIRED)       AS NotRequired,
    SUM(T.NOTREQUIREDYESNO)  AS NotRequiredYesNo
FROM LICENSINGDUTYREQUIREMENTSDETAILEDVIEW T
INNER JOIN SECURITYDUTY D
    ON D.RECID = T.SECURITYDUTY
WHERE (@DutyIdentifier IS NULL OR D.IDENTIFIER = @DutyIdentifier)
GROUP BY
    D.IDENTIFIER,
    D.NAME,
    T.SKUNAME,
    T.GROUPNAME
ORDER BY
    D.IDENTIFIER ASC,
    T.SKUNAME    ASC;
```

**Zukünftige Standard-Abfrage (Microsoft Native Summary View):**
```sql
-- 13_licensing_duty_requirements_summary.sql (NEU: Microsoft Standard)
SELECT
    D.IDENTIFIER             AS DUTYIDENTIFIER,
    D.NAME                   AS DUTYNAME_DISPLAY,
    V.SKUNAME,
    V.ENTITLED,
    V.NOTENTITLED,
    V.NOTREQUIRED,
    V.GROUPNAME,
    V.PRIORITY
FROM LicensingDutyRequirementsSummaryView V
INNER JOIN SECURITYDUTY D
    ON V.SECURITYDUTY = D.RECID
WHERE (@DutyIdentifier IS NULL OR D.IDENTIFIER = @DutyIdentifier)
ORDER BY
    D.IDENTIFIER ASC,
    V.SKUNAME    ASC;
```

#### 3.3.5 Vorteile der Standard-First SQL-Architektur
1. **Performance:** Microsoft berechnet und indexiert die Summary-Views systemseitig; der Overhead von wiederholten Tabellenscans und `GROUP BY`-Operationen über Millionen Zeilen entfällt.
2. **Release-Sicherheit:** Ändern sich in künftigen D365FO-Updates (z.B. 10.0.48+) Berechnungsregeln für Entitlements, bleiben die Microsoft Summary Views automatisch synchron.
3. **Wartbarkeit:** Der Code in `D365Licensing` bleibt schlank, robust und entspricht 1:1 dem Standardverhalten des D365FO-Clients (*System administration > Security > Security governance > Licenses usage summary*).

---

## 4. Schritt-für-Schritt Migrations- und Implementierungsplan

Der folgende Plan führt Entwickler strukturiert durch die Übernahme der 6 Pfeiler nach `D365Licensing`:

### Phase 1: Paketkonfiguration & SQL-Harmonisierung (Tag 1)
- [ ] **1.1 DESCRIPTION aktualisieren:**
  - `readxl` zu `Imports` in `D365Licensing/DESCRIPTION` hinzufügen (notwendig für `skuprice.xlsx` und `Kapazitaet_*.xlsx`).
- [ ] **1.2 Konfigurationserweiterung (`inst/config/config.yml`):**
  - Ergänzung um Abschnitte `pricing`, `ppac`, `capacity` und `single_license`:
    ```yaml
    pricing:
      price_file: "Data/skuprice.xlsx"
      sheet: "skuPrices"
      default_currency: "EUR"
    ppac:
      detailed_report_path: "Data/Input/PPAC_Detailed.csv"
      summary_report_path: "Data/Input/PPAC_Summary.csv"
      target_environment: "wibu-produktiv"
    capacity:
      forecast_file: "Data/Input/Kapazitaet/Kapazitaet_Current.xlsx"
    ```
- [ ] **1.3 Rules-Erweiterung (`inst/config/findings_rules.yml`):**
  - Ergänzung um Regeln:
    - `rule_unlicensed_missing_users` (Severität: HIGH)
    - `rule_overlicensed_surplus_users` (Severität: MEDIUM)
    - `rule_role_high_marginal_cost` (Severität: HIGH)
    - `rule_unmeasured_duties_in_expensive_role` (Severität: MEDIUM)
- [ ] **1.4 SQL-Harmonisierung in `inst/sql/`:**
  - Refactoring von `12_license_usage_summary_roles.sql` auf `LicensingRoleRequirementsSummaryView`.
  - Refactoring von `13_license_usage_summary_duties.sql` auf `LicensingDutyRequirementsSummaryView`.
  - Refactoring von `14_license_usage_summary_privileges.sql` auf `LicensingPrivilegeRequirementsSummaryView`.
  - Konsistente Benennung der 2-Wege-Views (Detailed vs. Summary) auf allen drei Ebenen.
- [ ] **1.5 R-Loader in `R/data_roles_licensing.R` anpassen:**
  - `load_role_license_summary()`, `load_duty_license_summary()` und `load_privilege_license_summary()` verbinden direkt mit den standardisierten Summary-SQLs.

### Phase 2: Core Pricing & PPAC Reconciliation Module (Tag 2-3)
- [ ] **2.1 `R/pricing_engine.R` implementieren:**
  - `read_license_prices()` portieren.
  - Hilfsfunktion `calculate_user_skus_cost(skus, prices)` mit Base/Attach-Sortierung implementieren.
  - `rank_roles_by_license_cost()` anbinden: Berechnung von $\Delta \text{Cost}(R)$ über Benutzer-Mengen.
- [ ] **2.2 `R/ppac_reconciliation.R` implementieren:**
  - `read_ppac_license_detail()` & `read_ppac_license_report()` portieren.
  - `reconcile_ppac_assignments(detailed_df, summary_df, prices)` erstellen.
  - Abgleichfunktion `compare_environment_license_cost()` für Test- vs. Prod-Drift integrieren.

### Phase 3: Graph-Dekonstruktion & Telemetrie-Profile (Tag 4-5)
- [ ] **3.1 `R/license_graph_drivers.R` implementieren:**
  - `read_license_graph()` (für Excel-Exporte oder direkte DB-Tabelle `LicensingSecurityObjectExplodedGraph`).
  - `build_role_license_drivers()`: Bottom-Up Rollup von Entry Point $\rightarrow$ Privilege $\rightarrow$ Duty $\rightarrow$ Role.
  - Markierung von `DRIVES_DUTY` und Klassifikation von Custom-Privileges.
- [ ] **3.2 `R/user_license_profile.R` implementieren (D21 Logik):**
  - Verbindung von `load_telemetry_touches()` aus `data_telemetry.R` mit dem Lizenzgraphen.
  - Unterscheidung von `BY_USAGE` (echter Footprint) und `IF_CONFIRMED` (Bereinigung unmessbarer Rechte).
  - Zuordnung der Profilklassen (`SAVES`, `REVIEW`, `KEEPS`, `NO_TELEMETRY`).

### Phase 4: Spezial-Module: Single-License & Kapazität (Tag 6-7)
- [ ] **4.1 `R/single_license_planner.R` implementieren (D10 Logik):**
  - Entflechtungsalgorithmus für zusammengesetzte Rollen.
  - Klassifikation der Objekte in `ONLY`, `SHARED`, `ACTIVITY`, `TEAM_MEMBERS`, `OUTSIDE`.
  - Empfehlungen für Duty-Splits (`WHOLE`, `PARTLY`, `NONE`).
- [ ] **4.2 `R/capacity_forecast.R` implementieren (D17 Logik):**
  - Einlesen des Statusblatts `Kapazitaet_*.xlsx` (`read_capacity_status()`).
  - Prognosealgorithmus für Belegung vs. Kontingent.
  - Berechnung der Speicher-Add-on-Kosten.

### Phase 5: Pipeline-Integration, Reporting & Tests (Tag 8-9)
- [ ] **5.1 Orchestrierung in `R/run_analysis.R` integrieren:**
  - Einfügen der neuen Ladeschritte (`pricing`, `ppac`, `graph`, `capacity`).
  - Ausführung der erweiterten Reconciliation und Benutzerprofilierung.
- [ ] **5.2 `R/reporting_excel.R` erweitern:**
  - Neue Reiter im Gesamtreport: `Kosten-Ranking`, `PPAC-Reconciliation`, `Benutzerprofile_D21`, `Kapazitätsprognose`.
- [ ] **5.3 Testabdeckung (`tests/testthat/`):**
  - `test-pricing-engine.R`: Validierung der Base/Attach Berechnungslogik.
  - `test-ppac-reconciliation.R`: Test mit Mock-PPAC-Daten (Sandbox vs. Prod).
  - `test-license-graph.R`: Test des Treiber-Rollups.
  - `test-capacity-forecast.R`: Test der Kontingent- und Kostenberechnung.

---

## 5. Bereitstellung & Übergabe

Das vorliegende Konzept steht sowohl in `D365Security` zur Dokumentation der Entflechtung als auch direkt in `D365Licensing` als Implementierungs-Leitfaden für das Entwicklungsteam zur Verfügung.

- **Referenz-Dokumentation in D365Security:** [D365Licensing_Auslagerung_Konzept.md](file:///c:/Users/Cedric/Documents/RProjects/D365Security/Data/Documentation/D365Licensing_Auslagerung_Konzept.md)
- **Implementierungs-Blueprint in D365Licensing:** `c:\Users\Cedric\Documents\RProjects\D365Licensing\ARCHITECTURE_MIGRATION_BLUEPRINT.md`
