-- =============================================================================
-- View: CUSTCUSTOMERENTITY
-- Schema: dbo
-- Description:
--   D365FO customer entity view. Joins CUSTTABLE (T1) with related tables to
--   expose a flat, entity-style projection of all customer master data.
--   Used by data management export "Customer V3" and by many analysis queries
--   (e.g. eInvoice PURPOSE analysis).
--
-- Key join: T1.PARTY = T5.RECID links the legal-entity customer record to the
--   global party (DIRPARTYBASEENTITY), which carries the PARTYNUMBER used to
--   look up contact data in DIRPARTYCONTACTENTITY / PartyContactsExport.
--
-- Source tables:
--   T1  CUSTTABLE                               core customer record
--   T2  CUSTCOLLECTIONSCONTACT                  collections contact person
--   T3  WHSCUSTTABLE                            warehouse-specific settings
--   T4  RETAILCUSTTABLE                         retail/POS settings
--   T5  DIRPARTYBASEENTITY                      global party (name, PARTYNUMBER)
--   T6  COMPANYNAFCODE                          French NAF code
--   T7  TAXGSTRELIEFGROUPHEADING_MY             Malaysian GST relief group
--   T8  DIMENSIONSETENTITY                      default financial dimension display
--   T9  TAXINFORMATIONCUSTTABLE_IN              Indian tax info
--   T10 CUSTWRITEOFFFINANCIALREASONSSETUPENTITY write-off reason
--   T11 LOGISTICSPOSTALADDRESSBASEENTITY        primary postal address (via T5)
--   T12 CUSTDEFAULTROLELOCATION (TYPE=2)        delivery address location
--   T13 CUSTDEFAULTROLELOCATION (TYPE=1)        invoice address location
--   T14 LOGISTICSLOCATIONEXT                    address extension (BR fields)
--   T15 LOGISTICSPOSTALADDRESSBASEENTITY        delivery postal address (via T12)
--   T16 LOGISTICSPOSTALADDRESSBASEENTITY        invoice postal address (via T13)
-- =============================================================================

CREATE VIEW [dbo].[CUSTCUSTOMERENTITY] AS
SELECT

    -- -------------------------------------------------------------------------
    -- Core customer identifiers (T1: CUSTTABLE)
    -- -------------------------------------------------------------------------
    T1.ACCOUNTNUM                           AS CUSTOMERACCOUNT,
    T1.DATAAREAID                           AS DATAAREAID,
    T1.PARTITION                            AS PARTITION,
    T1.RECID                                AS RECID,
    T1.RECVERSION                           AS RECVERSION,
    T1.MODIFIEDDATETIME                     AS MODIFIEDDATETIME,
    T1.MODIFIEDBY                           AS MODIFIEDBY,
    T1.CREATEDDATETIME                      AS CREATEDDATETIME,

    -- -------------------------------------------------------------------------
    -- Customer group & classification
    -- -------------------------------------------------------------------------
    T1.CUSTGROUP                            AS CUSTOMERGROUPID,
    T1.ONETIMECUSTOMER                      AS ISONETIMECUSTOMER,
    T1.STATISTICSGROUP                      AS STATISTICSGROUPID,
    T1.LINEOFBUSINESSID                     AS LINEOFBUSINESSID,
    T1.SEGMENTID                            AS SALESSEGMENTID,
    T1.SUBSEGMENTID                         AS SALESSUBSEGMENTID,
    T1.SALESDISTRICTID                      AS SALESDISTRICT,
    T1.COMPANYCHAINID                       AS COMPANYCHAIN,

    -- -------------------------------------------------------------------------
    -- Contact & responsible persons
    -- -------------------------------------------------------------------------
    T1.CONTACTPERSONID                      AS CONTACTPERSONID,
    T1.MAINCONTACTWORKER                    AS MAINCONTACTWORKER,
    (CAST((SELECT PERSONNELNUMBER FROM HCMWORKER
           WHERE HCMWORKER.RECID = T1.MAINCONTACTWORKER
          ) AS NVARCHAR(25)))               AS EMPLOYEERESPONSIBLENUMBER,

    -- -------------------------------------------------------------------------
    -- Sales & pricing
    -- -------------------------------------------------------------------------
    T1.CURRENCY                             AS SALESCURRENCYCODE,
    T1.MEMO                                 AS SALESMEMO,
    T1.PRICEGROUP                           AS DISCOUNTPRICEGROUPID,
    T1.LINEDISC                             AS LINEDISCOUNTCODE,
    T1.MULTILINEDISC                        AS MULTILINEDISCOUNTCODE,
    T1.ENDDISC                              AS TOTALDISCOUNTCODE,
    T1.COMMISSIONGROUP                      AS COMMISSIONCUSTOMERGROUPID,
    T1.SALESGROUP                           AS COMMISSIONSALESGROUPID,
    T1.SALESPOOLID                          AS SALESORDERPOOLID,
    T1.OURACCOUNTNUM                        AS SALESACCOUNTNUMBER,
    T1.ORDERENTRYDEADLINEGROUPID            AS ORDERENTRYDEADLINE,
    T1.PDSREBATETMAGROUP                    AS CUSTOMERREBATEGROUPID,
    T1.PDSCUSTREBATEGROUPID                 AS CUSTOMERTMAGROUPID,
    T1.SUPPITEMGROUPID                      AS SUPPLEMENTARYITEMGROUPID,
    T1.CUSTITEMGROUPID                      AS ITEMCUSTOMERGROUPID,
    T1.ACCOUNTSTATEMENT                     AS ACCOUNTSTATEMENT,

    -- -------------------------------------------------------------------------
    -- Credit & blocking
    -- -------------------------------------------------------------------------
    T1.BLOCKED                              AS ONHOLDSTATUS,
    T1.MANDATORYCREDITLIMIT                 AS CREDITLIMITISMANDATORY,
    T1.CREDITRATING                         AS CREDITRATING,
    T1.CREDITMAX                            AS CREDITLIMIT,
    T1.CUSTEXCLUDEINTERESTCHARGES           AS ISEXCLUDEDFROMINTERESTCHARGECALCULATION,
    T1.CUSTEXCLUDECOLLECTIONFEE             AS ISEXCLUDEDFROMCOLLECTIONFEECALCULATION,
    T1.MARKUPGROUP                          AS CHARGESGROUPID,

    -- -------------------------------------------------------------------------
    -- Payment
    -- -------------------------------------------------------------------------
    T1.PAYMTERMID                           AS PAYMENTTERMS,
    T1.PAYMMODE                             AS PAYMENTMETHOD,
    T1.PAYMSPEC                             AS PAYMENTSPECIFICATION,
    T1.PAYMSCHED                            AS PAYMENTSCHEDULE,
    T1.PAYMDAYID                            AS PAYMENTDAY,
    T1.CASHDISC                             AS PAYMENTCASHDISCOUNT,
    T1.CASHDISCBASEDAYS                     AS PAYMENTTERMSBASEDAYS,
    T1.BANKACCOUNT                          AS PAYMENTBANKACCOUNT,
    T1.FACTORINGACCOUNT                     AS PAYMENTFACTORINGACCOUNT,
    T1.PAYMIDTYPE                           AS PAYMENTIDTYPE,
    T1.USECASHDISC                          AS PAYMENTUSECASHDISCOUNT,
    T1.BANKCENTRALBANKPURPOSECODE           AS CENTRALBANKPURPOSECODE,
    T1.BANKCENTRALBANKPURPOSETEXT           AS CENTRALBANKPURPOSENOTES,
    T1.CREDITCARDADDRESSVERIFICATION        AS CREDITCARDADDRESSVERIFICATION,
    T1.CREDITCARDADDRESSVERIFICATIONVOID    AS CREDITCARDADDRESSVERIFICATIONISAUTHORIZATIONVOIDEDONFAILURE,
    T1.CREDITCARDADDRESSVERIFICATIONLEVEL   AS CREDITCARDADDRESSVERIFICATIONLEVEL,
    T1.CREDITCARDCVC                        AS CREDITCARDCVC,

    -- -------------------------------------------------------------------------
    -- Invoice & billing
    -- -------------------------------------------------------------------------
    T1.INVOICEACCOUNT                       AS INVOICEACCOUNT,
    T1.INVOICEADDRESS                       AS INVOICEADDRESS,
    T1.NUMBERSEQUENCEGROUP                  AS NUMBERSEQUENCEGROUP,
    T1.EINVOICE                             AS ISELECTRONICINVOICE,
    T1.EINVOICEEANNUM                       AS ELECTRONICINVOICEEAN,
    T1.GIROTYPE                             AS GIROTYPE,
    T1.GIROTYPEFREETEXTINVOICE              AS GIROTYPEFREETEXTINVOICE,
    T1.GIROTYPEINTERESTNOTE                 AS GIROTYPEINTERESTNOTE,
    T1.GIROTYPECOLLECTIONLETTER             AS GIROTYPECOLLECTIONLETTER,
    T1.GIROTYPEPROJINVOICE                  AS GIROTYPEPROJINVOICE,
    T1.GIROTYPEACCOUNTSTATEMENT             AS GIROTYPEACCOUNTSTATEMENT,

    -- -------------------------------------------------------------------------
    -- Tax
    -- -------------------------------------------------------------------------
    T1.TAXGROUP                             AS SALESTAXGROUP,
    T1.VATNUM                               AS TAXEXEMPTNUMBER,
    T1.INCLTAX                              AS ISSALESTAXINCLUDEDINPRICES,
    T1.TAXLICENSENUM                        AS PACKINGDUTYLICENSE,
    T1.FISCALCODE                           AS FISCALCODE,
    T1.PACKMATERIALFEELICENSENUM            AS PACKINGMATERIALFEELICENSENUMBER,
    T1.TAXWITHHOLDCALCULATE_TH              AS ISWITHHOLDINGTAXCALCULATED,
    T1.TAXWITHHOLDGROUP_TH                  AS WITHHOLDINGTAXGROUPCODE,
    T1.TAXWITHHOLDCALCULATE_IN              AS CALCULATEWITHHOLDINGTAX,
    T1.IDENTIFICATIONNUMBER                 AS IDENTIFICATIONNUMBER,
    T1.ORGID                                AS NATIONALREGISTRYNUMBER,

    -- -------------------------------------------------------------------------
    -- Delivery & logistics
    -- -------------------------------------------------------------------------
    T1.INVENTSITEID                         AS SITEID,
    T1.INVENTLOCATION                       AS WAREHOUSEID,
    T1.DEFAULTINVENTSTATUSID                AS DEFAULTINVENTORYSTATUSID,
    T1.FREIGHTZONE                          AS DELIVERYFREIGHTZONE,
    T1.DLVTERM                              AS DELIVERYTERMS,
    T1.DLVMODE                              AS DELIVERYMODE,
    T1.DLVREASON                            AS DELIVERYREASON,
    T1.DESTINATIONCODEID                    AS DESTINATIONCODE,
    T1.SALESCALENDARID                      AS RECEIPTCALENDAR,
    T1.PDSFREIGHTACCRUED                    AS ISFREIGHTACCRUED,
    T1.EXPRESSBILLOFLADING                  AS ISEXPRESSBILLOFLADINGACCEPTED,

    -- -------------------------------------------------------------------------
    -- Vendor & other links
    -- -------------------------------------------------------------------------
    T1.VENDACCOUNT                          AS VENDORACCOUNT,
    T1.DEFAULTDIMENSION                     AS DEFAULTDIMENSION,
    T1.USEPURCHREQUEST                      AS ISPURCHREQUESTUSED,
    T1.ISEXTERNALLYMAINTAINED               AS ISEXTERNALLYMAINTAINED,

    -- -------------------------------------------------------------------------
    -- US Federal fields
    -- -------------------------------------------------------------------------
    T1.PARTYCOUNTRY                         AS PARTYCOUNTRY,
    T1.PARTYSTATE                           AS PARTYSTATE,
    T1.FEDNONFEDINDICATOR                   AS FEDERALINDICATOR,
    T1.AGENCYLOCATIONCODE                   AS FEDERALAGENCYLOCATIONCODE,
    T1.FEDERALCOMMENTS                      AS FEDERALCOMMENTS,
    T1.IRS1099CINDICATOR                    AS IRS1099CINDICATOR,

    -- -------------------------------------------------------------------------
    -- Country-specific: France, Mexico, Japan, Poland, Italy
    -- -------------------------------------------------------------------------
    T1.COMPANYIDSIRET                       AS FRENCHSIRET,
    T1.COMPANYTYPE_MX                       AS COMPANYTYPE,
    T1.CURP_MX                              AS CURPNUMBER,
    T1.RFC_MX                               AS RFCNUMBER,
    T1.STATEINSCRIPTION_MX                  AS STATEINSCRIPTION,
    T1.FOREIGNTAXREGISTRATION_MX            AS TAXREGISTRATIONID,
    T1.CONSDAY_JP                           AS CONSOLIDATIONDAY,
    T1.EXPORTSALES_PL                       AS EXPORTSALE,
    T1.BIRTHCOUNTYCODE_IT                   AS BIRTHCOUNTYCODE,
    T1.BIRTHPLACE_IT                        AS BIRTHPLACE,
    T1.RESIDENCEFOREIGNCOUNTRYREGIONID_IT   AS RESIDENCEFOREIGNCOUNTRYREGIONID,

    -- -------------------------------------------------------------------------
    -- Country-specific: Brazil
    -- -------------------------------------------------------------------------
    T1.FINECODE_BR                          AS CUSTOMERPAYMENTFINECODE,
    T1.INTERESTCODE_BR                      AS CUSTOMERPAYMENTFINANCIALINTERESTCODE,
    T1.CCMNUM_BR                            AS BRAZILIANCCM,
    T1.CNAE_BR                              AS BRAZILIANCNAE,
    T1.CNPJCPFNUM_BR                        AS BRAZILIANCNPJORCPF,
    T1.CUSTFINALUSER_BR                     AS ISFINALUSER,
    T1.CUSTWHTCONTRIBUTIONTYPE_BR           AS CUSTOMERWITHHOLDINGCONTRIBUTIONTYPE,
    T1.GENERATEINCOMINGFISCALDOCUMENT_BR    AS ISINCOMINGFISCALDOCUMENTGENERATED,
    T1.ICMSCONTRIBUTOR_BR                   AS ISICMSCONTRIBUTOR,
    T1.IENUM_BR                             AS BRAZILIANIE,
    T1.INSSCEI_BR                           AS BRAZILIANINSSCEI,
    T1.NIT_BR                               AS BRAZILIANNIT,
    T1.SERVICECODEONDLVADDRESS_BR           AS ISSERVICEDELIVERYADDRESSBASED,
    T1.SUFRAMA_BR                           AS ISINSUFRAMAREGION,
    T1.SUFRAMANUMBER_BR                     AS SUFRAMANUMBER,
    T1.SUFRAMAPISCOFINS_BR                  AS HASSUFRAMADISCOUNTPISANDCOFINS,
    T1.FOREIGNERID_BR                       AS FOREIGNERID,
    T1.PRESENCETYPE_BR                      AS TRANSACTIONPRESENCETYPE,

    -- -------------------------------------------------------------------------
    -- T2: Collections contact
    -- -------------------------------------------------------------------------
    T2.CONTACTPERSONID                      AS COLLECTIONSCONTACTPERSONID,
    T2.RECVERSION                           AS RECVERSION#2,
    T2.DATAAREAID                           AS DATAAREAID#2,
    T2.PARTITION                            AS PARTITION#2,
    T2.RECID                                AS RECID#2,

    -- -------------------------------------------------------------------------
    -- T3: Warehouse settings
    -- -------------------------------------------------------------------------
    T3.GENERATEASN                          AS WAREHOUSEISASNGENERATED,
    T3.FILLENTIREORDER                      AS WAREHOUSEISENTIRESHIPMENTFILLED,
    T3.RECVERSION                           AS RECVERSION#3,
    T3.DATAAREAID                           AS DATAAREAID#3,
    T3.PARTITION                            AS PARTITION#3,
    T3.RECID                                AS RECID#3,

    -- -------------------------------------------------------------------------
    -- T4: Retail settings
    -- -------------------------------------------------------------------------
    T4.POSTASSHIPMENT                       AS ISTRANSACTIONPOSTEDASSHIPMENT,
    T4.USEORDERNUMBERREFERENCE              AS ISORDERNUMBERREFERENCEUSED,
    T4.RETURNTAXGROUP_W                     AS SALESRETURNTAXGROUP,
    T4.RECEIPTEMAIL                         AS RECEIPTEMAIL,
    T4.RECEIPTOPTION                        AS RECEIPTOPTION,
    T4.RECVERSION                           AS RECVERSION#4,
    T4.DATAAREAID                           AS DATAAREAID#4,
    T4.PARTITION                            AS PARTITION#4,
    T4.RECID                                AS RECID#4,

    -- -------------------------------------------------------------------------
    -- T5: Global party / DIRPARTYBASEENTITY
    --   PARTYNUMBER is the key used to look up DIRPARTYCONTACTENTITY / PartyContactsExport
    -- -------------------------------------------------------------------------
    T5.PARTYTYPE                            AS PARTYTYPE,
    T5.NAME                                 AS NAME,
    T5.NAMEALIAS                            AS NAMEALIAS,
    T5.KNOWNAS                              AS KNOWNAS,
    T5.ORGANIZATIONNUMBER                   AS ORGANIZATIONNUMBER,
    T5.ORGANIZATIONNUMOFEMPLOYEES           AS ORGANIZATIONNUMBEROFEMPLOYEES,
    T5.ORGANIZATIONABCCODE                  AS ORGANIZATIONABCCODE,
    T5.ORGANIZATIONPHONETICNAME             AS ORGANIZATIONPHONETICNAME,
    T5.PERSONINITIALS                       AS PERSONINITIALS,
    T5.PERSONPROFESSIONALTITLE              AS PERSONPROFESSIONALTITLE,
    T5.PERSONPROFESSIONALSUFFIX             AS PERSONPROFESSIONALSUFFIX,
    T5.PERSONPHONETICFIRSTNAME              AS PERSONPHONETICFIRSTNAME,
    T5.PERSONPHONETICLASTNAME               AS PERSONPHONETICLASTNAME,
    T5.PERSONPHONETICMIDDLENAME             AS PERSONPHONETICMIDDLENAME,
    T5.PERSONGENDER                         AS PERSONGENDER,
    T5.PERSONMARITALSTATUS                  AS PERSONMARITALSTATUS,
    T5.PERSONANNIVERSARYDAY                 AS PERSONANNIVERSARYDAY,
    T5.PERSONANNIVERSARYMONTH               AS PERSONANNIVERSARYMONTH,
    T5.PERSONANNIVERSARYYEAR                AS PERSONANNIVERSARYYEAR,
    T5.PERSONCHILDRENNAMES                  AS PERSONCHILDRENNAMES,
    T5.PERSONHOBBIES                        AS PERSONHOBBIES,
    T5.PARTYNUMBER                          AS PARTYNUMBER,
    T5.ADDRESSBOOKS                         AS ADDRESSBOOKS,
    T5.LANGUAGEID                           AS LANGUAGEID,
    T5.ADDRESSLOCATIONROLES                 AS ADDRESSLOCATIONROLES,
    T5.ELECTRONICLOCATIONID                 AS ELECTRONICLOCATIONID,
    -- Primary contact fields (denormalized from DIRPARTYCONTACTENTITY)
    T5.PRIMARYCONTACTEMAIL                  AS PRIMARYCONTACTEMAIL,
    T5.PRIMARYCONTACTEMAILDESCRIPTION       AS PRIMARYCONTACTEMAILDESCRIPTION,
    T5.PRIMARYCONTACTEMAILISIM              AS PRIMARYCONTACTEMAILISIM,
    T5.PRIMARYCONTACTEMAILPURPOSE           AS PRIMARYCONTACTEMAILPURPOSE,
    T5.PRIMARYCONTACTFAX                    AS PRIMARYCONTACTFAX,
    T5.PRIMARYCONTACTFAXDESCRIPTION         AS PRIMARYCONTACTFAXDESCRIPTION,
    T5.PRIMARYCONTACTFAXEXTENSION           AS PRIMARYCONTACTFAXEXTENSION,
    T5.PRIMARYCONTACTFAXPURPOSE             AS PRIMARYCONTACTFAXPURPOSE,
    T5.PRIMARYCONTACTPHONE                  AS PRIMARYCONTACTPHONE,
    T5.PRIMARYCONTACTPHONEDESCRIPTION       AS PRIMARYCONTACTPHONEDESCRIPTION,
    T5.PRIMARYCONTACTPHONEEXTENSION         AS PRIMARYCONTACTPHONEEXTENSION,
    T5.PRIMARYCONTACTPHONEISMOBILE          AS PRIMARYCONTACTPHONEISMOBILE,
    T5.PRIMARYCONTACTPHONEPURPOSE           AS PRIMARYCONTACTPHONEPURPOSE,
    T5.PRIMARYCONTACTTELEX                  AS PRIMARYCONTACTTELEX,
    T5.PRIMARYCONTACTTELEXDESCRIPTION       AS PRIMARYCONTACTTELEXDESCRIPTION,
    T5.PRIMARYCONTACTTELEXPURPOSE           AS PRIMARYCONTACTTELEXPURPOSE,
    T5.PRIMARYCONTACTURL                    AS PRIMARYCONTACTURL,
    T5.PRIMARYCONTACTURLDESCRIPTION         AS PRIMARYCONTACTURLDESCRIPTION,
    T5.PRIMARYCONTACTURLPURPOSE             AS PRIMARYCONTACTURLPURPOSE,
    T5.PRIMARYCONTACTFACEBOOK               AS PRIMARYCONTACTFACEBOOK,
    T5.PRIMARYCONTACTFACEBOOKDESCRIPTION    AS PRIMARYCONTACTFACEBOOKDESCRIPTION,
    T5.PRIMARYCONTACTFACEBOOKPURPOSE        AS PRIMARYCONTACTFACEBOOKPURPOSE,
    T5.PRIMARYCONTACTLINKEDIN               AS PRIMARYCONTACTLINKEDIN,
    T5.PRIMARYCONTACTLINKEDINDESCRIPTION    AS PRIMARYCONTACTLINKEDINDESCRIPTION,
    T5.PRIMARYCONTACTLINKEDINPURPOSE        AS PRIMARYCONTACTLINKEDINPURPOSE,
    T5.PRIMARYCONTACTTWITTERDESCRIPTION     AS PRIMARYCONTACTTWITTERDESCRIPTION,
    T5.PRIMARYCONTACTTWITTER               AS PRIMARYCONTACTTWITTER,
    T5.PRIMARYCONTACTTWITTERPURPOSE        AS PRIMARYCONTACTTWITTERPURPOSE,
    T5.RECVERSION                           AS RECVERSION#5,
    T5.PARTITION                            AS PARTITION#5,
    T5.RECID                                AS RECID#5,

    -- -------------------------------------------------------------------------
    -- T6: French NAF code
    -- -------------------------------------------------------------------------
    T6.COMPANYIDNAF                         AS NAFCODE,
    T6.RECVERSION                           AS RECVERSION#12,
    T6.DATAAREAID                           AS DATAAREAID#12,
    T6.PARTITION                            AS PARTITION#12,
    T6.RECID                                AS RECID#12,

    -- -------------------------------------------------------------------------
    -- T7: Malaysian GST relief group
    -- -------------------------------------------------------------------------
    T7.RELIEFGROUPID                        AS RELIEFGROUPID,
    T7.RECVERSION                           AS RECVERSION#13,
    T7.DATAAREAID                           AS DATAAREAID#13,
    T7.PARTITION                            AS PARTITION#13,
    T7.RECID                                AS RECID#13,

    -- -------------------------------------------------------------------------
    -- T8: Default financial dimension display value
    -- -------------------------------------------------------------------------
    T8.DISPLAYVALUE                         AS DEFAULTDIMENSIONDISPLAYVALUE,
    T8.RECVERSION                           AS RECVERSION#14,
    T8.PARTITION                            AS PARTITION#14,
    T8.RECID                                AS RECID#14,

    -- -------------------------------------------------------------------------
    -- T9: Indian tax information
    -- -------------------------------------------------------------------------
    T9.ISFOREIGN                            AS FOREIGNCUSTOMER,
    T9.TCSGROUP                             AS TCSGROUP,
    T9.TDSGROUP                             AS TDSGROUP,
    T9.ISPREFERENTIAL                       AS PREFERENTIALCUSTOMER,
    T9.NATUREOFASSESSEE                     AS NATUREOFASSESSEE,
    T9.PANNUMBER                            AS PANNUMBER,
    T9.PANREFERENCENUMBER                   AS PANREFERENCENUMBER,
    T9.PANSTATUS                            AS PANSTATUS,
    T9.RECVERSION                           AS RECVERSION#15,
    T9.DATAAREAID                           AS DATAAREAID#15,
    T9.PARTITION                            AS PARTITION#15,
    T9.RECID                                AS RECID#15,

    -- -------------------------------------------------------------------------
    -- T10: Write-off reason
    -- -------------------------------------------------------------------------
    T10.COMPANY                             AS WRITEOFFCOMPANY,
    T10.WRITEOFFREASON                      AS WRITEOFFREASON,
    T10.RECVERSION                          AS RECVERSION#16,
    T10.PARTITION                           AS PARTITION#16,
    T10.RECID                               AS RECID#16,

    -- -------------------------------------------------------------------------
    -- T11: Primary postal address (via T5.PRIMARYADDRESSLOCATION)
    -- -------------------------------------------------------------------------
    T11.ADDRESS                             AS FULLPRIMARYADDRESS,
    T11.DESCRIPTION                         AS ADDRESSDESCRIPTION,
    T11.ZIPCODE                             AS ADDRESSZIPCODE,
    T11.CITY                                AS ADDRESSCITY,
    T11.COUNTRYREGIONID                     AS ADDRESSCOUNTRYREGIONID,
    T11.COUNTRYREGIONISOCODE                AS ADDRESSCOUNTRYREGIONISOCODE,
    T11.COUNTY                              AS ADDRESSCOUNTY,
    T11.DISTRICTNAME                        AS ADDRESSDISTRICTNAME,
    T11.LATITUDE                            AS ADDRESSLATITUDE,
    T11.LOCATIONID                          AS ADDRESSLOCATIONID,
    T11.LONGITUDE                           AS ADDRESSLONGITUDE,
    T11.STATE                               AS ADDRESSSTATE,
    T11.STREET                              AS ADDRESSSTREET,
    T11.TIMEZONE                            AS ADDRESSTIMEZONE,
    T11.VALIDFROM                           AS ADDRESSVALIDFROM,
    T11.VALIDTO                             AS ADDRESSVALIDTO,
    T11.RECVERSION                          AS RECVERSION#6,
    T11.PARTITION                           AS PARTITION#6,
    T11.RECID                               AS RECID#6,

    -- -------------------------------------------------------------------------
    -- T12 / T13: Delivery and invoice address location records
    -- -------------------------------------------------------------------------
    T12.DATAAREAID                          AS DATAAREAID#8,
    T12.PARTITION                           AS PARTITION#8,
    T12.RECID                               AS RECID#8,
    T13.DATAAREAID                          AS DATAAREAID#10,
    T13.PARTITION                           AS PARTITION#10,
    T13.RECID                               AS RECID#10,

    -- -------------------------------------------------------------------------
    -- T14: Address extension (Brazilian CNPJ/IE on primary address)
    -- -------------------------------------------------------------------------
    T14.CNPJCPFNUM_BR                       AS ADDRESSBRAZILIANCNPJORCPF,
    T14.IENUM_BR                            AS ADDRESSBRAZILIANIE,
    T14.RECVERSION                          AS RECVERSION#7,
    T14.DATAAREAID                          AS DATAAREAID#7,
    T14.PARTITION                           AS PARTITION#7,
    T14.RECID                               AS RECID#7,

    -- -------------------------------------------------------------------------
    -- T15: Delivery postal address (via T12, TYPE=2)
    -- -------------------------------------------------------------------------
    T15.DESCRIPTION                         AS DELIVERYADDRESSDESCRIPTION,
    T15.ZIPCODE                             AS DELIVERYADDRESSZIPCODE,
    T15.TIMEZONE                            AS DELIVERYADDRESSTIMEZONE,
    T15.CITY                                AS DELIVERYADDRESSCITY,
    T15.COUNTRYREGIONID                     AS DELIVERYADDRESSCOUNTRYREGIONID,
    T15.COUNTRYREGIONISOCODE                AS DELIVERYADDRESSCOUNTRYREGIONISOCODE,
    T15.COUNTY                              AS DELIVERYADDRESSCOUNTY,
    T15.DISTRICTNAME                        AS DELIVERYADDRESSDISTRICTNAME,
    T15.LATITUDE                            AS DELIVERYADDRESSLATITUDE,
    T15.LONGITUDE                           AS DELIVERYADDRESSLONGITUDE,
    T15.LOCATIONID                          AS DELIVERYADDRESSLOCATIONID,
    T15.STATE                               AS DELIVERYADDRESSSTATE,
    T15.STREET                              AS DELIVERYADDRESSSTREET,
    T15.VALIDFROM                           AS DELIVERYADDRESSVALIDFROM,
    T15.VALIDTO                             AS DELIVERYADDRESSVALIDTO,
    T15.RECVERSION                          AS RECVERSION#9,
    T15.PARTITION                           AS PARTITION#9,
    T15.RECID                               AS RECID#9,

    -- -------------------------------------------------------------------------
    -- T16: Invoice postal address (via T13, TYPE=1)
    -- -------------------------------------------------------------------------
    T16.DESCRIPTION                         AS INVOICEADDRESSDESCRIPTION,
    T16.ZIPCODE                             AS INVOICEADDRESSZIPCODE,
    T16.TIMEZONE                            AS INVOICEADDRESSTIMEZONE,
    T16.CITY                                AS INVOICEADDRESSCITY,
    T16.COUNTRYREGIONID                     AS INVOICEADDRESSCOUNTRYREGIONID,
    T16.COUNTRYREGIONISOCODE                AS INVOICEADDRESSCOUNTRYREGIONISOCODE,
    T16.COUNTY                              AS INVOICEADDRESSCOUNTY,
    T16.DISTRICTNAME                        AS INVOICEADDRESSDISTRICTNAME,
    T16.LATITUDE                            AS INVOICEADDRESSLATITUDE,
    T16.LONGITUDE                           AS INVOICEADDRESSLONGITUDE,
    T16.LOCATIONID                          AS INVOICEADDRESSLOCATIONID,
    T16.STATE                               AS INVOICEADDRESSSTATE,
    T16.STREET                              AS INVOICEADDRESSSTREET,
    T16.VALIDFROM                           AS INVOICEADDRESSVALIDFROM,
    T16.VALIDTO                             AS INVOICEADDRESSVALIDTO,
    T16.RECVERSION                          AS RECVERSION#11,
    T16.PARTITION                           AS PARTITION#11,
    T16.RECID                               AS RECID#11,

    -- -------------------------------------------------------------------------
    -- Placeholder columns (not implemented in this version)
    -- -------------------------------------------------------------------------
    CAST(NULL AS INT)           AS ISRFIDPALLETTAGGINGENABLED,
    CAST(NULL AS INT)           AS ISRFIDCASETAGGINGENABLED,
    CAST(NULL AS INT)           AS ISRFIDITEMTAGGINGENABLED,
    CAST(NULL AS NVARCHAR(50))  AS ENTERPRISENUMBER,
    CAST(NULL AS INT)           AS ISFUELSURCHARGEAPPLIED,
    CAST(NULL AS INT)           AS FULFILLMENTERRORTOLERANCE,
    CAST(NULL AS INT)           AS WAREHOUSEFULFILLMENTTYPE,
    CAST(NULL AS NUMERIC(32,16)) AS WAREHOUSEFULFILLMENTRATE

FROM CUSTTABLE T1

    -- Collections contact (optional)
    LEFT OUTER JOIN CUSTCOLLECTIONSCONTACT T2
        ON  T1.ACCOUNTNUM  = T2.ACCOUNTNUM
        AND T1.DATAAREAID  = T2.DATAAREAID
        AND T1.PARTITION   = T2.PARTITION

    -- Warehouse settings (optional)
    LEFT OUTER JOIN WHSCUSTTABLE T3
        ON  T1.ACCOUNTNUM  = T3.ACCOUNTNUM
        AND T1.DATAAREAID  = T3.DATAAREAID
        AND T1.PARTITION   = T3.PARTITION

    -- Retail settings (optional)
    LEFT OUTER JOIN RETAILCUSTTABLE T4
        ON  T1.ACCOUNTNUM  = T4.ACCOUNTNUM
        AND T1.DATAAREAID  = T4.DATAAREAID
        AND T1.PARTITION   = T4.PARTITION

    -- Global party — mandatory (resolves NAME, PARTYNUMBER, primary contacts)
    CROSS JOIN DIRPARTYBASEENTITY T5

    -- French NAF code (optional)
    LEFT OUTER JOIN COMPANYNAFCODE T6
        ON  T1.COMPANYNAFCODE = T6.RECID
        AND T1.DATAAREAID     = T6.DATAAREAID
        AND T1.PARTITION      = T6.PARTITION

    -- Malaysian GST relief group (optional)
    LEFT OUTER JOIN TAXGSTRELIEFGROUPHEADING_MY T7
        ON  T1.TAXGSTRELIEFGROUPHEADING_MY = T7.RECID
        AND T1.DATAAREAID                  = T7.DATAAREAID
        AND T1.PARTITION                   = T7.PARTITION

    -- Default dimension display value (optional)
    LEFT OUTER JOIN DIMENSIONSETENTITY T8
        ON  T1.DEFAULTDIMENSION = T8.RECID
        AND T1.PARTITION        = T8.PARTITION

    -- Indian tax information (optional)
    LEFT OUTER JOIN TAXINFORMATIONCUSTTABLE_IN T9
        ON  T1.ACCOUNTNUM  = T9.CUSTTABLE
        AND T1.DATAAREAID  = T9.DATAAREAID
        AND T1.PARTITION   = T9.PARTITION

    -- Write-off reason (optional)
    LEFT OUTER JOIN CUSTWRITEOFFFINANCIALREASONSSETUPENTITY T10
        ON  T1.CUSTWRITEOFFREFRECID = T10.RECID
        AND T1.PARTITION            = T10.PARTITION

    -- Primary postal address — date-effective via context functions
    LEFT OUTER JOIN LOGISTICSPOSTALADDRESSBASEENTITY T11
        ON  T5.PRIMARYADDRESSLOCATION = T11.LOCATIONRECID
        AND T5.PARTITION              = T11.PARTITION
        AND T11.VALIDFROM <= (SELECT ValidFromInContextInfo FROM [dbo].GetValidFromDateInContextInfoAsTable())
        AND T11.VALIDTO   >= (SELECT ValidToInContextInfo   FROM [dbo].GetValidToDateInContextInfoAsTable())

    -- Delivery address location record (TYPE=2)
    LEFT OUTER JOIN CUSTDEFAULTROLELOCATION T12
        ON  T1.ACCOUNTNUM  = T12.ACCOUNTNUM
        AND T1.DATAAREAID  = T12.DATAAREAID
        AND T1.PARTITION   = T12.PARTITION
        AND T5.RECID       = T12.PARTY
        AND T5.PARTITION   = T12.PARTITION
        AND T12.TYPE       = 2

    -- Invoice address location record (TYPE=1)
    LEFT OUTER JOIN CUSTDEFAULTROLELOCATION T13
        ON  T1.ACCOUNTNUM  = T13.ACCOUNTNUM
        AND T1.DATAAREAID  = T13.DATAAREAID
        AND T1.PARTITION   = T13.PARTITION
        AND T5.RECID       = T13.PARTY
        AND T5.PARTITION   = T13.PARTITION
        AND T13.TYPE       = 1

    -- Address extension for Brazilian CNPJ/IE on primary address (optional)
    LEFT OUTER JOIN LOGISTICSLOCATIONEXT T14
        ON  T11.RECID     = T14.LOCATION
        AND T11.PARTITION = T14.PARTITION

    -- Delivery postal address — date-effective (optional)
    LEFT OUTER JOIN LOGISTICSPOSTALADDRESSBASEENTITY T15
        ON  T12.LOGISTICSLOCATION = T15.LOCATIONRECID
        AND T12.PARTITION         = T15.PARTITION
        AND T15.VALIDFROM <= (SELECT ValidFromInContextInfo FROM [dbo].GetValidFromDateInContextInfoAsTable())
        AND T15.VALIDTO   >= (SELECT ValidToInContextInfo   FROM [dbo].GetValidToDateInContextInfoAsTable())

    -- Invoice postal address — date-effective (optional)
    LEFT OUTER JOIN LOGISTICSPOSTALADDRESSBASEENTITY T16
        ON  T13.LOGISTICSLOCATION = T16.LOCATIONRECID
        AND T13.PARTITION         = T16.PARTITION
        AND T16.VALIDFROM <= (SELECT ValidFromInContextInfo FROM [dbo].GetValidFromDateInContextInfoAsTable())
        AND T16.VALIDTO   >= (SELECT ValidToInContextInfo   FROM [dbo].GetValidToDateInContextInfoAsTable())

WHERE T1.PARTY    = T5.RECID
  AND T1.PARTITION = T5.PARTITION;

GO
