-- =============================================================================
-- View: SALESINVOICEHEADERENTITY
-- Schema: dbo
-- Description:
--   D365FO sales invoice header entity view. Joins CUSTINVOICEJOUR (T1) with
--   the originating sales order (SALESTABLE), invoice address, tax totals, and
--   the responsible sales person.
--   Used by data management export "Sales invoice headers V2".
--
-- Key column for customer linkage:
--   T1.INVOICEACCOUNT → INVOICECUSTOMERACCOUNTNUMBER
--   T1.SALESID        → join to SALESTABLE for order-level fields
--
-- Source tables:
--   T1  CUSTINVOICEJOUR                    core invoice journal (one row per invoice)
--   T2  SALESTABLE                         originating sales order (optional)
--   T3  LOGISTICSPOSTALADDRESSBASEENTITY   invoice postal address (via T1.INVOICEPOSTALADDRESS)
--   T4  CUSTINVOICEJOURTOTALTAXAMOUNTVIEW  pre-aggregated tax total per invoice
--   T5  HCMWORKER                          sales responsible (via T2.WORKERSALESRESPONSIBLE)
-- =============================================================================

CREATE VIEW [dbo].[SALESINVOICEHEADERENTITY] AS
SELECT

    -- -------------------------------------------------------------------------
    -- T1: Core invoice fields (CUSTINVOICEJOUR)
    -- -------------------------------------------------------------------------
    T1.INVOICEID                            AS INVOICENUMBER,
    T1.INVOICEDATE                          AS INVOICEDATE,
    T1.INVOICEAMOUNT                        AS TOTALINVOICEAMOUNT,
    T1.CURRENCYCODE                         AS CURRENCYCODE,
    T1.SUMTAX                               AS TOTALTAXAMOUNT,
    T1.SUMMARKUP                            AS TOTALCHARGEAMOUNT,
    T1.ENDDISC                              AS TOTALDISCOUNTCUSTOMERGROUPCODE,
    T1.INVOICEACCOUNT                       AS INVOICECUSTOMERACCOUNTNUMBER,
    T1.MODIFIEDDATETIME                     AS MODIFIEDDATETIME,
    T1.CREATEDDATETIME                      AS CREATEDDATETIME,
    T1.CREATEDBY                            AS CREATEDBY,
    T1.RECVERSION                           AS RECVERSION,
    T1.DATAAREAID                           AS DATAAREAID,
    T1.PARTITION                            AS PARTITION,
    T1.RECID                                AS RECID,

    -- -------------------------------------------------------------------------
    -- T1: Computed discount total
    --   Sum of line discount (SUMLINEDISC), cash discount (CASHDISC),
    --   and the end/total discount (ENDDISC)
    -- -------------------------------------------------------------------------
    (CAST(((T1.ENDDISC) + (T1.SUMLINEDISC) + (T1.CASHDISC)) AS NUMERIC(32, 16)))
                                            AS TOTALDISCOUNTAMOUNT,

    -- -------------------------------------------------------------------------
    -- T2: Sales order fields (SALESTABLE — optional, NULL if no originating order)
    -- -------------------------------------------------------------------------
    T2.CONTACTPERSONID                      AS CONTACTPERSONID,
    T2.CUSTOMERREF                          AS CUSTOMERSORDERREFERENCE,
    T2.DLVMODE                              AS DELIVERYMODECODE,
    T2.DLVTERM                              AS DELIVERYTERMSCODE,
    T2.PAYMENT                              AS PAYMENTTERMSNAME,
    T2.SALESID                              AS SALESORDERNUMBER,
    T2.SALESORIGINID                        AS SALESORDERORIGINCODE,
    T2.RECVERSION                           AS RECVERSION#2,
    T2.DATAAREAID                           AS DATAAREAID#2,
    T2.PARTITION                            AS PARTITION#2,
    T2.RECID                                AS RECID#2,

    -- -------------------------------------------------------------------------
    -- T3: Invoice postal address (LOGISTICSPOSTALADDRESSBASEENTITY)
    --   Linked via T1.INVOICEPOSTALADDRESS → T3.ADDRESSRECID
    -- -------------------------------------------------------------------------
    T3.STATE                                AS INVOICEADDRESSSTATE,
    T3.STREET                               AS INVOICEADDRESSSTREET,
    T3.STREETNUMBER                         AS INVOICEADDRESSSTREETNUMBER,
    T3.ZIPCODE                              AS INVOICEADDRESSZIPCODE,
    T3.CITY                                 AS INVOICEADDRESSCITY,
    T3.COUNTRYREGIONID                      AS INVOICEADDRESSCOUNTRYREGIONID,
    T3.COUNTRYREGIONISOCODE                 AS INVOICEADDRESSCOUNTRYREGIONISOCODE,
    T3.RECVERSION                           AS RECVERSION#4,
    T3.PARTITION                            AS PARTITION#4,
    T3.RECID                                AS RECID#4,

    -- -------------------------------------------------------------------------
    -- T4: Pre-aggregated tax total (CUSTINVOICEJOURTOTALTAXAMOUNTVIEW)
    --   Note: T1.SUMTAX = total tax; T4.TAXAMOUNT = header-level breakdown
    -- -------------------------------------------------------------------------
    T4.TAXAMOUNT                            AS INVOICEHEADERTAXAMOUNT,
    T4.DATAAREAID                           AS DATAAREAID#5,
    T4.PARTITION                            AS PARTITION#5,
    T4.RECID                                AS RECID#5,

    -- -------------------------------------------------------------------------
    -- T5: Sales responsible (HCMWORKER — via T2.WORKERSALESRESPONSIBLE)
    -- -------------------------------------------------------------------------
    T5.PERSONNELNUMBER                      AS SALESORDERRESPONSIBLEPERSONNELNUMBER,
    T5.RECVERSION                           AS RECVERSION#3,
    T5.PARTITION                            AS PARTITION#3,
    T5.RECID                                AS RECID#3

FROM CUSTINVOICEJOUR T1

    -- Originating sales order (optional — free-text invoices have no SALESID)
    LEFT OUTER JOIN SALESTABLE T2
        ON  T1.SALESID    = T2.SALESID
        AND T1.DATAAREAID = T2.DATAAREAID
        AND T1.PARTITION  = T2.PARTITION

    -- Invoice postal address (linked by address record ID, not location ID)
    LEFT OUTER JOIN LOGISTICSPOSTALADDRESSBASEENTITY T3
        ON  T1.INVOICEPOSTALADDRESS = T3.ADDRESSRECID
        AND T1.PARTITION            = T3.PARTITION

    -- Pre-aggregated tax total per invoice
    LEFT OUTER JOIN CUSTINVOICEJOURTOTALTAXAMOUNTVIEW T4
        ON  T1.RECID      = T4.CUSTINVOICEJOURRECID
        AND T1.DATAAREAID = T4.DATAAREAID
        AND T1.PARTITION  = T4.PARTITION

    -- Sales responsible person (via sales order → HCM worker)
    LEFT OUTER JOIN HCMWORKER T5
        ON  T2.WORKERSALESRESPONSIBLE = T5.RECID
        AND T2.PARTITION              = T5.PARTITION;

GO
