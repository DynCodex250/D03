-- =============================================================================
-- SQL-Äquivalent zu prepare_poductDefaultordersettings()
--
-- Quelle: InventProductSpecificOrderSettingsV3Entity
--
-- Logik:
--   1. Felder normalisieren (LOWER + ISNULL für Variantendimensionen)
--   2. ID   = ITEMNUMBER-CONFIG-COLOR-SIZE-STYLE-VERSION-DATAAREAID-PARTITION
--   3. KEY  = ITEMNUMBER + SITE + CONFIG + COLOR + SIZE + STYLE + VERSION + DATAAREAID + PARTITION
--   4. KEY2 = ITEMNUMBER + SITE + CONFIG + COLOR + SIZE + STYLE + VERSION + RANK
--             (mandantenübergreifender Abgleichschlüssel, ohne DATAAREAID/PARTITION)
--   5. is_duplicate  = zweite+ Zeile je KEY  (entspricht R duplicated(KEY))
--   6. is_duplicate2 = zweite+ Zeile je KEY2 (entspricht R duplicated(KEY2))
--
-- Parameter: DATAAREAID-Filter in CTE "src" anpassen
--   Alle Mandanten : WHERE DATAAREAID IN ('0360', '0800', '0900')
--   Nur Ziel       : WHERE DATAAREAID = '0360'
--   Nur Quelle     : WHERE DATAAREAID IN ('0800', '0900')
-- =============================================================================

WITH src AS (

    -- Schritt 1: Felder selektieren und normalisieren
    SELECT
        LOWER(ITEMNUMBER)                                AS ITEMNUMBER,
        ISNULL(OPERATIONALSITEID,              '')       AS OPERATIONALSITEID,
        LOWER(ISNULL(PRODUCTCONFIGURATIONID,   ''))      AS PRODUCTCONFIGURATIONID,
        LOWER(ISNULL(PRODUCTSIZEID,            ''))      AS PRODUCTSIZEID,
        LOWER(ISNULL(PRODUCTCOLORID,           ''))      AS PRODUCTCOLORID,
        LOWER(ISNULL(PRODUCTSTYLEID,           ''))      AS PRODUCTSTYLEID,
        LOWER(ISNULL(PRODUCTVERSIONID,         ''))      AS PRODUCTVERSIONID,
        CAST(ORDERSETTINGSRANK AS VARCHAR(20))           AS ORDERSETTINGSRANK,
        ISSALESLEADTIMEOVERRIDDEN,
        PROCUREMENTLEADTIMEDAYS,
        SALESLEADTIMEDAYS,
        ARESALESDEFAULTORDERSETTINGSOVERRIDDEN,
        SALESORDERPROMISINGMETHOD,
        SALESATPTIMEFENCEDAYS,
        PROCUREMENTWAREHOUSEID,
        DATAAREAID,
        PARTITION
    FROM InventProductSpecificOrderSettingsV3Entity WITH (NOLOCK)
    WHERE DATAAREAID IN ('0360', '0800', '0900')   -- << hier anpassen

),
with_keys AS (

    -- Schritt 2: Schlüssel berechnen
    SELECT
        *,

        -- ID: Varianten-Schlüssel inkl. Mandant/Partition (Trennzeichen "-")
        ITEMNUMBER + '-'
            + PRODUCTCONFIGURATIONID         + '-'
            + PRODUCTCOLORID                 + '-'
            + PRODUCTSIZEID                  + '-'
            + PRODUCTSTYLEID                 + '-'
            + PRODUCTVERSIONID               + '-'
            + DATAAREAID                     + '-'
            + CAST(PARTITION AS NVARCHAR(20))            AS ID,

        -- KEY: Standortbezogener Schlüssel inkl. Mandant/Partition (kein Trennzeichen)
        ITEMNUMBER
            + OPERATIONALSITEID
            + PRODUCTCONFIGURATIONID
            + PRODUCTCOLORID
            + PRODUCTSIZEID
            + PRODUCTSTYLEID
            + PRODUCTVERSIONID
            + DATAAREAID
            + CAST(PARTITION AS NVARCHAR(20))            AS [KEY],

        -- KEY2: Mandantenübergreifender Abgleichschlüssel inkl. Rank (kein DATAAREAID/PARTITION)
        --       Wird für den Matching-Join 0800/0900 → 0360 verwendet
        ITEMNUMBER
            + OPERATIONALSITEID
            + PRODUCTCONFIGURATIONID
            + PRODUCTCOLORID
            + PRODUCTSIZEID
            + PRODUCTSTYLEID
            + PRODUCTVERSIONID
            + ORDERSETTINGSRANK                          AS KEY2

    FROM src

)

-- Schritt 3: Duplikat-Flags
SELECT
    ITEMNUMBER,
    OPERATIONALSITEID,
    PRODUCTCONFIGURATIONID,
    PRODUCTSIZEID,
    PRODUCTCOLORID,
    PRODUCTSTYLEID,
    PRODUCTVERSIONID,
    ORDERSETTINGSRANK,
    ISSALESLEADTIMEOVERRIDDEN,
    PROCUREMENTLEADTIMEDAYS,
    SALESLEADTIMEDAYS,
    ARESALESDEFAULTORDERSETTINGSOVERRIDDEN,
    SALESORDERPROMISINGMETHOD,
    SALESATPTIMEFENCEDAYS,
    PROCUREMENTWAREHOUSEID,
    DATAAREAID,
    PARTITION,
    ID,
    [KEY],
    KEY2,

    -- is_duplicate: TRUE für 2.+ Vorkommen von KEY
    CASE WHEN ROW_NUMBER() OVER (
        PARTITION BY [KEY]
        ORDER BY (SELECT NULL)
    ) > 1 THEN 1 ELSE 0 END                             AS is_duplicate,

    -- is_duplicate2: TRUE für 2.+ Vorkommen von KEY2
    CASE WHEN ROW_NUMBER() OVER (
        PARTITION BY KEY2
        ORDER BY (SELECT NULL)
    ) > 1 THEN 1 ELSE 0 END                             AS is_duplicate2

FROM with_keys
