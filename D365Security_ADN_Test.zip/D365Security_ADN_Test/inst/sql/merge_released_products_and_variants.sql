-- =============================================================================
-- SQL-Äquivalent zu merge_released_products_and_variants()
--
-- Kombiniert EcoResReleasedProductVariantV2Entity (Variantenebene)
-- und EcoResReleasedProductV2Entity (Masterebene) zu einer vollständigen
-- Produktsicht.
--
-- Logik:
--   1. VARIANT-Zeilen: Varianten + Dimensionsgruppen vom Master (LEFT JOIN)
--   2. MASTER-Zeilen:  Master-Datensätze mit leeren Variantendimensionen
--   → UNION ALL beider Mengen
--
-- Schlüsselfeld ID entspricht dem R-Schlüssel aus prepare_poductDefaultordersettings():
--   paste(ITEMNUMBER, CONFIGID, COLORID, SIZEID, STYLEID, VERSIONID, sep = "-")
--
-- Parameter: DATAAREAID-Filter anpassen
-- =============================================================================

SELECT
    -- Identifikation
    LOWER(v.ITEMNUMBER)                                AS ITEMNUMBER,
    p.PRODUCTNUMBER,
    v.PRODUCTMASTERNUMBER,

    -- Lifecycle State: Variantenebene hat Vorrang vor Masterebene
    COALESCE(
        v.PRODUCTLIFECYCLESTATEID,
        p.PRODUCTLIFECYCLESTATEID
    )                                                  AS PRODUCTLIFECYCLESTATEID,

    -- Dimension Groups: immer vom Produktmaster
    p.PRODUCTDIMENSIONGROUPNAME,
    p.STORAGEDIMENSIONGROUPNAME,
    p.TRACKINGDIMENSIONGROUPNAME,

    -- Variantendimensionen (normalisiert)
    LOWER(ISNULL(v.PRODUCTCONFIGURATIONID, ''))        AS PRODUCTCONFIGURATIONID,
    LOWER(ISNULL(v.PRODUCTSIZEID,          ''))        AS PRODUCTSIZEID,
    LOWER(ISNULL(v.PRODUCTCOLORID,         ''))        AS PRODUCTCOLORID,
    LOWER(ISNULL(v.PRODUCTSTYLEID,         ''))        AS PRODUCTSTYLEID,
    LOWER(ISNULL(v.PRODUCTVERSIONID,       ''))        AS PRODUCTVERSIONID,
    v.WIBURETAILVARIANTID,

    'VARIANT'                                          AS LEVEL,

    -- Zusammengesetzter Schlüssel
    LOWER(v.ITEMNUMBER)                          + '-'
        + LOWER(ISNULL(v.PRODUCTCONFIGURATIONID, '')) + '-'
        + LOWER(ISNULL(v.PRODUCTCOLORID,         '')) + '-'
        + LOWER(ISNULL(v.PRODUCTSIZEID,          '')) + '-'
        + LOWER(ISNULL(v.PRODUCTSTYLEID,         '')) + '-'
        + LOWER(ISNULL(v.PRODUCTVERSIONID,       '')) AS ID,

    v.DATAAREAID,
    v.PARTITION

FROM EcoResReleasedProductVariantV2Entity v WITH (NOLOCK)
    LEFT JOIN EcoResReleasedProductV2Entity p WITH (NOLOCK)
        ON  p.ITEMNUMBER = v.ITEMNUMBER
        AND p.DATAAREAID = v.DATAAREAID
        AND p.PARTITION  = v.PARTITION

WHERE v.DATAAREAID IN ('0360', '0800', '0900')

UNION ALL

-- Master-Datensätze ohne Variantendimensionen
SELECT
    LOWER(p.ITEMNUMBER)                                AS ITEMNUMBER,
    p.PRODUCTNUMBER,
    NULL                                               AS PRODUCTMASTERNUMBER,
    p.PRODUCTLIFECYCLESTATEID,
    p.PRODUCTDIMENSIONGROUPNAME,
    p.STORAGEDIMENSIONGROUPNAME,
    p.TRACKINGDIMENSIONGROUPNAME,
    ''                                                 AS PRODUCTCONFIGURATIONID,
    ''                                                 AS PRODUCTSIZEID,
    ''                                                 AS PRODUCTCOLORID,
    ''                                                 AS PRODUCTSTYLEID,
    ''                                                 AS PRODUCTVERSIONID,
    NULL                                               AS WIBURETAILVARIANTID,
    'MASTER'                                           AS LEVEL,
    LOWER(p.ITEMNUMBER) + '-' + '-' + '-' + '-' + '-' AS ID,

    p.DATAAREAID,
    p.PARTITION

FROM EcoResReleasedProductV2Entity p WITH (NOLOCK)

WHERE p.DATAAREAID IN ('0360', '0800', '0900')
