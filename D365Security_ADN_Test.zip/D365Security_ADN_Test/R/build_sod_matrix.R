#' Apply the catalog of segregation of duties to the roles of an environment
#'
#' Takes the catalog of \code{\link{read_sod_catalog}} and the license graph of
#' an environment (\code{\link{read_license_graph}}) and works out which
#' functions the roles hold through their duties, which rules apply, and which
#' roles, and with \code{assignments} which users, hold both functions of a
#' rule. The result is the content of the deliverable D07; see
#' \code{\link{export_sod_matrix}}.
#'
#' @details
#'
#' **Duties.** A role holds a function when it holds one of the function's
#' duties, also through a sub-role: the license graph lists the duties of the
#' sub-roles under the role. Duty names are compared without regard to
#' capitals. Only duties count; a privilege given to a role directly, or the
#' same privilege in another duty, is not seen, as in the check of D365
#' itself.
#'
#' **Roles checked.** All roles of the license graph, or those whose
#' identifier or name matches \code{role_pattern}. With \code{assignments},
#' only the roles that users hold; a user is checked over all of their roles
#' among them, so a conflict can come from two roles of which neither holds
#' both functions. Only users with at least one checked role count as checked.
#'
#' **Conflict.** A role or user is in conflict with a rule through two
#' different duties, one of each function. A duty that the catalog lists in
#' both functions is no conflict on its own.
#'
#' **Rules.** A rule applies (\code{RELEVANT}) when a checked role holds the
#' first function and a checked role holds the second. \code{ALLE} as second
#' function stands for every function of another area. The pairs of duties of
#' the rules that apply, with the severity of D365 (\code{High},
#' \code{Medium}, \code{Low}), can be entered under System administration >
#' Security > Segregation of duties > Segregation of duties rules.
#'
#' @param catalog
#' Result of \code{\link{read_sod_catalog}}.
#'
#' @param graph
#' License graph with the columns \code{ROLEIDENTIFIER}, \code{ROLENAME} and
#' \code{DUTYIDENTIFIER} (\code{DUTYNAME} optional), as
#' \code{\link{read_license_graph}} returns it.
#'
#' @param assignments
#' Optional. Roles of the users: \code{USERID} and \code{ROLEIDENTIFIER} (or
#' \code{SECURITYROLEIDENTIFIER}), the role by identifier or name, for example
#' the detailed PPAC report of \code{\link{read_ppac_license_detail}} or
#' \code{\link{get_sql_user_role_assignments}}. A role the graph lacks is
#' left out, with a warning.
#'
#' @param role_pattern
#' Optional regular expression on role identifier and name, for example
#' \code{"WIBU"} for the roles of the customer. \code{NULL} = all roles.
#'
#' @return
#' A list:
#' \describe{
#'   \item{\code{Functions}}{The functions of the catalog with \code{DUTIES},
#'     \code{DUTIES_FOUND} (in the graph), \code{DUTIES_ACTIVE} (held by a
#'     checked role), \code{ROLES}, \code{USERS} (\code{NA} without
#'     assignments) and \code{ACTIVE}.}
#'   \item{\code{Duties}}{The duties of the catalog with \code{DUTY_NAME},
#'     \code{FOUND} and \code{ROLES}.}
#'   \item{\code{DutyRoles}}{One row per duty and checked role that holds it.}
#'   \item{\code{Rules}}{The rules with \code{ACTIVE_1}, \code{ACTIVE_2},
#'     \code{RELEVANT}, \code{REASON} (\code{NA} when it applies;
#'     \code{NO_DUTY_IN_CATALOG} when a function has no duty in the catalog,
#'     so the rule cannot be checked; else \code{FUNCTION_1_INACTIVE},
#'     \code{FUNCTION_2_INACTIVE} or \code{BOTH_INACTIVE}),
#'     \code{ROLES_IN_CONFLICT} and \code{USERS_IN_CONFLICT}.}
#'   \item{\code{RoleConflicts}}{\code{RULE_ID}, \code{ROLEIDENTIFIER},
#'     \code{ROLENAME}, \code{DUTIES_1}, \code{DUTIES_2}.}
#'   \item{\code{UserConflicts}}{\code{RULE_ID}, \code{USERID},
#'     \code{ROLES_1}, \code{ROLES_2}, \code{SAME_ROLE} (one role holds
#'     both); empty without assignments.}
#'   \item{\code{D365Rules}}{\code{RULE_ID}, \code{FIRST_DUTY},
#'     \code{SECOND_DUTY}, \code{FUNCTION_1}, \code{FUNCTION_2},
#'     \code{SEVERITY}, \code{RISK}, \code{MITIGATION}.}
#'   \item{\code{Matrix}}{The active functions against each other; a cell
#'     holds the rules that apply to the pair.}
#'   \item{\code{Check}}{The counts in one row.}
#' }
#'
#' @examples
#' \dontrun{
#'
#' catalog <- read_sod_catalog("Data/Documentation/SoD_Katalog.xlsx")
#' graph   <- read_license_graph(con = cnn)
#' detail  <- read_ppac_license_detail("<...>_Detailed_Report_pseudonymized.csv", environment = "wibu-produktiv")
#' sod     <- build_sod_matrix(catalog, graph, assignments = detail)
#' sod$Rules[sod$Rules$RELEVANT, ]
#'
#' }
#'
#' @seealso
#' \code{\link{read_sod_catalog}}
#' \code{\link{export_sod_matrix}}
#'
#' @export
build_sod_matrix <- function(catalog, graph, assignments = NULL, role_pattern = NULL) {

  .check_sod_matrix_inputs(catalog, graph, assignments, role_pattern)
  role_duties  <- .sod_role_duties(graph)
  user_roles   <- if (is.null(assignments)) NULL else .sod_user_roles(assignments, graph)
  scope        <- .sod_scope(role_duties, user_roles, role_pattern)
  holders      <- .sod_holders(catalog$Duties, role_duties[role_duties$ROLE_KEY %in% scope, ])
  user_holders <- if (is.null(user_roles)) NULL else
    dplyr::inner_join(user_roles[user_roles$ROLE_KEY %in% scope, ], holders, by = "ROLE_KEY", relationship = "many-to-many")

  functions      <- .sod_functions(catalog, role_duties, holders, user_holders)
  sets           <- .sod_rule_sets(catalog)
  role_conflicts <- .sod_role_conflicts(sets, catalog$Rules, holders)
  user_conflicts <- .sod_user_conflicts(sets, catalog$Rules, user_holders)
  rules          <- .sod_rules(catalog$Rules, sets, functions, role_conflicts, if (is.null(user_holders)) NULL else user_conflicts)

  result <- list(
    Functions     = functions,
    Duties        = .sod_duties(catalog, role_duties, holders),
    DutyRoles     = dplyr::arrange(dplyr::distinct(holders, FUNCTION_ID, DUTY, ROLEIDENTIFIER, ROLENAME), FUNCTION_ID, DUTY, ROLENAME),
    Rules         = rules,
    RoleConflicts = role_conflicts,
    UserConflicts = user_conflicts,
    D365Rules     = .sod_d365_rules(rules, sets, holders),
    Matrix        = .sod_matrix(functions, rules, sets)
  )
  result$Check <- .sod_check(result, length(scope), user_roles[user_roles$ROLE_KEY %in% scope, ], role_pattern)
  message(.sod_message(result$Check))
  result
}

.SOD_D365_SEVERITY <- c(hoch = "High", mittel = "Medium", niedrig = "Low")

.check_sod_matrix_inputs <- function(catalog, graph, assignments, role_pattern) {
  if (!is.list(catalog) || !all(c("Functions", "Duties", "Rules") %in% names(catalog))) {
    stop("catalog must be the result of read_sod_catalog().", call. = FALSE)
  }
  missing <- setdiff(c("ROLEIDENTIFIER", "ROLENAME", "DUTYIDENTIFIER"), names(graph))
  if (!is.data.frame(graph) || length(missing) > 0L) {
    stop("The license graph lacks the column", if (length(missing) == 1L) "" else "s", " ",
         paste(missing, collapse = .LIST_SEPARATOR), ".", call. = FALSE)
  }
  if (!is.null(assignments) &&
      (!is.data.frame(assignments) || !"USERID" %in% names(assignments) ||
       !any(c("ROLEIDENTIFIER", "SECURITYROLEIDENTIFIER") %in% names(assignments)))) {
    stop("assignments need the columns USERID and ROLEIDENTIFIER (or SECURITYROLEIDENTIFIER).", call. = FALSE)
  }
  if (!is.null(role_pattern) &&
      (!.is_single_string(role_pattern) || inherits(try(grepl(role_pattern, ""), silent = TRUE), "try-error"))) {
    stop("role_pattern must be one regular expression, or NULL for all roles.", call. = FALSE)
  }
  invisible(TRUE)
}

# One row per role and duty, in the spelling met first.
.sod_role_duties <- function(graph) {
  name <- if ("DUTYNAME" %in% names(graph)) as.character(graph$DUTYNAME) else NA_character_
  rows <- tibble::tibble(ROLEIDENTIFIER = as.character(graph$ROLEIDENTIFIER), ROLENAME = as.character(graph$ROLENAME),
                         DUTY_GRAPH = as.character(graph$DUTYIDENTIFIER), DUTY_NAME_GRAPH = name)
  rows <- rows[!.is_blank(rows$ROLEIDENTIFIER) & !.is_blank(rows$DUTY_GRAPH), ]
  rows$ROLE_KEY <- .identifier_key(rows$ROLEIDENTIFIER)
  rows$DUTY_KEY <- .identifier_key(rows$DUTY_GRAPH)
  rows[!duplicated(rows[, c("ROLE_KEY", "DUTY_KEY")]), ]
}

.sod_user_roles <- function(assignments, graph) {
  role  <- if ("ROLEIDENTIFIER" %in% names(assignments)) assignments$ROLEIDENTIFIER else assignments$SECURITYROLEIDENTIFIER
  rows  <- tibble::tibble(USERID = as.character(assignments$USERID), ROLE = as.character(role))
  rows  <- rows[!.is_blank(rows$USERID) & !.is_blank(rows$ROLE), ]
  if (nrow(rows) == 0L) {
    stop("assignments has no rows with a user and a role: no user to check. Check the environment of the report, ",
         "or leave assignments out.", call. = FALSE)
  }
  roles <- dplyr::distinct(tibble::tibble(ROLE = rows$ROLE, ROLE_KEY = .identifier_key(rows$ROLE)))
  found <- suppressWarnings(.graph_roles_of(roles, graph))
  if (length(found$missing) > 0L) {
    warning(sprintf("%d role%s of the assignments %s not in the license graph: %s. Their users are checked without them.",
                    length(found$missing), if (length(found$missing) == 1L) "" else "s",
                    if (length(found$missing) == 1L) "is" else "are", paste(found$missing, collapse = .LIST_SEPARATOR)),
            call. = FALSE)
  }
  several <- sort(unique(found$map$ROLE[duplicated(found$map$ROLE)]))
  if (length(several) > 0L) {
    warning("Role names of the assignments that stand for several roles of the license graph: ",
            paste(several, collapse = .LIST_SEPARATOR), ". Their users are checked with all of these roles.", call. = FALSE)
  }
  joined <- dplyr::inner_join(rows, found$map, by = "ROLE", relationship = "many-to-many")
  dplyr::distinct(tibble::tibble(USERID = joined$USERID, ROLE_KEY = joined$GRAPH_ROLE_KEY))
}

.sod_scope <- function(role_duties, user_roles, role_pattern) {
  roles <- dplyr::distinct(role_duties, ROLE_KEY, ROLEIDENTIFIER, ROLENAME)
  keep  <- rep(TRUE, nrow(roles))
  if (!is.null(role_pattern)) {
    keep <- grepl(role_pattern, roles$ROLEIDENTIFIER, ignore.case = TRUE) | grepl(role_pattern, roles$ROLENAME, ignore.case = TRUE)
  }
  if (!is.null(user_roles)) keep <- keep & roles$ROLE_KEY %in% user_roles$ROLE_KEY
  unique(roles$ROLE_KEY[keep])
}

# The catalog duties held by the checked roles, in the spelling of the catalog.
.sod_holders <- function(duties, role_duties) {
  catalog <- tibble::tibble(FUNCTION_ID = duties$FUNCTION_ID, DUTY = duties$DUTY, DUTY_KEY = .identifier_key(duties$DUTY))
  joined  <- dplyr::inner_join(catalog, role_duties, by = "DUTY_KEY", relationship = "many-to-many")
  dplyr::distinct(joined, FUNCTION_ID, DUTY, DUTY_KEY, ROLE_KEY, ROLEIDENTIFIER, ROLENAME)
}

.count_per <- function(ids, keys, values) {
  vapply(ids, function(id) length(unique(values[keys == id])), integer(1), USE.NAMES = FALSE)
}

.sod_functions <- function(catalog, role_duties, holders, user_holders) {
  duties <- catalog$Duties
  found  <- .identifier_key(duties$DUTY) %in% role_duties$DUTY_KEY
  ids    <- catalog$Functions$FUNCTION_ID
  result <- catalog$Functions
  result$DUTIES        <- .count_per(ids, duties$FUNCTION_ID, duties$DUTY)
  result$DUTIES_FOUND  <- .count_per(ids, duties$FUNCTION_ID[found], duties$DUTY[found])
  result$DUTIES_ACTIVE <- .count_per(ids, holders$FUNCTION_ID, holders$DUTY_KEY)
  result$ROLES         <- .count_per(ids, holders$FUNCTION_ID, holders$ROLE_KEY)
  result$USERS         <- if (is.null(user_holders)) NA_integer_ else .count_per(ids, user_holders$FUNCTION_ID, user_holders$USERID)
  result$ACTIVE        <- result$DUTIES_ACTIVE > 0L
  result
}

.sod_duties <- function(catalog, role_duties, holders) {
  duties <- catalog$Duties
  key    <- .identifier_key(duties$DUTY)
  graph_name <- role_duties$DUTY_NAME_GRAPH[match(key, role_duties$DUTY_KEY)]
  functions  <- catalog$Functions
  tibble::tibble(
    FUNCTION_ID = duties$FUNCTION_ID,
    AREA        = functions$AREA[match(duties$FUNCTION_ID, functions$FUNCTION_ID)],
    FUNCTION    = functions$FUNCTION[match(duties$FUNCTION_ID, functions$FUNCTION_ID)],
    DUTY        = duties$DUTY,
    DUTY_NAME   = dplyr::coalesce(duties$DUTY_NAME, graph_name),
    FOUND       = key %in% role_duties$DUTY_KEY,
    ROLES       = .count_per(key, holders$DUTY_KEY, holders$ROLE_KEY)
  )
}

# The functions of each rule: the first, and the second or, for ALLE, every function of another area.
.sod_rule_sets <- function(catalog) {
  functions <- catalog$Functions
  rules     <- catalog$Rules
  lapply(seq_len(nrow(rules)), function(i) {
    first  <- rules$FUNCTION_1[[i]]
    second <- rules$FUNCTION_2[[i]]
    if (identical(second, .SOD_ALL)) {
      area   <- functions$AREA[functions$FUNCTION_ID == first]
      second <- functions$FUNCTION_ID[!functions$AREA %in% area & functions$FUNCTION_ID != first]
    }
    list(first = first, second = second)
  })
}

# The holders (roles or users, by key) of both functions of each rule, through two
# different duties: a duty that sits in both functions is no conflict on its own.
.sod_pairs <- function(sets, holders, key) {
  rows <- lapply(seq_along(sets), function(i) {
    one  <- holders[holders$FUNCTION_ID == sets[[i]]$first, ]
    two  <- holders[holders$FUNCTION_ID %in% sets[[i]]$second, ]
    keys <- sort(intersect(one[[key]], two[[key]]), method = "radix")
    pairs <- lapply(keys, function(k) list(rule = i, one = one[one[[key]] == k, ], two = two[two[[key]] == k, ]))
    Filter(function(p) length(unique(c(p$one$DUTY_KEY, p$two$DUTY_KEY))) > 1L, pairs)
  })
  unlist(rows, recursive = FALSE)
}

.sod_role_conflicts <- function(sets, rules, holders) {
  pairs <- .sod_pairs(sets, holders, "ROLE_KEY")
  if (length(pairs) == 0L) {
    return(tibble::tibble(RULE_ID = character(), ROLEIDENTIFIER = character(), ROLENAME = character(),
                          DUTIES_1 = character(), DUTIES_2 = character()))
  }
  dplyr::bind_rows(lapply(pairs, function(p) tibble::tibble(
    RULE_ID        = rules$RULE_ID[[p$rule]],
    ROLEIDENTIFIER = p$one$ROLEIDENTIFIER[[1]],
    ROLENAME       = p$one$ROLENAME[[1]],
    DUTIES_1       = .sorted_list(p$one$DUTY),
    DUTIES_2       = .sorted_list(p$two$DUTY)
  )))
}

.sod_user_conflicts <- function(sets, rules, user_holders) {
  empty <- tibble::tibble(RULE_ID = character(), USERID = character(), ROLES_1 = character(), ROLES_2 = character(),
                          SAME_ROLE = logical())
  pairs <- if (is.null(user_holders)) list() else .sod_pairs(sets, user_holders, "USERID")
  if (length(pairs) == 0L) return(empty)
  dplyr::bind_rows(lapply(pairs, function(p) tibble::tibble(
    RULE_ID   = rules$RULE_ID[[p$rule]],
    USERID    = p$one$USERID[[1]],
    ROLES_1   = .sorted_list(p$one$ROLENAME),
    ROLES_2   = .sorted_list(p$two$ROLENAME),
    SAME_ROLE = length(intersect(p$one$ROLE_KEY, p$two$ROLE_KEY)) > 0L
  )))
}

.sod_rules <- function(rules, sets, functions, role_conflicts, user_conflicts) {
  active    <- stats::setNames(functions$ACTIVE, functions$FUNCTION_ID)
  has_duty  <- stats::setNames(functions$DUTIES > 0L, functions$FUNCTION_ID)
  active_1  <- vapply(sets, function(s) isTRUE(active[[s$first]]), logical(1))
  active_2  <- vapply(sets, function(s) any(active[s$second]), logical(1))
  checkable <- vapply(sets, function(s) isTRUE(has_duty[[s$first]]) && any(has_duty[s$second]), logical(1))
  result    <- rules
  result$ACTIVE_1 <- active_1
  result$ACTIVE_2 <- active_2
  result$RELEVANT <- active_1 & active_2
  # a function without any duty in the catalog cannot be found in a role: the rule cannot be checked
  result$REASON   <- ifelse(result$RELEVANT, NA_character_,
                     ifelse(!checkable, "NO_DUTY_IN_CATALOG",
                     ifelse(!active_1 & !active_2, "BOTH_INACTIVE",
                     ifelse(!active_1, "FUNCTION_1_INACTIVE", "FUNCTION_2_INACTIVE"))))
  result$ROLES_IN_CONFLICT <- .count_per(rules$RULE_ID, role_conflicts$RULE_ID, role_conflicts$ROLEIDENTIFIER)
  result$USERS_IN_CONFLICT <- if (is.null(user_conflicts)) NA_integer_ else
    .count_per(rules$RULE_ID, user_conflicts$RULE_ID, user_conflicts$USERID)
  result
}

# The duty pairs of the rules that apply, for the rules of D365.
.sod_d365_rules <- function(rules, sets, holders) {
  held <- dplyr::distinct(holders, FUNCTION_ID, DUTY, DUTY_KEY)
  rows <- lapply(which(rules$RELEVANT), function(i) {
    one   <- held[held$FUNCTION_ID == sets[[i]]$first, ]
    two   <- held[held$FUNCTION_ID %in% sets[[i]]$second, ]
    pairs <- expand.grid(a = seq_len(nrow(one)), b = seq_len(nrow(two)))
    pairs <- pairs[one$DUTY_KEY[pairs$a] != two$DUTY_KEY[pairs$b], , drop = FALSE]
    tibble::tibble(
      RULE_ID     = rules$RULE_ID[[i]],
      FIRST_DUTY  = one$DUTY[pairs$a],
      SECOND_DUTY = two$DUTY[pairs$b],
      FUNCTION_1  = one$FUNCTION_ID[pairs$a],
      FUNCTION_2  = two$FUNCTION_ID[pairs$b],
      SEVERITY    = unname(.SOD_D365_SEVERITY[rules$SEVERITY[[i]]]),
      RISK        = rules$RISK[[i]],
      MITIGATION  = rules$CONTROL[[i]]
    )
  })
  dplyr::distinct(dplyr::bind_rows(c(list(tibble::tibble(
    RULE_ID = character(), FIRST_DUTY = character(), SECOND_DUTY = character(), FUNCTION_1 = character(),
    FUNCTION_2 = character(), SEVERITY = character(), RISK = character(), MITIGATION = character())), rows)),
    RULE_ID, FIRST_DUTY, SECOND_DUTY, .keep_all = TRUE)
}

.sod_matrix <- function(functions, rules, sets) {
  ids   <- functions$FUNCTION_ID[functions$ACTIVE]
  cells <- matrix("", length(ids), length(ids), dimnames = list(ids, ids))
  for (i in which(rules$RELEVANT)) {
    first <- sets[[i]]$first
    for (second in intersect(sets[[i]]$second, ids)) {
      for (cell in list(c(first, second), c(second, first))) {
        cells[cell[[1]], cell[[2]]] <- paste0(cells[cell[[1]], cell[[2]]], if (nzchar(cells[cell[[1]], cell[[2]]])) ", " else "",
                                              rules$RULE_ID[[i]])
      }
    }
  }
  dplyr::bind_cols(
    tibble::tibble(FUNCTION_ID = ids, FUNCTION = functions$FUNCTION[functions$ACTIVE]),
    tibble::as_tibble(cells, .name_repair = "minimal")
  )
}

.sod_check <- function(result, roles, user_roles, role_pattern) {
  tibble::tibble(
    FUNCTIONS         = nrow(result$Functions),
    FUNCTIONS_ACTIVE  = sum(result$Functions$ACTIVE),
    DUTIES            = nrow(result$Duties),
    DUTIES_FOUND      = sum(result$Duties$FOUND),
    DUTIES_ACTIVE     = sum(result$Duties$ROLES > 0L),
    RULES             = nrow(result$Rules),
    RULES_RELEVANT    = sum(result$Rules$RELEVANT),
    RULES_NOT_CHECKABLE = sum(result$Rules$REASON %in% "NO_DUTY_IN_CATALOG"),
    ROLES             = roles,
    ROLES_IN_CONFLICT = length(unique(result$RoleConflicts$ROLEIDENTIFIER)),
    USERS             = if (is.null(user_roles)) NA_integer_ else length(unique(user_roles$USERID)),
    USERS_IN_CONFLICT = if (is.null(user_roles)) NA_integer_ else length(unique(result$UserConflicts$USERID)),
    ROLE_PATTERN      = if (is.null(role_pattern)) NA_character_ else role_pattern
  )
}

.sod_message <- function(check) {
  users <- if (is.na(check$USERS)) "" else sprintf(", %d of %d users", check$USERS_IN_CONFLICT, check$USERS)
  sprintf("SoD matrix: %d of %d functions held by %d checked roles; %d of %d rules apply; in conflict: %d roles%s.",
          check$FUNCTIONS_ACTIVE, check$FUNCTIONS, check$ROLES, check$RULES_RELEVANT, check$RULES, check$ROLES_IN_CONFLICT, users)
}
