#' Create the role file for the import in the browser
#'
#' Writes roles and privileges in the format D365 exports and imports in the
#' browser: as the security governance writes it, or as the security
#' configuration writes it.
#'
#' @details
#'
#' **Where it comes from and goes to.** Two places in D365 write this file:
#' Security governance > Manage security process roles, export with the type
#' "Security configuration"; and System administration > Security > Security
#' configuration, Data > Export. The security configuration imports it with
#' Data > Import. The two exports differ only in how they write an empty
#' element: the security governance as \code{<Forms />}, the security
#' configuration as \code{<Forms/>}. \code{format} chooses which one the file
#' follows, character for character: one line, no XML declaration, no final
#' line break, UTF-8.
#'
#' **Lists.** The envelope \code{SecurityCustomizationData} holds one list each
#' for roles, duties and privileges; each list holds the changed, the disabled
#' and the new objects. A role or privilege is written in the layout of its
#' AOT file (\code{\link{create_d365fo_role_xml}}), into the list of new or of
#' changed objects. A changed role holds the whole role, not only the change:
#' the export of D365 does the same. A new privilege gets an empty
#' \code{<Forms/>} in every entry point without one and an empty
#' \code{<FormControlOverrides/>} at its end, as D365 writes them. The lists
#' of duties stay empty.
#'
#' **Names.** D365 gives an object created in the browser a GUID as name and
#' the typed name as label. This function writes the names it is given, for
#' example \code{_WIBU_VERKAUF_INNENDIENST_SCM}. Whether the import accepts a
#' readable name for a new object is still to be tested in ADN.
#'
#' @param new_roles,changed_roles
#' One role, or a list of roles, as \code{\link{convert_sql_to_security_role}}
#' returns them: new roles, and existing roles in their whole new version.
#' Each role is a list with:
#' \describe{
#'   \item{\code{role_name}}{Name of the role: an AOT name or a GUID.}
#'   \item{\code{role_label}}{Label of the role.}
#'   \item{\code{direct_access_permissions}}{Data frame of the direct access
#'     permissions, as \code{convert_sql_to_security_role()} builds it; it may
#'     have no rows, but needs the column \code{Ebene}.}
#'   \item{\code{duties}, \code{privileges}, \code{subroles}}{Names, each a
#'     character vector; empty is allowed.}
#'   \item{\code{role_description}}{Optional; left out when empty.}
#' }
#' For example:
#' \preformatted{
#' list(
#'   role_name  = "_WIBU_Verkauf_Innendienst_SCM",
#'   role_label = "_WIBU Verkauf Innendienst SCM",
#'   direct_access_permissions = data.frame(Ebene = character()),
#'   duties     = c("CASECASEPROGRESSINQUIRE", "MCRSALESMAINTAIN"),
#'   privileges = "SALESQUOTATIONTABLEDETAILSVIEW",
#'   subroles   = "_WIBU_ARTIKELSTAMMPFLEGE"
#' )
#' }
#'
#' @param new_privileges
#' One privilege, or a list of privileges, each an \code{AxSecurityPrivilege}
#' document of \code{xml2}: as \code{\link{build_license_roles}} writes it, or
#' read from an AOT privilege file with \code{xml2::read_xml()}, for example
#' \preformatted{
#' xml2::read_xml("AxSecurityPrivilege/SalesTableMaintain_SCM.xml")
#' }
#' The documents stay as they are.
#'
#' @param output_file
#' Path of the file to write. \code{NULL} = only return the text.
#'
#' @param format
#' \code{"configuration"} (default) = as the security configuration exports
#' it; \code{"governance"} = as the security governance exports it.
#'
#' @return
#' The XML as one string, for example (shortened):
#' \preformatted{
#' <SecurityCustomizationData xmlns="http://schemas.datacontract.org/..." ...>
#'   ...<_x003C_NewObjectList_x003E_k__BackingField>
#'     <AxSecurityRole xmlns=""><Name>_WIBU_Verkauf_Innendienst_SCM</Name>...
#' }
#' (without the line breaks). With \code{output_file}, the same text is also
#' written to that file.
#'
#' @examples
#' \dontrun{
#'
#' rows <- load_sql_security_role_objects_detailed(cnn, "_WIBU_VERKAUF_INNENDIENST_LEITUNG")
#' role <- convert_sql_to_security_role(rows)
#'
#' # The whole role as a change of the existing AOT role
#' create_d365fo_security_configuration_xml(changed_roles = role,
#'                                          output_file = "Output/_WIBU_VERKAUF_INNENDIENST_LEITUNG.xml")
#'
#' # A copy as a new role, as the security governance writes it
#' role$role_name <- "_WIBU_Verkauf_Innendienst_Leitung_Kopie"
#' create_d365fo_security_configuration_xml(new_roles = role, format = "governance",
#'                                          output_file = "Output/Kopie.xml")
#'
#' }
#'
#' @seealso
#' \code{\link{export_role_xml}}
#' \code{\link{build_license_roles}}
#' \code{\link{create_d365fo_role_xml}}
#'
#' @export
create_d365fo_security_configuration_xml <- function(new_roles = list(), changed_roles = list(), new_privileges = list(),
                                                     output_file = NULL, format = c("configuration", "governance")) {

  format         <- match.arg(format)
  new_roles      <- .as_role_list(new_roles, "new_roles")
  changed_roles  <- .as_role_list(changed_roles, "changed_roles")
  new_privileges <- .as_privilege_list(new_privileges)
  if (length(new_roles) + length(changed_roles) + length(new_privileges) == 0L) {
    stop("Nothing to write: give at least one role or privilege.", call. = FALSE)
  }
  .stop_on_same_names(c(.role_names(new_roles), .role_names(changed_roles)), "roles")
  .stop_on_same_names(.privilege_names(new_privileges), "new_privileges")

  doc <- xml2::xml_new_root(
    "SecurityCustomizationData",
    xmlns     = .SECURITY_CONFIGURATION_NS[["data"]],
    "xmlns:i" = .SECURITY_CONFIGURATION_NS[["instance"]]
  )
  types <- xml2::xml_add_child(doc, .backing_field("CustomizationsForTypeList"))

  roles <- .add_type_customizations(types, "Role")
  for (role in changed_roles) xml2::xml_add_child(roles$changed, xml2::xml_root(create_d365fo_role_xml(role)))
  for (role in new_roles) xml2::xml_add_child(roles$new, xml2::xml_root(create_d365fo_role_xml(role)))
  .add_type_customizations(types, "Duty")
  privileges <- .add_type_customizations(types, "Privilege")
  for (privilege in new_privileges) .complete_privilege(xml2::xml_add_child(privileges$new, privilege))

  text <- .as_net_xml_text(doc, format)
  if (!is.null(output_file)) {
    writeBin(charToRaw(enc2utf8(text)), output_file)
  }
  text
}

.SECURITY_CONFIGURATION_NS <- c(
  data      = "http://schemas.datacontract.org/2004/07/Microsoft.Dynamics.AX.Security.Management",
  instance  = "http://www.w3.org/2001/XMLSchema-instance",
  arrays    = "http://schemas.microsoft.com/2003/10/Serialization/Arrays"
)

# The .NET serializer of D365 names each member after its backing field.
.backing_field <- function(name) paste0("_x003C_", name, "_x003E_k__BackingField")

# The lists of one object type; returns the nodes that take the changed and the new objects.
.add_type_customizations <- function(parent, type) {
  node <- xml2::xml_add_child(parent, "BaseRepositoryCustomizations")
  xml2::xml_attr(node, "i:type") <- paste0("RepositoryCustomizationsOfAxSecurity", type, "NcCATIYq")
  changed  <- xml2::xml_add_child(node, .backing_field("CustomizedObjectList"))
  disabled <- xml2::xml_add_child(node, .backing_field("DisabledObjectSet"))
  xml2::xml_attr(disabled, "xmlns:a") <- .SECURITY_CONFIGURATION_NS[["arrays"]]
  list(changed = changed, new = xml2::xml_add_child(node, .backing_field("NewObjectList")))
}

# The copy of a privilege in the file gets what the export of D365 writes and an
# AOT privilege file may lack: xmlns="", without which it would take the namespace
# of the envelope; the forms of each entry point; the form control overrides. The
# copy of a privilege without xmlns="" keeps the namespace of the envelope in
# memory, so its parts are found by local name.
.complete_privilege <- function(node) {
  if (!"xmlns" %in% names(xml2::xml_attrs(node))) {
    xml2::xml_set_attr(node, "xmlns", "")
  }
  entries <- xml2::xml_find_all(node, paste0(
    "*[local-name()='EntryPoints']/*[local-name()='AxSecurityEntryPointReference'][not(*[local-name()='Forms'])]"
  ))
  for (entry in entries) {
    xml2::xml_add_child(entry, "Forms")
  }
  if (length(xml2::xml_find_all(node, "*[local-name()='FormControlOverrides']")) == 0L) {
    xml2::xml_add_child(node, "FormControlOverrides")
  }
  invisible(node)
}

# One line without declaration. libxml2 writes an empty element "<x/>", as the
# security configuration does; the security governance writes "<x />". "/>"
# only closes an element: libxml2 writes ">" in a text as "&gt;".
.as_net_xml_text <- function(doc, format) {
  text <- sub("\n$", "", as.character(doc, options = "no_declaration"))
  if (format == "governance") gsub("/>", " />", text, fixed = TRUE) else text
}

# The parts of a role: a list that names one of them is a single role.
.ROLE_PARTS <- c("role_name", "role_label", "direct_access_permissions", "duties", "privileges", "subroles")

.as_role_list <- function(roles, argument) {
  if (is.list(roles) && any(.ROLE_PARTS %in% names(roles))) {
    roles <- list(roles)
  }
  for (i in seq_along(roles)) {
    role    <- if (is.list(roles[[i]])) roles[[i]] else list()
    missing <- c(
      if (!.is_single_string(role$role_name)) "role_name",
      if (!.is_single_string(role$role_label)) "role_label",
      if (!is.data.frame(role$direct_access_permissions)) "direct_access_permissions"
    )
    if (length(missing) > 0L) {
      stop(argument, ": role ", i, " has no ", paste(missing, collapse = ", "),
           ". Each role needs role_name, role_label and direct_access_permissions, ",
           "as convert_sql_to_security_role() returns them.", call. = FALSE)
    }
  }
  roles
}

.as_privilege_list <- function(privileges) {
  if (inherits(privileges, c("xml_document", "xml_node"))) {
    privileges <- list(privileges)
  }
  lapply(seq_along(privileges), function(i) {
    node <- if (inherits(privileges[[i]], c("xml_document", "xml_node"))) xml2::xml_root(privileges[[i]])
    if (is.null(node) || xml2::xml_name(node) != "AxSecurityPrivilege" ||
        !.is_single_string(xml2::xml_text(xml2::xml_find_first(node, "Name")))) {
      stop("new_privileges: privilege ", i, " is no AxSecurityPrivilege document with a Name, ",
           "as build_license_roles() writes it or xml2::read_xml() reads an AOT privilege file.", call. = FALSE)
    }
    node
  })
}

.role_names      <- function(roles) vapply(roles, function(role) role$role_name, character(1))
.privilege_names <- function(nodes) vapply(nodes, function(node) xml2::xml_text(xml2::xml_find_first(node, "Name")), character(1))

.stop_on_same_names <- function(names, what) {
  twice <- duplicated(.identifier_key(names))
  if (any(twice)) {
    stop(what, ": several have the same name: ", paste(unique(trimws(names[twice])), collapse = ", "),
         ". D365 takes each name once; give each its own name.", call. = FALSE)
  }
  invisible(names)
}
