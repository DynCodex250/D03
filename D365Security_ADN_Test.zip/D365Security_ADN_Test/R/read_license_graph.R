#' Read the license graph of D365FO
#'
#' Reads the table \code{LicensingSecurityObjectExplodedGraph}: one row per
#' path role - sub-role - duty - privilege - object, with the access level and
#' the license the object needs at it. From exported \code{.xlsx} files or
#' from the database. The result goes into
#' \code{\link{plan_role_license_cleanup}}.
#'
#' @details
#'
#' D365FO keeps the table from version 10.0.47 (preview feature "Security
#' object licenses" of User Security Governance); a job fills it. It holds
#' every role of the environment, so an export is often larger than one
#' Excel sheet and comes in several files, split by rows: the files are read
#' together, and rows that two files share count once.
#'
#' The columns are \code{ROLEIDENTIFIER}, \code{ROLENAME},
#' \code{SUBROLEIDENTIFIER}, \code{SUBROLENAME}, \code{DUTYIDENTIFIER},
#' \code{DUTYNAME}, \code{PRIVILEGEIDENTIFIER}, \code{PRIVILEGENAME},
#' \code{SECURABLETYPE} (a number, 1 = display menu item),
#' \code{SECURABLENAME}, \code{SECURABLECHILDNAME}, \code{ACCESSLEVEL} (1 read,
#' 2 write) and \code{LICENSE} (for example \code{"Finance or Supply Chain
#' Management"}, \code{"None"}, \code{"Not required"}). Their names may be
#' written in any case; further columns are dropped. All values stay text.
#' Rows without a role (duties and privileges that no role holds) are kept;
#' \code{\link{plan_role_license_cleanup}} counts and leaves them out.
#'
#' @param path
#' Paths of the exported \code{.xlsx} files; the first sheet of each is read.
#' For example \code{list.files("Input/Database", "EXPLODEDGAPH_.*[.]xlsx$",
#' full.names = TRUE)}.
#'
#' @param con
#' Database connection (\code{get_connection()}) instead of \code{path}.
#'
#' @return
#' Tibble with the columns above, all text, without duplicate rows.
#'
#' @examples
#' \dontrun{
#'
#' files <- list.files("Input/Excel/Database", pattern = "EXPLODEDGAPH_.*[.]xlsx$", full.names = TRUE)
#' graph <- read_license_graph(files)
#'
#' # straight from the database of the environment
#' graph <- read_license_graph(con = get_connection("ADN", "db_credentials.xlsx"))
#'
#' }
#'
#' @seealso
#' \code{\link{plan_role_license_cleanup}}
#' \code{\link{report_role_license}}
#'
#' @export
read_license_graph <- function(path = NULL, con = NULL) {

  if (is.null(path) == is.null(con)) {
    stop("Pass path or con: the exported .xlsx files of ", .LICENSE_GRAPH_TABLE, ", or a database connection.",
         call. = FALSE)
  }
  graph <- if (is.null(con)) .read_graph_files(path) else .graph_columns(.query_license_graph(con), "the database")
  graph <- dplyr::distinct(graph)

  message(sprintf("License graph: %d rows, %d roles from %s.", nrow(graph),
                  dplyr::n_distinct(graph$ROLEIDENTIFIER[!is.na(graph$ROLEIDENTIFIER)]),
                  if (is.null(con)) sprintf("%d file%s", length(path), if (length(path) == 1L) "" else "s") else
                    "the database"))
  graph
}

.read_graph_files <- function(path) {

  if (!is.character(path) || length(path) == 0L || !all(grepl("[.]xlsx$", path, ignore.case = TRUE))) {
    stop("path must name the exported .xlsx files of ", .LICENSE_GRAPH_TABLE, ".", call. = FALSE)
  }
  missing <- path[!file.exists(path)]
  if (length(missing) > 0L) {
    stop("License graph not found: ", paste(missing, collapse = .LIST_SEPARATOR), call. = FALSE)
  }
  dplyr::bind_rows(lapply(path, function(file) {
    .graph_columns(readxl::read_excel(file, col_types = "text"), basename(file))
  }))
}

.query_license_graph <- function(con) {
  query <- paste("SELECT", paste(.GRAPH_COLUMNS, collapse = ", "), "FROM", toupper(.LICENSE_GRAPH_TABLE))
  tryCatch(DBI::dbGetQuery(con, query), error = function(e) {
    stop("Reading the license graph (", .LICENSE_GRAPH_TABLE, ") failed: ", .without_sql_statement(conditionMessage(e)),
         call. = FALSE)
  })
}

# The columns of the graph as text, whatever the case of their names; empty text is NA.
.graph_columns <- function(table, source) {
  names(table) <- toupper(trimws(names(table)))
  missing <- setdiff(.GRAPH_COLUMNS, names(table))
  if (length(missing) > 0L) {
    stop("The license graph (", source, ") lacks the column", if (length(missing) == 1L) "" else "s", " ",
         paste(missing, collapse = .LIST_SEPARATOR), ".", call. = FALSE)
  }
  tibble::as_tibble(lapply(table[.GRAPH_COLUMNS], function(column) {
    text <- trimws(as.character(column))
    ifelse(is.na(text) | !nzchar(text), NA_character_, text)
  }))
}
