#' Write the capacity forecast with its history as deliverable D17
#'
#' Writes one or more results of \code{\link{forecast_capacity}} as the Excel
#' workbook of the deliverable D17. The first sheet shows the newest state,
#' and every state keeps a sheet of its own, so the history stays visible.
#'
#' @details
#'
#' **Sheets.** \code{Überblick}: the newest state with its key figures, the
#' consumption at milestones, the environments, the assumptions and the
#' windows of the option, then the history of all states (one row each) and
#' the chart. Then one sheet per state, named by its date alone
#' (\code{20.10.2026}), newest first, with the same tables. The order of
#' \code{forecasts} does not matter.
#'
#' **The history stays.** The workbook is written anew from the input
#' workbooks of all states. A date sheet of the existing workbook whose state
#' is missing in \code{forecasts} stops the function: otherwise that state
#' would be lost. Two forecasts of the same day stop it too.
#'
#' @param forecasts
#' List of results of \code{\link{forecast_capacity}}, one per state.
#'
#' @param path
#' Path of the workbook, in an existing folder, as a rule
#' \code{"Data/Deliverables/D17_Kapazitaetsprognose.xlsx"}.
#'
#' @param overwrite
#' \code{TRUE} = replace an existing file at \code{path}. Default \code{FALSE}.
#'
#' @return
#' Invisibly \code{path}.
#'
#' @examples
#' \dontrun{
#'
#' files <- c("Data/Input/Kapazitaet/Kapazitaet_2026-11-15.xlsx", "Data/Input/Kapazitaet/Kapazitaet_2026-10-20.xlsx")
#' forecasts <- lapply(files, function(file) forecast_capacity(read_capacity_status(file)))
#' export_capacity_forecast(forecasts, "Data/Deliverables/D17_Kapazitaetsprognose.xlsx", overwrite = TRUE)
#'
#' }
#'
#' @seealso
#' \code{\link{read_capacity_status}}
#' \code{\link{forecast_capacity}}
#' \code{\link{capacity_tables}}
#'
#' @export
export_capacity_forecast <- function(forecasts, path, overwrite = FALSE) {

  forecasts <- .sorted_capacity_forecasts(forecasts)
  names     <- vapply(forecasts, .capacity_sheet_name, character(1))
  .check_inventory_path(path, overwrite)
  .check_capacity_history(path, names)

  chart <- tempfile(fileext = ".png")
  on.exit(unlink(chart), add = TRUE)
  .write_capacity_chart(forecasts[[1]], chart)

  wb <- openxlsx::createWorkbook()
  .add_capacity_sheet(wb, "Überblick", forecasts[[1]], forecasts, chart)
  for (i in seq_along(forecasts)) .add_capacity_sheet(wb, names[[i]], forecasts[[i]])
  openxlsx::saveWorkbook(wb, path, overwrite = TRUE)
  message(sprintf("D17 written: %s (%d states, newest %s).", path, length(forecasts), names[[1]]))
  invisible(path)
}

.capacity_sheet_name <- function(forecast) .capacity_german_date(forecast$Facts$STATUS_DATE)

.write_capacity_chart <- function(forecast, path) {
  grDevices::png(path, width = 1100, height = 660, res = 110)
  on.exit(grDevices::dev.off())
  plot_capacity_forecast(forecast)
}

.sorted_capacity_forecasts <- function(forecasts) {
  if (!is.list(forecasts) || length(forecasts) == 0L ||
      !all(vapply(forecasts, function(x) is.list(x) && !is.null(x$Facts$STATUS_DATE) && !is.null(x$Figures), logical(1)))) {
    stop("forecasts must be a list of results of forecast_capacity().", call. = FALSE)
  }
  dates <- do.call(c, lapply(forecasts, function(x) x$Facts$STATUS_DATE))
  twice <- unique(dates[duplicated(dates)])
  if (length(twice) > 0L) {
    stop("Two states have the same day: ", paste(.capacity_german_date(twice), collapse = .LIST_SEPARATOR), ".", call. = FALSE)
  }
  forecasts[order(dates, decreasing = TRUE)]
}

# The history lives in the input workbooks: a state dropped from the list would vanish from D17.
.check_capacity_history <- function(path, names) {
  if (!file.exists(path)) return(invisible(TRUE))
  earlier <- grep("^[0-9]{2}[.][0-9]{2}[.][0-9]{4}$", readxl::excel_sheets(path), value = TRUE)
  gone    <- setdiff(earlier, names)
  if (length(gone) > 0L) {
    stop("'", path, "' holds states that are not in the list: ", paste(gone, collapse = .LIST_SEPARATOR),
         ". Add their input workbooks, so that the history stays.", call. = FALSE)
  }
  invisible(TRUE)
}

.capacity_history_table <- function(forecasts) {
  value <- function(f, field) .capacity_german_number(f$Facts[[field]])
  row   <- function(f) {
    s1 <- f$Figures[f$Figures$ID == "S1", ]
    data.frame(
      "Stand" = .capacity_sheet_name(f), "Kontingent (GB)" = value(f, "QUOTA_GB"), "Belegt (GB)" = value(f, "USED_GB"),
      "Go-Live" = .capacity_german_date(f$Facts$GO_LIVE),
      "Prod (GB)" = .capacity_german_number(f$Environments$GB[f$Environments$ENVIRONMENT == "Prod"]),
      "Fehlmenge S1 vor dem Go-Live (GB)" = .capacity_german_number(s1$MISSING_BEFORE_GO_LIVE),
      "Reserve nach der Löschung (GB)" = .capacity_german_number(s1$RESERVE_AFTER_DELETION),
      check.names = FALSE, stringsAsFactors = FALSE
    )
  }
  do.call(rbind, lapply(forecasts, row))
}

# One sheet: the tables one below the other; the overview adds the history and the chart.
.add_capacity_sheet <- function(wb, name, forecast, history = NULL, chart = NULL) {
  tables <- capacity_tables(forecast)
  openxlsx::addWorksheet(wb, name)
  title  <- openxlsx::createStyle(textDecoration = "bold", fontSize = 14)
  bold   <- openxlsx::createStyle(textDecoration = "bold")
  body   <- .deliverable_style("body")
  header <- .deliverable_style("it_head")
  stand  <- paste("Stand", .capacity_sheet_name(forecast))
  openxlsx::writeData(wb, name, paste("D17 Kapazitätsprognose Datenbank:", stand), startRow = 1)
  openxlsx::addStyle(wb, name, title, rows = 1, cols = 1)
  if (!is.null(history)) {
    openxlsx::writeData(wb, name, paste("Dieses Blatt zeigt den neuesten Stand. Die Blätter mit Datum zeigen jeden Stand; so bleibt",
                                        "die Historie erhalten. S1: wie geplant. S2: PRJ und Migrationssandbox bereinigt wie INT.",
                                        "S3: wie S2, Migrationssandbox transaktionslos."), startRow = 2)
  }
  blocks <- list("Kennzahlen je Szenario" = tables$Figures,
                 "Verbrauch je Szenario und Kontingent an Stichtagen (GB)" = tables$Milestones,
                 "Belegung je Umgebung (GB)" = tables$Environments,
                 "Annahmen" = tables$Assumptions,
                 "Geplante Nutzung der Option" = tables$Windows)
  if (!is.null(history)) blocks <- c(blocks, list("Verlauf der Stände" = .capacity_history_table(history)))
  row <- 4L
  for (heading in names(blocks)) {
    data <- blocks[[heading]]
    openxlsx::writeData(wb, name, heading, startRow = row)
    openxlsx::addStyle(wb, name, bold, rows = row, cols = 1)
    openxlsx::writeData(wb, name, data, startRow = row + 1L, headerStyle = header)
    openxlsx::addStyle(wb, name, body, rows = seq(row + 2L, length.out = max(nrow(data), 1L)), cols = seq_along(data),
                       gridExpand = TRUE, stack = TRUE)
    row <- row + nrow(data) + 3L
  }
  openxlsx::setColWidths(wb, name, cols = 1:8, widths = c(52, 30, 12, 12, 12, 14, 14, 14))
  if (!is.null(chart)) openxlsx::insertImage(wb, name, chart, startRow = row, startCol = 1, width = 10, height = 6, units = "in")
  invisible(wb)
}
