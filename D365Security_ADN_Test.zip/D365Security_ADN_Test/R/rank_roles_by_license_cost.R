#' Rank the roles by the license costs that arise only because of them
#'
#' The ranking of the most expensive roles (D04 of the strategy): for every
#' role, the license costs per month that its users would no longer have if
#' the role triggered no license, given all their other roles.
#'
#' @details
#'
#' **Costs only because of a role.** A user needs the licenses all their
#' roles trigger. The costs of a role are, summed over its users, the costs
#' of the user with all roles minus the costs without this role. When another
#' role of the user triggers the same license, cleaning up this role alone
#' saves nothing there; the ranking therefore looks at the whole set of roles
#' of each user. \code{COST} is what a cleanup of the role saves at most.
#'
#' **Versions of a role.** An AOT role and the role of the user interface of
#' the same name (\code{\link{load_role_mapping}}) count as one role: users who
#' have both would otherwise cost nothing "only because" of either. The
#' ranking shows the AOT role, its UI versions in \code{VERSIONS}. When the
#' mapping cannot be read, every role stands alone, with a warning.
#'
#' **Costs of a user.** Of the base licenses (Commerce, Finance, Supply Chain
#' Management and others of the base group) the first in the order Supply
#' Chain Management, Finance, Commerce counts at its base price, every further
#' one at its attach price, as WIBU is billed:
#' \preformatted{
#' Finance + SCM             SCM Base + Finance Attach
#' Commerce + Finance        Finance Base + Commerce Attach
#' Commerce + Finance + SCM  SCM Base + Finance Attach + Commerce Attach
#' }
#' Other base licenses (Premium) come after these three, the dearest first.
#' \code{Users$BILLED_AS} shows the billing per user. Without a base license,
#' the highest price of the light licenses
#' counts (Operations - Activity includes Team Members). Light licenses next
#' to a base license cost nothing. "None" costs nothing. Amounts are rounded
#' to cents. Disabled users (\code{USERENABLED} 0) are left out, and license
#' rows without a role, with a warning.
#'
#' **Data source.** Either the database: \code{LICENSINGUSERLICENSESBYROLE},
#' the licenses D365 computes per user and role
#' (\code{\link{get_user_licenses_by_role}}); \code{LICENSINGALLSKUS} for the
#' base group and the order of the licenses; \code{SECURITYROLE} for the
#' versions. Or, without a database, one environment of the detailed license
#' report of the Power Platform admin center (\code{licenses}, from
#' \code{\link{read_ppac_license_detail}}). That report names the roles by
#' their name only, so an AOT role and the UI role of the same name are one
#' role there already; Commerce, Finance and Supply Chain Management (also
#' Premium) are the base licenses.
#'
#' **Two bases for the costs only because of a role** (\code{basis}). Both
#' take what the users pay with all their roles from PPAC (or
#' \code{LICENSINGUSERLICENSESBYROLE}); they differ in what a user would need
#' without a role.
#' \describe{
#'   \item{\code{"ppac"}}{The licenses PPAC names at his other roles. PPAC
#'     names each license of a user at one of his roles only and \code{None}
#'     at the others that need it too, so the costs are an upper bound that
#'     can be far too high.}
#'   \item{\code{"graph"}}{The licenses the objects of his other roles need
#'     by the license graph (\code{\link{read_license_graph}}), the cheapest
#'     set. Where the graph wants more for an object than PPAC bills the user,
#'     PPAC has priority and its licenses cover the object. \code{LICENSES}
#'     then holds the licenses the role's own objects need, \code{Breakdown}
#'     the billing by the graph with and without the role.}
#' }
#' Neither looks at the telemetry; what can really go shows
#' \code{\link{plan_role_license_cleanup}}.
#'
#' @param con
#' Database connection. Result of \code{get_connection()}. With
#' \code{licenses} it is optional: given, the roles of the PPAC report get
#' their AOT name from \code{SECURITYROLE} (\code{ROLE}), their UI copies of
#' the same name go to \code{VERSIONS}; \code{NULL}, the roles keep the names
#' of the report.
#'
#' @param prices
#' Prices per user and month, see \code{\link{read_license_prices}}: the SKU
#' list of the sheet \code{skuPrices} (\code{"Finance Base"},
#' \code{"Finance Attach"}, ...), or a table or \code{.xlsx} file with one row
#' per license:
#' \describe{
#'   \item{\code{LICENSE}}{Name as \code{LicensingAllSkus} writes it.}
#'   \item{\code{BASE_PRICE}}{Price as the (first) base license, or the price
#'     of a light license.}
#'   \item{\code{ATTACH_PRICE}}{Price as an additional base license; empty
#'     for light licenses, and where empty for a base license, the base price
#'     counts.}
#' }
#' For example:
#' \preformatted{
#' LICENSE                  BASE_PRICE  ATTACH_PRICE
#' Team Members                   7.50
#' Operations - Activity         46.80
#' Commerce                     164.60         31.20
#' Finance                      164.60         31.20
#' Supply Chain Management      164.60         31.20
#' }
#' Every license the users have needs a row. \code{NULL} = the estimates of
#' the strategy paper (October 2026) shown above, with a warning;
#' \code{Check$PRICES_ESTIMATED} says so.
#'
#' @param export_path
#' Path of an \code{.xlsx} file for the ranking; \code{NULL} = no file. The
#' sheets Users and Users and roles hold user ids.
#'
#' @param language
#' Language of the workbook: \code{"de"} or \code{"en"}.
#'
#' @param licenses
#' The license rows of one environment instead of the database, for example
#' \code{read_ppac_license_detail(path, environment = "wibu-produktiv")}. In a
#' sandbox the license a role would need in production counts. \code{NULL} =
#' read from \code{con}.
#'
#' @param basis
#' \code{"ppac"} (default, as before) or \code{"graph"}: where the costs only
#' because of a role come from, see above.
#'
#' @param graph
#' The license graph for \code{basis = "graph"}, \code{\link{read_license_graph}}.
#' \code{NULL} = read from \code{con}. Not used with \code{basis = "ppac"}
#' (a warning says so).
#'
#' @return
#' List:
#' \describe{
#'   \item{\code{Check}}{\code{CREATED}, \code{USERS} (active users with a
#'     license row), \code{ROLES}, \code{TOTAL_COST} (all users, per month),
#'     \code{PRICES_ESTIMATED}, \code{SOURCE} (\code{"database"}, or the
#'     environment of the PPAC report and its date), \code{BASIS},
#'     \code{USERS_GRAPH_DIFFERS} (with \code{basis = "graph"}: users whose
#'     graph needs less than PPAC bills; \code{NA} otherwise).}
#'   \item{\code{Ranking}}{One row per role, most expensive first:
#'     \code{RANK}, \code{ROLE}, \code{NAME}, \code{VERSIONS} (UI roles of the
#'     same name), \code{IS_WIBU}, \code{USERS} (active users with the role),
#'     \code{USERS_COST} (what these users pay per month with all their roles),
#'     \code{USERS_SAVING} (users who would pay less without it),
#'     \code{LICENSES} (licenses the role triggers), \code{COST} (per month,
#'     only because of the role), \code{COST_PER_USER} (\code{COST} per user
#'     who would pay less).}
#'   \item{\code{Breakdown}}{The calculation behind \code{COST}: per role its
#'     users grouped by how they are billed with the role and without it.
#'     \code{RANK}, \code{ROLE}, \code{USERS}, \code{BILLED_WITH} ("SCM Base +
#'     Finance Attach + Commerce Attach"), \code{CALC_WITH} ("168.50 + 27.30 +
#'     31.20 = 227.00"), \code{BILLED_WITHOUT}, \code{CALC_WITHOUT},
#'     \code{SAVING_PER_USER}, \code{SAVING} (\code{USERS} times it),
#'     \code{DROPPED} (licenses no longer billed without the role; empty when
#'     other roles trigger the same licenses), \code{USERIDS} (the users of that
#'     group, separated by comma). The \code{SAVING} of a role add
#'     up to its \code{COST}.}
#'   \item{\code{Users}}{One row per user: \code{USERID}, \code{ROLES},
#'     \code{LICENSES}, \code{BILLED_AS}, \code{CALCULATION}, \code{COST}.}
#'   \item{\code{UserRoles}}{One row per user and role that costs the user
#'     something only because of it: \code{USERID}, \code{ROLE}, \code{NAME},
#'     \code{COST}.}
#'   \item{\code{Prices}}{The prices used.}
#' }
#' Example of \code{Ranking}:
#' \preformatted{
#' RANK ROLE                                    USERS USERS_SAVING LICENSES                                   COST
#'    1 _WIBU_Verkauf_Innendienst_Mitarbeiter      12           12 Commerce, Finance, Supply Chain Management 2724.00
#'    2 _WIBU_Einkauf_Mitarbeiter                   9            4 Finance, Supply Chain Management            124.80
#' }
#'
#' @examples
#' \dontrun{
#'
#' prices <- data.frame(
#'   LICENSE      = c("Team Members", "Operations - Activity", "Commerce", "Finance", "Supply Chain Management"),
#'   BASE_PRICE   = c(7.50, 46.80, 164.60, 164.60, 164.60),
#'   ATTACH_PRICE = c(NA, NA, 31.20, 31.20, 31.20)
#' )
#' ranking <- rank_roles_by_license_cost(cnn, prices = prices, export_path = "Output/D04_Rangliste.xlsx")
#' head(ranking$Ranking, 10)
#'
#' # Prices from a workbook
#' rank_roles_by_license_cost(cnn, prices = "Data/Lizenzpreise.xlsx")
#'
#' # Production from the detailed PPAC report; with cnn the roles get their AOT names
#' licenses <- read_ppac_license_detail("Input/Finance_And_Operations_Licensing_Detailed_Report.csv",
#'                                      environment = "wibu-produktiv")
#' rank_roles_by_license_cost(cnn, licenses = licenses, prices = "Data/Lizenzpreise.xlsx")
#'
#' # Without any database: the role names of the report
#' rank_roles_by_license_cost(licenses = licenses, prices = "Data/Lizenzpreise.xlsx")
#'
#' # Both bases side by side
#' graph <- read_license_graph(list.files("Input/Excel/Database", "EXPLODEDGAPH_.*[.]xlsx$", full.names = TRUE))
#' ppac  <- rank_roles_by_license_cost(licenses = licenses, prices = "Data/Lizenzpreise.xlsx")
#' objs  <- rank_roles_by_license_cost(licenses = licenses, prices = "Data/Lizenzpreise.xlsx",
#'                                     basis = "graph", graph = graph)
#' merge(ppac$Ranking[c("ROLE", "COST")], objs$Ranking[c("ROLE", "COST")], by = "ROLE", suffixes = c("_PPAC", "_GRAPH"))
#'
#' }
#'
#' @seealso
#' \code{\link{read_ppac_license_detail}}
#' \code{\link{read_license_prices}}
#' \code{\link{get_user_licenses_by_role}}
#' \code{\link{report_role_license}}
#' \code{\link{build_license_roles}}
#'
#' @export
rank_roles_by_license_cost <- function(con = NULL, prices = NULL, export_path = NULL, language = "de", licenses = NULL,
                                       basis = "ppac", graph = NULL) {

  language <- .check_report_language(language)
  basis    <- .check_ranking_basis(basis)
  if (!is.null(export_path)) .check_xlsx_path(export_path)
  price_table <- .license_prices(prices)
  graph       <- .ranking_graph(basis, graph, con)

  input <- .ranking_input(con, licenses)
  skus  <- input$skus
  rows  <- .cost_rows(input$licenses, input$families)
  .check_prices_cover(price_table$prices, rows$SKUNAME)

  base       <- skus$SKUNAME[.is_base_group(skus$GROUPNAME, "^Base")]
  cost_of    <- .license_cost_function(price_table$prices, base)
  by_graph   <- if (!is.null(graph)) .graph_ranking_costs(rows, graph, price_table$prices, cost_of, !is.null(licenses))
  user_roles <- if (is.null(by_graph)) .user_role_costs(rows, cost_of) else
    dplyr::select(by_graph$pairs, USER_KEY, USERID, FAMILY_KEY, TOTAL, COST)
  ranking    <- .cost_ranking(rows, user_roles, skus)
  if (!is.null(by_graph)) ranking$LICENSES <- unname(by_graph$licenses[ranking$ROLE_KEY])
  if (!is.null(input$versions)) {
    ranking$VERSIONS <- dplyr::coalesce(unname(input$versions[ranking$ROLE_KEY]), ranking$VERSIONS)
  }

  result <- list(
    Check     = list(CREATED = Sys.Date(), USERS = dplyr::n_distinct(rows$USER_KEY), ROLES = nrow(ranking),
                     TOTAL_COST = sum(dplyr::distinct(user_roles, USER_KEY, TOTAL)$TOTAL),
                     PRICES_ESTIMATED = price_table$estimated, SOURCE = input$source, BASIS = basis,
                     USERS_GRAPH_DIFFERS = if (is.null(by_graph)) NA_integer_ else by_graph$differs),
    Ranking   = ranking,
    Breakdown = if (is.null(by_graph)) .cost_breakdown(rows, ranking, cost_of) else
      .graph_cost_breakdown(by_graph$pairs, ranking, cost_of),
    Users     = .cost_users(rows, user_roles, skus, cost_of),
    UserRoles = user_roles |>
      dplyr::filter(COST > 0) |>
      dplyr::left_join(dplyr::select(ranking, FAMILY_KEY = ROLE_KEY, ROLE, NAME), by = "FAMILY_KEY") |>
      dplyr::arrange(dplyr::desc(COST), USERID) |>
      dplyr::select(USERID, ROLE, NAME, COST),
    Prices    = price_table$prices
  )
  result$Ranking <- dplyr::select(result$Ranking, -ROLE_KEY)

  if (!is.null(export_path)) {
    .export_license_cost_ranking(result, export_path, language)
  }

  message(.cost_ranking_message(result))
  result
}

# The license rows to rank with the licenses and role families that go with them: from
# the licenses given (one environment of the PPAC report, no database access), else from
# the database.
.ranking_input <- function(con, licenses) {

  if (!is.null(licenses)) {
    .check_required_columns(licenses, c("USERID", "USERENABLED", "ROLEIDENTIFIER", "SECURITYROLENAME", "SKUNAME"),
                            "licenses")
    environments <- if ("ENVIRONMENT" %in% names(licenses)) sort(unique(licenses$ENVIRONMENT)) else character()
    if (length(environments) > 1L) {
      stop("licenses holds several environments: ", paste(environments, collapse = .LIST_SEPARATOR), ". Rank one, ",
           "for example read_ppac_license_detail(path, environment = \"", environments[[1]], "\").", call. = FALSE)
    }
    source <- if (length(environments) == 0L) "licenses as given" else
      paste0("PPAC ", environments, if ("REFRESHEDON" %in% names(licenses)) paste0(", ", .latest(licenses$REFRESHEDON)))
    named  <- if (is.null(con)) list(licenses = licenses, versions = NULL) else .ppac_role_identifiers(con, licenses)
    return(list(licenses = named$licenses, skus = .STANDARD_LICENSE_SKUS, families = NULL, source = source,
                versions = named$versions))
  }

  if (is.null(con)) {
    stop("Pass con or licenses: a database connection, or the licenses of one environment from ",
         "read_ppac_license_detail().", call. = FALSE)
  }
  licenses <- get_user_licenses_by_role(con)
  .check_required_columns(licenses, c("USERID", "USERENABLED", "ROLEIDENTIFIER", "SECURITYROLENAME", "SKUNAME"),
                          "user licenses")
  list(licenses = licenses, skus = .load_license_skus(con), families = .role_families(con), source = "database")
}

# The PPAC report names the roles by their label. In SECURITYROLE an AOT role is named
# "<label> (<AOT name>)", its UI copy "<label>" with a GUID as AOT name: the AOT role
# stands for the label, its UI copies become its versions. A label not in SECURITYROLE
# keeps its name, with a warning.
.ppac_role_identifiers <- function(con, licenses) {

  stored <- tryCatch(.load_security_role_names(con), error = function(e) {
    warning("SECURITYROLE could not be read, so the roles keep the names of the PPAC report: ",
            .without_sql_statement(conditionMessage(e)), call. = FALSE)
    NULL
  })
  if (is.null(stored)) {
    return(list(licenses = licenses, versions = NULL))
  }
  # Only an AOT role carries "(<AOT name>)" after its label; the name of a UI copy is its
  # label, brackets included ("Buchhalter (Kreditoren)" is no copy of "Buchhalter").
  stored <- tibble::tibble(AOTNAME = as.character(stored$AOTNAME), NAME = as.character(stored$NAME)) |>
    dplyr::mutate(
      IS_GUID   = is_guid_name(AOTNAME),
      NAME_KEY  = .identifier_key(NAME),
      LABEL_KEY = ifelse(IS_GUID, NAME_KEY, .identifier_key(sub("\\s*\\([^()]*\\)\\s*$", "", NAME)))
    ) |>
    dplyr::arrange(IS_GUID, AOTNAME)

  labels <- unique(licenses$SECURITYROLENAME[!is.na(licenses$SECURITYROLENAME)])
  found  <- lapply(.identifier_key(labels), function(key) stored$AOTNAME[stored$NAME_KEY == key | stored$LABEL_KEY == key])
  aot    <- vapply(found, function(ids) if (length(ids) == 0L) NA_character_ else ids[[1]], character(1))

  missing <- labels[is.na(aot)]
  if (length(missing) > 0L) {
    warning(sprintf("%d role%s of the PPAC report %s not in SECURITYROLE: %s. %s %s name.", length(missing),
                    if (length(missing) == 1L) "" else "s", if (length(missing) == 1L) "is" else "are",
                    paste(missing, collapse = .LIST_SEPARATOR), if (length(missing) == 1L) "It keeps" else "They keep",
                    if (length(missing) == 1L) "its" else "their"), call. = FALSE)
  }

  .warn_on_ambiguous_role_names(labels, found, aot)

  versions <- vapply(found, function(ids) paste(ids[-1], collapse = .LIST_SEPARATOR), character(1))
  list(
    licenses = dplyr::mutate(licenses, ROLEIDENTIFIER = dplyr::coalesce(aot[match(SECURITYROLENAME, labels)],
                                                                        ROLEIDENTIFIER)),
    versions = stats::setNames(versions[!is.na(aot)], .identifier_key(aot[!is.na(aot)]))
  )
}

# Merged without a word otherwise: several AOT roles behind one name of the report (the
# first counts, the others become its versions), or several names on one AOT role.
.warn_on_ambiguous_role_names <- function(labels, found, aot) {

  several <- labels[vapply(found, function(ids) sum(!is_guid_name(ids)) > 1L, logical(1))]
  if (length(several) > 0L) {
    warning(sprintf("%d role name%s of the PPAC report match%s several AOT roles in SECURITYROLE: %s. The first counts, ",
                    length(several), if (length(several) == 1L) "" else "s", if (length(several) == 1L) "es" else "",
                    paste(several, collapse = .LIST_SEPARATOR)),
            "the others are listed as its versions.", call. = FALSE)
  }

  known     <- !is.na(aot)
  per_role  <- tapply(.identifier_key(labels[known]), .identifier_key(aot[known]), function(keys) length(unique(keys)))
  shared    <- names(per_role)[per_role > 1L]
  if (length(shared) > 0L) {
    roles <- unique(aot[known][.identifier_key(aot[known]) %in% shared])
    warning(sprintf("%d AOT role%s several role names of the PPAC report and count%s as one role: %s.", length(roles),
                    if (length(roles) == 1L) " carries" else "s carry", if (length(roles) == 1L) "s" else "",
                    paste(roles, collapse = .LIST_SEPARATOR)), call. = FALSE)
  }
  invisible(NULL)
}

.load_security_role_names <- function(con) {
  tibble::as_tibble(DBI::dbGetQuery(con, "SELECT AOTNAME, NAME FROM SECURITYROLE"))
}

# The AOT role of each UI role of the same name; NULL when the mapping cannot be read.
# A UI role with several AOT roles of its name stays on its own.
.role_families <- function(con) {
  mapping <- tryCatch(
    {
      loaded <- load_role_mapping(con)
      .check_required_columns(loaded, c("CONFIDENT", "DEVIDENT"), "role mapping")
      loaded
    },
    error = function(e) {
      warning("The role mapping could not be read, so every role is ranked on its own, also an AOT role and its ",
              "UI role of the same name: ", .without_sql_statement(conditionMessage(e)), call. = FALSE)
      NULL
    }
  )
  if (is.null(mapping)) {
    return(NULL)
  }
  pairs <- mapping[!is.na(mapping$CONFIDENT) & !is.na(mapping$DEVIDENT), ]
  pairs <- dplyr::distinct(
    tibble::tibble(MEMBER_KEY = .identifier_key(pairs$CONFIDENT), FAMILY_KEY = .identifier_key(pairs$DEVIDENT),
                   FAMILY_ROLE = trimws(as.character(pairs$DEVIDENT))),
    MEMBER_KEY, FAMILY_KEY, .keep_all = TRUE
  )
  pairs[!pairs$MEMBER_KEY %in% pairs$MEMBER_KEY[duplicated(pairs$MEMBER_KEY)], ]
}

# One row per active user, role and license, with the role family it counts in. As in
# analyze_role_license_decision(), only USERENABLED = 0 (or FALSE) means disabled.
.cost_rows <- function(licenses, families) {
  role   <- dplyr::coalesce(as.character(licenses$ROLEIDENTIFIER), as.character(licenses$SECURITYROLENAME))
  active <- !toupper(as.character(licenses$USERENABLED)) %in% c("0", "FALSE") & !is.na(licenses$USERID)

  without_role <- sum(active & is.na(role))
  if (without_role > 0L) {
    warning(sprintf("%d license row%s without a role %s left out: %s neither to a role nor to the costs of %s user.",
                    without_role, if (without_role == 1L) "" else "s", if (without_role == 1L) "is" else "are",
                    if (without_role == 1L) "it counts" else "they count", if (without_role == 1L) "its" else "their"),
            call. = FALSE)
  }
  if (!any(active & !is.na(role))) {
    stop("No active user with a role holds a license row (in LICENSINGUSERLICENSESBYROLE or the PPAC report), so there ",
         "is nothing to count. Check that the license data of the environment is filled.", call. = FALSE)
  }

  rows <- tibble::tibble(
    USERID   = as.character(licenses$USERID),
    USER_KEY = tolower(trimws(as.character(licenses$USERID))),
    ROLE     = role,
    ROLE_KEY = .identifier_key(role),
    ROLENAME = as.character(licenses$SECURITYROLENAME),
    SKUNAME  = as.character(licenses$SKUNAME),
    SKU_KEY  = .identifier_key(licenses$SKUNAME)
  )[active & !is.na(role), ]

  member <- if (is.null(families)) NA_integer_ else match(rows$ROLE_KEY, families$MEMBER_KEY)
  dplyr::mutate(
    rows,
    FAMILY_KEY  = dplyr::coalesce(if (is.null(families)) NA_character_ else families$FAMILY_KEY[member], ROLE_KEY),
    FAMILY_ROLE = dplyr::coalesce(if (is.null(families)) NA_character_ else families$FAMILY_ROLE[member], ROLE)
  )
}

# Per user and role family: the user's costs with all roles (TOTAL) and the part that
# arises only because of the family (COST).
.user_role_costs <- function(rows, cost_of) {
  per_user <- lapply(split(seq_len(nrow(rows)), rows$USER_KEY), function(i) {
    skus     <- rows$SKU_KEY[i]
    family   <- rows$FAMILY_KEY[i]
    total    <- cost_of(skus)
    families <- unique(family)
    list(USER_KEY = rows$USER_KEY[[i[[1]]]], USERID = rows$USERID[[i[[1]]]], FAMILY_KEY = families, TOTAL = total,
         COST = vapply(families, function(f) round(total - cost_of(skus[family != f]), 2), numeric(1), USE.NAMES = FALSE))
  })
  families <- vapply(per_user, function(user) length(user$FAMILY_KEY), integer(1))
  pick     <- function(field, type) rep(vapply(per_user, `[[`, type, field, USE.NAMES = FALSE), families)

  tibble::tibble(
    USER_KEY   = pick("USER_KEY", character(1)),
    USERID     = pick("USERID", character(1)),
    FAMILY_KEY = unlist(lapply(per_user, `[[`, "FAMILY_KEY"), use.names = FALSE),
    TOTAL      = pick("TOTAL", numeric(1)),
    COST       = unlist(lapply(per_user, `[[`, "COST"), use.names = FALSE)
  )
}

.licenses_by_priority <- function(licenses, skus) {
  licenses <- unique(licenses[!is.na(licenses) & licenses != .NO_LICENSE])
  priority <- skus$PRIORITY[match(.identifier_key(licenses), .identifier_key(skus$SKUNAME))]
  paste(licenses[order(priority, licenses)], collapse = .LIST_SEPARATOR)
}

# One row per role family: the AOT role, or the role itself, with its UI versions.
.cost_ranking <- function(rows, user_roles, skus) {

  # VERSIONS before ROLE: summarise() hands later expressions the summarised ROLE
  roles <- rows |>
    dplyr::group_by(FAMILY_KEY) |>
    dplyr::summarise(
      VERSIONS = paste(unique(ROLE[ROLE_KEY != FAMILY_KEY[[1]]]), collapse = .LIST_SEPARATOR),
      NAME     = { own <- ROLENAME[ROLE_KEY == FAMILY_KEY[[1]]]; if (length(own) > 0L) own[[1]] else ROLENAME[[1]] },
      LICENSES = .licenses_by_priority(SKUNAME, skus),
      ROLE     = { own <- ROLE[ROLE_KEY == FAMILY_KEY[[1]]]; if (length(own) > 0L) own[[1]] else FAMILY_ROLE[[1]] },
      .groups  = "drop"
    )
  costs <- user_roles |>
    dplyr::group_by(FAMILY_KEY) |>
    dplyr::summarise(USERS = dplyr::n_distinct(USER_KEY), USERS_COST = round(sum(TOTAL), 2), USERS_SAVING = sum(COST > 0),
                     COST = sum(COST), .groups = "drop")

  dplyr::inner_join(roles, costs, by = "FAMILY_KEY") |>
    dplyr::mutate(
      IS_WIBU       = grepl("wibu", paste(ROLE, NAME, VERSIONS), ignore.case = TRUE),
      COST_PER_USER = ifelse(USERS_SAVING > 0, COST / USERS_SAVING, NA_real_),
      USERS         = as.integer(USERS),
      USERS_SAVING  = as.integer(USERS_SAVING)
    ) |>
    dplyr::arrange(dplyr::desc(COST), dplyr::desc(USERS), ROLE) |>
    dplyr::mutate(RANK = dplyr::min_rank(dplyr::desc(COST))) |>
    dplyr::select(RANK, ROLE, NAME, VERSIONS, IS_WIBU, USERS, USERS_COST, USERS_SAVING, LICENSES, COST, COST_PER_USER,
                  ROLE_KEY = FAMILY_KEY)
}

.cost_users <- function(rows, user_roles, skus, cost_of) {
  rows |>
    dplyr::group_by(USER_KEY) |>
    dplyr::summarise(USERID = USERID[[1]], ROLES = dplyr::n_distinct(FAMILY_KEY),
                     LICENSES = .licenses_by_priority(SKUNAME, skus), BILLED_AS = cost_of(SKU_KEY, "billing"),
                     CALCULATION = cost_of(SKU_KEY, "calc"), .groups = "drop") |>
    dplyr::left_join(dplyr::distinct(user_roles, USER_KEY, COST = TOTAL), by = "USER_KEY") |>
    dplyr::arrange(dplyr::desc(COST), USERID) |>
    dplyr::select(USERID, ROLES, LICENSES, BILLED_AS, CALCULATION, COST)
}

# The calculation behind COST: per role, its users grouped by how they are billed with the
# role and without it. The savings of a role add up to its COST.
.cost_breakdown <- function(rows, ranking, cost_of) {
  per_user <- lapply(split(seq_len(nrow(rows)), rows$USER_KEY), function(i) {
    user_id  <- rows$USERID[i[[1]]]
    skus     <- rows$SKU_KEY[i]
    family   <- rows$FAMILY_KEY[i]
    families <- unique(family)
    rest     <- lapply(families, function(f) skus[family != f])
    without  <- function(what) vapply(rest, cost_of, character(1), what = what, USE.NAMES = FALSE)
    billed   <- cost_of(skus, "billed")
    list(
      USERID          = rep(user_id, length(families)),
      FAMILY_KEY      = families,
      BILLED_WITH     = rep(cost_of(skus, "billing"), length(families)),
      CALC_WITH       = rep(cost_of(skus, "calc"), length(families)),
      BILLED_WITHOUT  = without("billing"),
      CALC_WITHOUT    = without("calc"),
      SAVING_PER_USER = round(cost_of(skus) - vapply(rest, cost_of, numeric(1), USE.NAMES = FALSE), 2),
      DROPPED         = vapply(rest, function(r) {
        paste(.order_by_license_priority(setdiff(billed, cost_of(r, "billed"))), collapse = .LIST_SEPARATOR)
      }, character(1), USE.NAMES = FALSE)
    )
  })
  column <- function(name) unlist(lapply(per_user, `[[`, name), use.names = FALSE)

  steps <- tibble::tibble(USERID = column("USERID"), FAMILY_KEY = column("FAMILY_KEY"),
                          BILLED_WITH = column("BILLED_WITH"), CALC_WITH = column("CALC_WITH"),
                          BILLED_WITHOUT = column("BILLED_WITHOUT"), CALC_WITHOUT = column("CALC_WITHOUT"),
                          SAVING_PER_USER = column("SAVING_PER_USER"), DROPPED = column("DROPPED"))
  .summarise_breakdown(steps, ranking)
}

# One row per role and case of billing with and without it, from one row per user and role.
.summarise_breakdown <- function(steps, ranking) {
  steps |>
    dplyr::group_by(FAMILY_KEY, BILLED_WITH, CALC_WITH, BILLED_WITHOUT, CALC_WITHOUT, SAVING_PER_USER, DROPPED) |>
    dplyr::summarise(
      USERS   = dplyr::n(),
      USERIDS = .sorted_list(USERID),
      .groups = "drop"
    ) |>
    dplyr::mutate(SAVING = round(USERS * SAVING_PER_USER, 2)) |>
    dplyr::inner_join(dplyr::select(ranking, RANK, ROLE, FAMILY_KEY = ROLE_KEY), by = "FAMILY_KEY") |>
    dplyr::arrange(RANK, ROLE, dplyr::desc(SAVING_PER_USER), dplyr::desc(USERS)) |>
    dplyr::select(RANK, ROLE, USERS, BILLED_WITH, CALC_WITH, BILLED_WITHOUT, CALC_WITHOUT, SAVING_PER_USER, SAVING, DROPPED, USERIDS)
}

.cost_ranking_message <- function(result) {
  top <- result$Ranking[1, ]
  sprintf("Ranking of %d roles over %d users, %.2f per month in all%s, basis %s. Most expensive: %s, %.2f per month only because of it.",
          result$Check$ROLES, result$Check$USERS, result$Check$TOTAL_COST,
          if (result$Check$PRICES_ESTIMATED) " (estimated prices)" else "",
          if (identical(result$Check$BASIS, "graph")) "license graph" else "PPAC", top$ROLE, top$COST)
}
