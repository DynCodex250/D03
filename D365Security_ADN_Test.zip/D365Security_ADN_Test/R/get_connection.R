#' Connect to the database of one environment
#'
#' Opens an ODBC connection to the D365FO database of one environment. The
#' credentials come from an Excel workbook, so that no password is written in
#' code.
#'
#' @details
#' The workbook needs the sheet \code{AllConnections} with one row per
#' environment and the columns \code{Umgebung}, \code{server},
#' \code{database}, \code{uid} and \code{pwd}, for example (placeholders):
#' \preformatted{
#' Umgebung  server         database         uid     pwd
#' ADN       <server name>  <database name>  <user>  <password>
#' PRJ       <server name>  <database name>  <user>  <password>
#' }
#' All cells are read as text. The ODBC driver is \code{SQL Server}. Keep the
#' workbook out of folders that are passed on, and never print its values.
#' Close the connection with \code{DBI::dbDisconnect()}.
#'
#' The function stops with \code{"Keine Credentials für Umgebung: <env>"}
#' when the sheet has no row for \code{env}; readxl stops when the file or the
#' sheet is missing, the ODBC driver when the login fails.
#'
#' @param env
#' Name of the environment, as in the column \code{Umgebung}, for example
#' \code{"ADN"}.
#'
#' @param cred_path
#' Path of the credentials workbook, for example
#' \code{"C:/Path/To/db_credentials.xlsx"}. Keep it outside the package folder.
#'
#' @return
#' A DBI connection (\code{OdbcConnection}). The functions of the package take
#' it as \code{con} or \code{connection}.
#'
#' @examples
#' \dontrun{
#'
#' cnn <- get_connection("ADN", "C:/Path/To/db_credentials.xlsx")
#' report <- analyze_role_license_report(cnn, "_WIBU_VERKAUF_INNENDIENST_MITARBEITER")
#' DBI::dbDisconnect(cnn)
#'
#' }
#'
#' @export
get_connection <- function(env, cred_path) {

 #p <-"C:/Users/ckam_admin/Documents/RProjects/D365_Admin/db_credentials.xlsx"
  #cred_path <- "C:/Users/Cedric/Documents/RProjects/D365Security/inst/config/report_mapping.xlsx"
  credentials <- readxl::read_excel(path = cred_path,sheet = "AllConnections",col_types = "text")

  row <- credentials |>
    dplyr::filter(Umgebung == env)

  if (nrow(row) == 0) {
    stop(paste("Keine Credentials für Umgebung:", env))
  }

  DBI::dbConnect(
    drv = odbc::odbc(),
    Driver   = "SQL Server",
    server   = row$server,
    database = row$database,
    uid      = row$uid,
    pwd      = row$pwd)


}
