#' Find every place where a role, duty or privilege made in the user interface sits
#'
#' The inventory before UI objects are replaced by their AOT counterparts: a
#' UI role can sit as sub-role in other roles, a UI duty in roles, a UI
#' privilege in duties or directly in roles. The function lists every place of
#' every UI object, with the type of the place, whether the place is itself a
#' UI object, and the AOT counterpart of the same name. Its result is the
#' content of the deliverable D24; see \code{\link{export_ui_inventory}}.
#'
#' @details
#'
#' **UI objects** have a GUID as identifier (\code{\link{is_guid_name}}). Roles
#' come from \code{SECURITYROLE}, duties from \code{SECURITYDUTY}, privileges
#' from \code{SECURITYPRIVILEGE}.
#'
#' **Places.** Sub-roles from \code{SYSTEMSECURITYSUBROLEENTITY}; the own
#' duties of a role, its privileges outside any duty and the privileges of a
#' duty from \code{UserSecGovRelatedObjects}. Only direct places count: a duty
#' inside a sub-role sits in the sub-role, not in the role above it.
#' Identifiers are compared without regard to capitals and shown as the
#' security tables write them.
#'
#' **Counterpart.** The AOT object of the same type and name, as in
#' \code{\link{plan_ui_counterparts}}; whether both are equal says D20 (roles),
#' D22 (duties) and D23 (privileges). \code{pairs} sets counterparts by hand.
#'
#' A UI object that sits nowhere gets one row without a place.
#'
#' @param con
#' Database connection. Result of \code{get_connection()}.
#'
#' @param pairs
#' Optional table with \code{UI_IDENTIFIER} and \code{AOT_IDENTIFIER}:
#' counterparts set by hand, for any type.
#'
#' @return
#' A list:
#' \describe{
#'   \item{\code{Places}}{One row per UI object and place: \code{TYPE}
#'     (\code{ROLE}, \code{DUTY}, \code{PRIVILEGE}), \code{UI_IDENTIFIER},
#'     \code{UI_NAME}, \code{CONTAINER_IDENTIFIER}, \code{CONTAINER_TYPE}
#'     (\code{ROLE} or \code{DUTY}), \code{CONTAINER_NAME},
#'     \code{CONTAINER_UI} (the place is a UI object itself),
#'     \code{COUNTERPART}, \code{COUNTERPART_NAME}, \code{MATCH}
#'     (\code{NAME}, \code{MANUAL}, \code{NONE}, \code{SEVERAL}).}
#'   \item{\code{Objects}}{One row per UI object: \code{TYPE},
#'     \code{UI_IDENTIFIER}, \code{UI_NAME}, \code{PLACES}, \code{COUNTERPART},
#'     \code{COUNTERPART_NAME}, \code{MATCH}.}
#'   \item{\code{Check}}{\code{CREATED}, \code{ROLES}, \code{DUTIES},
#'     \code{PRIVILEGES} (UI objects), \code{PLACES}, \code{NOWHERE},
#'     \code{IN_UI_CONTAINERS}, \code{WITH_COUNTERPART},
#'     \code{WITHOUT_COUNTERPART}, \code{SEVERAL}.}
#' }
#'
#' @examples
#' \dontrun{
#'
#' inventory <- inventory_ui_objects(cnn)
#' table(inventory$Places$TYPE, inventory$Places$CONTAINER_TYPE, useNA = "ifany")
#' export_ui_inventory(inventory, "Data/Deliverables/D24_UI_Inventur.xlsx")
#'
#' }
#'
#' @seealso
#' \code{\link{export_ui_inventory}}
#' \code{\link{plan_ui_counterparts}}
#' \code{\link{plan_role_consolidation}}
#'
#' @export
inventory_ui_objects <- function(con, pairs = NULL) {

  .check_ui_pairs(pairs)
  types        <- c("ROLE", "DUTY", "PRIVILEGE")
  objects      <- dplyr::bind_rows(lapply(types, function(type) .load_security_objects(con, type)))
  pairs        <- .validate_ui_pairs(pairs, objects, "UI roles, duties or privileges")
  counterparts <- dplyr::bind_rows(lapply(types, function(type) .ui_counterparts(objects[objects$TYPE == type, ], pairs)))
  places       <- .ui_places(.load_ui_structure(con, c("role_parts", "duty_privileges", "subroles")))

  located <- .locate_ui_objects(counterparts, places, objects)
  summary <- .ui_inventory_objects(counterparts, located)
  result  <- list(Places = located, Objects = summary, Check = .ui_inventory_check(summary, located))
  message(sprintf("UI objects: %d roles, %d duties, %d privileges at %d places; %d sit nowhere, %d have no AOT counterpart.",
                  result$Check$ROLES, result$Check$DUTIES, result$Check$PRIVILEGES, result$Check$PLACES,
                  result$Check$NOWHERE, result$Check$WITHOUT_COUNTERPART))
  result
}

.UI_TYPE_ORDER <- c("ROLE", "DUTY", "PRIVILEGE")

# Every direct place: sub-roles in roles, duties and privileges in roles, privileges in duties.
.ui_places <- function(structure) {
  parts <- .role_part_keys(structure$role_parts)
  pairs <- .duty_privilege_keys(structure$duty_privileges)
  sub   <- structure$subroles
  dplyr::bind_rows(
    tibble::tibble(CHILD_TYPE = "ROLE", CHILD_KEY = .identifier_key(sub$SECURITYSUBROLEIDENTIFIER),
                   CONTAINER_TYPE = "ROLE", CONTAINER = as.character(sub$SECURITYROLEIDENTIFIER)),
    tibble::tibble(CHILD_TYPE = "DUTY", CHILD_KEY = parts$duties$CHILD_KEY, CONTAINER_TYPE = "ROLE",
                   CONTAINER = as.character(parts$duties$ROLE)),
    tibble::tibble(CHILD_TYPE = "PRIVILEGE", CHILD_KEY = parts$privileges$CHILD_KEY, CONTAINER_TYPE = "ROLE",
                   CONTAINER = as.character(parts$privileges$ROLE)),
    tibble::tibble(CHILD_TYPE = "PRIVILEGE", CHILD_KEY = pairs$PRIVILEGE_KEY, CONTAINER_TYPE = "DUTY",
                   CONTAINER = as.character(pairs$DUTY))
  ) |>
    dplyr::mutate(CONTAINER_KEY = .identifier_key(CONTAINER)) |>
    dplyr::distinct(CHILD_TYPE, CHILD_KEY, CONTAINER_TYPE, CONTAINER_KEY, .keep_all = TRUE)
}

.locate_ui_objects <- function(counterparts, places, objects) {
  located <- dplyr::left_join(counterparts, places, by = c(TYPE = "CHILD_TYPE", UI_KEY = "CHILD_KEY"),
                              relationship = "one-to-many")
  at <- match(paste(located$CONTAINER_TYPE, located$CONTAINER_KEY), paste(objects$TYPE, objects$KEY))
  located <- tibble::tibble(
    TYPE = located$TYPE, UI_IDENTIFIER = located$UI_IDENTIFIER, UI_NAME = located$UI_NAME,
    CONTAINER_IDENTIFIER = dplyr::coalesce(objects$IDENTIFIER[at], located$CONTAINER),
    CONTAINER_TYPE = located$CONTAINER_TYPE, CONTAINER_NAME = objects$NAME[at],
    CONTAINER_UI = ifelse(is.na(located$CONTAINER), NA, is_guid_name(trimws(located$CONTAINER))),
    COUNTERPART = located$AOT_IDENTIFIER, COUNTERPART_NAME = located$AOT_NAME, MATCH = located$MATCH
  )
  located[order(match(located$TYPE, .UI_TYPE_ORDER), located$UI_NAME, located$UI_IDENTIFIER,
                located$CONTAINER_TYPE, located$CONTAINER_IDENTIFIER), ]
}

.ui_inventory_objects <- function(counterparts, located) {
  placed <- located$UI_IDENTIFIER[!is.na(located$CONTAINER_IDENTIFIER)]
  objects <- tibble::tibble(
    TYPE = counterparts$TYPE, UI_IDENTIFIER = counterparts$UI_IDENTIFIER, UI_NAME = counterparts$UI_NAME,
    PLACES = vapply(counterparts$UI_IDENTIFIER, function(id) sum(placed == id), integer(1), USE.NAMES = FALSE),
    COUNTERPART = counterparts$AOT_IDENTIFIER, COUNTERPART_NAME = counterparts$AOT_NAME, MATCH = counterparts$MATCH
  )
  objects[order(match(objects$TYPE, .UI_TYPE_ORDER), objects$UI_NAME, objects$UI_IDENTIFIER), ]
}

.ui_inventory_check <- function(objects, located) {
  list(
    CREATED = Sys.Date(), ROLES = sum(objects$TYPE == "ROLE"), DUTIES = sum(objects$TYPE == "DUTY"),
    PRIVILEGES = sum(objects$TYPE == "PRIVILEGE"), PLACES = sum(!is.na(located$CONTAINER_IDENTIFIER)),
    NOWHERE = sum(objects$PLACES == 0L), IN_UI_CONTAINERS = sum(located$CONTAINER_UI %in% TRUE),
    WITH_COUNTERPART = sum(objects$MATCH %in% c("NAME", "MANUAL")), WITHOUT_COUNTERPART = sum(objects$MATCH == "NONE"),
    SEVERAL = sum(objects$MATCH == "SEVERAL")
  )
}
