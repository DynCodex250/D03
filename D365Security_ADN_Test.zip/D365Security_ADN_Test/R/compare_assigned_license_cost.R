#' Compare the costs of the required and the assigned licenses per user
#'
#' Uses the license report per user of the Power Platform admin center
#' (\code{\link{read_ppac_license_report}}, production only): what the
#' licenses each user requires cost per month, what the assigned ones cost, and
#' the difference. It shows what the missing licenses will add once D365
#' enforces them, and what licenses assigned beyond the need cost.
#'
#' @details
#'
#' **Costs of a set of licenses** as in \code{\link{rank_roles_by_license_cost}}:
#' the first base license in the order Supply Chain Management, Finance,
#' Commerce counts at its base price, every further one at its attach price
#' (SCM Base + Finance Attach + Commerce Attach). Without a base license the
#' dearest light license counts. Commerce, Finance and Supply Chain Management
#' (also Premium) are the base licenses.
#'
#' **Status per user**
#' \describe{
#'   \item{\code{MISSING}}{The report names a missing license.}
#'   \item{\code{MORE_THAN_NEEDED}}{Nothing is missing, and the assigned
#'     licenses cost more than the required ones.}
#'   \item{\code{OK}}{Otherwise.}
#' }
#'
#' @param users
#' The result of \code{\link{read_ppac_license_report}}.
#'
#' @param prices
#' Prices, see \code{\link{read_license_prices}}. \code{NULL} = the estimates
#' of the strategy paper, with a warning.
#'
#' @param export_path
#' Path of an \code{.xlsx} file; \code{NULL} = no file. The sheet Users holds
#' user ids.
#'
#' @param language
#' Language of the workbook: \code{"de"} or \code{"en"}.
#'
#' @return
#' List:
#' \describe{
#'   \item{\code{Check}}{\code{CREATED}, \code{REFRESHED_ON} (date of the
#'     report), \code{USERS}, \code{REQUIRED_COST}, \code{ASSIGNED_COST} (per
#'     month, all users), \code{MISSING_COST} (sum of the positive
#'     differences), \code{SURPLUS_COST} (sum of the negative ones, as a
#'     positive amount), \code{USERS_MISSING}, \code{USERS_MORE_THAN_NEEDED},
#'     \code{PRICES_ESTIMATED}.}
#'   \item{\code{Users}}{One row per user, largest difference first:
#'     \code{USERID}, \code{REQUIRED}, \code{ASSIGNED}, \code{MISSING},
#'     \code{REQUIRED_COST}, \code{ASSIGNED_COST}, \code{DIFFERENCE}
#'     (required minus assigned), \code{STATUS}.}
#'   \item{\code{Licenses}}{One row per license, cheapest first: the number of
#'     users who require it (\code{REQUIRED}), have it (\code{ASSIGNED}) and
#'     miss it (\code{MISSING}).}
#'   \item{\code{Prices}}{The prices used.}
#' }
#'
#' @examples
#' \dontrun{
#'
#' users  <- read_ppac_license_report("Input/Finance_And_Operations_Licensing_Report_20261027_pseudonymized.csv")
#' result <- compare_assigned_license_cost(users, prices = "Data/Lizenzpreise.xlsx",
#'                                         export_path = "Output/Lizenzen_benoetigt_zugewiesen.xlsx")
#' result$Check$MISSING_COST
#' result$Licenses
#'
#' }
#'
#' @seealso
#' \code{\link{read_ppac_license_report}}
#' \code{\link{compare_environment_license_cost}}
#' \code{\link{rank_roles_by_license_cost}}
#'
#' @export
compare_assigned_license_cost <- function(users, prices = NULL, export_path = NULL, language = "de") {

  language <- .check_report_language(language)
  if (!is.null(export_path)) .check_xlsx_path(export_path)
  if (!is.data.frame(users) || !all(c("USERID", "REQUIRED", "ASSIGNED", "MISSING") %in% names(users))) {
    stop("users must be the result of read_ppac_license_report().", call. = FALSE)
  }
  price_table <- .license_prices(prices)

  required <- .split_license_list(users$REQUIRED)
  assigned <- .split_license_list(users$ASSIGNED)
  missing  <- .split_license_list(users$MISSING)
  .check_prices_cover(price_table$prices, unlist(c(required, assigned, missing)))

  cost_of  <- .license_cost_function(price_table$prices, .standard_base_licenses())
  cost     <- function(sets) vapply(sets, function(set) cost_of(.identifier_key(set)), numeric(1), USE.NAMES = FALSE)
  per_user <- tibble::tibble(
    USERID        = users$USERID,
    REQUIRED      = users$REQUIRED,
    ASSIGNED      = users$ASSIGNED,
    MISSING       = users$MISSING,
    REQUIRED_COST = cost(required),
    ASSIGNED_COST = cost(assigned)
  ) |>
    dplyr::mutate(
      DIFFERENCE = round(REQUIRED_COST - ASSIGNED_COST, 2),
      STATUS     = dplyr::case_when(nzchar(MISSING) ~ "MISSING", ASSIGNED_COST > REQUIRED_COST ~ "MORE_THAN_NEEDED",
                                    TRUE ~ "OK")
    ) |>
    dplyr::arrange(dplyr::desc(DIFFERENCE), USERID)

  result <- list(
    Check    = list(CREATED = Sys.Date(), REFRESHED_ON = .latest(users$REFRESHEDON), USERS = nrow(per_user),
                    REQUIRED_COST = sum(per_user$REQUIRED_COST), ASSIGNED_COST = sum(per_user$ASSIGNED_COST),
                    MISSING_COST = sum(pmax(per_user$DIFFERENCE, 0)), SURPLUS_COST = sum(pmax(-per_user$DIFFERENCE, 0)),
                    USERS_MISSING = sum(per_user$STATUS == "MISSING"),
                    USERS_MORE_THAN_NEEDED = sum(per_user$STATUS == "MORE_THAN_NEEDED"),
                    PRICES_ESTIMATED = price_table$estimated),
    Users    = per_user,
    Licenses = .license_user_counts(required, assigned, missing),
    Prices   = price_table$prices
  )

  if (!is.null(export_path)) {
    .export_assigned_license_cost(result, export_path, language)
  }
  check <- result$Check
  message(sprintf(paste("License costs of %d users per month: required %.2f, assigned %.2f. Missing licenses add %.2f",
                        "(%d users), licenses beyond the need cost %.2f (%d users)%s."),
                  check$USERS, check$REQUIRED_COST, check$ASSIGNED_COST, check$MISSING_COST, check$USERS_MISSING,
                  check$SURPLUS_COST, check$USERS_MORE_THAN_NEEDED, if (check$PRICES_ESTIMATED) "; estimated prices" else ""))
  result
}

.split_license_list <- function(texts) {
  lapply(dplyr::coalesce(texts, ""), function(text) {
    names <- trimws(strsplit(text, .LIST_SEPARATOR, fixed = TRUE)[[1]])
    names[nzchar(names)]
  })
}

# The newest of the dates as the report writes them; they sort as text.
.latest <- function(dates) {
  dates <- dates[!is.na(dates)]
  if (length(dates) == 0L) NA_character_ else max(dates)
}

.license_user_counts <- function(required, assigned, missing) {
  licenses <- .order_by_license_priority(unique(as.character(unlist(c(required, assigned, missing)))))
  count    <- function(sets) vapply(licenses, function(name) sum(vapply(sets, `%in%`, logical(1), x = name)), integer(1),
                                    USE.NAMES = FALSE)
  tibble::tibble(LICENSE = licenses, REQUIRED = count(required), ASSIGNED = count(assigned), MISSING = count(missing))
}
