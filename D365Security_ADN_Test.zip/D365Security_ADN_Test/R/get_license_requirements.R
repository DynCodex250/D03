#' Get licensing requirements for D365FO privileges
#'
#' Retrieves licensing information from the
#' `LICENSINGPRIVILEGEREQUIREMENTSDETAILEDVIEW` and returns the
#' relationship between security privileges and the corresponding
#' Dynamics 365 Finance & Operations license requirements.
#'
#' The function can be used to determine whether a privilege is entitled
#' or not entitled for a specific license SKU. This is especially useful
#' when analysing security roles, duties and privileges in the context
#' of license optimization or security governance projects.
#'
#' By default, the function returns the rows of all license SKUs.
#' Optionally, the result can be limited to one SKU and to a set of
#' privilege identifiers.
#'
#' `ENTITLED` and `NOTENTITLED` always refer to the SKU of the row. Analyses
#' that ask "is this privilege covered by license X" (for example
#' `find_privilege_replacement_candidates()`) need the rows of exactly one SKU and must
#' pass `sku_name`.
#'
#' @param con A valid database connection object.
#'
#' @param privilege_identifiers Character vector containing one or more
#'   D365FO privilege identifiers.
#'   If empty, all privileges matching the selected SKU are returned.
#'
#' @param sku_name Character value containing the license SKU name,
#'   for example `"Operations - Activity"`.
#'   Defaults to `NULL`: no SKU filter, the rows of all SKUs are returned.
#'
#' @return A data frame containing:
#' \describe{
#'   \item{IDENTIFIER}{Privilege identifier}
#'   \item{AOTNAME}{AOT object name}
#'   \item{SKUNAME}{License SKU name}
#'   \item{ENTITLED}{Indicates whether the privilege is entitled}
#'   \item{NOTENTITLED}{Indicates whether the privilege is not entitled}
#'   \item{ACCESSLEVEL}{Required access level}
#' }
#'
#' @details
#' The function queries the table
#' `LICENSINGPRIVILEGEREQUIREMENTSDETAILEDVIEW`
#' and joins it with `SECURITYPRIVILEGE` in order to retrieve
#' privilege identifiers that are meaningful in security analyses.
#'
#' Typical use cases:
#' \itemize{
#'   \item Identify the license impact of specific privileges.
#'   \item Validate whether privileges are covered by an
#'         Operations Activity license.
#'   \item Support role cleanup and license optimization projects.
#'   \item Analyse licensing implications of custom security roles.
#' }
#'
#' @examples
#' \dontrun{
#'
#' # Retrieve the license rows of all SKUs
#' get_license_requirements(con)
#'
#' # Only the rows of one SKU
#' get_license_requirements(con, sku_name = "Operations - Activity")
#'
#' # Retrieve specific privileges
#' get_license_requirements(
#'   con,
#'   privilege_identifiers = c(
#'     "WHSLOADPLANNINGWORKBENCHVIEW",
#'     "WHSLOADPLANNINGWORKBENCHMAINTAIN"
#'   )
#' )
#'
#' # Analyse a different license SKU
#' get_license_requirements(
#'   con,
#'   sku_name = "Operations - Task"
#' )
#'
#' }
#'
#' @export
get_license_requirements <- function(
    con,
    privilege_identifiers = character(),
    sku_name = NULL
){
  #=============================================
  # ABFRAGE DEFINIEREN
  #=============================================

  query <- "
SELECT
    SP.IDENTIFIER,
    SP.NAME AS PRIVILEGE,
    LPRDV.AOTNAME,
    LPRDV.SKURECID,
    LPRDV.SKUNAME,
    LPRDV.PRIORITY,
    LPRDV.GROUPNAME,
    LPRDV.ENTITLED,
    LPRDV.NOTENTITLED,
    LPRDV.ACCESSLEVEL
FROM LICENSINGPRIVILEGEREQUIREMENTSDETAILEDVIEW LPRDV
INNER JOIN SECURITYPRIVILEGE SP
    ON SP.RECID = LPRDV.SECURITYPRIVILEGE
WHERE 1 = 1
"
  #=============================================
  #  FILTER HINZUFÜGEN
  #=============================================


  if(

    !is.null(sku_name) &&
    length(sku_name) > 0 &&
    nzchar(sku_name)

  ){

    query <- paste0(

      query,

      "\nAND LPRDV.SKUNAME = '",

      gsub("'", "''", sku_name),

      "'"

    )

  }

  if(length(privilege_identifiers) > 0){

    privilege_list <- paste0(

      "'",

      gsub(
        "'",
        "''",
        privilege_identifiers
      ),

      "'",

      collapse = ","

    )

    query <- paste0(

      query,

      "\nAND SP.IDENTIFIER IN (",

      privilege_list,

      ")"

    )

  }
  #=============================================
  # ABFRAGE AUSFÜHREN
  #=============================================

  DBI::dbGetQuery(
    con,
    query
  )

}
