#' Compare the license data of the tool with exports from D365FO
#'
#' Tests a result of the license tools against the object lists that D365FO
#' exports from the license view of a role. Object by object it checks
#' whether both sides know the object, whether the access level is the same
#' and whether each license covers the object on both sides.
#'
#' @details
#'
#' **Exports from D365FO**
#'
#' In the license view of the role, select one license, open its object list
#' and export it to Excel. One file per license; every file lists all objects
#' of the role with the columns type, AOT name, child name, access level,
#' entitled, not entitled and not required. The columns are read by position,
#' so the language of the user interface does not matter.
#'
#' The license is not written inside a file. Either pass a folder and let the
#' file names say it: the text after the last \code{_} is the license, as in
#' \code{..._Objects_Commerce.xlsx}; \code{TM}, \code{Activity} and \code{SCM}
#' stand for Team Members, Operations - Activity and Supply Chain Management.
#' Or pass a vector of files named by license:
#' \code{c("Finance Premium" = "C:/.../export.xlsx")}.
#'
#' All files must come from the same role and environment. The function stops
#' when they do not list the same objects.
#'
#' A license that covers no object of the role is compared like any other.
#' The tool result does not name such a license, so the function warns: the
#' name is either that license or a file name that is not a license.
#'
#' **Result of the tool**
#'
#' \code{tool_result} can be the workbook written by
#' \code{\link{export_role_license_report}} (its sheet "All objects") or by
#' \code{\link{export_role_license_decision}} (its sheet
#' \code{EntryPointDrivers}), or the result of
#' \code{\link{analyze_role_license_report}},
#' \code{\link{analyze_role_license_decision}} or
#' \code{\link{get_role_license_drivers}} still in memory.
#'
#' **What is compared**
#'
#' Objects are compared by their AOT name, because the tool knows each name
#' once. D365FO lists some names several times, with different types or child
#' objects. Such a name is compared by its strictest entry: the highest
#' access level, and a license covers the name only when it covers every
#' entry. \code{D365_ENTRIES} in \code{Objects} says how many entries a name
#' has.
#'
#' \enumerate{
#'   \item The object names of the role on both sides.
#'   \item The access level of every name both sides know.
#'   \item For every exported license: does it cover the object? Objects
#'     whose access level differs are left out here, because another access
#'     level means another license.
#'   \item For every exported license: does it cover the whole role?
#' }
#'
#' @param tool_result
#' Path of a workbook written by the tool, or a result of the tool in memory.
#'
#' @param d365_exports
#' Folder with one D365FO export per license, or a character vector of export
#' files named by license. The folder must exist. In a folder, the text after
#' the last \code{_} of each file name is the license; a folder for one role
#' looks like this:
#' \preformatted{
#' Exported_by_role/_WIBU_VERKAUF_INNENDIENST_MITARBEITER/
#'   DynamicsExport_..._Objects_Activity.xlsx    Operations - Activity
#'   DynamicsExport_..._Objects_Commerce.xlsx    Commerce
#'   DynamicsExport_..._Objects_Finance.xlsx     Finance
#'   DynamicsExport_..._Objects_SCM.xlsx         Supply Chain Management
#'   DynamicsExport_..._Objects_TM.xlsx          Team Members
#' }
#' One file per license; licenses without a file are not tested. Lock files of
#' Excel (\code{~$...xlsx}) are ignored. As a vector:
#' \code{c(Commerce = "C:/.../a.xlsx", "Team Members" = "C:/.../b.xlsx")}.
#'
#' @param export_path
#' Path of an \code{.xlsx} file to write the comparison to. \code{NULL} =
#' do not write a file. The file must not be the tool workbook or one of the
#' exports.
#'
#' @param overwrite
#' \code{TRUE} = replace an existing file at \code{export_path}. Default:
#' \code{FALSE}, the function stops when the file exists.
#'
#' @return
#'
#' List:
#'
#' \describe{
#'   \item{\code{Passed}}{\code{TRUE} when no check has the result
#'     \code{"DIFFERENT"}: both sides agree on the access level and on what
#'     every exported license covers.}
#'   \item{\code{Summary}}{One row per check with \code{COMPARED},
#'     \code{MATCHING}, \code{DIFFERENT} and \code{RESULT}: \code{"ok"},
#'     \code{"DIFFERENT"}, or \code{"note"} for a difference that cannot
#'     change a license statement (objects only one side knows that every
#'     exported license covers).}
#'   \item{\code{Licenses}}{One row per license: its export file, the objects
#'     it does not cover on each side, and how many objects agree.
#'     \code{D365_NOT_ENTITLED_ROWS} is the number D365FO shows as "not
#'     entitled".}
#'   \item{\code{Differences}}{One row per object and difference, with the
#'     value of D365FO and the value of the tool.}
#'   \item{\code{OnlyInD365}, \code{OnlyInTool}}{Objects only one side
#'     knows. \code{D365_NOT_COVERED_BY} names the exported licenses that do
#'     not cover an object; empty means every exported license covers it.}
#'   \item{\code{Objects}}{Every compared object with access level and
#'     coverage per license on both sides.}
#' }
#'
#' @examples
#' \dontrun{
#'
#' comparison <- compare_role_license_with_d365(
#'   tool_result  = "Data/D365FO_License_Report__WIBU_VERKAUF_INNENDIENST_MITARBEITER.xlsx",
#'   d365_exports = "C:/Exports/_WIBU_Verkauf_Innendienst_Mitarbeiter",
#'   export_path  = "Data/Comparison__WIBU_VERKAUF_INNENDIENST_MITARBEITER.xlsx"
#' )
#'
#' comparison$Passed
#' comparison$Summary
#' comparison$Differences
#'
#' }
#'
#' @seealso
#' \code{\link{export_role_license_report}}
#' \code{\link{export_role_license_decision}}
#'
#' @export
compare_role_license_with_d365 <- function(
  tool_result,
  d365_exports,
  export_path = NULL,
  overwrite   = FALSE
) {

  tool <- .tool_license_objects(tool_result)
  d365 <- .read_d365_license_exports(d365_exports)
  .check_comparison_path(export_path, overwrite, tool_result, d365$files)
  d365 <- .match_d365_licenses(d365, tool)

  by_name  <- .d365_objects_by_name(d365)
  compared <- .pair_license_objects(by_name$objects, tool)
  coverage <- .compare_license_coverage(compared, by_name$coverage)
  licenses <- .compare_licenses(coverage, by_name$coverage, d365$licenses, tool)
  objects  <- .compared_objects_table(compared, coverage, licenses$LICENSE)
  summary  <- .comparison_summary(by_name, tool, compared, licenses, objects)

  comparison <- list(
    Passed      = !.COMPARISON_DIFFERENT %in% summary$RESULT,
    Summary     = summary,
    Licenses    = licenses,
    Differences = .comparison_differences(compared, coverage),
    OnlyInD365  = .describe_d365_objects(d365, tool),
    OnlyInTool  = .describe_tool_objects(tool[!tool$OBJECT_KEY %in% by_name$objects$OBJECT_KEY, ]),
    Objects     = objects
  )

  if (!is.null(export_path)) {
    .write_license_comparison(comparison, export_path)
  }

  comparison
}

.COMPARISON_OK        <- "ok"
.COMPARISON_NOTE      <- "note"
.COMPARISON_DIFFERENT <- "DIFFERENT"

# The comparison workbook must not take the place of another file: not of the
# tool workbook or an export it was built from, and not of any existing file
# unless the caller says so. A mistyped path could otherwise destroy a report
# or the key file of the pseudonyms.
.check_comparison_path <- function(export_path, overwrite, tool_result, d365_files) {

  if (is.null(export_path)) {
    return(invisible(export_path))
  }

  if (!.is_single_string(export_path) || !grepl("[.]xlsx$", export_path, ignore.case = TRUE)) {
    stop("export_path must be the path of one .xlsx file.")
  }
  if (!is.logical(overwrite) || length(overwrite) != 1L || is.na(overwrite)) {
    stop("overwrite must be TRUE or FALSE.")
  }

  same_file <- function(path) {
    paths <- tolower(normalizePath(c(export_path, path), winslash = "/", mustWork = FALSE))
    paths[[1]] == paths[[2]]
  }
  inputs <- c(if (.is_single_string(tool_result)) tool_result, unname(d365_files))

  if (any(vapply(inputs, same_file, logical(1)))) {
    stop("export_path names a file the comparison reads. Choose another file for the result.")
  }
  if (file.exists(export_path) && !overwrite) {
    stop("export_path exists already: ", export_path, ". Pass overwrite = TRUE to replace it.")
  }

  invisible(export_path)
}

.COVERED_LABELS <- c("covered", "not covered")

# Sheet of each table in the comparison workbook.
.COMPARISON_SHEETS <- c(
  Summary     = "Summary",
  Licenses    = "Licenses",
  Differences = "Differences",
  OnlyInD365  = "Only in D365",
  OnlyInTool  = "Only in tool",
  Objects     = "Objects"
)

# Columns of the sheet "All objects" of the report workbook, by position.
.ALL_OBJECTS_COLUMNS <- c(object = 1L, type = 2L, access = 3L, covered_by = 6L)

.DRIVER_OBJECT_COLUMNS <- c("ENTRYPOINT", "ENTRYPOINTTYPE", "ACCESSLEVEL", "LICENSE_STATUS", "COVERING_SKUS")

# =============================================================================
# Objects as the tool knows them: one row per name, with the strictest access
# and the licenses that cover every access to the object.
# =============================================================================

.tool_license_objects <- function(tool_result) {

  objects <- if (.is_single_string(tool_result)) {
    .tool_objects_from_workbook(tool_result)
  } else if (is.data.frame(tool_result)) {
    .tool_objects_from_drivers(tool_result)
  } else if (is.list(tool_result) && is.data.frame(tool_result$ObjectNeeds)) {
    .tool_objects_from_needs(tool_result$ObjectNeeds)
  } else if (is.list(tool_result) && is.data.frame(tool_result$EntryPointDrivers)) {
    .tool_objects_from_drivers(tool_result$EntryPointDrivers)
  } else {
    stop(
      "tool_result must be the path of a workbook written by export_role_license_report() ",
      "or export_role_license_decision(), or the result of analyze_role_license_report(), ",
      "analyze_role_license_decision() or get_role_license_drivers()."
    )
  }

  objects <- .one_tool_row_per_name(objects)

  if (nrow(objects) == 0L) {
    stop("tool_result holds no object with license data; there is nothing to compare.")
  }

  objects
}

# A name listed twice is taken by its strictest entry, as on the D365FO side:
# the highest access, and only the licenses that cover every entry.
.one_tool_row_per_name <- function(objects) {
  objects |>
    dplyr::filter(!is.na(OBJECT_KEY), OBJECT_KEY != "") |>
    dplyr::group_by(OBJECT_KEY) |>
    dplyr::summarise(
      OBJECT      = dplyr::first(OBJECT),
      TOOL_TYPE   = dplyr::first(TOOL_TYPE),
      ACCESS_TOOL = .max_or_na(ACCESS_TOOL),
      COVERED_BY  = list(Reduce(intersect, COVERED_BY)),
      .groups     = "drop"
    )
}

.tool_objects_from_workbook <- function(path) {

  if (!file.exists(path)) {
    stop("tool_result: file not found: ", path)
  }

  sheets       <- readxl::excel_sheets(path)
  object_sheet <- intersect(.all_objects_sheet_names(), sheets)

  if ("EntryPointDrivers" %in% sheets) {
    return(.tool_objects_from_drivers(readxl::read_excel(path, sheet = "EntryPointDrivers", col_types = "text")))
  }
  if (length(object_sheet) > 0L) {
    return(.tool_objects_from_object_sheet(readxl::read_excel(path, sheet = object_sheet[[1]], col_types = "text")))
  }

  stop(
    "tool_result: ", basename(path), " has neither the sheet EntryPointDrivers nor the ",
    "sheet with all objects. It must be written by export_role_license_decision() or by ",
    "the current export_role_license_report()."
  )
}

# Name of the sheet with all objects in every language of the report.
.all_objects_sheet_names <- function() {
  vapply(
    .report_languages(),
    function(language) .report_texts(language)$sheets_role[[6]],
    character(1),
    USE.NAMES = FALSE
  )
}

.tool_objects_from_drivers <- function(drivers) {

  .check_required_columns(drivers, .DRIVER_OBJECT_COLUMNS, "tool_result")

  drivers |>
    dplyr::filter(
      LICENSE_STATUS %in% c(.LICENSE_LICENSED, .LICENSE_NOT_ENTITLED),
      !is.na(ENTRYPOINT)
    ) |>
    dplyr::mutate(
      OBJECT_KEY    = toupper(trimws(ENTRYPOINT)),
      ACCESSLEVEL   = suppressWarnings(as.numeric(ACCESSLEVEL)),
      COVERING_SKUS = dplyr::coalesce(as.character(COVERING_SKUS), "")
    ) |>
    dplyr::group_by(OBJECT_KEY) |>
    dplyr::summarise(
      OBJECT      = dplyr::first(ENTRYPOINT),
      TOOL_TYPE   = dplyr::first(ENTRYPOINTTYPE[!is.na(ENTRYPOINTTYPE)]),
      ACCESS_TOOL = .max_or_na(ACCESSLEVEL),
      COVERED_BY  = list(Reduce(intersect, .split_skus(COVERING_SKUS))),
      .groups     = "drop"
    )
}

.tool_objects_from_needs <- function(object_needs) {

  .check_required_columns(
    object_needs, c("ENTRYPOINT", "ENTRYPOINTTYPE", "ACCESSLEVEL", "COVERED_BY"), "tool_result"
  )

  tibble::tibble(
    OBJECT_KEY  = toupper(trimws(object_needs$ENTRYPOINT)),
    OBJECT      = object_needs$ENTRYPOINT,
    TOOL_TYPE   = object_needs$ENTRYPOINTTYPE,
    ACCESS_TOOL = as.numeric(object_needs$ACCESSLEVEL),
    COVERED_BY  = .split_skus(dplyr::coalesce(as.character(object_needs$COVERED_BY), ""))
  )
}

.tool_objects_from_object_sheet <- function(sheet) {

  if (ncol(sheet) < max(.ALL_OBJECTS_COLUMNS)) {
    stop("tool_result: the sheet with all objects has fewer columns than expected.")
  }

  column <- function(name) sheet[[.ALL_OBJECTS_COLUMNS[[name]]]]

  tibble::tibble(
    OBJECT_KEY  = toupper(trimws(column("object"))),
    OBJECT      = column("object"),
    TOOL_TYPE   = column("type"),
    ACCESS_TOOL = as.numeric(match(tolower(column("access")), tolower(.ACCESS_LABELS))),
    COVERED_BY  = .split_skus(dplyr::coalesce(column("covered_by"), ""))
  )
}

# =============================================================================
# Comparison
# =============================================================================

# The licenses of the exports in the spelling of the tool. The tool result
# names only licenses that cover at least one object, so a name it does not
# know is either a license that covers nothing in this role or a wrong file
# name. Both are compared; the warning tells the two apart.
.match_d365_licenses <- function(d365, tool) {

  known    <- unique(unlist(tool$COVERED_BY))
  given    <- d365$licenses$LICENSE
  found    <- match(tolower(given), tolower(known))
  licenses <- ifelse(is.na(found), given, known[found])

  if (anyNA(found)) {
    warning(
      "The tool result names no object that '", paste(given[is.na(found)], collapse = "', '"),
      "' covers. If this is a license, the tool says it covers nothing in this role and it ",
      "is compared as such. If it is not, let the export file names end in _<license>.xlsx ",
      "or pass d365_exports as a vector named by license. The tool names: ",
      paste(sort(known), collapse = .LIST_SEPARATOR), ".",
      call. = FALSE
    )
  }
  if (anyDuplicated(licenses) > 0L) {
    stop(
      "d365_exports holds two exports for the same license: ",
      paste(unique(licenses[duplicated(licenses)]), collapse = .LIST_SEPARATOR)
    )
  }

  list(
    objects  = d365$objects,
    coverage = dplyr::mutate(d365$coverage, LICENSE = licenses[match(LICENSE, given)]),
    licenses = dplyr::mutate(d365$licenses, LICENSE = licenses)
  )
}

# D365FO per object name, as the tool sees an object: the strictest access of
# all entries, and a license covers the name only when it covers every entry.
.d365_objects_by_name <- function(d365) {

  objects <- d365$objects |>
    dplyr::group_by(OBJECT_KEY) |>
    dplyr::summarise(
      OBJECT       = dplyr::first(OBJECT),
      D365_TYPE    = .collapse_sorted(D365_TYPE),
      D365_ENTRIES = dplyr::n(),
      ACCESS_D365  = max(ACCESS_D365),
      .groups      = "drop"
    )

  coverage <- d365$coverage |>
    dplyr::inner_join(dplyr::select(d365$objects, ROW_KEY, OBJECT_KEY), by = "ROW_KEY") |>
    dplyr::group_by(OBJECT_KEY, LICENSE) |>
    dplyr::summarise(D365_COVERS = all(D365_COVERS), .groups = "drop")

  list(objects = objects, coverage = coverage)
}

# The names both sides know, with the access level of each side.
.pair_license_objects <- function(d365_names, tool) {
  d365_names |>
    dplyr::inner_join(dplyr::select(tool, -OBJECT), by = "OBJECT_KEY") |>
    dplyr::mutate(ACCESS_AGREES = !is.na(ACCESS_TOOL) & ACCESS_D365 == ACCESS_TOOL)
}

# One row per compared object and license.
.compare_license_coverage <- function(compared, d365_coverage) {

  rows <- compared |>
    dplyr::select(OBJECT_KEY, OBJECT, D365_TYPE, ACCESS_AGREES, COVERED_BY) |>
    dplyr::inner_join(d365_coverage, by = "OBJECT_KEY")

  tool_covers <- vapply(
    seq_len(nrow(rows)),
    function(row) rows$LICENSE[[row]] %in% rows$COVERED_BY[[row]],
    logical(1)
  )

  dplyr::mutate(rows, TOOL_COVERS = tool_covers, AGREES = D365_COVERS == TOOL_COVERS)
}

.compare_licenses <- function(coverage, d365_coverage, d365_licenses, tool) {

  agreement <- coverage |>
    dplyr::filter(ACCESS_AGREES) |>
    dplyr::group_by(LICENSE) |>
    dplyr::summarise(
      COMPARED         = dplyr::n(),
      MATCHING         = sum(AGREES),
      D365_ONLY_COVERS = sum(D365_COVERS & !TOOL_COVERS),
      TOOL_ONLY_COVERS = sum(!D365_COVERS & TOOL_COVERS),
      .groups          = "drop"
    )
  d365_not_covered <- d365_coverage |>
    dplyr::group_by(LICENSE) |>
    dplyr::summarise(D365_NOT_COVERED = sum(!D365_COVERS), .groups = "drop")

  tool_not_covered <- function(license) {
    sum(!vapply(tool$COVERED_BY, function(skus) license %in% skus, logical(1)))
  }

  d365_licenses |>
    dplyr::rename(D365_NOT_ENTITLED_ROWS = D365_NOT_ENTITLED) |>
    dplyr::left_join(d365_not_covered, by = "LICENSE") |>
    dplyr::mutate(
      TOOL_NOT_COVERED = vapply(LICENSE, tool_not_covered, integer(1), USE.NAMES = FALSE),
      D365_COVERS_ROLE = D365_NOT_COVERED == 0L,
      TOOL_COVERS_ROLE = TOOL_NOT_COVERED == 0L
    ) |>
    dplyr::left_join(agreement, by = "LICENSE") |>
    dplyr::mutate(
      dplyr::across(c(COMPARED, MATCHING, D365_ONLY_COVERS, TOOL_ONLY_COVERS), function(x) dplyr::coalesce(x, 0L)),
      RESULT = dplyr::if_else(MATCHING == COMPARED, .COMPARISON_OK, .COMPARISON_DIFFERENT)
    )
}

# Every compared object with access and coverage per license on both sides.
.compared_objects_table <- function(compared, coverage, licenses) {

  flags <- coverage |>
    dplyr::select(OBJECT_KEY, LICENSE, D365 = D365_COVERS, TOOL = TOOL_COVERS) |>
    tidyr::pivot_wider(
      names_from = LICENSE, values_from = c(D365, TOOL), names_glue = "{.value}: {LICENSE}"
    )
  licenses_agree <- coverage |>
    dplyr::group_by(OBJECT_KEY) |>
    dplyr::summarise(LICENSES_AGREE = all(AGREES), .groups = "drop")

  flag_columns <- as.vector(rbind(paste0("D365: ", licenses), paste0("TOOL: ", licenses)))

  compared |>
    dplyr::left_join(flags, by = "OBJECT_KEY") |>
    dplyr::left_join(licenses_agree, by = "OBJECT_KEY") |>
    dplyr::mutate(
      TYPE        = D365_TYPE,
      ACCESS_D365 = .access_label(ACCESS_D365),
      ACCESS_TOOL = .access_label(ACCESS_TOOL),
      AGREES      = ACCESS_AGREES & dplyr::coalesce(LICENSES_AGREE, TRUE)
    ) |>
    dplyr::select(
      OBJECT, TYPE, D365_ENTRIES, ACCESS_D365, ACCESS_TOOL, dplyr::any_of(flag_columns), AGREES
    ) |>
    dplyr::arrange(AGREES, OBJECT)
}

.comparison_differences <- function(compared, coverage) {

  unknown_if_missing <- function(label) dplyr::coalesce(label, "unknown")
  covered_label      <- function(covers) .COVERED_LABELS[ifelse(covers, 1L, 2L)]

  access <- compared |>
    dplyr::filter(!ACCESS_AGREES) |>
    dplyr::transmute(
      OBJECT, TYPE = D365_TYPE, CHECK = "Access level",
      D365 = unknown_if_missing(.access_label(ACCESS_D365)),
      TOOL = unknown_if_missing(.access_label(ACCESS_TOOL))
    )
  licenses <- coverage |>
    dplyr::filter(ACCESS_AGREES, !AGREES) |>
    dplyr::transmute(
      OBJECT, TYPE = D365_TYPE, CHECK = paste("Covered by", LICENSE),
      D365 = covered_label(D365_COVERS), TOOL = covered_label(TOOL_COVERS)
    )

  dplyr::arrange(dplyr::bind_rows(access, licenses), OBJECT, CHECK)
}

# Entries of D365FO whose name the tool does not know. The licenses that do
# not cover an entry show at once whether it matters for the license need.
.describe_d365_objects <- function(d365, tool) {

  not_covered_by <- d365$coverage |>
    dplyr::group_by(ROW_KEY) |>
    dplyr::summarise(
      D365_NOT_COVERED_BY = paste(LICENSE[!D365_COVERS], collapse = .LIST_SEPARATOR),
      .groups             = "drop"
    )

  d365$objects |>
    dplyr::filter(!OBJECT_KEY %in% tool$OBJECT_KEY) |>
    dplyr::left_join(not_covered_by, by = "ROW_KEY") |>
    dplyr::transmute(
      OBJECT, TYPE = D365_TYPE, CHILD_NAME, ACCESS = .access_label(ACCESS_D365), D365_NOT_COVERED_BY
    ) |>
    dplyr::arrange(OBJECT, TYPE, CHILD_NAME)
}

.describe_tool_objects <- function(tool_objects) {
  tool_objects |>
    dplyr::transmute(
      OBJECT, TYPE = TOOL_TYPE, ACCESS = .access_label(ACCESS_TOOL),
      COVERED_BY = vapply(COVERED_BY, paste, character(1), collapse = .SKU_SEPARATOR)
    ) |>
    dplyr::arrange(OBJECT)
}

# =============================================================================
# Summary and workbook
# =============================================================================

# `harmless` marks a difference that cannot change a license statement; it is
# reported as a note and does not fail the comparison.
.comparison_row <- function(check, compared, matching, note = "", harmless = FALSE) {

  result <- if (compared == matching) {
    .COMPARISON_OK
  } else if (harmless) {
    .COMPARISON_NOTE
  } else {
    .COMPARISON_DIFFERENT
  }

  tibble::tibble(
    CHECK     = check,
    COMPARED  = as.integer(compared),
    MATCHING  = as.integer(matching),
    DIFFERENT = as.integer(compared - matching),
    RESULT    = result,
    NOTE      = note
  )
}

# The names only one side knows, and how many of them matter: a name every
# exported license covers cannot change what a license covers.
.one_sided_names <- function(by_name, tool, licenses) {

  only_d365   <- setdiff(by_name$objects$OBJECT_KEY, tool$OBJECT_KEY)
  only_tool   <- tool[!tool$OBJECT_KEY %in% by_name$objects$OBJECT_KEY, ]
  not_covered <- by_name$coverage$OBJECT_KEY[!by_name$coverage$D365_COVERS]

  tool_matters <- !vapply(only_tool$COVERED_BY, function(skus) all(licenses %in% skus), logical(1))

  list(
    only_d365    = length(only_d365),
    d365_matters = length(intersect(only_d365, not_covered)),
    only_tool    = nrow(only_tool),
    tool_matters = sum(tool_matters)
  )
}

.object_names_row <- function(by_name, tool, compared, licenses) {

  one_sided <- .one_sided_names(by_name, tool, licenses)

  .comparison_row(
    "Objects of the role, by name",
    length(union(by_name$objects$OBJECT_KEY, tool$OBJECT_KEY)), nrow(compared),
    sprintf(
      paste(
        "D365: %d names, tool: %d names; only in D365: %d (%d not covered by every",
        "exported license); only in tool: %d (%d not covered by every exported license)"
      ),
      nrow(by_name$objects), nrow(tool),
      one_sided$only_d365, one_sided$d365_matters, one_sided$only_tool, one_sided$tool_matters
    ),
    harmless = one_sided$d365_matters + one_sided$tool_matters == 0L
  )
}

.comparison_summary <- function(by_name, tool, compared, licenses, objects) {

  covering <- function(covers) {
    if (any(covers)) paste(licenses$LICENSE[covers], collapse = .LIST_SEPARATOR) else "none"
  }
  license_rows <- lapply(seq_len(nrow(licenses)), function(row) {
    .comparison_row(
      paste("Covered by", licenses$LICENSE[[row]]),
      licenses$COMPARED[[row]], licenses$MATCHING[[row]],
      "objects with the same access level on both sides"
    )
  })

  dplyr::bind_rows(
    .object_names_row(by_name, tool, compared, licenses$LICENSE),
    .comparison_row(
      "Access level", nrow(compared), sum(compared$ACCESS_AGREES),
      sprintf(
        "%d name(s) that D365 lists several times are compared by their strictest entry",
        sum(compared$D365_ENTRIES > 1L)
      )
    ),
    dplyr::bind_rows(license_rows),
    .comparison_row(
      "License covers the whole role",
      nrow(licenses), sum(licenses$D365_COVERS_ROLE == licenses$TOOL_COVERS_ROLE),
      sprintf("D365: %s; tool: %s", covering(licenses$D365_COVERS_ROLE), covering(licenses$TOOL_COVERS_ROLE))
    ),
    .comparison_row(
      "Objects where access level and all licenses agree", nrow(objects), sum(objects$AGREES)
    )
  )
}

.write_license_comparison <- function(comparison, export_path) {

  if (!dir.exists(dirname(export_path))) {
    dir.create(dirname(export_path), recursive = TRUE)
  }

  workbook <- openxlsx::createWorkbook(creator = .WORKBOOK_CREATOR)
  styles   <- .report_styles(.report_texts())

  for (table in names(.COMPARISON_SHEETS)) {
    data <- comparison[[table]]
    .add_table_sheet(
      workbook, .COMPARISON_SHEETS[[table]],
      list(data = data, highlight = .rows_with_difference(data), widths = c(48, rep(24, ncol(data) - 1L))),
      styles
    )
  }

  openxlsx::saveWorkbook(workbook, export_path, overwrite = TRUE)

  invisible(export_path)
}

# Rows of a comparison table that report a difference.
.rows_with_difference <- function(data) {

  if ("RESULT" %in% names(data)) {
    return(data$RESULT == .COMPARISON_DIFFERENT)
  }
  if ("AGREES" %in% names(data)) {
    return(!data$AGREES)
  }

  rep(FALSE, nrow(data))
}
