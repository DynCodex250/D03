#' Export a role from the database as role XML
#'
#' Reads a role from the table \code{UserSecGovRelatedObjects} and writes it
#' as an AOT role file (\code{AxSecurityRole}), the format of a Visual Studio
#' project, and packs it into a zip. The role keeps its structure: its own
#' duties, privileges, sub-roles and direct access permissions; what comes
#' through a sub-role stays in the sub-role.
#'
#' @details
#'
#' **Names.** The role and its sub-roles are written in the spelling of the
#' table \code{SECURITYROLE}; \code{UserSecGovRelatedObjects} holds them in
#' capitals. When \code{SECURITYROLE} cannot be read, the function warns and
#' keeps the capitals; D365 does not tell the two apart.
#'
#' **Files.** The XML goes to \code{<output_folder>/AxSecurityRole/<name>.xml},
#' the folder layout of a model. The zip \code{<output_folder>/<name>.zip}
#' holds that folder; unpacked into a model folder, Visual Studio finds the
#' role. An existing file of the same name is replaced.
#'
#' **Sub-roles of the user interface.** A role created in the user interface
#' (its identifier is a GUID) exists only in the database; Visual Studio cannot
#' resolve it as a sub-role. When an AOT role of the same name exists
#' (\code{\link{load_role_mapping}}), it is written in place of the UI role.
#' Both are compared first (\code{\link{compare_role_versions}}); the function
#' warns when they differ, because the users of the role then get other rights:
#' fewer when the UI role grants more, more when the AOT role does. A UI role
#' without, or with several, AOT roles of the same name stays as it is, with a
#' warning: nothing is created blindly. So does a UI role whose comparison
#' fails. When the replacement names one AOT role twice, it is written once.
#' Each comparison takes about half a minute. \code{subroles} in the result
#' lists every sub-role with what was done; see \code{\link{describe_subroles}}
#' for the meaning of \code{NOTE}. A role that would hold itself as a sub-role
#' stops with an error, for example a UI copy that holds the AOT role, written
#' under the name of that AOT role; \code{\link{export_merged_role_xml}} brings
#' the two together.
#'
#' **Import in the browser.** The role is also written for the import in the
#' browser, twice: \code{<output_folder>/SecurityGovernance/<name>.xml} as the
#' security governance exports it, and
#' \code{<output_folder>/SecurityConfiguration/<name>.xml} as the security
#' configuration exports it (System administration > Security > Security
#' configuration, Data > Export); see
#' \code{\link{create_d365fo_security_configuration_xml}}. Both hold the same
#' role as the AOT file, with the same sub-roles, and stay outside the zip,
#' which belongs into a model folder. The AOT role under its own name goes
#' into the list of changed roles: an import replaces that role with this
#' version. A copy under another name (\code{name}), or a role of the user
#' interface, goes into the list of new roles. The format follows exports of
#' D365; an import of such a file has not been tested in ADN yet, nor whether
#' the import accepts a readable name for a new role.
#'
#' @param con
#' Database connection. Result of \code{get_connection()}.
#'
#' @param role_identifier
#' AOT name or GUID of the role.
#'
#' @param output_folder
#' Folder for the XML and the zip; it is created when missing.
#'
#' @param name
#' AOT name of the written role, for a copy under another name. \code{NULL} =
#' the name of the role. No whitespace.
#'
#' @param label
#' Label of the written role. \code{NULL} = the label of the role.
#'
#' @param zip
#' \code{TRUE} = also write the zip.
#'
#' @param replace_ui_subroles
#' \code{TRUE} (default) = write the AOT role of the same name in place of a
#' UI sub-role, see Details. \code{FALSE} = keep every sub-role as it is.
#'
#' @param browser_files
#' \code{TRUE} (default) = also write the two files for the import in the
#' browser, see Details.
#'
#' @return
#' Invisibly a list with \code{xml} (path of the XML), \code{zip} (path of the
#' zip, \code{NA} without zip), \code{security_governance} and
#' \code{security_configuration} (paths of the files for the import in the
#' browser, \code{NA} without them), \code{role} (the role as written) and
#' \code{subroles}: one row per sub-role with \code{SUBROLE} (as the role
#' holds it), \code{KIND} (\code{"AOT"} or \code{"UI"}), \code{COUNTERPART}
#' (the AOT role written in its place, or \code{NA}) and \code{NOTE}, for
#' example:
#' \preformatted{
#' SUBROLE                               KIND COUNTERPART NOTE
#' TradeSalesClerk                       AOT  NA          AOT_ROLE
#' 53FAE280-022E-4A30-A5BA-9E79AF7418BA  UI   NA          NO_COUNTERPART
#' }
#'
#' @examples
#' \dontrun{
#'
#' result <- export_role_xml(
#'   cnn,
#'   role_identifier = "_WIBU_VERKAUF_INNENDIENST_LEITUNG",
#'   output_folder   = "Output/Roles"
#' )
#' result$zip
#'
#' # The role of the user interface as a copy under an AOT name
#' export_role_xml(
#'   cnn, "E5BD996C-D492-4533-B562-F207DCC0B214", "Output/Roles",
#'   name = "_WIBU_Verkauf_Innendienst_Leitung_UI", label = "_WIBU Verkauf Innendienst Leitung (UI)"
#' )
#'
#' }
#'
#' @seealso
#' \code{\link{load_sql_security_role_objects_detailed}}
#' \code{\link{convert_sql_to_security_role}}
#' \code{\link{create_d365fo_role_xml}}
#'
#' @export
export_role_xml <- function(con, role_identifier, output_folder, name = NULL, label = NULL, zip = TRUE,
                            replace_ui_subroles = TRUE, browser_files = TRUE) {

  if (!.is_single_string(role_identifier)) {
    stop("role_identifier must name one role: the AOT name, or the GUID of a role created in the user interface.",
         call. = FALSE)
  }
  if (!.is_single_string(output_folder)) {
    stop("output_folder must be the path of one folder.", call. = FALSE)
  }
  if (!is.null(name)) .check_aot_name(name)

  role <- .load_role_to_export(con, role_identifier)
  stored_name     <- role$role_name
  role$role_name  <- if (is.null(name)) role$role_name else name
  role$role_label <- if (is.null(label)) role$role_label else label
  .check_aot_name(role$role_name)

  resolved <- .resolve_role_subroles(con, role, replace_ui_subroles)
  role     <- resolved$role
  files    <- .write_role_files(role, output_folder, zip, browser_files, stored_name)

  message(sprintf(
    "Role %s written: %d duties, %d privileges, %d sub-roles, %d direct access permissions.",
    role$role_name, length(role$duties), length(role$privileges), length(role$subroles),
    .direct_access_count(role)
  ))

  invisible(c(files, list(role = role, subroles = resolved$subroles)))
}

# The role as convert_sql_to_security_role() returns it, in the spelling of SECURITYROLE.
.load_role_to_export <- function(con, role_identifier) {
  rows <- load_sql_security_role_objects_detailed(con, role_identifier)
  if (nrow(rows) == 0L) {
    stop("No security objects found for role '", role_identifier, "' in UserSecGovRelatedObjects.", call. = FALSE)
  }
  .with_stored_role_names(con, convert_sql_to_security_role(rows))
}

# The AOT counterparts in place of the UI sub-roles (look_up = TRUE), with the
# warnings about them; returns the role and one row per sub-role it held.
.resolve_role_subroles <- function(con, role, look_up) {
  subroles           <- .ui_subrole_counterparts(con, role$subroles, look_up = look_up)
  role$subroles      <- .unique_subroles(dplyr::coalesce(subroles$COUNTERPART, subroles$SUBROLE))
  role$subrole_count <- length(role$subroles)
  .warn_about_counterparts(subroles)
  .warn_about_ui_subroles(role$subroles)
  list(role = role, subroles = subroles)
}

# The AOT file, the zip and the two browser files of a role; stored_name is the
# name of the role in the database, which makes the browser files a change of it.
.write_role_files <- function(role, output_folder, zip, browser_files, stored_name) {
  .stop_on_self_subrole(role)
  xml_file <- file.path(.AOT_ROLE_FOLDER, paste0(role$role_name, ".xml"))
  xml_path <- file.path(output_folder, xml_file)
  dir.create(dirname(xml_path), recursive = TRUE, showWarnings = FALSE)
  create_d365fo_role_xml(role, xml_path)

  zip_path <- if (isTRUE(zip)) .zip_metadata(output_folder, xml_file, role$role_name) else NA_character_
  browser  <- if (isTRUE(browser_files)) .write_role_browser_files(role, output_folder, stored_name) else .NO_BROWSER_FILES

  list(xml = xml_path, zip = zip_path, security_governance = browser[["governance"]],
       security_configuration = browser[["configuration"]])
}

.direct_access_count <- function(role) sum(role$direct_access_permissions$Ebene == "Entity")

# A UI copy can hold the AOT role as a sub-role; written under the name of that
# AOT role, it would hold itself, which Visual Studio cannot build.
.stop_on_self_subrole <- function(role) {
  if (any(.identifier_key(role$subroles) == .identifier_key(role$role_name))) {
    stop("Role ", role$role_name, " would hold itself: the role holds a sub-role of that name. ",
         "To bring the two together, merge them with export_merged_role_xml().", call. = FALSE)
  }
  invisible(role)
}

.BROWSER_FOLDERS  <- c(governance = "SecurityGovernance", configuration = "SecurityConfiguration")
.NO_BROWSER_FILES <- c(governance = NA_character_, configuration = NA_character_)

# The file for the import in the browser, once as the security governance and once as
# the security configuration writes it: <folder>/<format folder>/<file_name>.xml.
.write_browser_files <- function(folder, file_name, ...) {
  vapply(names(.BROWSER_FOLDERS), function(format) {
    path <- file.path(folder, .BROWSER_FOLDERS[[format]], paste0(file_name, ".xml"))
    dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
    create_d365fo_security_configuration_xml(..., output_file = path, format = format)
    path
  }, character(1))
}

# The AOT role under its own name is a change of that role; a copy under another
# name, or a role of the user interface, is a new role.
.write_role_browser_files <- function(role, output_folder, stored_name) {
  as_change <- .identifier_key(role$role_name) == .identifier_key(stored_name) && !is_guid_name(role$role_name)
  roles     <- list(role)
  .write_browser_files(output_folder, role$role_name,
                       new_roles     = if (as_change) list() else roles,
                       changed_roles = if (as_change) roles else list())
}

# A UI sub-role replaced by an AOT role that grants something else changes the
# rights of the users.
.COUNTERPART_WARNINGS <- c(
  UI_HAS_MORE          = "grants more than its AOT counterpart %s, which takes its place: the users of the role lose rights. Align %s first.",
  AOT_HAS_MORE         = "grants less than its AOT counterpart %s, which takes its place: the users of the role get more rights, perhaps another license.",
  DIFFERENT            = "and its AOT counterpart %s, which takes its place, each grant something the other lacks. Compare them with compare_role_versions().",
  SEVERAL_COUNTERPARTS = "has several AOT roles of the same name; it stays as it is."
)

# A replacement can name one AOT role twice: two UI roles with the same AOT
# counterpart, or a UI role whose counterpart is a sub-role already. A role file
# holds each sub-role once.
.unique_subroles <- function(subroles) {
  twice <- duplicated(.identifier_key(subroles))
  if (any(twice)) {
    warning("Sub-roles written once although the replacement names them twice: ",
            paste(unique(subroles[twice]), collapse = ", "), ".", call. = FALSE)
  }
  subroles[!twice]
}

.warn_about_counterparts <- function(subroles) {
  for (i in which(subroles$NOTE %in% names(.COUNTERPART_WARNINGS))) {
    text <- .COUNTERPART_WARNINGS[[subroles$NOTE[[i]]]]
    warning("Sub-role ", subroles$SUBROLE[[i]], " ", gsub("%s", subroles$COUNTERPART[[i]], text, fixed = TRUE), call. = FALSE)
  }
  invisible(subroles)
}

.AOT_ROLE_FOLDER      <- "AxSecurityRole"
.AOT_PRIVILEGE_FOLDER <- "AxSecurityPrivilege"

# Letters, digits, underscores, and the hyphens of a GUID: the name becomes a file
# name, so a dot or slash could leave the output folder.
.check_aot_name <- function(name) {
  if (!.is_single_string(name) || !grepl("^[A-Za-z0-9_][A-Za-z0-9_-]*$", name)) {
    stop("name must be an AOT name of letters, digits and underscores, without whitespace, dots or slashes: '",
         paste(name, collapse = "', '"), "'.", call. = FALSE)
  }
  invisible(name)
}

# A role created in the user interface exists only in the database, not in the
# AOT: a Visual Studio project cannot resolve it as a sub-role.
.warn_about_ui_subroles <- function(subroles) {
  ui_roles <- subroles[is_guid_name(subroles)]
  if (length(ui_roles) > 0L) {
    warning(
      "Sub-roles created in the user interface: ", paste(ui_roles, collapse = ", "),
      ". Visual Studio cannot resolve them, and no compared AOT role of the same name takes their place. ",
      "Decide whether they become AOT roles, or import the role in the browser.",
      call. = FALSE
    )
  }
  invisible(ui_roles)
}

# The role and its sub-roles in the spelling of SECURITYROLE.
.with_stored_role_names <- function(con, role) {

  stored <- tryCatch(
    .load_stored_role_names(con, c(role$role_name, role$subroles)),
    error = function(e) {
      warning("SECURITYROLE could not be read, the role names stay as UserSecGovRelatedObjects writes them: ",
              .without_sql_statement(conditionMessage(e)), call. = FALSE)
      NULL
    }
  )
  if (is.null(stored) || nrow(stored) == 0L) {
    return(role)
  }

  spelled <- function(x) {
    found <- stored$AOTNAME[match(.identifier_key(x), .identifier_key(stored$AOTNAME))]
    dplyr::coalesce(found, x)
  }
  role$role_name <- spelled(role$role_name)
  role$subroles  <- spelled(role$subroles)
  role
}

.load_stored_role_names <- function(con, identifiers) {
  identifiers  <- unique(identifiers[!is.na(identifiers)])
  placeholders <- paste(rep("?", length(identifiers)), collapse = ", ")
  DBI::dbGetQuery(
    con,
    paste0("SELECT AOTNAME, NAME FROM SECURITYROLE WHERE AOTNAME IN (", placeholders, ")"),
    params = as.list(identifiers)
  )
}

# Packs files of a folder into <folder>/<name>.zip; the paths inside the zip
# are the paths below the folder.
.zip_metadata <- function(folder, files, name) {
  folder   <- normalizePath(folder, winslash = "/", mustWork = TRUE)
  zip_path <- file.path(folder, paste0(name, ".zip"))
  if (file.exists(zip_path) && !file.remove(zip_path)) {
    stop("The zip '", zip_path, "' cannot be replaced; it may be open in another program.", call. = FALSE)
  }
  zip::zip(zipfile = zip_path, files = files, root = folder, mode = "mirror")
  zip_path
}
