#' Check duties or privileges of one role against another role
#'
#' Answers two questions: which objects of these duties or privileges does the
#' target role already grant, and which of the privileges can be added to it
#' without needing another license? Built for a role that is to keep one
#' license, for example the SCM version of a role: does it still hold the
#' objects of a Commerce duty that SCM covers as well?
#'
#' @details
#'
#' **Data source**
#'
#' Both roles are read from the license graph of D365FO, the table
#' \code{LicensingSecurityObjectExplodedGraph}, see
#' \code{\link{analyze_role_license_report}}. Objects are compared by name, as
#' in the role license report, with their access level: a menu item and a
#' table of the same name count as one object.
#'
#' **Groups** (column \code{GROUP})
#'
#' \describe{
#'   \item{\code{NOT_COVERED}}{The license does not cover the object. It stays
#'     out of the target role on purpose.}
#'   \item{\code{BASE_COVERED}}{The object needs a base license, and the
#'     license is one of those that cover it, for example "Commerce or Supply
#'     Chain Management".}
#'   \item{\code{BELOW_BASE}}{Team Members or Operations - Activity is enough.}
#' }
#'
#' **States** (column \code{STATE})
#'
#' \code{IN_ROLE}: the target role grants the object with at least the access
#' needed. \code{ONLY_READ}: it grants it for reading where writing is needed.
#' \code{MISSING}: it does not grant it. A gap is an object of the groups
#' \code{BASE_COVERED} or \code{BELOW_BASE} that is \code{ONLY_READ} or
#' \code{MISSING}.
#'
#' **Actions** (column \code{ACTION} of \code{Privileges})
#'
#' \describe{
#'   \item{\code{ADD}}{Add the privilege to the target role: the license covers
#'     all of its objects, and it closes at least one gap, that is, it grants
#'     a gap object with the access needed.}
#'   \item{\code{NOT_POSSIBLE}}{The privilege holds objects the license does
#'     not cover; adding it would need another license.}
#'   \item{\code{NOT_NEEDED}}{The license covers the privilege, but it closes
#'     no gap.}
#'   \item{\code{IN_ROLE}}{The target role holds the privilege already.}
#' }
#'
#' **Workbook**
#'
#' With \code{export_path} the result is written to Excel with the sheets
#' Overview, Gaps, Privileges, Not closable and Legend. The legend explains
#' every sheet, column and value in English and German.
#'
#' @param con
#' Database connection. Result of \code{get_connection()}.
#'
#' @param source_role
#' AOT name of the role that holds the duties and privileges.
#'
#' @param duty
#' Duties to check (AOT names). \code{NULL} = none.
#'
#' @param privilege
#' Privileges to check (AOT names). \code{NULL} = none. Give duties,
#' privileges or both; everything given is checked together.
#'
#' @param target_role
#' AOT name of the role to check against; for a role created in the user
#' interface its GUID.
#'
#' @param license
#' The license the target role is to keep, as \code{LicensingAllSkus} names
#' it. Default: \code{"Supply Chain Management"}.
#'
#' @param export_path
#' Path of the Excel file (\code{.xlsx}). \code{NULL} = no file. An existing
#' file is overwritten.
#'
#' @param language
#' Language of sheet names, headers and values in the workbook: \code{"en"} or
#' \code{"de"}. The legend is always in both. Default: \code{"en"}.
#'
#' @return
#' List with \code{Check} (what was checked), \code{Summary} (objects per
#' group and state), \code{Gaps}, \code{Privileges} and \code{NotClosable}
#' (gaps no privilege covered by the license can close).
#'
#' @examples
#' \dontrun{
#'
#' result <- check_duty_against_role(
#'   con         = cnn,
#'   source_role = "_WIBU_VERKAUF_INNENDIENST_MITARBEITER",
#'   duty        = c("RetailDiscountOfferMaintain", "RetailDiscountOfferView"),
#'   target_role = "5CDA51EB-9559-4B27-88C4-14601045B1F0",
#'   license     = "Supply Chain Management",
#'   export_path = "Data/Check_RetailDiscountOffer.xlsx",
#'   language    = "de"
#' )
#'
#' result$Summary
#' result$Privileges[result$Privileges$ACTION == "ADD", ]
#'
#' }
#'
#' @seealso
#' \code{\link{analyze_role_license_report}}
#' \code{\link{export_role_license_report}}
#'
#' @export
check_duty_against_role <- function(
  con,
  source_role,
  duty        = NULL,
  privilege   = NULL,
  target_role,
  license     = "Supply Chain Management",
  export_path = NULL,
  language    = "en"
) {

  .duty_check_request(source_role, target_role, duty, privilege, export_path)
  language <- .check_report_language(language)

  skus <- .load_license_skus(con)
  .check_license_name(license, skus)

  source_graph <- .load_role_license_graph(con, source_role)
  .duty_check_names_in_graph(source_graph, duty, privilege, source_role)

  target_graph <- .load_role_license_graph(con, target_role)
  if (nrow(target_graph) == 0L) {
    stop("The license graph holds no rows for role '", target_role, "'.", call. = FALSE)
  }

  check <- list(
    SOURCE_ROLE = source_role, TARGET_ROLE = target_role, DUTIES = duty,
    PRIVILEGES = privilege, LICENSE = license, CREATED = Sys.Date()
  )
  result <- .duty_check_result(.duty_check_rows(source_graph, duty, privilege, skus, license), target_graph, check)

  message(.duty_check_message(result))

  if (!is.null(export_path)) {
    .export_duty_check(result, export_path, language)
  }

  result
}

.DUTY_CHECK_GROUPS  <- c("NOT_COVERED", "BASE_COVERED", "BELOW_BASE")
.DUTY_CHECK_STATES  <- c("IN_ROLE", "ONLY_READ", "MISSING")
.DUTY_CHECK_ACTIONS <- c("ADD", "NOT_POSSIBLE", "NOT_NEEDED", "IN_ROLE")

# Stands for a privilege that is assigned to a role directly.
.DUTY_CHECK_NO_DUTY <- "(no duty)"

.duty_check_request <- function(source_role, target_role, duty, privilege, export_path) {

  if (!.is_single_string(source_role) || !.is_single_string(target_role)) {
    stop(
      "source_role and target_role must each name one role: the AOT name, or the GUID of a role ",
      "created in the user interface.",
      call. = FALSE
    )
  }

  is_names <- function(x) is.null(x) || (is.character(x) && length(x) > 0L && !anyNA(x) && all(nzchar(x)))

  if (!is_names(duty) || !is_names(privilege) || (is.null(duty) && is.null(privilege))) {
    stop(
      "Name one or more duties or privileges, for example ",
      "duty = c(\"RetailDiscountOfferMaintain\", \"RetailDiscountOfferView\") or ",
      "privilege = c(\"GUPPriceSimulatorProcess\", \"GUPPriceReportMaintain\").",
      call. = FALSE
    )
  }
  .check_xlsx_path(export_path)

  invisible(TRUE)
}

# NULL, or the path of one .xlsx file.
.check_xlsx_path <- function(export_path) {

  if (!is.null(export_path) && !(.is_single_string(export_path) && grepl("[.]xlsx$", export_path, ignore.case = TRUE))) {
    stop("export_path must be the path of one .xlsx file.", call. = FALSE)
  }

  invisible(export_path)
}

# A misspelt name would otherwise drop out of the check without a word.
.duty_check_names_in_graph <- function(graph, duty, privilege, role) {

  unknown <- c(
    duty[!.identifier_key(duty) %in% .identifier_key(graph$DUTYIDENTIFIER)],
    privilege[!.identifier_key(privilege) %in% .identifier_key(graph$PRIVILEGEIDENTIFIER)]
  )

  if (length(unknown) > 0L) {
    stop(
      "The license graph holds no objects of ", paste0("'", unknown, "'", collapse = .LIST_SEPARATOR),
      " in role '", role, "'.",
      call. = FALSE
    )
  }

  invisible(TRUE)
}

.check_license_name <- function(license, skus) {

  if (!.is_single_string(license) || !license %in% skus$SKUNAME) {
    stop(
      "Unknown license '", paste(license, collapse = .LIST_SEPARATOR), "'. LicensingAllSkus lists: ",
      paste(skus$SKUNAME, collapse = .LIST_SEPARATOR),
      call. = FALSE
    )
  }

  invisible(license)
}

# The rows of the duties and privileges, with the licenses that cover each row.
.duty_check_rows <- function(graph, duty, privilege, skus, license) {

  wanted <- .identifier_key(graph$DUTYIDENTIFIER) %in% .identifier_key(duty) |
    .identifier_key(graph$PRIVILEGEIDENTIFIER) %in% .identifier_key(privilege)

  .license_covered_rows(graph[wanted, ], skus, license)
}

# Graph rows with the licenses that cover each of them (COVERING) and whether
# the license, Operations - Activity or Team Members covers the row.
.license_covered_rows <- function(rows, skus, license) {

  # Without an access level a row could not be compared and would hide a gap.
  if (anyNA(suppressWarnings(as.numeric(rows$ACCESSLEVEL)))) {
    stop(
      "The license graph holds rows without an access level (1 or 2); the check cannot judge them.",
      call. = FALSE
    )
  }

  texts    <- unique(rows$LICENSE)
  covering <- lapply(texts, .graph_covering_skus, skus = skus, base_group_pattern = "^Base")
  cover    <- covering[match(rows$LICENSE, texts)]

  dplyr::mutate(
    rows,
    KEY                 = .identifier_key(SECURABLENAME),
    ACCESS              = as.numeric(ACCESSLEVEL),
    DUTY                = dplyr::if_else(is.na(DUTYIDENTIFIER) | !nzchar(DUTYIDENTIFIER), .DUTY_CHECK_NO_DUTY, DUTYIDENTIFIER),
    COVERING            = cover,
    LICENSE_COVERS      = vapply(cover, function(x) license %in% x, logical(1)),
    ACTIVITY_COVERS     = vapply(cover, function(x) .ACTIVITY_SKU %in% x, logical(1)),
    TEAM_MEMBERS_COVERS = vapply(cover, function(x) any(grepl(.LICENSE_FLOOR_PATTERN, x)), logical(1))
  )
}

.duty_check_result <- function(rows, target_graph, check) {

  objects    <- .duty_check_objects(rows, target_graph)
  privileges <- .duty_check_privileges(rows, objects, target_graph)
  gaps       <- .duty_check_gaps(rows, objects, privileges)

  list(
    Check       = check,
    Summary     = .duty_check_summary(objects),
    Gaps        = gaps,
    Privileges  = privileges,
    NotClosable = gaps[is.na(gaps$CLOSED_BY), ]
  )
}

# One row per object: what the checked duties and privileges need, and what the
# target role grants.
.duty_check_objects <- function(rows, target_graph) {

  rows |>
    dplyr::group_by(KEY) |>
    dplyr::summarise(
      OBJECT     = dplyr::first(SECURABLENAME),
      ACCESS     = max(ACCESS),
      LICENSE    = .collapse_sorted(LICENSE, " / "),
      COVERED    = all(LICENSE_COVERS),
      BELOW_BASE = all(ACTIVITY_COVERS),
      DUTIES     = .collapse_sorted(DUTY, .LIST_SEPARATOR),
      PRIVILEGES = .collapse_sorted(PRIVILEGEIDENTIFIER, .LIST_SEPARATOR),
      .groups    = "drop"
    ) |>
    dplyr::left_join(.duty_check_granted(target_graph), by = "KEY") |>
    dplyr::mutate(
      GROUP  = dplyr::case_when(!COVERED ~ "NOT_COVERED", !BELOW_BASE ~ "BASE_COVERED", TRUE ~ "BELOW_BASE"),
      STATE  = dplyr::case_when(is.na(TARGET_ACCESS) ~ "MISSING", TARGET_ACCESS < ACCESS ~ "ONLY_READ", TRUE ~ "IN_ROLE"),
      IS_GAP = GROUP != "NOT_COVERED" & STATE != "IN_ROLE"
    )
}

# The highest access the target role grants per object; none for a new role.
.duty_check_granted <- function(target_graph) {

  if (nrow(target_graph) == 0L) {
    return(tibble::tibble(KEY = character(), TARGET_ACCESS = numeric()))
  }

  target_graph |>
    dplyr::mutate(KEY = .identifier_key(SECURABLENAME), TARGET_ACCESS = as.numeric(ACCESSLEVEL)) |>
    dplyr::group_by(KEY) |>
    dplyr::summarise(TARGET_ACCESS = max(TARGET_ACCESS), .groups = "drop")
}

# A row closes a gap when its object is a gap and the row grants the access the
# object needs. A privilege that only reads an object the duty writes does not.
.duty_check_with_closing <- function(rows, objects) {
  rows |>
    dplyr::left_join(dplyr::select(objects, KEY, NEEDED = ACCESS, IS_GAP), by = "KEY") |>
    dplyr::mutate(CLOSES_GAP = IS_GAP & ACCESS >= NEEDED)
}

.duty_check_privileges <- function(rows, objects, target_graph) {

  in_target <- unique(.identifier_key(target_graph$PRIVILEGEIDENTIFIER))

  .duty_check_with_closing(rows, objects) |>
    dplyr::group_by(PRIVILEGE = PRIVILEGEIDENTIFIER) |>
    dplyr::summarise(
      NAME        = dplyr::first(PRIVILEGENAME),
      DUTIES      = .collapse_sorted(DUTY, .LIST_SEPARATOR),
      OBJECTS     = dplyr::n_distinct(KEY),
      NOT_COVERED = dplyr::n_distinct(KEY[!LICENSE_COVERS]),
      GAPS        = dplyr::n_distinct(KEY[CLOSES_GAP]),
      .groups     = "drop"
    ) |>
    dplyr::mutate(
      IN_ROLE_ALREADY = .identifier_key(PRIVILEGE) %in% in_target,
      ACTION = dplyr::case_when(
        IN_ROLE_ALREADY  ~ "IN_ROLE",
        NOT_COVERED > 0L ~ "NOT_POSSIBLE",
        GAPS == 0L       ~ "NOT_NEEDED",
        TRUE             ~ "ADD"
      )
    ) |>
    dplyr::arrange(match(ACTION, .DUTY_CHECK_ACTIONS), dplyr::desc(GAPS), PRIVILEGE)
}

# Per gap object, the privileges with the action ADD that close it.
.duty_check_closing <- function(rows, objects, privileges) {

  addable <- privileges$PRIVILEGE[privileges$ACTION == "ADD"]

  .duty_check_with_closing(rows, objects) |>
    dplyr::filter(CLOSES_GAP, PRIVILEGEIDENTIFIER %in% addable) |>
    dplyr::group_by(KEY) |>
    dplyr::summarise(CLOSED_BY = .collapse_sorted(PRIVILEGEIDENTIFIER, .LIST_SEPARATOR), .groups = "drop")
}

# The gaps, each with the privileges that close it at the access it needs.
.duty_check_gaps <- function(rows, objects, privileges) {

  objects[objects$IS_GAP, ] |>
    dplyr::left_join(.duty_check_closing(rows, objects, privileges), by = "KEY") |>
    dplyr::arrange(match(GROUP, .DUTY_CHECK_GROUPS), OBJECT) |>
    dplyr::select(GROUP, STATE, OBJECT, ACCESS, TARGET_ACCESS, LICENSE, DUTIES, PRIVILEGES, CLOSED_BY)
}

# Objects per group and state; every group and state appears, also with 0.
.duty_check_summary <- function(objects) {

  count <- function(state) {
    vapply(.DUTY_CHECK_GROUPS, function(group) sum(objects$GROUP == group & objects$STATE == state), integer(1), USE.NAMES = FALSE)
  }

  tibble::tibble(
    GROUP     = .DUTY_CHECK_GROUPS,
    IN_ROLE   = count("IN_ROLE"),
    ONLY_READ = count("ONLY_READ"),
    MISSING   = count("MISSING")
  )
}

.duty_check_message <- function(result) {

  check <- result$Check
  gaps  <- result$Gaps

  sprintf(
    "%s: %d objects, %d gaps in role %s. Adding %d privileges covered by %s closes %d of them.",
    paste(c(check$DUTIES, check$PRIVILEGES), collapse = .LIST_SEPARATOR),
    sum(unlist(result$Summary[.DUTY_CHECK_STATES])), nrow(gaps), check$TARGET_ROLE,
    sum(result$Privileges$ACTION == "ADD"), check$LICENSE, sum(!is.na(gaps$CLOSED_BY))
  )
}
