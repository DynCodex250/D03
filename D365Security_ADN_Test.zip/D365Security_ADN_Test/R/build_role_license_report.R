#' Build the license report of a role
#'
#' Works out which license every building block of a role needs: the duties,
#' privileges and sub-roles assigned directly to the role, every duty and
#' privilege reached through it, and the single objects behind a base license.
#'
#' @details
#'
#' **Rule**
#'
#' A license covers a duty, a privilege or a sub-role when it entitles every
#' object in it. The need is the cheapest license all objects have in common.
#' Base licenses that all cover are alternatives and are joined with
#' \code{" | "}, for example \code{"Commerce | Finance"}. The need is
#' \code{"MULTIPLE"} when no single license covers the block and
#' \code{"UNKNOWN"} when D365FO has no license rows for it. Licenses below
#' Team Members are reported as Team Members.
#'
#' **Building blocks**
#'
#' A row of \code{structure} with a sub-role belongs to that sub-role, a row
#' with a duty and no sub-role is a duty of the role itself, and a row with
#' neither is a privilege assigned directly to the role.
#'
#' @param drivers
#' Result of \code{\link{build_role_license_drivers}}.
#'
#' @param structure
#' One row per sub-role, duty and privilege of the role, with the columns
#' \code{SUBROLEIDENTIFIER}, \code{SUBROLENAME}, \code{DUTYIDENTIFIER} and
#' \code{PRIVILEGEIDENTIFIER}. Empty or missing values mean "none".
#'
#' @param skus
#' License SKUs with the columns \code{SKUNAME}, \code{PRIORITY} and
#' \code{GROUPNAME}.
#'
#' @param base_group_pattern
#' Regex that recognises the group of base licenses. Default: \code{"^Base"}.
#'
#' @return
#'
#' List of tibbles:
#'
#' \describe{
#'   \item{\code{Blocks}}{Building blocks of the role with \code{NEED},
#'     \code{IS_BASE}, the licenses that cover the block (\code{COVERED_BY})
#'     and object counts. \code{FIXING_OBJECT_COUNT} counts the objects
#'     that, as the block grants them, only the named license covers.}
#'   \item{\code{Duties}}{Every duty of the role, with \code{ASSIGNMENT}
#'     (\code{"DIRECT"} or \code{"SUBROLE"}).}
#'   \item{\code{Privileges}}{Every privilege per duty; privileges without a
#'     duty appear under the duty \code{"(direkt)"}.}
#'   \item{\code{Objects}}{Objects that need a base license, with their
#'     origin (\code{duty > privilege}).}
#'   \item{\code{Sets}}{Number of base license objects per need.}
#'   \item{\code{SingleLicenseOptions}}{For every license: the blocks it does
#'     not cover, that is, what would have to go for this license alone.}
#'   \item{\code{RoleNeed}}{One row with the need of the role as a whole.}
#'   \item{\code{ObjectNeeds}, \code{BlockObjects}}{Need, strictest access
#'     level and covering licenses per object, and the objects per block;
#'     input of \code{\link{build_role_usage_report}} and
#'     \code{\link{compare_role_license_with_d365}}.}
#' }
#'
#' @examples
#' \dontrun{
#'
#' cnn    <- get_connection("ADN", "db_credentials.xlsx")
#' report <- analyze_role_license_report(cnn, "_WIBU_VERKAUF_INNENDIENST_MITARBEITER")
#'
#' report$Blocks
#' report$SingleLicenseOptions
#'
#' }
#'
#' @seealso
#' \code{\link{analyze_role_license_report}}
#' \code{\link{build_role_usage_report}}
#' \code{\link{export_role_license_report}}
#'
#' @export
build_role_license_report <- function(
  drivers,
  structure,
  skus,
  base_group_pattern = "^Base"
) {

  .check_required_columns(drivers, .driver_columns(), "drivers")
  .check_required_columns(
    structure,
    c("SUBROLEIDENTIFIER", "SUBROLENAME", "DUTYIDENTIFIER", "PRIVILEGEIDENTIFIER"),
    "structure"
  )
  .check_required_columns(skus, c("SKUNAME", "PRIORITY", "GROUPNAME"), "skus")

  licensed      <- .licensed_rows(drivers, skus, base_group_pattern)
  object_needs  <- .object_needs(licensed, skus, base_group_pattern)
  block_objects <- .block_objects(structure, licensed)
  blocks        <- .block_needs(structure, drivers, block_objects, skus, base_group_pattern)

  list(
    Blocks               = blocks,
    Duties               = .duty_needs(drivers, licensed, structure, skus, base_group_pattern),
    Privileges           = .privilege_needs(drivers, licensed, skus, base_group_pattern),
    Objects              = .base_license_objects(licensed, object_needs),
    Sets                 = .license_sets(object_needs, block_objects),
    SingleLicenseOptions = .single_license_options(blocks, object_needs, skus),
    RoleNeed             = .license_need(.split_skus(object_needs$COVERED_BY), skus, base_group_pattern),
    ObjectNeeds          = object_needs,
    BlockObjects         = block_objects
  )
}

.BLOCK_DUTY      <- "Duty"
.BLOCK_PRIVILEGE <- "Privilege"
.BLOCK_SUBROLE   <- "SubRole"

.ASSIGNMENT_DIRECT  <- "DIRECT"
.ASSIGNMENT_SUBROLE <- "SUBROLE"

# Rows with license information. ROW_IS_BASE marks a row whose own object
# needs a base license. Rows no SKU covers (NOT_ENTITLED) have no covering SKU.
.licensed_rows <- function(drivers, skus, base_group_pattern) {

  rows <- drivers |>
    dplyr::filter(
      LICENSE_STATUS %in% c(.LICENSE_LICENSED, .LICENSE_NOT_ENTITLED),
      !is.na(ENTRYPOINT)
    ) |>
    dplyr::mutate(
      COVERING_SKUS  = dplyr::coalesce(COVERING_SKUS, ""),
      # same key as .distinct_duty_entrypoints() and .normalize_usage()
      ENTRYPOINT_KEY = toupper(ENTRYPOINT),
      PRIVILEGE_KEY  = .identifier_key(PRIVILEGEIDENTIFIER),
      MEASURABLE     = dplyr::coalesce(as.logical(MEASURABLE), FALSE),
      ACCESSLEVEL    = suppressWarnings(as.numeric(ACCESSLEVEL))
    )

  coverings <- unique(rows$COVERING_SKUS)
  is_base   <- vapply(coverings, function(covering) {
    .license_need(.split_skus(covering), skus, base_group_pattern)$IS_BASE
  }, logical(1), USE.NAMES = FALSE)

  dplyr::mutate(rows, ROW_IS_BASE = is_base[match(COVERING_SKUS, coverings)])
}

# Need per object: the strictest access to it in the whole role counts.
.object_needs <- function(licensed, skus, base_group_pattern) {

  described <- licensed |>
    dplyr::group_by(ENTRYPOINT_KEY) |>
    dplyr::summarise(
      ENTRYPOINT     = dplyr::first(ENTRYPOINT),
      ENTRYPOINTTYPE = dplyr::first(ENTRYPOINTTYPE[!is.na(ENTRYPOINTTYPE)]),
      MEASURABLE     = any(MEASURABLE),
      ACCESSLEVEL    = .max_or_na(ACCESSLEVEL),
      .groups        = "drop"
    )

  dplyr::left_join(
    described,
    .need_per_group(licensed, "ENTRYPOINT_KEY", skus, base_group_pattern),
    by = "ENTRYPOINT_KEY"
  )
}

# Building block of every structure row, with the privileges behind it.
.structure_blocks <- function(structure) {

  empty_if_missing <- function(x) dplyr::coalesce(trimws(as.character(x)), "")

  structure |>
    dplyr::mutate(
      SUBROLE    = empty_if_missing(SUBROLEIDENTIFIER),
      DUTY       = empty_if_missing(DUTYIDENTIFIER),
      PRIVILEGE  = empty_if_missing(PRIVILEGEIDENTIFIER),
      BLOCK_TYPE = dplyr::case_when(
        SUBROLE != "" ~ .BLOCK_SUBROLE,
        DUTY != ""    ~ .BLOCK_DUTY,
        TRUE          ~ .BLOCK_PRIVILEGE
      ),
      BLOCK_ID = dplyr::case_when(
        SUBROLE != "" ~ SUBROLE,
        DUTY != ""    ~ DUTY,
        TRUE          ~ PRIVILEGE
      ),
      SUBROLENAME   = empty_if_missing(SUBROLENAME),
      DUTY_KEY      = .identifier_key(DUTY),
      PRIVILEGE_KEY = .identifier_key(PRIVILEGE)
    ) |>
    dplyr::filter(BLOCK_ID != "") |>
    dplyr::distinct(BLOCK_TYPE, BLOCK_ID, SUBROLE, SUBROLENAME, DUTY_KEY, PRIVILEGE_KEY)
}

# Objects of every block. A privilege has the same objects wherever it sits.
.block_objects <- function(structure, licensed) {

  privilege_objects <- dplyr::distinct(
    licensed, PRIVILEGE_KEY, ENTRYPOINT_KEY, COVERING_SKUS, ROW_IS_BASE
  )

  .structure_blocks(structure) |>
    dplyr::distinct(BLOCK_TYPE, BLOCK_ID, PRIVILEGE_KEY) |>
    dplyr::inner_join(privilege_objects, by = "PRIVILEGE_KEY", relationship = "many-to-many")
}

.block_names <- function(structure, drivers) {

  named <- .structure_blocks(structure)

  duty_names <- drivers |>
    dplyr::distinct(DUTY_KEY = .identifier_key(DUTYIDENTIFIER), DUTYNAME) |>
    dplyr::distinct(DUTY_KEY, .keep_all = TRUE)

  privilege_names <- drivers |>
    dplyr::distinct(PRIVILEGE_KEY = .identifier_key(PRIVILEGEIDENTIFIER), PRIVILEGENAME) |>
    dplyr::distinct(PRIVILEGE_KEY, .keep_all = TRUE)

  named |>
    dplyr::left_join(duty_names, by = "DUTY_KEY") |>
    dplyr::left_join(privilege_names, by = "PRIVILEGE_KEY") |>
    dplyr::mutate(
      BLOCK_NAME = dplyr::case_when(
        BLOCK_TYPE == .BLOCK_SUBROLE ~ SUBROLENAME,
        BLOCK_TYPE == .BLOCK_DUTY    ~ DUTYNAME,
        TRUE                         ~ PRIVILEGENAME
      ),
      BLOCK_NAME = dplyr::if_else(is.na(BLOCK_NAME) | BLOCK_NAME == "", BLOCK_ID, BLOCK_NAME)
    ) |>
    dplyr::distinct(BLOCK_TYPE, BLOCK_ID, .keep_all = TRUE) |>
    dplyr::select(BLOCK_TYPE, BLOCK_ID, BLOCK_NAME)
}

.block_needs <- function(structure, drivers, block_objects, skus, base_group_pattern) {

  block  <- c("BLOCK_TYPE", "BLOCK_ID")
  needs  <- .need_per_group(block_objects, block, skus, base_group_pattern)
  fixing <- .fixing_object_counts(block_objects, needs, skus, base_group_pattern)

  .block_names(structure, drivers) |>
    dplyr::left_join(needs, by = block) |>
    dplyr::left_join(.object_counts(block_objects, block), by = block) |>
    dplyr::left_join(fixing, by = block) |>
    .fill_unknown_need() |>
    dplyr::mutate(
      FIXING_OBJECT_COUNT = dplyr::coalesce(FIXING_OBJECT_COUNT, 0L)
    ) |>
    dplyr::arrange(BLOCK_TYPE, BLOCK_ID)
}

# Per block that needs exactly one base license: the objects that, as the
# block grants them, only this license covers.
.fixing_object_counts <- function(block_objects, needs, skus, base_group_pattern) {

  fixing_blocks <- needs |>
    dplyr::filter(.is_fixing_need(NEED, IS_BASE)) |>
    dplyr::select(BLOCK_TYPE, BLOCK_ID, BLOCK_NEED = NEED)

  block_objects |>
    dplyr::inner_join(fixing_blocks, by = c("BLOCK_TYPE", "BLOCK_ID")) |>
    .need_per_group(
      c("BLOCK_TYPE", "BLOCK_ID", "BLOCK_NEED", "ENTRYPOINT_KEY"), skus, base_group_pattern
    ) |>
    dplyr::filter(NEED == BLOCK_NEED) |>
    dplyr::count(BLOCK_TYPE, BLOCK_ID, name = "FIXING_OBJECT_COUNT")
}

# Blocks, duties and privileges without any license row keep an explicit UNKNOWN.
.fill_unknown_need <- function(needs) {
  dplyr::mutate(
    needs,
    NEED              = dplyr::coalesce(NEED, .NEED_UNKNOWN),
    IS_BASE           = dplyr::coalesce(IS_BASE, FALSE),
    COVERED_BY        = dplyr::coalesce(COVERED_BY, ""),
    OBJECT_COUNT      = dplyr::coalesce(OBJECT_COUNT, 0L),
    BASE_OBJECT_COUNT = dplyr::coalesce(BASE_OBJECT_COUNT, 0L)
  )
}

.object_counts <- function(licensed, group_columns) {
  licensed |>
    dplyr::group_by(dplyr::across(dplyr::all_of(group_columns))) |>
    dplyr::summarise(
      OBJECT_COUNT      = dplyr::n_distinct(ENTRYPOINT_KEY),
      BASE_OBJECT_COUNT = dplyr::n_distinct(ENTRYPOINT_KEY[ROW_IS_BASE]),
      .groups           = "drop"
    )
}

.duty_needs <- function(drivers, licensed, structure, skus, base_group_pattern) {

  assignment <- .structure_blocks(structure) |>
    dplyr::filter(DUTY_KEY != "") |>
    dplyr::group_by(DUTY_KEY) |>
    dplyr::summarise(
      ASSIGNMENT = if (any(SUBROLE == "")) .ASSIGNMENT_DIRECT else .ASSIGNMENT_SUBROLE,
      SUBROLES   = .collapse_sorted(SUBROLE[SUBROLE != ""], .LIST_SEPARATOR),
      .groups    = "drop"
    )

  in_duties <- dplyr::filter(licensed, DUTYIDENTIFIER != .DIRECT_DUTY_ID)

  drivers |>
    dplyr::filter(DUTYIDENTIFIER != .DIRECT_DUTY_ID) |>
    dplyr::group_by(DUTYIDENTIFIER) |>
    dplyr::summarise(
      DUTYNAME        = dplyr::first(DUTYNAME),
      PRIVILEGE_COUNT = dplyr::n_distinct(PRIVILEGEIDENTIFIER),
      .groups         = "drop"
    ) |>
    dplyr::mutate(DUTY_KEY = .identifier_key(DUTYIDENTIFIER)) |>
    dplyr::left_join(assignment, by = "DUTY_KEY") |>
    dplyr::left_join(.need_per_group(in_duties, "DUTYIDENTIFIER", skus, base_group_pattern), by = "DUTYIDENTIFIER") |>
    dplyr::left_join(.object_counts(in_duties, "DUTYIDENTIFIER"), by = "DUTYIDENTIFIER") |>
    .fill_unknown_need() |>
    dplyr::mutate(
      ASSIGNMENT = dplyr::coalesce(ASSIGNMENT, .ASSIGNMENT_SUBROLE),
      SUBROLES   = dplyr::coalesce(SUBROLES, "")
    ) |>
    dplyr::select(-DUTY_KEY) |>
    dplyr::arrange(DUTYIDENTIFIER)
}

.privilege_needs <- function(drivers, licensed, skus, base_group_pattern) {

  pair <- c("DUTYIDENTIFIER", "PRIVILEGEIDENTIFIER")

  drivers |>
    dplyr::distinct(DUTYIDENTIFIER, DUTYNAME, PRIVILEGEIDENTIFIER, PRIVILEGENAME) |>
    dplyr::distinct(DUTYIDENTIFIER, PRIVILEGEIDENTIFIER, .keep_all = TRUE) |>
    dplyr::left_join(.need_per_group(licensed, pair, skus, base_group_pattern), by = pair) |>
    dplyr::left_join(.object_counts(licensed, pair), by = pair) |>
    .fill_unknown_need() |>
    dplyr::arrange(DUTYIDENTIFIER, PRIVILEGEIDENTIFIER)
}

# Objects that need a base license, with the duties and privileges that grant
# the access causing it.
.base_license_objects <- function(licensed, object_needs) {

  origin <- licensed |>
    dplyr::filter(ROW_IS_BASE) |>
    dplyr::group_by(ENTRYPOINT_KEY) |>
    dplyr::summarise(
      ORIGIN  = .collapse_sorted(paste0(DUTYIDENTIFIER, " > ", PRIVILEGEIDENTIFIER), "; "),
      .groups = "drop"
    )

  object_needs |>
    dplyr::filter(IS_BASE) |>
    dplyr::left_join(origin, by = "ENTRYPOINT_KEY") |>
    dplyr::arrange(NEED_PRIORITY, NEED, ENTRYPOINT) |>
    dplyr::select(ENTRYPOINT, ENTRYPOINTTYPE, NEED, MEASURABLE, ORIGIN)
}

.license_sets <- function(object_needs, block_objects) {

  base_objects <- dplyr::filter(object_needs, IS_BASE)

  blocks_per_need <- block_objects |>
    dplyr::inner_join(dplyr::select(base_objects, ENTRYPOINT_KEY, NEED), by = "ENTRYPOINT_KEY") |>
    dplyr::group_by(NEED) |>
    dplyr::summarise(BLOCKS = .collapse_sorted(BLOCK_ID, .LIST_SEPARATOR), .groups = "drop")

  base_objects |>
    dplyr::group_by(NEED) |>
    dplyr::summarise(
      NEED_PRIORITY = dplyr::first(NEED_PRIORITY),
      IS_FIXING     = dplyr::first(.is_fixing_need(NEED, IS_BASE)),
      OBJECT_COUNT  = dplyr::n(),
      .groups       = "drop"
    ) |>
    dplyr::left_join(blocks_per_need, by = "NEED") |>
    dplyr::mutate(BLOCKS = dplyr::coalesce(BLOCKS, "")) |>
    dplyr::arrange(dplyr::desc(IS_FIXING), NEED_PRIORITY, NEED)
}

# For every license that occurs as a need: the blocks it does not cover.
.single_license_options <- function(blocks, object_needs, skus) {

  named_in_needs <- unlist(.split_skus(c(blocks$NEED, object_needs$NEED)))
  targets <- skus$SKUNAME[order(skus$PRIORITY)]
  targets <- targets[targets %in% named_in_needs]

  # keeps the columns when no license is named at all
  no_options <- tibble::tibble(
    TARGET_SKU = character(), TARGET_PRIORITY = numeric(), BLOCKS_TO_DROP = integer(),
    DUTIES = integer(), PRIVILEGES = integer(), SUBROLES = integer(), BLOCK_IDS = character()
  )

  options <- lapply(targets, function(target) {
    dropped <- .blocks_not_covered(blocks, target)
    tibble::tibble(
      TARGET_SKU      = target,
      TARGET_PRIORITY = skus$PRIORITY[match(target, skus$SKUNAME)],
      BLOCKS_TO_DROP  = nrow(dropped),
      DUTIES          = sum(dropped$BLOCK_TYPE == .BLOCK_DUTY),
      PRIVILEGES      = sum(dropped$BLOCK_TYPE == .BLOCK_PRIVILEGE),
      SUBROLES        = sum(dropped$BLOCK_TYPE == .BLOCK_SUBROLE),
      # a duty and a privilege can share a name; both are listed
      BLOCK_IDS       = paste(sort(dropped$BLOCK_ID), collapse = .LIST_SEPARATOR)
    )
  })

  dplyr::bind_rows(c(list(no_options), options)) |>
    dplyr::arrange(BLOCKS_TO_DROP, TARGET_PRIORITY)
}

# Blocks with license information that the license `target` does not cover.
.blocks_not_covered <- function(blocks, target) {

  known  <- blocks[blocks$NEED != .NEED_UNKNOWN, ]
  covers <- vapply(
    .split_skus(known$COVERED_BY),
    function(covering) target %in% covering,
    logical(1)
  )

  known[!covers, ]
}
