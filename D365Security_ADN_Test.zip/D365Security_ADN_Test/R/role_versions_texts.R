# =============================================================================
# Texts of the workbooks of compare_role_versions() and
# compare_role_version_pairs()
#
# One catalogue per language with the same entries. "{a}" and "{b}" stand for
# the names of the two versions, for example "AOT role" and "UI role".
# =============================================================================

.version_texts <- function(language = .REPORT_DEFAULT_LANGUAGE) {
  switch(
    language,
    en = .version_texts_en(),
    de = .version_texts_de(),
    stop("No texts for language '", language, "'.")
  )
}

.version_texts_en <- function() {
  list(
    sheets   = c(overview = "Overview", blocks = "Building blocks", duties = "Duties", privileges = "Privileges",
                 objects = "Objects", legend = "Legend"),
    kinds    = c(AOT = "AOT role", UI = "UI role", A = "role A", B = "role B"),
    title    = "Comparison of two versions of a role",
    facts    = c("Version A ({a})", "Version B ({b})", "Licenses of the {a}", "Licenses of the {b}", "Result", "Created on"),
    verdicts = c(
      SAME      = "Both versions grant the same objects with the same access.",
      A_IN_B    = "The {b} grants everything the {a} grants, and more.",
      B_IN_A    = "The {a} grants everything the {b} grants, and more.",
      DIFFERENT = "Each version grants objects the other does not, or grants them with more access."
    ),
    read_first = "How to read this file: sheet \"Legend\".",
    sides    = c(ONLY_A = "only in the {a}", ONLY_B = "only in the {b}", ASSIGNMENT = "assigned differently",
                 LICENSE = "different license", ACCESS = "different access"),
    items    = c(BLOCKS = "Building blocks assigned directly", DUTIES = "Duties", PRIVILEGES = "Privileges", OBJECTS = "Objects"),
    block_kinds = c(Duty = "Duty", Privilege = "Privilege", SubRole = "Sub-role"),
    assignments = c(DIRECT = "directly", SUBROLE = "via a sub-role"),
    summary_columns   = c("What", "Number in the {a}", "Number in the {b}", "Only in the {a}", "Only in the {b}", "Different"),
    block_columns     = c("Difference", "Kind", "Technical name", "Name", "License", "Objects", "Of these, the other version has"),
    duty_columns      = c("Difference", "Duty", "Name", "Assigned in the {a}", "Assigned in the {b}", "License in the {a}", "License in the {b}"),
    privilege_columns = c("Difference", "Privilege", "Name", "Duties", "License", "Objects", "Of these, the other version has"),
    object_columns    = c("Difference", "Object", "Type", "Access in the {a}", "Access in the {b}", "License in the {a}", "License in the {b}"),
    pair_columns      = c("Role A", "Name A", "Role B", "Name B", "Result", "Building blocks only in A", "Building blocks only in B",
                          "Duties only in A", "Duties only in B", "Objects only in A", "Objects only in B",
                          "Objects with other access or license", "Licenses of A", "Licenses of B", "File", "Error"),
    pair_verdicts = c(SAME = "same", A_IN_B = "B holds A and more", B_IN_A = "A holds B and more", DIFFERENT = "both differ"),
    legend = list(
      sheets       = c("Sheets", "Overview: the two versions, their licenses and the result. Building blocks, Duties, Privileges, Objects: only what differs."),
      only         = c("only in the {a} / only in the {b}", "Only this version has the element."),
      assignment   = c("assigned differently", "Both versions have the duty, one directly, the other through a sub-role."),
      license      = c("different license", "Both versions have the element, but it needs another license in each."),
      access       = c("different access", "Both versions grant the object, one for reading, the other for writing."),
      in_other     = c("Of these, the other version has", "How many objects of a building block or privilege only one version has the other version grants all the same. As many as \"Objects\": the other version holds the same function in another building block."),
      licenses     = c("Licenses of the version", "The base licenses that only a single license covers for some object of the version; or the license that covers it all."),
      verdict      = c("Result", "Same: both grant the same objects with the same access. One holds the other: it grants everything the other does, and more. Both differ: each grants something the other does not."),
      comparison   = c("How the comparison works", "Both roles are analysed as in the role license report, from the license graph of D365. Objects are compared by name.")
    )
  )
}

.version_texts_de <- function() {
  list(
    sheets   = c(overview = "Überblick", blocks = "Bausteine", duties = "Aufgaben", privileges = "Rechte",
                 objects = "Objekte", legend = "Legende"),
    kinds    = c(AOT = "AOT-Rolle", UI = "UI-Rolle", A = "Rolle A", B = "Rolle B"),
    title    = "Vergleich zweier Versionen einer Rolle",
    facts    = c("Version A ({a})", "Version B ({b})", "Lizenzen der {a}", "Lizenzen der {b}", "Ergebnis", "Erstellt am"),
    verdicts = c(
      SAME      = "Beide Versionen gewähren dieselben Objekte mit demselben Zugriff.",
      A_IN_B    = "Die {b} gewährt alles, was die {a} gewährt, und mehr.",
      B_IN_A    = "Die {a} gewährt alles, was die {b} gewährt, und mehr.",
      DIFFERENT = "Jede Version gewährt Objekte, die die andere nicht hat oder mit weniger Zugriff gewährt."
    ),
    read_first = "So lesen Sie diese Datei: Blatt „Legende“.",
    sides    = c(ONLY_A = "nur in der {a}", ONLY_B = "nur in der {b}", ASSIGNMENT = "anders zugeordnet",
                 LICENSE = "andere Lizenz", ACCESS = "anderer Zugriff"),
    items    = c(BLOCKS = "Direkt zugeordnete Bausteine", DUTIES = "Aufgaben", PRIVILEGES = "Rechte", OBJECTS = "Objekte"),
    block_kinds = c(Duty = "Aufgabe", Privilege = "Recht", SubRole = "Unterrolle"),
    assignments = c(DIRECT = "direkt", SUBROLE = "über eine Unterrolle"),
    summary_columns   = c("Was", "Anzahl in der {a}", "Anzahl in der {b}", "Nur in der {a}", "Nur in der {b}", "Unterschiedlich"),
    block_columns     = c("Unterschied", "Art", "Technischer Name", "Bezeichnung", "Lizenz", "Objekte", "Davon hat die andere Version"),
    duty_columns      = c("Unterschied", "Aufgabe", "Bezeichnung", "Zuordnung in der {a}", "Zuordnung in der {b}", "Lizenz in der {a}", "Lizenz in der {b}"),
    privilege_columns = c("Unterschied", "Recht", "Bezeichnung", "Aufgaben", "Lizenz", "Objekte", "Davon hat die andere Version"),
    object_columns    = c("Unterschied", "Objekt", "Typ", "Zugriff in der {a}", "Zugriff in der {b}", "Lizenz in der {a}", "Lizenz in der {b}"),
    pair_columns      = c("Rolle A", "Name A", "Rolle B", "Name B", "Ergebnis", "Bausteine nur in A", "Bausteine nur in B",
                          "Aufgaben nur in A", "Aufgaben nur in B", "Objekte nur in A", "Objekte nur in B",
                          "Objekte mit anderem Zugriff oder anderer Lizenz", "Lizenzen von A", "Lizenzen von B", "Datei", "Fehler"),
    pair_verdicts = c(SAME = "gleich", A_IN_B = "B enthält A und mehr", B_IN_A = "A enthält B und mehr", DIFFERENT = "beide verschieden"),
    legend = list(
      sheets       = c("Blätter", "Überblick: die beiden Versionen, ihre Lizenzen und das Ergebnis. Bausteine, Aufgaben, Rechte, Objekte: nur, was sich unterscheidet."),
      only         = c("nur in der {a} / nur in der {b}", "Nur diese Version hat das Element."),
      assignment   = c("anders zugeordnet", "Beide Versionen haben die Aufgabe, die eine direkt, die andere über eine Unterrolle."),
      license      = c("andere Lizenz", "Beide Versionen haben das Element, es braucht aber jeweils eine andere Lizenz."),
      access       = c("anderer Zugriff", "Beide Versionen gewähren das Objekt, die eine zum Lesen, die andere zum Schreiben."),
      in_other     = c("Davon hat die andere Version", "Wie viele Objekte eines Bausteins oder Rechts, das nur eine Version hat, die andere trotzdem gewährt. So viele wie „Objekte“: Die andere Version hat dieselbe Funktion in einem anderen Baustein."),
      licenses     = c("Lizenzen der Version", "Die Basislizenzen, die für ein Objekt der Version allein in Frage kommen; oder die Lizenz, die alles deckt."),
      verdict      = c("Ergebnis", "Gleich: beide gewähren dieselben Objekte mit demselben Zugriff. Eine enthält die andere: Sie gewährt alles, was die andere gewährt, und mehr. Beide verschieden: Jede gewährt etwas, das die andere nicht hat."),
      comparison   = c("So funktioniert der Vergleich", "Beide Rollen werden wie im Rollen-Lizenzbericht aus dem Lizenzgraphen von D365 ausgewertet. Objekte werden über ihren Namen verglichen.")
    )
  )
}
