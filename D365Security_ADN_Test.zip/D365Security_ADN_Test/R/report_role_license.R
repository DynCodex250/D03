#' Create the license report for one or several roles
#'
#' Analyses each role and writes one Excel report per role. The role name is
#' all the function needs; everything else comes from the database.
#'
#' @details
#'
#' For every role the function runs
#' \code{\link{analyze_role_license_report}} and
#' \code{\link{export_role_license_report}}. A role that cannot be reported,
#' for example because its name is misspelled, does not stop the others: the
#' function warns with the reason and returns \code{NA} for it.
#'
#' The report is English unless \code{language} or \code{translations} names
#' another language, see \code{\link{export_role_license_report}}.
#'
#' @param con
#' Database connection. Result of \code{get_connection()}.
#'
#' @param role_identifiers
#' Character vector with the AOT names of the roles
#' (\code{ROLEIDENTIFIER}).
#'
#' @param usage
#' Telemetry touches per user and entry point, see
#' \code{\link{analyze_user_duty_usage}}. \code{NULL} = report without usage
#' data.
#'
#' @param export_folder
#' Folder to write to. Created when missing. Default: \code{"Data"}.
#'
#' @param translations
#' Translation table or the path of its Excel file, see
#' \code{\link{export_role_license_report}}. \code{NULL} = English.
#'
#' @param with_users
#' \code{FALSE} = leave out the sheets with usage per user. Default:
#' \code{TRUE}.
#'
#' @param anonymize
#' \code{TRUE} = replace user ids by pseudonyms. Default: \code{FALSE}.
#'
#' @param key_path
#' Path of the key file (\code{.xlsx}) for the pseudonyms; required with
#' \code{anonymize = TRUE}. It must lie outside \code{export_folder}, because
#' it holds the real user ids.
#'
#' @param language
#' Language of the report texts: \code{"en"} or \code{"de"}. \code{NULL} =
#' the language of \code{translations}, otherwise English. See
#' \code{\link{export_role_license_report}}.
#'
#' @return
#' Character vector with the path of each report, named by role. \code{NA}
#' for a role that could not be reported.
#'
#' @examples
#' \dontrun{
#'
#' cnn   <- get_connection("ADN", "db_credentials.xlsx")
#' usage <- D365Licensing::load_telemetry_touches(D365Licensing::load_config())
#'
#' report_role_license(
#'   con              = cnn,
#'   role_identifiers = c("_WIBU_VERKAUF_INNENDIENST_MITARBEITER", "_WIBU_EINKAUF_MITARBEITER"),
#'   usage            = usage
#' )
#'
#' # German report without user data
#' report_role_license(
#'   cnn, "_WIBU_VERKAUF_INNENDIENST_MITARBEITER",
#'   translations = "Data/security_object_names_de.xlsx",
#'   with_users   = FALSE
#' )
#'
#' # German report with pseudonyms, to pass on
#' report_role_license(
#'   cnn, "_WIBU_VERKAUF_INNENDIENST_MITARBEITER",
#'   usage     = usage,
#'   language  = "de",
#'   anonymize = TRUE,
#'   key_path  = "C:/Keys/anonymization_key.xlsx"
#' )
#'
#' }
#'
#' @seealso
#' \code{\link{analyze_role_license_report}}
#' \code{\link{export_role_license_report}}
#'
#' @export
report_role_license <- function(
  con,
  role_identifiers,
  usage         = NULL,
  export_folder = "Data",
  translations  = NULL,
  with_users    = TRUE,
  anonymize     = FALSE,
  key_path      = NULL,
  language      = NULL
) {

  # Checked once, before the first query: a wrong path, table or language
  # should not surface as one warning per role.
  .check_report_request(role_identifiers, export_folder)
  .check_anonymize_request(anonymize, key_path)
  .check_key_outside_export(anonymize, key_path, export_folder)
  translations <- .read_report_translations(translations)
  if (!is.null(language)) {
    language <- .check_report_language(language, translations)
  }

  roles <- unique(role_identifiers)

  report_one <- function(role) {
    tryCatch(
      export_role_license_report(
        analyze_role_license_report(
          con, role, usage = usage, anonymize = anonymize, key_path = key_path
        ),
        export_folder = export_folder,
        translations  = translations,
        with_users    = with_users,
        language      = language
      ),
      error = function(e) {
        warning(
          "No report for role '", role, "': ", .without_sql_statement(conditionMessage(e)),
          call. = FALSE
        )
        NA_character_
      }
    )
  }

  paths <- vapply(roles, report_one, character(1), USE.NAMES = FALSE)
  names(paths) <- roles

  paths
}

.check_report_request <- function(role_identifiers, export_folder) {

  is_role_list <- is.character(role_identifiers) &&
    length(role_identifiers) > 0L &&
    !anyNA(role_identifiers) &&
    all(nzchar(role_identifiers))

  if (!is_role_list) {
    stop("role_identifiers must be a character vector with at least one role (AOT name).")
  }
  if (!.is_single_string(export_folder)) {
    stop("export_folder must be the path of one folder.")
  }

  invisible(role_identifiers)
}

# The key file holds the real user ids. In the folder of the reports, or in a
# folder below it, it would be passed on together with them.
.check_key_outside_export <- function(anonymize, key_path, export_folder) {

  if (!anonymize) {
    return(invisible(key_path))
  }

  folders <- normalizePath(c(dirname(key_path), export_folder), winslash = "/", mustWork = FALSE)
  folders <- paste0(tolower(sub("/+$", "", folders)), "/")

  if (startsWith(folders[[1]], folders[[2]])) {
    stop(
      "key_path must not lie in export_folder or below it: the key file holds the ",
      "real user ids and would be passed on with the reports."
    )
  }

  invisible(key_path)
}
