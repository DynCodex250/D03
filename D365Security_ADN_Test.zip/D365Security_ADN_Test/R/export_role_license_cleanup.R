# =============================================================================
# Workbook of plan_role_license_cleanup() (D04): overview, cleanup plan, actions,
# users, duties, users without telemetry, differences, prices, legend. The
# sheets of users hold user ids.
# =============================================================================

.cleanup_texts <- function(language) {

  texts <- list(
    en = list(
      sheets       = c(overview = "Overview", plan = "Cleanup plan", actions = "Actions", users = "Users",
                       duties = "Duties", no_usage = "No usage", differences = "Differences", prices = "Prices",
                       legend = "Legend"),
      title        = "Cleanup plan of the roles by the telemetry (D04)",
      facts        = c("Created", "Licenses", "License graph", "Telemetry", "Users", "with telemetry",
                       "without telemetry (wave 2)", "without licensed use (wave 2)",
                       "whose license graph differs from the licenses",
                       "Roles not in the license graph", "License costs today per month",
                       "Proven saving per month (wave 1)", "Possible saving after review per month (wave 3)",
                       "License costs of the users without usage per month (wave 2)", "Prices"),
      graph        = "%d rows, %d roles",
      period       = "%s to %s",
      date_format  = "%Y-%m-%d",
      price_kind   = c("estimates of the strategy paper (October 2026)", "as given"),
      none         = "none",
      note         = c(
        paste("A duty is used when the user opened one of its display menu items in the telemetry. A duty without one",
              "cannot be measured; it is kept until the business confirms that it is not used."),
        paste("Wave 1: the roles in the order of the steps; a user saves only when all his roles have changed.",
              "Wave 2: the users without telemetry or licensed use, after a check. Wave 3: the roles whose saving needs the",
              "review."),
        "The sheets Actions, Users and No usage hold user ids; do not pass them on."
      ),
      plan         = c("Wave", "Step", "Role", "Users with the role", "Users to change", "Remove the role", "Variant",
                       "Duties that go", "Saving of this step per month", "Saving cumulated per month", "Users to review",
                       "Duties to review", "Saving after review of the users concerned per month"),
      actions      = c("User", "Role", "Action", "Wave", "Duties", "Licenses", "Saving of the user per month"),
      action_names = c(REMOVE_ROLE = "Remove the role", VARIANT = "Variant without the duties", REVIEW = "Review"),
      users        = c("User", "Roles", "Billed today", "Costs today", "Billed by the graph", "Costs by the graph",
                       "Billed by usage", "Costs by usage", "Saving", "Billed after review", "Costs after review",
                       "Further saving after review", "Class", "Entry points opened", "Last seen"),
      class_names  = c(SAVES = "saves", REVIEW = "review", KEEPS = "keeps", NO_TELEMETRY = "no telemetry",
                       NO_USE = "no licensed use",
                       GRAPH_DIFFERS = "graph differs"),
      duties       = c("Role", "Duty", "Name", "License", "Measurable", "Users with the role", "Users who opened it",
                       "Users for whom it goes", "Users to review"),
      no_usage     = c("User", "Roles", "Billed today", "Costs today", "Class"),
      differences  = c("Role", "License by the graph", "Billed by PPAC", "Users", "Objects", "Examples"),
      prices       = c("License", "Base price", "Attach price"),
      yes_no       = c("yes", "no")
    ),
    de = list(
      sheets       = c(overview = "Überblick", plan = "Bereinigungsplan", actions = "Maßnahmen", users = "Benutzer",
                       duties = "Aufgaben", no_usage = "Ohne Nutzung", differences = "Abweichungen",
                       prices = "Preise", legend = "Legende"),
      title        = "Bereinigungsplan der Rollen nach der Telemetrie (D04)",
      facts        = c("Erstellt", "Lizenzen", "Lizenzgraph", "Telemetrie", "Benutzer", "davon mit Telemetrie",
                       "ohne Telemetrie (Welle 2)", "ohne lizenzpflichtige Nutzung (Welle 2)",
                       "deren Lizenzgraph von den Lizenzen abweicht",
                       "Rollen nicht im Lizenzgraphen", "Lizenzkosten heute je Monat",
                       "Belegte Einsparung je Monat (Welle 1)", "Mögliche Einsparung nach Prüfung je Monat (Welle 3)",
                       "Lizenzkosten der Benutzer ohne Nutzung je Monat (Welle 2)", "Preise"),
      graph        = "%d Zeilen, %d Rollen",
      period       = "%s bis %s",
      date_format  = "%d.%m.%Y",
      price_kind   = c("Schätzwerte der Strategie (Oktober 2026)", "wie übergeben"),
      none         = "keine",
      note         = c(
        paste("Eine Aufgabe gilt als genutzt, wenn der Benutzer einen ihrer Anzeige-Menüpunkte in der Telemetrie",
              "geöffnet hat. Eine Aufgabe ohne Anzeige-Menüpunkt ist nicht messbar; sie bleibt, bis der Fachbereich",
              "bestätigt, dass sie nicht genutzt wird."),
        paste("Welle 1: die Rollen in der Reihenfolge der Schritte; ein Benutzer spart erst, wenn alle seine Rollen",
              "geändert sind. Welle 2: die Benutzer ohne Telemetrie oder ohne lizenzpflichtige Nutzung, nach Prüfung.",
              "Welle 3: die Rollen, deren Einsparung die Prüfung braucht."),
        "Die Blätter Maßnahmen, Benutzer und Ohne Nutzung enthalten Benutzerkennungen; nicht weitergeben."
      ),
      plan         = c("Welle", "Schritt", "Rolle", "Benutzer mit der Rolle", "Benutzer zu ändern", "Rolle entziehen",
                       "Variante", "Aufgaben, die entfallen", "Einsparung dieses Schritts je Monat",
                       "Einsparung kumuliert je Monat", "Benutzer zur Prüfung", "Aufgaben zur Prüfung",
                       "Einsparung nach Prüfung der betroffenen Benutzer je Monat"),
      actions      = c("Benutzer", "Rolle", "Maßnahme", "Welle", "Aufgaben", "Lizenzen",
                       "Einsparung des Benutzers je Monat"),
      action_names = c(REMOVE_ROLE = "Rolle entziehen", VARIANT = "Variante ohne die Aufgaben", REVIEW = "Prüfen"),
      users        = c("Benutzer", "Rollen", "Abgerechnet heute", "Kosten heute", "Abgerechnet laut Graph",
                       "Kosten laut Graph", "Abgerechnet nach Nutzung", "Kosten nach Nutzung", "Einsparung",
                       "Abgerechnet nach Prüfung", "Kosten nach Prüfung", "Weitere Einsparung nach Prüfung", "Klasse",
                       "Geöffnete Einstiegspunkte", "Zuletzt gesehen"),
      class_names  = c(SAVES = "spart", REVIEW = "prüfen", KEEPS = "behält", NO_TELEMETRY = "ohne Telemetrie",
                       NO_USE = "ohne lizenzpflichtige Nutzung",
                       GRAPH_DIFFERS = "Graph weicht ab"),
      duties       = c("Rolle", "Aufgabe", "Bezeichnung", "Lizenz", "Messbar", "Benutzer mit der Rolle",
                       "Benutzer, die sie geöffnet haben", "Benutzer, bei denen sie entfällt", "Benutzer zur Prüfung"),
      no_usage     = c("Benutzer", "Rollen", "Abgerechnet heute", "Kosten heute", "Klasse"),
      differences  = c("Rolle", "Lizenz laut Graph", "Abgerechnet laut PPAC", "Benutzer", "Objekte", "Beispiele"),
      prices       = c("Lizenz", "Basispreis", "Attach-Preis"),
      yes_no       = c("ja", "nein")
    )
  )
  texts[[language]]
}

.CLEANUP_LEGEND <- list(
  c("Duty used",
    "The user opened at least one display menu item of the duty, or of a privilege outside any duty, in the telemetry. Its actions, outputs and data entities count with it.",
    "Aufgabe genutzt",
    "Der Benutzer hat in der Telemetrie mindestens einen Anzeige-Menüpunkt der Aufgabe oder eines Rechts ohne Aufgabe geöffnet. Ihre Aktionen, Ausgaben und Datenentitäten zählen mit ihr."),
  c("Not measurable",
    "A duty without a display menu item: the telemetry cannot see whether it is used. It is kept; only the review may drop it (wave 3).",
    "Nicht messbar",
    "Eine Aufgabe ohne Anzeige-Menüpunkt: Die Telemetrie sieht nicht, ob sie genutzt wird. Sie bleibt; erst die Prüfung kann sie streichen (Welle 3)."),
  c("Proven saving",
    "Costs today minus the costs by usage: the cheapest licenses that cover the objects of the duties the user uses and of those that cannot be measured.",
    "Belegte Einsparung",
    "Kosten heute minus Kosten nach Nutzung: die günstigsten Lizenzen für die Objekte der Aufgaben, die der Benutzer nutzt, und der nicht messbaren."),
  c("Costs by the graph",
    "The cheapest licenses that cover every object of all roles of the user, from the license graph. PPAC has priority: where the graph wants more for an object than PPAC bills, the licenses of PPAC cover it (sheet Differences). Where the graph needs less than PPAC bills, it lacks something: no saving (class graph differs).",
    "Kosten laut Graph",
    "Die günstigsten Lizenzen für alle Objekte aller Rollen des Benutzers, aus dem Lizenzgraphen. PPAC hat Vorrang: Wo der Graph für ein Objekt mehr verlangt, als PPAC abrechnet, decken es die Lizenzen von PPAC (Blatt Abweichungen). Wo der Graph weniger braucht, als PPAC abrechnet, fehlt ihm etwas: keine Einsparung (Klasse Graph weicht ab)."),
  c("Remove the role",
    "The user opened nothing of the role, and all its duties can be measured.",
    "Rolle entziehen",
    "Der Benutzer hat nichts von der Rolle geöffnet, und alle ihre Aufgaben sind messbar."),
  c("Variant without the duties",
    "A version of the role without the duties named, for the users who do not use them (see plan_single_license_role).",
    "Variante ohne die Aufgaben",
    "Eine Version der Rolle ohne die genannten Aufgaben, für die Benutzer, die sie nicht nutzen (siehe plan_single_license_role)."),
  c("Review",
    "The saving needs the business to confirm that the duties named are not used, among them duties that cannot be measured.",
    "Prüfen",
    "Die Einsparung setzt voraus, dass der Fachbereich bestätigt, dass die genannten Aufgaben nicht genutzt werden, darunter nicht messbare."),
  c("Step, saving of this step",
    "A user saves only when all his roles have changed. The steps order the roles so that each completes the most savings; a step with 0 prepares the next one.",
    "Schritt, Einsparung dieses Schritts",
    "Ein Benutzer spart erst, wenn alle seine Rollen geändert sind. Die Schritte ordnen die Rollen so, dass jeder die meisten Einsparungen vollendet; ein Schritt mit 0 bereitet den nächsten vor."),
  c("Waves",
    "1: the roles with proven savings, by step. 2: the users without telemetry or without licensed use, after a check (sheet No usage). 3: the roles whose saving needs the review.",
    "Wellen",
    "1: die Rollen mit belegter Einsparung, nach Schritten. 2: die Benutzer ohne Telemetrie oder ohne lizenzpflichtige Nutzung, nach Prüfung (Blatt Ohne Nutzung). 3: die Rollen, deren Einsparung die Prüfung braucht."),
  c("Saving of the user",
    "In the sheet Actions the saving of the user, the same at each of his roles: it comes only when all of them have changed. Add it up per user, not over the rows.",
    "Einsparung des Benutzers",
    "Im Blatt Maßnahmen die Einsparung des Benutzers, bei jeder seiner Rollen dieselbe: Sie entsteht erst, wenn alle geändert sind. Je Benutzer zählen, nicht über die Zeilen summieren."),
  c("Saving after review of the users concerned",
    "Sum of the further savings after review of the users with a review action at the role; a user with review actions at several roles counts at each.",
    "Einsparung nach Prüfung der betroffenen Benutzer",
    "Summe der weiteren Einsparungen nach Prüfung der Benutzer mit einer Prüfaktion an der Rolle; ein Benutzer mit Prüfaktionen an mehreren Rollen zählt bei jeder."),
  c("No telemetry",
    "The user opened nothing in the period of the telemetry. He may work with the warehouse app or through an integration; check before licenses are taken away.",
    "Ohne Telemetrie",
    "Der Benutzer hat im Zeitraum der Telemetrie nichts geöffnet. Vielleicht arbeitet er mit der Lager-App oder über eine Schnittstelle; vor dem Entzug von Lizenzen prüfen."),
  c("No licensed use",
    "The user opened only what needs no license, for example the dashboard: by the telemetry he would need no license at all. Checked like a user without telemetry, not counted as a saving.",
    "Ohne lizenzpflichtige Nutzung",
    "Der Benutzer hat nur geöffnet, was keine Lizenz braucht, etwa das Dashboard: Nach der Telemetrie bräuchte er gar keine Lizenz. Wird geprüft wie ein Benutzer ohne Telemetrie, zählt nicht als Einsparung."),
  c("Period of the telemetry",
    "Work done once a year, such as the closing of the year, may not show in it.",
    "Zeitraum der Telemetrie",
    "Arbeit, die nur einmal im Jahr anfällt, etwa der Jahresabschluss, zeigt sich darin vielleicht nicht."),
  c("Base price, attach price",
    "Of the base licenses of a user the first in the order SCM, Finance, Commerce counts at its base price, every further one at its attach price.",
    "Basispreis, Attach-Preis",
    "Von den Basislizenzen eines Benutzers zählt die erste in der Reihenfolge SCM, Finance, Commerce mit ihrem Basispreis, jede weitere mit ihrem Attach-Preis.")
)

.export_role_license_cleanup <- function(result, export_path, language) {

  texts    <- .cleanup_texts(language)
  workbook <- openxlsx::createWorkbook(creator = .WORKBOOK_CREATOR)
  header   <- openxlsx::createStyle(textDecoration = "bold", fgFill = "#DDEBF7", border = "bottom", wrapText = TRUE)
  amount   <- openxlsx::createStyle(numFmt = "#,##0.00")
  add      <- function(name, table, columns, widths, money = integer(), wrap = FALSE) {
    sheet <- texts$sheets[[name]]
    .add_duty_check_table(workbook, sheet, stats::setNames(as.data.frame(table, stringsAsFactors = FALSE), columns),
                          header, widths, wrap = wrap)
    if (nrow(table) > 0L && length(money) > 0L) {
      openxlsx::addStyle(workbook, sheet, amount, rows = seq_len(nrow(table)) + 1L, cols = money, gridExpand = TRUE)
    }
  }
  in_words <- function(values, names) dplyr::coalesce(unname(names[values]), values)
  yes_no   <- function(flags) ifelse(flags, texts$yes_no[[1]], texts$yes_no[[2]])

  .add_cleanup_overview(workbook, result$Check, texts, language)
  add("plan", result$Plan, texts$plan, c(7, 8, 44, 12, 12, 12, 10, 60, 16, 16, 12, 60, 22), money = c(9L, 10L, 13L))
  add("actions", dplyr::mutate(result$Actions, ACTION = in_words(ACTION, texts$action_names)), texts$actions,
      c(24, 44, 26, 7, 60, 36, 16), money = 7L)
  add("users", dplyr::mutate(result$Users, CLASS = in_words(CLASS, texts$class_names)), texts$users,
      c(24, 60, 40, 12, 40, 12, 40, 12, 12, 40, 12, 14, 16, 12, 12), money = c(4L, 6L, 8L, 9L, 11L, 12L))
  add("duties", dplyr::mutate(result$Duties, MEASURABLE = yes_no(MEASURABLE)), texts$duties,
      c(44, 40, 44, 36, 10, 12, 14, 14, 12))
  add("no_usage", dplyr::mutate(result$NoUsage, CLASS = in_words(CLASS, texts$class_names)), texts$no_usage,
      c(24, 60, 40, 12, 28), money = 4L)
  add("differences", result$Differences, texts$differences, c(44, 32, 40, 10, 10, 70))
  add("prices", result$Prices, texts$prices, c(34, 14, 14), money = 2:3)
  add("legend", do.call(rbind, .CLEANUP_LEGEND), c("Term", "Meaning", "Begriff", "Bedeutung"), .DUTY_CHECK_LEGEND_WIDTHS,
      wrap = TRUE)

  dir.create(dirname(export_path), recursive = TRUE, showWarnings = FALSE)
  openxlsx::saveWorkbook(workbook, export_path, overwrite = TRUE)
  invisible(export_path)
}

.add_cleanup_overview <- function(workbook, check, texts, language) {

  sheet  <- texts$sheets[["overview"]]
  date   <- function(day) format(day, texts$date_format)
  amount <- function(value) .cleanup_amount(value, language)
  values <- c(
    date(check$CREATED), check$SOURCE, sprintf(texts$graph, check$GRAPH_ROWS, check$GRAPH_ROLES),
    sprintf(texts$period, date(check$TELEMETRY_FROM), date(check$TELEMETRY_TO)), check$USERS,
    check$USERS_WITH_TELEMETRY, check$USERS_WITHOUT_TELEMETRY, check$USERS_WITHOUT_LICENSED_USE,
    check$USERS_GRAPH_DIFFERS,
    if (length(check$ROLES_NOT_IN_GRAPH) == 0L) texts$none else paste(check$ROLES_NOT_IN_GRAPH, collapse = .LIST_SEPARATOR),
    amount(check$COST_NOW), amount(check$SAVING), amount(check$SAVING_IF_CONFIRMED),
    amount(check$COST_WITHOUT_USE), if (check$PRICES_ESTIMATED) texts$price_kind[[1]] else texts$price_kind[[2]]
  )
  facts <- data.frame(label = texts$facts, value = as.character(values), stringsAsFactors = FALSE)

  openxlsx::addWorksheet(workbook, sheet)
  openxlsx::writeData(workbook, sheet, texts$title, startRow = 1L)
  openxlsx::addStyle(workbook, sheet, openxlsx::createStyle(textDecoration = "bold", fontSize = 13), rows = 1L, cols = 1L)
  openxlsx::writeData(workbook, sheet, facts, startRow = 3L, colNames = FALSE)
  openxlsx::writeData(workbook, sheet, texts$note, startRow = nrow(facts) + 4L)
  openxlsx::setColWidths(workbook, sheet, cols = 1:2, widths = c(62, 60))
  invisible(workbook)
}

# 2075.1 as "2.075,10" in German, "2,075.10" in English.
.cleanup_amount <- function(value, language) {
  german <- identical(language, "de")
  formatC(round(value, 2), format = "f", digits = 2, big.mark = if (german) "." else ",",
          decimal.mark = if (german) "," else ".")
}
