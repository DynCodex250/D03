# =============================================================================
# License need from the license graph
#
# Used by plan_role_license_cleanup(). The graph names, for every object of a
# role, the license it needs at its access level. A user needs the cheapest set
# of licenses that covers the objects of every duty he keeps. Which duties he
# keeps follows from the telemetry: a duty is used when he opened one of its
# display menu items; a duty without a display menu item cannot be measured and
# is kept, unless the business confirms that it is not used.
#
# Sets of licenses are bit masks over the license list: bit i stands for
# skus$SKUNAME[i]. The mask of an object holds every license that covers it.
# =============================================================================

.GRAPH_NOT_REQUIRED <- "Not required"

# The licenses the graph names: the standard ones, and Human Resources, its self service
# and Project Operations, which WIBU does not price.
.graph_license_skus <- function() {
  dplyr::bind_rows(.STANDARD_LICENSE_SKUS, tibble::tribble(
    ~SKUNAME,                        ~PRIORITY, ~GROUPNAME,
    "Human Resources Self Service",  25,        NA_character_,
    "Human Resources",               40,        "Base - Human Resources, Project Operations",
    "Project Operations",            50,        "Base - Human Resources, Project Operations"
  ))
}

.license_bits <- function(licenses, skus) {
  position <- unique(match(.identifier_key(licenses), .identifier_key(skus$SKUNAME)))
  as.integer(sum(2^(position[!is.na(position)] - 1)))
}

# "Not required" (write access to system objects) needs no license, like "None".
.graph_license_masks <- function(license_texts, skus) {
  texts <- ifelse(.identifier_key(license_texts) == .identifier_key(.GRAPH_NOT_REQUIRED), .GRAPH_NO_LICENSE, license_texts)
  vapply(texts, function(text) .license_bits(.graph_covering_skus(text, skus, "^Base"), skus), integer(1),
         USE.NAMES = FALSE)
}

# .identifier_key() of a long column with few distinct values, once per value: the graph
# has 677,000 rows but some 23,000 objects.
.distinct_key <- function(values) {
  distinct <- unique(values)
  .identifier_key(distinct)[match(values, distinct)]
}

.is_display_type <- function(types) {
  named <- dplyr::coalesce(unname(.SECURABLE_TYPE_NAMES[as.character(types)]), as.character(types))
  grepl(.MEASURABLE_TYPE_PATTERN, named, ignore.case = TRUE)
}

# One row per graph role, unit, object and license at the highest access level the unit
# grants. A unit is a duty, or a privilege outside any duty.
.graph_units <- function(graph, skus) {
  rows   <- graph[!is.na(graph$ROLEIDENTIFIER), ]
  texts  <- unique(rows$LICENSE)
  direct <- is.na(rows$DUTYIDENTIFIER)
  object <- .distinct_key(rows$SECURABLENAME)
  units  <- tibble::tibble(
    GRAPH_ROLE_KEY = .distinct_key(rows$ROLEIDENTIFIER),
    UNIT           = ifelse(direct, paste0("privilege:", .distinct_key(rows$PRIVILEGEIDENTIFIER)),
                            .distinct_key(rows$DUTYIDENTIFIER)),
    UNIT_ID        = dplyr::coalesce(rows$DUTYIDENTIFIER, rows$PRIVILEGEIDENTIFIER),
    UNIT_NAME      = ifelse(direct, dplyr::coalesce(rows$PRIVILEGENAME, rows$PRIVILEGEIDENTIFIER),
                            dplyr::coalesce(rows$DUTYNAME, rows$DUTYIDENTIFIER)),
    OBJECT         = object,
    OBJECT_KEY     = paste(rows$SECURABLETYPE, object, .distinct_key(dplyr::coalesce(rows$SECURABLECHILDNAME, "")),
                           sep = "|"),
    DISPLAY        = .is_display_type(rows$SECURABLETYPE),
    LEVEL          = dplyr::coalesce(suppressWarnings(as.integer(rows$ACCESSLEVEL)), 0L),
    LICENSE        = rows$LICENSE,
    MASK           = .graph_license_masks(texts, skus)[match(rows$LICENSE, texts)]
  )
  .at_highest_level(units)
}

# An object listed with two licenses at that level keeps both rows: a set of licenses
# covers it only when it covers each (an AND of the masks could be empty, as if the object
# needed nothing).
.at_highest_level <- function(units) {
  id      <- paste(units$GRAPH_ROLE_KEY, units$UNIT, units$OBJECT_KEY, sep = "\t")
  order   <- order(id, -units$LEVEL, method = "radix")
  first   <- order[!duplicated(id[order])]
  highest <- units$LEVEL == units$LEVEL[first][match(id, id[first])]
  units   <- units[highest, ]
  dplyr::select(units[!duplicated(paste(id[highest], units$MASK, sep = "\t")), ], -LEVEL)
}

# The roles of the graph behind each role of the licenses: by its AOT name, else by its
# name as written, else by its name without "(<AOT name>)". The graph and the PPAC report
# both name an AOT role "<label> (<AOT name>)" and a UI copy "<label>"; a label alone
# finds the AOT role only when no role carries it as its name. A name that still stands
# for several roles takes them all.
.graph_roles_of <- function(license_roles, graph) {
  stored <- dplyr::distinct(tibble::tibble(ROLEIDENTIFIER = graph$ROLEIDENTIFIER, ROLENAME = graph$ROLENAME)) |>
    dplyr::filter(!is.na(ROLEIDENTIFIER)) |>
    dplyr::mutate(
      GRAPH_ROLE_KEY = .identifier_key(ROLEIDENTIFIER),
      NAME_KEY       = .identifier_key(ROLENAME),
      LABEL_KEY      = ifelse(is_guid_name(ROLEIDENTIFIER), NAME_KEY,
                              .identifier_key(sub("\\s*\\([^()]*\\)\\s*$", "", ROLENAME)))
    )
  found <- lapply(seq_len(nrow(license_roles)), function(i) {
    by_id <- unique(stored$GRAPH_ROLE_KEY[stored$GRAPH_ROLE_KEY == license_roles$ROLE_KEY[[i]]])
    if (length(by_id) > 0L) return(by_id)
    name  <- .identifier_key(license_roles$ROLE[[i]])
    exact <- unique(stored$GRAPH_ROLE_KEY[stored$NAME_KEY == name])
    if (length(exact) > 0L) return(exact)
    unique(stored$GRAPH_ROLE_KEY[stored$LABEL_KEY == name])
  })
  .warn_on_graph_role_matches(license_roles$ROLE, found)
  list(
    map     = tibble::tibble(ROLE = rep(license_roles$ROLE, lengths(found)), GRAPH_ROLE_KEY = unlist(found)),
    missing = sort(unique(license_roles$ROLE[lengths(found) == 0L]))
  )
}

.warn_on_graph_role_matches <- function(roles, found) {
  missing <- sort(unique(roles[lengths(found) == 0L]))
  if (length(missing) > 0L) {
    one <- length(missing) == 1L
    warning(sprintf("%d role%s of the licenses %s not in the license graph: %s. %s objects are missing from the ",
                    length(missing), if (one) "" else "s", if (one) "is" else "are",
                    paste(missing, collapse = .LIST_SEPARATOR), if (one) "Its" else "Their"),
            "license need of its users, so they will rather show as differing from PPAC.", call. = FALSE)
  }
  several <- sort(unique(roles[lengths(found) > 1L]))
  if (length(several) > 0L) {
    one <- length(several) == 1L
    warning(sprintf("%d role name%s of the licenses stand%s for several roles of the license graph: %s. ",
                    length(several), if (one) "" else "s", if (one) "s" else "", paste(several, collapse = .LIST_SEPARATOR)),
            "Their objects are taken together.", call. = FALSE)
  }
  invisible(NULL)
}

# PPAC has priority (decided 2026-10-28): where the graph wants more for an object than the
# licenses PPAC bills the user (now_bits), PPAC knows a rule the graph does not, and those
# licenses cover the object; where PPAC bills none, it needs none.
.ppac_priority_masks <- function(masks, now_bits, needed, skus) {
  above <- needed(masks) & bitwAnd(masks, now_bits) == 0L
  none  <- .license_bits(skus$SKUNAME, skus)
  dplyr::case_when(!above ~ masks, now_bits == 0L ~ none, TRUE ~ bitwOr(masks, now_bits))
}

# The cheapest set of priced licenses that covers a set of object masks. Ties go to the
# set within prefer (the licenses the user has), then to fewer and cheaper licenses.
.license_cover_function <- function(skus, priced, cost_of) {
  count <- length(priced)
  sets  <- lapply(seq_len(2^count) - 1L, function(i) priced[bitwAnd(i, 2^(seq_len(count) - 1)) != 0])
  bits  <- vapply(sets, .license_bits, integer(1), skus = skus)
  cost  <- vapply(sets, function(set) cost_of(.identifier_key(set)), numeric(1))
  size  <- lengths(sets)
  rank  <- vapply(sets, function(set) sum(skus$PRIORITY[match(set, skus$SKUNAME)]), numeric(1))
  none  <- .license_bits(skus$SKUNAME, skus)
  reach <- .license_bits(priced, skus)

  cover <- function(masks, prefer = NA_integer_) {
    needed  <- unique(masks[masks != none & bitwAnd(masks, reach) != 0L])
    covers  <- vapply(bits, function(set) all(bitwAnd(needed, set) != 0L), logical(1))
    outside <- if (is.na(prefer)) rep(FALSE, length(bits)) else bitwAnd(bits, bitwNot(prefer)) != 0L
    best    <- which(covers)[order(cost[covers], outside[covers], size[covers], rank[covers])[[1]]]
    list(bits = bits[[best]], cost = cost[[best]], billing = cost_of(.identifier_key(sets[[best]]), "billing"),
         set = sets[[best]])
  }
  list(cover    = cover,
       needed   = function(masks) masks != none & bitwAnd(masks, reach) != 0L,
       unpriced = function(masks) masks != none & bitwAnd(masks, reach) == 0L)
}
