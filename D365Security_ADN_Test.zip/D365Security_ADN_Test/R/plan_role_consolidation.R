#' Plan the consolidation of AOT roles and their copies in the user interface
#'
#' Many roles exist twice: as an AOT role from development and as a copy
#' created in the user interface (its identifier is a GUID). The two do not
#' always grant the same, and users hold one, the other or both. Before a role
#' is changed, cleaned up or licensed anew, both versions are brought
#' together. The function goes through every pair, tells pairs without any
#' difference from pairs to merge, and writes a merged role for the latter.
#' Its result is the content of the deliverable D20; see
#' \code{\link{export_role_consolidation}}.
#'
#' @details
#'
#' **No difference.** A pair has no difference when both versions hold the
#' same own duties, privileges and sub-roles and the same direct access
#' permissions with the same rights (capitals do not count). Such a pair is
#' left as it is (\code{ACTION = "NO_DIFFERENCE"}). The license comparison
#' alone does not decide this: it covers only objects with license data.
#'
#' **Differences.** Every other pair gets \code{ACTION = "MERGE"}. With
#' \code{merge_folder}, \code{\link{export_merged_role_xml}} writes one merged
#' role per AOT role with at least one differing copy, from the AOT role and
#' all of its copies: named \code{<AOT name>_MERGED}, as AOT file, zip and the
#' two files for the browser, straight into \code{merge_folder}
#' (\code{AxSecurityRole/}, \code{SecurityConfiguration/},
#' \code{SecurityGovernance/}, the zip beside them), the folder of the
#' security objects of the project, \code{Data/SecurityObjects}. Files of
#' other roles there stay; a file of the same name is replaced, its earlier
#' version stays in Git. Copies without difference add nothing to it, but they
#' get its name in \code{MERGED_ROLE}: the merged role holds them too. Without
#' \code{merge_folder} nothing is written.
#'
#' **One role to work with.** The merged role is the first step, not the
#' end: analysis, cleanup and the check of the segregation of duties work with
#' it instead of two versions. Merging changes no assignment; users keep their
#' roles until the cleaned-up role replaces both versions.
#'
#' **Check.** A pair whose versions cannot be loaded gets
#' \code{ACTION = "CHECK"} and the reason in \code{ERROR}.
#'
#' **License comparison.** With \code{compare = TRUE},
#' \code{\link{compare_role_versions}} adds the verdict, the licenses of both
#' versions and the objects that differ. It takes about half a minute per
#' pair; a pair whose comparison fails keeps its result, with a warning.
#'
#' **Users.** Per pair the number of users of each version and of both,
#' from \code{\link{get_sql_user_role_assignments}}; no user ids.
#'
#' @param con
#' Database connection. Result of \code{get_connection()}.
#'
#' @param pairs
#' Table with \code{DEVIDENT} (AOT role) and \code{CONFIDENT} (UI role),
#' optionally \code{DEVROLE} and \code{CONFROLE}. Default: every pair
#' \code{\link{load_role_mapping}} finds. A pair given twice (capitals do not
#' count) is taken once.
#'
#' @param merge_folder
#' Folder for the merged roles, as a rule \code{"Data/SecurityObjects"};
#' \code{NULL} = write none.
#'
#' @param compare
#' \code{TRUE} (default) = add the license comparison of each pair.
#'
#' @return
#' A list:
#' \describe{
#'   \item{\code{Pairs}}{One row per pair: \code{NUMBER}, \code{ROLE_AOT},
#'     \code{NAME_AOT}, \code{ROLE_UI}, \code{NAME_UI}, the differences of the
#'     structure (\code{DUTIES_ONLY_AOT}, \code{DUTIES_ONLY_UI},
#'     \code{PRIVILEGES_ONLY_AOT}, \code{PRIVILEGES_ONLY_UI},
#'     \code{SUBROLES_ONLY_AOT}, \code{SUBROLES_ONLY_UI},
#'     \code{DIRECT_ACCESS_DIFFERENT}), \code{VERDICT}, \code{LICENSES_AOT},
#'     \code{LICENSES_UI}, \code{USERS_AOT}, \code{USERS_UI},
#'     \code{USERS_BOTH}, \code{ACTION}, \code{MERGED_ROLE},
#'     \code{MERGE_ERROR}, \code{COMPARE_ERROR} and \code{ERROR}.}
#'   \item{\code{Differences}}{The differences of the structure:
#'     \code{NUMBER}, \code{ELEMENT} (\code{DUTY}, \code{PRIVILEGE},
#'     \code{SUBROLE}, \code{DIRECT_ACCESS}), \code{NAME}, \code{SIDE}
#'     (\code{ONLY_AOT}, \code{ONLY_UI}, \code{OTHER_RIGHTS}),
#'     \code{RIGHTS_AOT}, \code{RIGHTS_UI}.}
#'   \item{\code{LicenseDifferences}}{The objects of the license comparison
#'     that differ, with \code{NUMBER}.}
#'   \item{\code{Merges}}{One row per merged role: \code{MERGED_ROLE},
#'     \code{ROLE_AOT}, \code{ROLES_UI}, \code{NUMBERS}, the counts of its
#'     \code{DUTIES}, \code{PRIVILEGES}, \code{SUBROLES} and
#'     \code{DIRECT_ACCESS}, the files relative to \code{merge_folder}
#'     (\code{XML}, \code{ZIP}, \code{CONFIGURATION}, \code{GOVERNANCE}) and
#'     \code{ERROR}.}
#'   \item{\code{Check}}{The counts in one row.}
#' }
#'
#' @examples
#' \dontrun{
#'
#' plan <- plan_role_consolidation(cnn, merge_folder = "Data/SecurityObjects")
#' table(plan$Pairs$ACTION)
#' export_role_consolidation(plan, "Data/Deliverables/D20_Rollenkonsolidierung.xlsx")
#'
#' }
#'
#' @seealso
#' \code{\link{export_role_consolidation}}
#' \code{\link{export_merged_role_xml}}
#' \code{\link{compare_role_versions}}
#'
#' @export
plan_role_consolidation <- function(con, pairs = NULL, merge_folder = NULL, compare = TRUE) {

  if (!is.null(merge_folder) && !.is_single_string(merge_folder)) {
    stop("merge_folder must be the path of one folder, or NULL for no merged roles.", call. = FALSE)
  }
  pairs <- .version_pairs(con, pairs)
  pairs <- pairs[!duplicated(paste(.identifier_key(pairs$DEVIDENT), .identifier_key(pairs$CONFIDENT))), ]
  roles <- .load_consolidation_roles(con, unique(c(pairs$DEVIDENT, pairs$CONFIDENT)))

  parts  <- lapply(seq_len(nrow(pairs)), function(i) .consolidation_pair(con, pairs[i, ], i, roles, isTRUE(compare)))
  rows   <- dplyr::bind_rows(lapply(parts, `[[`, "row"))
  rows   <- .with_consolidation_users(con, rows)
  merged <- .write_consolidation_merges(con, rows, merge_folder)

  result <- list(
    Pairs              = merged$pairs,
    Differences        = dplyr::bind_rows(c(list(.EMPTY_STRUCTURE_DIFFERENCES), lapply(parts, `[[`, "differences"))),
    LicenseDifferences = dplyr::bind_rows(lapply(parts, `[[`, "licenses")),
    Merges             = merged$merges
  )
  result$Check <- .consolidation_check(result)
  message(sprintf("Role consolidation: %d pairs; %d without difference, %d to merge, %d to check; %d merged roles written.",
                  result$Check$PAIRS, result$Check$NO_DIFFERENCE, result$Check$MERGE, result$Check$CHECK,
                  result$Check$MERGED_ROLES))
  result
}

.EMPTY_STRUCTURE_DIFFERENCES <- tibble::tibble(
  NUMBER = integer(), ELEMENT = character(), NAME = character(), SIDE = character(),
  RIGHTS_AOT = character(), RIGHTS_UI = character()
)

# Each role once, keyed by its identifier: the role, or the reason it could not be loaded.
.load_consolidation_roles <- function(con, identifiers) {
  loaded <- lapply(identifiers, function(id) {
    tryCatch(.load_role_to_export(con, id), error = function(e) .without_sql_statement(conditionMessage(e)))
  })
  stats::setNames(loaded, .identifier_key(identifiers))
}

.consolidation_pair <- function(con, pair, number, roles, compare) {
  aot   <- roles[[.identifier_key(pair$DEVIDENT)]]
  ui    <- roles[[.identifier_key(pair$CONFIDENT)]]
  error <- c(if (is.character(aot)) aot, if (is.character(ui)) ui)
  row   <- tibble::tibble(
    NUMBER   = number,
    ROLE_AOT = if (is.list(aot)) aot$role_name else pair$DEVIDENT,
    NAME_AOT = if (is.list(aot)) aot$role_label else pair$DEVROLE,
    ROLE_UI  = pair$CONFIDENT,
    NAME_UI  = if (is.list(ui)) ui$role_label else pair$CONFROLE
  )
  if (length(error) > 0L) {
    row <- dplyr::bind_cols(row, .structure_counts(NULL), .version_columns(NULL),
                            tibble::tibble(ACTION = "CHECK", COMPARE_ERROR = NA_character_, ERROR = paste(error, collapse = " ")))
    return(list(row = row, differences = NULL, licenses = NULL))
  }

  differences <- .role_structure_differences(aot, ui)
  versions    <- if (compare) .compare_versions_safely(con, pair) else NULL
  row <- dplyr::bind_cols(
    row, .structure_counts(differences), .version_columns(versions$result),
    tibble::tibble(ACTION = if (nrow(differences) == 0L) "NO_DIFFERENCE" else "MERGE",
                   COMPARE_ERROR = if (is.null(versions)) NA_character_ else versions$error, ERROR = NA_character_)
  )
  licenses <- if (is.null(versions$result)) NULL else
    dplyr::mutate(tibble::as_tibble(versions$result$Objects), NUMBER = number, .before = 1)
  list(row = row, differences = dplyr::mutate(differences, NUMBER = number, .before = 1), licenses = licenses)
}

.compare_versions_safely <- function(con, pair) {
  tryCatch(
    list(result = compare_role_versions(con, pair$DEVIDENT, pair$CONFIDENT), error = NA_character_),
    error = function(e) {
      reason <- .without_sql_statement(conditionMessage(e))
      warning("No license comparison of '", pair$DEVIDENT, "' and '", pair$CONFIDENT, "': ", reason, call. = FALSE)
      list(result = NULL, error = reason)
    }
  )
}

.version_columns <- function(result) {
  tibble::tibble(
    VERDICT      = if (is.null(result)) NA_character_ else result$Check$VERDICT,
    LICENSES_AOT = if (is.null(result)) NA_character_ else result$Licenses$LICENSES[[1]],
    LICENSES_UI  = if (is.null(result)) NA_character_ else result$Licenses$LICENSES[[2]]
  )
}

# What one version holds and the other does not, in the own structure of both roles.
.role_structure_differences <- function(aot, ui) {
  parts <- c(DUTY = "duties", PRIVILEGE = "privileges", SUBROLE = "subroles")
  rows  <- lapply(names(parts), function(element) {
    a <- aot[[parts[[element]]]]
    b <- ui[[parts[[element]]]]
    dplyr::bind_rows(.only_in(a, b, element, "ONLY_AOT"), .only_in(b, a, element, "ONLY_UI"))
  })
  dplyr::bind_rows(c(list(.EMPTY_STRUCTURE_DIFFERENCES[, -1]), rows,
                     list(.direct_access_differences(aot$direct_access_permissions, ui$direct_access_permissions))))
}

.only_in <- function(x, y, element, side) {
  only <- x[!.identifier_key(x) %in% .identifier_key(y)]
  tibble::tibble(ELEMENT = rep(element, length(only)), NAME = as.character(only), SIDE = rep(side, length(only)),
                 RIGHTS_AOT = NA_character_, RIGHTS_UI = NA_character_)
}

# Direct access permissions per object or field: "Read=Allow, Update=Allow".
.describe_direct_access <- function(permissions) {
  if (is.null(permissions) || nrow(permissions) == 0L) {
    return(tibble::tibble(KEY = character(), NAME = character(), RIGHTS = character()))
  }
  rights <- vapply(seq_len(nrow(permissions)), function(i) {
    given <- vapply(.ACCESS_RIGHTS, function(r) as.character(permissions[[r]][[i]]), character(1))
    given <- given[!is.na(given) & nzchar(given)]
    paste(paste0(names(given), "=", given), collapse = ", ")
  }, character(1))
  tibble::tibble(
    KEY    = .identifier_key(paste(permissions$ObjektTyp, permissions$Objektname, permissions$Ebene, permissions$Feldname, sep = "|")),
    NAME   = ifelse(permissions$Ebene == "Field", paste0(permissions$Objektname, ".", permissions$Feldname), permissions$Objektname),
    RIGHTS = rights
  )
}

.direct_access_differences <- function(a, b) {
  da   <- .describe_direct_access(a)
  db   <- .describe_direct_access(b)
  both <- dplyr::inner_join(da, db, by = "KEY", suffix = c("_AOT", "_UI"))
  both <- both[both$RIGHTS_AOT != both$RIGHTS_UI, ]
  dplyr::bind_rows(
    tibble::tibble(ELEMENT = "DIRECT_ACCESS", NAME = da$NAME[!da$KEY %in% db$KEY], SIDE = "ONLY_AOT",
                   RIGHTS_AOT = da$RIGHTS[!da$KEY %in% db$KEY], RIGHTS_UI = NA_character_),
    tibble::tibble(ELEMENT = "DIRECT_ACCESS", NAME = db$NAME[!db$KEY %in% da$KEY], SIDE = "ONLY_UI",
                   RIGHTS_AOT = NA_character_, RIGHTS_UI = db$RIGHTS[!db$KEY %in% da$KEY]),
    tibble::tibble(ELEMENT = "DIRECT_ACCESS", NAME = both$NAME_AOT, SIDE = "OTHER_RIGHTS",
                   RIGHTS_AOT = both$RIGHTS_AOT, RIGHTS_UI = both$RIGHTS_UI)
  )
}

.structure_counts <- function(differences) {
  count <- function(element, side) {
    if (is.null(differences)) NA_integer_ else sum(differences$ELEMENT == element & differences$SIDE %in% side)
  }
  tibble::tibble(
    DUTIES_ONLY_AOT         = count("DUTY", "ONLY_AOT"),
    DUTIES_ONLY_UI          = count("DUTY", "ONLY_UI"),
    PRIVILEGES_ONLY_AOT     = count("PRIVILEGE", "ONLY_AOT"),
    PRIVILEGES_ONLY_UI      = count("PRIVILEGE", "ONLY_UI"),
    SUBROLES_ONLY_AOT       = count("SUBROLE", "ONLY_AOT"),
    SUBROLES_ONLY_UI        = count("SUBROLE", "ONLY_UI"),
    DIRECT_ACCESS_DIFFERENT = count("DIRECT_ACCESS", c("ONLY_AOT", "ONLY_UI", "OTHER_RIGHTS"))
  )
}

# The number of users of each version and of both; NA when the assignments cannot be read.
.with_consolidation_users <- function(con, rows) {
  assignments <- tryCatch(
    get_sql_user_role_assignments(con, roles = unique(c(rows$ROLE_AOT, rows$ROLE_UI))),
    error = function(e) {
      warning("The role assignments could not be read, so the users are not counted: ",
              .without_sql_statement(conditionMessage(e)), call. = FALSE)
      NULL
    }
  )
  users_of <- function(role) {
    unique(assignments$USERID[.identifier_key(assignments$SECURITYROLEIDENTIFIER) == .identifier_key(role)])
  }
  count <- function(a, b = NULL) {
    if (is.null(assignments)) return(NA_integer_)
    length(if (is.null(b)) users_of(a) else intersect(users_of(a), users_of(b)))
  }
  rows$USERS_AOT  <- vapply(rows$ROLE_AOT, count, integer(1), USE.NAMES = FALSE)
  rows$USERS_UI   <- vapply(rows$ROLE_UI, count, integer(1), USE.NAMES = FALSE)
  rows$USERS_BOTH <- vapply(seq_len(nrow(rows)), function(i) count(rows$ROLE_AOT[[i]], rows$ROLE_UI[[i]]), integer(1))
  rows
}

.EMPTY_MERGES <- tibble::tibble(
  MERGED_ROLE = character(), ROLE_AOT = character(), ROLES_UI = character(), NUMBERS = character(),
  DUTIES = integer(), PRIVILEGES = integer(), SUBROLES = integer(), DIRECT_ACCESS = integer(),
  XML = character(), ZIP = character(), CONFIGURATION = character(), GOVERNANCE = character(), ERROR = character()
)

# One merged role per AOT role with a differing copy, from the AOT role and all of its loaded copies:
# a copy without difference adds nothing, but the merged role then stands for it too.
.write_consolidation_merges <- function(con, rows, merge_folder) {
  rows$MERGED_ROLE <- NA_character_
  rows$MERGE_ERROR <- NA_character_
  aot_keys <- .identifier_key(rows$ROLE_AOT)
  to_merge <- rows$ACTION %in% c("MERGE", "NO_DIFFERENCE") & aot_keys %in% aot_keys[rows$ACTION == "MERGE"]
  if (is.null(merge_folder) || !any(to_merge)) {
    return(list(pairs = .order_consolidation_columns(rows), merges = .EMPTY_MERGES))
  }
  dir.create(merge_folder, recursive = TRUE, showWarnings = FALSE)

  groups <- split(rows[to_merge, ], aot_keys[to_merge])
  merges <- lapply(groups, function(group) {
    merged <- tryCatch(
      suppressMessages(export_merged_role_xml(con, c(group$ROLE_AOT[[1]], group$ROLE_UI), merge_folder)),
      error = function(e) .without_sql_statement(conditionMessage(e))
    )
    .merge_row(group, merged, merge_folder)
  })
  merges <- dplyr::bind_rows(c(list(.EMPTY_MERGES), merges))
  for (i in seq_len(nrow(merges))) {
    at <- rows$NUMBER %in% as.integer(strsplit(merges$NUMBERS[[i]], .LIST_SEPARATOR, fixed = TRUE)[[1]])
    rows$MERGED_ROLE[at] <- merges$MERGED_ROLE[[i]]
    rows$MERGE_ERROR[at] <- merges$ERROR[[i]]
  }
  list(pairs = .order_consolidation_columns(rows), merges = merges)
}

# A path below the folder, without the folder: the folder is a local path.
.path_below <- function(path, folder) {
  if (is.null(path) || length(path) != 1L || is.na(path)) return(NA_character_)
  base <- paste0(normalizePath(folder, winslash = "/", mustWork = FALSE), "/")
  full <- normalizePath(path, winslash = "/", mustWork = FALSE)
  if (startsWith(full, base)) substring(full, nchar(base) + 1L) else full
}

.merge_row <- function(group, merged, merge_folder) {
  failed <- is.character(merged)
  if (failed) {
    warning("No merged role of '", group$ROLE_AOT[[1]], "': ", merged, call. = FALSE)
  }
  file_of <- function(part) if (failed) NA_character_ else .path_below(merged[[part]], merge_folder)
  tibble::tibble(
    MERGED_ROLE   = if (failed) NA_character_ else merged$role$role_name,
    ROLE_AOT      = group$ROLE_AOT[[1]],
    ROLES_UI      = paste(group$ROLE_UI, collapse = .LIST_SEPARATOR),
    NUMBERS       = paste(group$NUMBER, collapse = .LIST_SEPARATOR),
    DUTIES        = if (failed) NA_integer_ else length(merged$role$duties),
    PRIVILEGES    = if (failed) NA_integer_ else length(merged$role$privileges),
    SUBROLES      = if (failed) NA_integer_ else length(merged$role$subroles),
    DIRECT_ACCESS = if (failed) NA_integer_ else as.integer(.direct_access_count(merged$role)),
    XML           = file_of("xml"),
    ZIP           = file_of("zip"),
    CONFIGURATION = file_of("security_configuration"),
    GOVERNANCE    = file_of("security_governance"),
    ERROR         = if (failed) merged else NA_character_
  )
}

.order_consolidation_columns <- function(rows) {
  first <- c("NUMBER", "ROLE_AOT", "NAME_AOT", "ROLE_UI", "NAME_UI")
  last  <- c("ACTION", "MERGED_ROLE", "MERGE_ERROR", "COMPARE_ERROR", "ERROR")
  rows[, c(first, setdiff(names(rows), c(first, last)), last)]
}

.consolidation_check <- function(result) {
  pairs <- result$Pairs
  tibble::tibble(
    PAIRS         = nrow(pairs),
    NO_DIFFERENCE = sum(pairs$ACTION == "NO_DIFFERENCE"),
    MERGE         = sum(pairs$ACTION == "MERGE"),
    CHECK         = sum(pairs$ACTION == "CHECK"),
    COMPARED      = sum(!is.na(pairs$VERDICT)),
    MERGED_ROLES  = sum(!is.na(result$Merges$MERGED_ROLE)),
    MERGE_ERRORS  = sum(!is.na(result$Merges$ERROR)),
    USERS_AOT     = sum(pairs$USERS_AOT, na.rm = TRUE),
    USERS_UI      = sum(pairs$USERS_UI, na.rm = TRUE)
  )
}
