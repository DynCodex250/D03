#' Fill the test ticket of a cleaned-up role (D11, strand A)
#'
#' Fills the ticket template of the test concept D11 (section 6) for one role:
#' the new role in the title, previous and target license, the affected users
#' and their companies, the rank in the ranking of the most expensive roles
#' (D04), and what changes: the license drivers that are removed, moved to an
#' add-on role, or left to clarify. Writes the ticket as text, to paste into
#' the ticket system, and as Word.
#'
#' @details
#'
#' **What is filled from the data.**
#' \describe{
#'   \item{New role}{\code{WIBU_<role_area>_<short name of the target
#'     license>}, the naming rule of the role model, for example
#'     \code{WIBU_Verkauf_Innendienst_SCM}.}
#'   \item{Previous license}{The licenses the role fixes today
#'     (\code{report$Licenses}), for example "Commerce + Finance + Supply Chain
#'     Management"; without one, the need of the role.}
#'   \item{Affected users}{The active users of the role (\code{report$Users})
#'     and their companies from the role assignments. Users assigned without
#'     company are named next to the companies ("0360, 0800; 1 Benutzer in
#'     allen Gesellschaften"); only when all are, the ticket says "allen
#'     Gesellschaften".}
#'   \item{Rank}{The rank of the role in \code{ranking}, also when the role
#'     is a UI version listed under its AOT role, and in a ranking from the
#'     PPAC report, which names the role by its label.}
#'   \item{License drivers}{Each block of the role that fixes a base license
#'     other than the target license: moved to an add-on role
#'     \code{WIBU_<role_area>_<short name>} when users used it; removed when
#'     the telemetry can see it and nobody used it (partly used counts as not
#'     used, as in the proposal), with the number of users without usage data
#'     to check before; left to clarify with the business department when it
#'     holds no form, or when no user of the role has usage data.}
#' }
#'
#' **What stays a placeholder** in square brackets until it is given: the
#' person assigned, the due date, the test user, the test cases (until the
#' process-role matrix D19 is passed as \code{test_cases}), whether the
#' blocklist D18 is touched (until it is passed as \code{blocklist}), the rank
#' without \code{ranking}, and the result. The ticket gets no ticket number.
#'
#' @param con
#' Database connection. Result of \code{get_connection()}. Needed for the
#' companies, and for the report when \code{report} is \code{NULL}.
#'
#' @param role
#' AOT name or GUID of the cleaned-up role, for example
#' \code{"_WIBU_VERKAUF_INNENDIENST_MITARBEITER"}. With \code{report} also the
#' name of its role as the PPAC report writes it, for example
#' \code{"_WIBU Verkauf Innendienst Mitarbeiter"}; the ticket then works with
#' the AOT name of the report.
#'
#' @param role_area
#' The \code{<Bereich>_<Funktion>} part of the new role name, of letters,
#' digits and underscores, for example \code{"Verkauf_Innendienst"}.
#'
#' @param target_license
#' The license the new role is to need. Default:
#' \code{"Supply Chain Management"}.
#'
#' @param usage
#' Telemetry, see \code{\link{analyze_role_license_report}}; only used when
#' \code{report} is \code{NULL}.
#'
#' @param report
#' The result of \code{\link{analyze_role_license_report}} for the role, with
#' usage data and not anonymized: the companies are found by the user ids.
#' \code{NULL} = built here (a few minutes).
#'
#' @param ranking
#' The result of \code{\link{rank_roles_by_license_cost}}, or its
#' \code{Ranking}, from the database or from the PPAC report. \code{NULL} =
#' the rank stays a placeholder.
#'
#' @param environment
#' Test environment. Default: \code{"INT"}.
#'
#' @param project
#' Project of the ticket system. Default: \code{"MD3"}.
#'
#' @param assignee,due_date,test_user
#' Person assigned, due date (a \code{Date} or text) and test user, for
#' example \code{"TST_VIT01"}. \code{NULL} = placeholder.
#'
#' @param test_cases
#' The test cases of the role's processes: a table with the columns
#' \code{TESTCASE_ID} and \code{PROCESS} (line breaks become spaces, "|" is
#' escaped), for example
#' \code{data.frame(TESTCASE_ID = "TC-01", PROCESS = "Auftrag anlegen")}.
#' \code{NULL} = placeholder rows.
#'
#' @param blocklist
#' The controlled duties and privileges of the blocklist D18, as AOT names.
#' The ticket names those the role holds, or "nein". \code{NULL} = placeholder.
#'
#' @param proposal_file
#' Name of the proposal the change follows, for example
#' \code{"Vorschlag__WIBU_VERKAUF_INNENDIENST_MITARBEITER.xlsx"}. \code{NULL} =
#' "D365Security" with today's date.
#'
#' @param output_folder
#' Folder for \code{Ticket_Strang_A_<role>.md} and \code{.docx}; created when
#' missing. Files of the same name are overwritten. \code{NULL} = no files. The Word file needs the package rmarkdown
#' and pandoc (RStudio brings both); without, only the text file is written,
#' with a warning.
#'
#' @return
#' List:
#' \describe{
#'   \item{\code{Text}}{The ticket as Markdown text.}
#'   \item{\code{Fields}}{One row per field: \code{FIELD}, \code{VALUE},
#'     \code{FILLED} (\code{FALSE} for a placeholder).}
#'   \item{\code{Files}}{\code{text} and \code{word}, the paths, or
#'     \code{NA}.}
#' }
#'
#' @examples
#' \dontrun{
#'
#' report  <- analyze_role_license_report(cnn, "_WIBU_VERKAUF_INNENDIENST_MITARBEITER", usage = usage)
#' ranking <- rank_roles_by_license_cost(cnn, prices = "Data/Lizenzpreise.xlsx")
#'
#' ticket <- create_role_test_ticket(
#'   cnn, "_WIBU_VERKAUF_INNENDIENST_MITARBEITER",
#'   role_area     = "Verkauf_Innendienst",
#'   report        = report,
#'   ranking       = ranking,
#'   assignee      = "Key-User Innendienst",
#'   due_date      = as.Date("2026-11-15"),
#'   output_folder = "Data/Reports/Tickets"
#' )
#' ticket$Fields[!ticket$Fields$FILLED, ]
#'
#' }
#'
#' @seealso
#' \code{\link{analyze_role_license_report}}
#' \code{\link{rank_roles_by_license_cost}}
#' \code{\link{build_license_roles}}
#'
#' @export
create_role_test_ticket <- function(con, role, role_area, target_license = "Supply Chain Management",
                                    usage = NULL, report = NULL, ranking = NULL,
                                    environment = "INT", project = "MD3",
                                    assignee = NULL, due_date = NULL, test_user = NULL,
                                    test_cases = NULL, blocklist = NULL, proposal_file = NULL,
                                    output_folder = NULL) {

  .ticket_request(role, role_area, report, test_cases, output_folder,
                  texts = list(target_license = target_license, environment = environment, project = project))
  report <- if (is.null(report)) analyze_role_license_report(con, role, usage = usage) else report
  role   <- report$Role$IDENTIFIER   # the AOT name, also when role was given by its name

  drivers <- .ticket_drivers(report, target_license)
  values  <- list(
    new_role    = paste0("WIBU_", role_area, "_", .license_suffix(target_license)),
    project     = project,
    environment = environment,
    assignee    = .or_placeholder(assignee, "[Key-User / Tester]"),
    due_date    = .or_placeholder(if (inherits(due_date, "Date")) format(due_date, "%d.%m.%Y") else due_date, "[Datum]"),
    old_role    = dplyr::coalesce(report$Role$NAME, report$Role$IDENTIFIER),
    rank        = .ticket_rank(ranking, role, report$Role$NAME),
    before      = .ticket_licenses_before(report),
    target      = target_license,
    users       = nrow(report$Users),
    companies   = .ticket_companies(con, role, report$Users$USERID),
    proposal    = .or_placeholder(proposal_file, paste0("D365Security, Stand ", format(Sys.Date(), "%d.%m.%Y"))),
    removed     = .ticket_removed(drivers, report),
    add_on      = .ticket_add_ons(drivers, role_area),
    clarify     = .ticket_blocks(drivers[drivers$ACTION == "CLARIFY", ]),
    blocklist   = .ticket_blocklist(report, blocklist),
    test_user   = .or_placeholder(test_user, "[TST_…]"),
    test_cases  = test_cases
  )

  text   <- .ticket_text(values)
  fields <- .ticket_fields(values)
  files  <- if (is.null(output_folder)) list(text = NA_character_, word = NA_character_) else
    .write_ticket(text, output_folder, paste0("Ticket_Strang_A_", gsub("[^A-Za-z0-9_-]", "_", role)))

  message(sprintf("Ticket for %s filled; %d of %d fields open: %s.", values$new_role, sum(!fields$FILLED), nrow(fields),
                  paste(fields$FIELD[!fields$FILLED], collapse = ", ")))
  list(Text = text, Fields = fields, Files = files)
}

.ticket_request <- function(role, role_area, report, test_cases, output_folder, texts) {
  if (!.is_single_string(role)) {
    stop("role must name one role: the AOT name, or the GUID of a role created in the user interface.", call. = FALSE)
  }
  if (!.is_single_string(role_area) || !grepl("^[A-Za-z0-9_]+$", role_area)) {
    stop("role_area must be the <Bereich>_<Funktion> part of the new role name, of letters, digits and underscores, ",
         "for example \"Verkauf_Innendienst\".", call. = FALSE)
  }
  for (name in names(texts)) {
    if (!.is_single_string(texts[[name]])) stop(name, " must be one text, for example \"INT\".", call. = FALSE)
  }
  if (!is.null(report) && !.identifier_key(role) %in% .identifier_key(.report_role_names(report$Role))) {
    stop("report is for ", report$Role$IDENTIFIER, " (", report$Role$NAME, "), not for ", role, ". Give role as the ",
         "AOT name or the name of the report's role.", call. = FALSE)
  }
  if (isTRUE(report$Role$ANONYMIZED)) {
    stop("report is anonymized, so the companies of its users cannot be found. Pass the report without anonymize; ",
         "the ticket itself holds counts and companies only, no user ids.", call. = FALSE)
  }
  if (!is.null(test_cases) && !(is.data.frame(test_cases) && all(c("TESTCASE_ID", "PROCESS") %in% names(test_cases)))) {
    stop("test_cases must be a table with the columns TESTCASE_ID and PROCESS, or NULL.", call. = FALSE)
  }
  if (!is.null(output_folder) && !.is_single_string(output_folder)) {
    stop("output_folder must be the path of one folder.", call. = FALSE)
  }
  invisible(TRUE)
}

# The AOT name, the name and the label of a role: the report names the role
# "_WIBU Verkauf Innendienst Mitarbeiter (_WIBU_...)", the PPAC report "_WIBU Verkauf
# Innendienst Mitarbeiter".
.report_role_names <- function(role) {
  name <- if (is.null(role$NAME)) NA_character_ else role$NAME
  unique(stats::na.omit(c(role$IDENTIFIER, name, sub("\\s*\\([^()]*\\)\\s*$", "", name))))
}

.or_placeholder <- function(value, placeholder) {
  if (.is_single_string(value)) value else placeholder
}

# The licenses the role fixes, cheapest first; without one, the need of the role.
.ticket_licenses_before <- function(report) {
  if (nrow(report$Licenses) > 0L) {
    return(paste(report$Licenses$SKUNAME, collapse = " + "))
  }
  gsub(" | ", " oder ", report$RoleNeed$NEED[[1]], fixed = TRUE)
}

# The rank of the role in the ranking, also as a UI version of its AOT role, and by its
# label: the ranking from the PPAC report names roles as "_WIBU Verkauf Innendienst
# Mitarbeiter", the report as "_WIBU Verkauf Innendienst Mitarbeiter (_WIBU_...)".
.ticket_rank <- function(ranking, role, role_name = NA_character_) {
  table <- if (is.data.frame(ranking)) ranking else ranking$Ranking
  if (is.null(table) || nrow(table) == 0L) {
    return("[n]")
  }
  names    <- .identifier_key(.report_role_names(list(IDENTIFIER = role, NAME = role_name)))
  versions <- strsplit(dplyr::coalesce(table$VERSIONS, ""), .LIST_SEPARATOR, fixed = TRUE)
  found    <- .identifier_key(table$ROLE) %in% names |
    vapply(versions, function(v) .identifier_key(role) %in% .identifier_key(v), logical(1))
  if (any(found)) as.character(table$RANK[found][[1]]) else "[n]"
}

# The companies of the active users of the role. "All" stands for an assignment without
# company; it is named next to the companies, so one such user does not hide them.
.ticket_companies <- function(con, role, user_ids) {
  if (length(user_ids) == 0L) {
    return("[Gesellschaft(en)]")
  }
  assignments <- tryCatch(
    get_sql_user_role_assignments(con, roles = role),
    error = function(e) {
      warning("The role assignments could not be read, so the companies stay a placeholder: ",
              .without_sql_statement(conditionMessage(e)), call. = FALSE)
      NULL
    }
  )
  if (is.null(assignments)) {
    return("[Gesellschaft(en)]")
  }
  own <- assignments[.identifier_key(assignments$SECURITYROLEIDENTIFIER) == .identifier_key(role) &
                       tolower(assignments$USERID) %in% tolower(user_ids), ]
  companies  <- sort(unique(own$ORGANIZATIONID[!is.na(own$ORGANIZATIONID) & own$ORGANIZATIONID != "All"]))
  everywhere <- length(unique(tolower(own$USERID[own$ORGANIZATIONID %in% "All"])))
  if (length(companies) == 0L) {
    return(if (everywhere > 0L) "allen Gesellschaften" else "[Gesellschaft(en)]")
  }
  paste0(paste(companies, collapse = .LIST_SEPARATOR),
         if (everywhere > 0L) sprintf("; %d Benutzer in allen Gesellschaften", everywhere) else "")
}

# Each block that fixes a base license other than the target license, with what happens to it.
.ticket_drivers <- function(report, target_license) {
  blocks <- report$Blocks[report$Blocks$IS_BASE & report$Blocks$FIXING_OBJECT_COUNT > 0 &
                            report$Blocks$NEED != target_license, ]
  usage  <- report$UserBlocks
  has_usage <- isTRUE(report$Role$HAS_USAGE) && !is.null(usage)

  info <- lapply(seq_len(nrow(blocks)), function(i) {
    rows <- if (has_usage) usage[usage$BLOCK_TYPE == blocks$BLOCK_TYPE[[i]] & usage$BLOCK_ID == blocks$BLOCK_ID[[i]], ] else NULL
    measurable <- !is.null(rows) && max(rows$BASE_MEASURABLE_COUNT, 0, na.rm = TRUE) > 0 &&
      any(rows$RATING != .USAGE_NO_DATA)
    used_by    <- if (is.null(rows)) character() else unique(tolower(rows$USERID[rows$RATING == .USAGE_USED]))
    list(ACTION = if (length(used_by) > 0L) "ADD_ON" else if (!measurable) "CLARIFY" else "REMOVE", USED_BY = list(used_by))
  })
  dplyr::mutate(
    dplyr::select(blocks, BLOCK_TYPE, BLOCK_ID, BLOCK_NAME, NEED),
    ACTION  = vapply(info, `[[`, character(1), "ACTION"),
    USED_BY = lapply(info, function(x) x$USED_BY[[1]])
  )
}

.ticket_blocks <- function(blocks) {
  if (nrow(blocks) == 0L) "keine" else paste0(blocks$BLOCK_ID, " (", blocks$BLOCK_NAME, ")", collapse = .LIST_SEPARATOR)
}

# The drivers nobody used; users without usage data may still need them.
.ticket_removed <- function(drivers, report) {
  removed <- .ticket_blocks(drivers[drivers$ACTION == "REMOVE", ])
  rated   <- report$UserBlocks
  no_data <- if (is.null(rated)) 0L else length(unique(tolower(rated$USERID[rated$RATING == .USAGE_NO_DATA])))
  if (removed == "keine" || no_data == 0L) removed else
    sprintf("%s; ohne Nutzungsdaten: %d Benutzer, vor dem Entfernen prüfen", removed, no_data)
}

# One add-on role per license, for the users who used its blocks.
.ticket_add_ons <- function(drivers, role_area) {
  add_ons <- drivers[drivers$ACTION == "ADD_ON", ]
  if (nrow(add_ons) == 0L) {
    return("keine")
  }
  lines <- vapply(split(add_ons, add_ons$NEED), function(part) {
    sprintf("WIBU_%s_%s (%s) für %d Benutzer: %s", role_area, .license_suffix(part$NEED[[1]]), part$NEED[[1]],
            length(unique(unlist(part$USED_BY))), .ticket_blocks(part))
  }, character(1))
  paste(unname(lines), collapse = "; ")
}

.ticket_blocklist <- function(report, blocklist) {
  if (is.null(blocklist)) {
    return("[ja/nein, welche]")
  }
  held <- unique(c(report$Duties$DUTYIDENTIFIER, report$Privileges$PRIVILEGEIDENTIFIER))
  hits <- held[.identifier_key(held) %in% .identifier_key(blocklist)]
  if (length(hits) == 0L) "nein" else paste0("ja: ", paste(hits, collapse = .LIST_SEPARATOR))
}

.ticket_test_case_rows <- function(test_cases) {
  if (is.null(test_cases) || nrow(test_cases) == 0L) {
    return(c("| [ID] | [Prozess] | | |", "| [ID] | [Prozess] | | |"))
  }
  sprintf("| %s | %s | | |", .ticket_cell(test_cases$TESTCASE_ID), .ticket_cell(test_cases$PROCESS))
}

# A table cell of one line: no line breaks, "|" escaped, empty for a missing value.
.ticket_cell <- function(value) {
  gsub("|", "\\|", gsub("[\r\n]+", " ", dplyr::coalesce(as.character(value), "")), fixed = TRUE)
}

# The template of D11, section 6.
.ticket_text <- function(v) {
  paste(c(
    sprintf("# [Strang A] Test der bereinigten Rolle %s mit den vorhandenen Testfällen", v$new_role),
    "",
    sprintf("**Projekt / Typ / Komponente:** %s · Test · Berechtigungen  ", v$project),
    sprintf("**Umgebung:** %s  ", v$environment),
    sprintf("**Zugewiesen an:** %s · **Fällig bis:** %s", v$assignee, v$due_date),
    "",
    "## 1. Hintergrund",
    "",
    sprintf("Im Rahmen der Lizenzkostensenkung (Strang A) wurde die Rolle %s bereinigt. Sie steht auf Platz %s der Rangliste der teuersten Rollen (D04).",
            v$old_role, v$rank),
    "",
    sprintf("- Bisherige Lizenz: %s", v$before),
    sprintf("- Ziel-Lizenz: %s", v$target),
    sprintf("- Betroffene Benutzer: %d in %s", v$users, v$companies),
    "",
    "## 2. Was geändert wurde",
    "",
    sprintf("- Neue Rolle: %s (Vorschlag aus dem Werkzeug: %s)", v$new_role, v$proposal),
    sprintf("- Entfernte Aufgaben (Lizenztreiber, nicht genutzt): %s", v$removed),
    sprintf("- In eine Zusatzrolle ausgelagert: %s", v$add_on),
    sprintf("- Nicht messbar, mit dem Fachbereich zu klären: %s", v$clarify),
    sprintf("- Kontrollierte Funktionen (Sperrliste D18) berührt: %s", v$blocklist),
    "",
    "## 3. Testbenutzer",
    "",
    sprintf("- %s: erhält nur die neue Rolle und die übrigen Rollen seiner Stelle (D06), keine Administratorrechte.", v$test_user),
    sprintf("- Gesellschaft(en): %s", v$companies),
    "",
    "## 4. Zu testende Prozesse",
    "",
    "Getestet werden die Prozesse, nicht die Rolle. Es laufen die vorhandenen Testfälle aus den Tests für Updates und Paketeinspielungen:",
    "",
    "| Testfall-ID | Prozess | Ergebnis (ok / Fehler) | Bemerkung |",
    "|---|---|---|---|",
    .ticket_test_case_rows(v$test_cases),
    "",
    "## 5. Abnahmekriterien",
    "",
    "1. Alle Testfälle laufen unverändert durch.",
    "2. Der Testbenutzer löst die geplante Lizenz aus (D365: „Zusammenfassung der Lizenznutzung“ oder Lizenzbericht des Werkzeugs).",
    "3. Keine Rechte aus der Sperrliste (D18) ohne Freigabe.",
    "",
    "## 6. Wenn etwas nicht passt",
    "",
    "- Ein Prozessschritt bricht ab oder eine Funktion fehlt: Fehler „Security / Berechtigung – Blocker“ anlegen und mit diesem Ticket verknüpfen. Die Rolle wird erst umgestellt, wenn der Fehler behoben ist.",
    "- Nachbesserung: Ändert die fehlende Funktion die Lizenz nicht, kommt sie in die Rolle. Ändert oder erhöht sie die Lizenz, wird dafür eine Zusatzrolle erstellt.",
    "- Kein Testfall deckt einen Prozess der Rolle ab: Testfall ergänzen, bevor die Rolle umgestellt wird.",
    "- Der Prozess läuft, löst aber eine höhere Lizenz aus: Fehler „Warning / License Issue“.",
    "- Nach der Umstellung fehlt etwas: Die bisherigen Rollen werden wieder eingespielt; die Lücke kommt in ein neues Ticket.",
    "",
    "## 7. Ergebnis (füllt der Tester aus)",
    "",
    "- Ergebnis gesamt: [bestanden / nicht bestanden]",
    "- Lizenz laut D365: [ … ]",
    "- Freigabe zur Umstellung durch den Owner der Rolle (D05): [Name, Datum]",
    "",
    "**Anhänge:** Lizenzbericht vorher und nachher, Export der Rolle, Liste der geänderten Aufgaben.",
    ""
  ), collapse = "\n")
}

.ticket_fields <- function(v) {
  value <- c(v$new_role, v$project, v$environment, v$assignee, v$due_date, v$old_role, v$rank, v$before, v$target,
             as.character(v$users), v$companies, v$proposal, v$removed, v$add_on, v$clarify, v$blocklist, v$test_user,
             if (is.null(v$test_cases)) "[ID] / [Prozess]" else paste(v$test_cases$TESTCASE_ID, collapse = .LIST_SEPARATOR))
  tibble::tibble(
    FIELD  = c("Titel / neue Rolle", "Projekt", "Umgebung", "Zugewiesen an", "Fällig bis", "Bisheriger Rollenname",
               "Platz in D04", "Bisherige Lizenz", "Ziel-Lizenz", "Betroffene Benutzer", "Gesellschaften", "Vorschlag",
               "Entfernte Aufgaben", "Zusatzrollen", "Zu klären", "Sperrliste D18", "Testbenutzer", "Testfälle"),
    VALUE  = value,
    FILLED = !startsWith(value, "[")
  )
}

# The text as Markdown (UTF-8) and, with pandoc, as Word.
.write_ticket <- function(text, folder, name) {
  dir.create(folder, recursive = TRUE, showWarnings = FALSE)
  text_path <- file.path(folder, paste0(name, ".md"))
  writeBin(charToRaw(enc2utf8(text)), text_path)

  if (!requireNamespace("rmarkdown", quietly = TRUE) || !rmarkdown::pandoc_available()) {
    warning("rmarkdown or pandoc was not found, so only the text file was written. RStudio brings both; outside ",
            "RStudio install rmarkdown and set RSTUDIO_PANDOC to the pandoc folder.", call. = FALSE)
    return(list(text = text_path, word = NA_character_))
  }
  word_path <- file.path(folder, paste0(name, ".docx"))
  rmarkdown::pandoc_convert(basename(text_path), to = "docx", from = "markdown", output = basename(word_path),
                            wd = normalizePath(folder, winslash = "/"))
  list(text = text_path, word = word_path)
}
