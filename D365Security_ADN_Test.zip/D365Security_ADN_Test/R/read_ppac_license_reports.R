#' Read the detailed license report of the Power Platform admin center
#'
#' Reads the detailed Finance and Operations license report of the Power
#' Platform admin center (PPAC) as one row per environment, user, role and
#' license, in the layout of \code{\link{get_user_licenses_by_role}}. The
#' result goes into \code{\link{rank_roles_by_license_cost}} (one environment)
#' and \code{\link{compare_environment_license_cost}} (two environments).
#'
#' @details
#'
#' The report lists, per environment, every user with every role and the
#' license the role requires; a role that requires several licenses has a row
#' for each, and it needs all of them.
#' \itemize{
#'   \item In production \code{RequiredLicense} names the license, or
#'     \code{None}.
#'   \item In a sandbox the report counts no license and writes
#'     \code{Not Applicable (<license>)}. The license in brackets is the one the
#'     role would need in production; it becomes \code{SKUNAME},
#'     \code{COUNTED} is \code{FALSE}.
#' }
#' \code{USERID} comes from a column \code{USERID} when the file has one, for
#' example after pseudonymizing; otherwise it is the part of the e-mail before
#' the @. The report's own \code{UserId} (an Entra id) is not used. Every user
#' counts as enabled: the report holds no disabled users.
#'
#' @param path
#' Path of the \code{.csv} file, as exported from the PPAC or written after
#' pseudonymizing (a leading column of row numbers is ignored).
#'
#' @param environment
#' Names of the environments to keep, as in \code{EnvironmentName}, for
#' example \code{"wibu-produktiv"}. \code{NULL} = all.
#'
#' @return
#' Tibble: \code{ENVIRONMENT}, \code{ENVIRONMENT_TYPE} (\code{Production} or
#' \code{Sandbox}), \code{USERID}, \code{USEREMAIL}, \code{USERENABLED}
#' (always 1), \code{ROLEIDENTIFIER} and \code{SECURITYROLENAME} (both the role
#' name of the report), \code{SKUNAME}, \code{COUNTED}, \code{REFRESHEDON}.
#'
#' @examples
#' \dontrun{
#'
#' path <- "Input/Finance_And_Operations_Licensing_Detailed_Report_20261027_pseudonymized.csv"
#' prod <- read_ppac_license_detail(path, environment = "wibu-produktiv")
#' all  <- read_ppac_license_detail(path)
#' table(all$ENVIRONMENT)
#'
#' }
#'
#' @seealso
#' \code{\link{read_ppac_license_report}}
#' \code{\link{rank_roles_by_license_cost}}
#' \code{\link{compare_environment_license_cost}}
#'
#' @export
read_ppac_license_detail <- function(path, environment = NULL) {

  report <- .read_ppac_csv(path, c("EnvironmentName", "EnvironmentType", "UserEmail", "SecurityRole", "RequiredLicense",
                                   "RefreshedOn"), "detailed license report")
  report <- report[report$EnvironmentName %in% .ppac_environments(report$EnvironmentName, environment), ]
  report <- .ppac_rows_with_user(report, "detailed license report", needs = "RequiredLicense")

  required       <- trimws(report$RequiredLicense)
  not_applicable <- grepl("^Not Applicable", required, ignore.case = TRUE)
  in_brackets    <- sub("^Not Applicable\\s*\\((.*)\\)\\s*$", "\\1", required, ignore.case = TRUE)
  license        <- ifelse(!not_applicable, required, ifelse(in_brackets == required, .NO_LICENSE, in_brackets))

  tibble::tibble(
    ENVIRONMENT      = report$EnvironmentName,
    ENVIRONMENT_TYPE = report$EnvironmentType,
    USERID           = .ppac_user_ids(report),
    USEREMAIL        = report$UserEmail,
    USERENABLED      = 1L,
    ROLEIDENTIFIER   = report$SecurityRole,
    SECURITYROLENAME = report$SecurityRole,
    SKUNAME          = .standard_license_names(license),
    COUNTED          = !not_applicable,
    REFRESHEDON      = report$RefreshedOn
  )
}

#' Read the license report per user of the Power Platform admin center
#'
#' Reads the Finance and Operations license report of the Power Platform admin
#' center (PPAC): one row per user of the production environment with the
#' licenses the user requires, has been assigned and misses. The result goes
#' into \code{\link{compare_assigned_license_cost}}.
#'
#' @details
#'
#' The report writes the licenses without spaces and separated by commas
#' (\code{Commerce,Finance,SupplyChainManagement}). They are returned with the
#' names of the detailed report and \code{LicensingAllSkus}, cheapest first and
#' separated by ", ": \code{"Commerce, Finance, Supply Chain Management"};
#' Activity becomes Operations - Activity, TeamMember Team Members.
#' \code{NotApplicable} and \code{-} become an empty text. \code{USERID} as in
#' \code{\link{read_ppac_license_detail}}. A user the report lists in several
#' rows (one with the licenses, empty ones besides) becomes one row with all
#' licenses of those rows, with a warning.
#'
#' @param path
#' Path of the \code{.csv} file.
#'
#' @return
#' Tibble: \code{USERID}, \code{USEREMAIL}, \code{REQUIRED}, \code{ASSIGNED},
#' \code{MISSING}, \code{REFRESHEDON}.
#'
#' @examples
#' \dontrun{
#'
#' users <- read_ppac_license_report("Input/Finance_And_Operations_Licensing_Report_20261027_pseudonymized.csv")
#' table(users$MISSING)
#'
#' }
#'
#' @seealso
#' \code{\link{compare_assigned_license_cost}}
#' \code{\link{read_ppac_license_detail}}
#'
#' @export
read_ppac_license_report <- function(path) {

  report <- .read_ppac_csv(path, c("UserEmail", "RequiredLicense(s)", "AssignedLicense(s)", "MissingLicense(s)",
                                   "RefreshedOn"), "license report")
  report <- .ppac_rows_with_user(report, "license report")
  .merge_user_rows(tibble::tibble(
    USERID      = .ppac_user_ids(report),
    USEREMAIL   = report$UserEmail,
    REQUIRED    = .ppac_license_list(report$`RequiredLicense(s)`),
    ASSIGNED    = .ppac_license_list(report$`AssignedLicense(s)`),
    MISSING     = .ppac_license_list(report$`MissingLicense(s)`),
    REFRESHEDON = report$RefreshedOn
  ))
}

# The report can list a user more than once, with the licenses in one row and empty
# rows besides; one row per user, with all licenses of its rows.
.merge_user_rows <- function(users) {

  several <- unique(users$USERID[duplicated(users$USERID)])
  if (length(several) == 0L) {
    return(users)
  }
  warning(sprintf("%d user%s several rows in the license report; they are merged into one row per user.",
                  length(several), if (length(several) == 1L) " has" else "s have"), call. = FALSE)

  combine <- function(lists) {
    names <- unique(unlist(strsplit(lists[nzchar(lists)], .LIST_SEPARATOR, fixed = TRUE)))
    paste(.order_by_license_priority(as.character(names)), collapse = .LIST_SEPARATOR)
  }
  users |>
    dplyr::mutate(ORDER = match(USERID, unique(USERID))) |>
    dplyr::group_by(ORDER, USERID) |>
    dplyr::summarise(USEREMAIL = USEREMAIL[[1]], REQUIRED = combine(REQUIRED), ASSIGNED = combine(ASSIGNED),
                     MISSING = combine(MISSING), REFRESHEDON = .latest(REFRESHEDON), .groups = "drop") |>
    dplyr::select(-ORDER)
}

# Reads all columns as text; UTF-8 with or without byte order mark. A byte that is no
# UTF-8 ends the reading with a mere warning, so every warning but a missing last line
# break stops here: otherwise the rows after it would be lost without a word.
.read_ppac_csv <- function(path, columns, what) {

  if (!.is_single_string(path)) {
    stop(what, ": path must be the path of one .csv file.", call. = FALSE)
  }
  if (!file.exists(path)) {
    stop(what, ": file not found: ", path, call. = FALSE)
  }
  fail  <- function(reason) stop(structure(class = c("ppac_read_error", "error", "condition"),
                                           list(message = paste0(what, " ", path, " cannot be read", reason), call = NULL)))
  table <- tryCatch(
    withCallingHandlers(
      utils::read.csv(path, check.names = FALSE, colClasses = "character", na.strings = c("", "NA"),
                      fileEncoding = "UTF-8-BOM"),
      warning = function(w) {
        if (!grepl("incomplete final line", conditionMessage(w), fixed = TRUE)) {
          fail(paste0(" as UTF-8: ", conditionMessage(w), ". Save it as UTF-8, for example with readr::write_csv()."))
        }
        invokeRestart("muffleWarning")
      }
    ),
    error = function(e) if (inherits(e, "ppac_read_error")) stop(e) else fail(paste0(": ", conditionMessage(e)))
  )
  missing <- setdiff(columns, names(table))
  if (length(missing) > 0L) {
    stop(what, " ", path, " lacks the columns: ", paste(missing, collapse = .LIST_SEPARATOR), ". Is it the ", what,
         " of the Power Platform admin center?", call. = FALSE)
  }
  tibble::as_tibble(table[, c(columns, intersect("USERID", names(table))), drop = FALSE])
}

.ppac_environments <- function(available, wanted) {
  available <- sort(unique(available))
  if (is.null(wanted)) {
    return(available)
  }
  unknown <- setdiff(wanted, available)
  if (length(unknown) > 0L) {
    stop(paste(unknown, collapse = .LIST_SEPARATOR), " is not in the report; it holds: ",
         paste(available, collapse = .LIST_SEPARATOR), ".", call. = FALSE)
  }
  wanted
}

.ppac_user_ids <- function(report) {
  from_mail <- sub("@.*$", "", report$UserEmail)
  if ("USERID" %in% names(report)) dplyr::coalesce(report$USERID, from_mail) else from_mail
}

# Rows without a user (or without the column `needs`) cannot be counted. A user id that
# stands for several e-mails merges their users, for example max@a.com and max@b.com.
.ppac_rows_with_user <- function(report, what, needs = NULL) {

  user <- .ppac_user_ids(report)
  gap  <- is.na(user) | !nzchar(trimws(user))
  if (!is.null(needs)) gap <- gap | is.na(report[[needs]]) | !nzchar(trimws(report[[needs]]))
  if (any(gap)) {
    warning(sprintf("%d row%s of the %s %s no user or no license and %s left out.", sum(gap),
                    if (sum(gap) == 1L) "" else "s", what, if (sum(gap) == 1L) "has" else "have",
                    if (sum(gap) == 1L) "is" else "are"), call. = FALSE)
  }
  report <- report[!gap, ]

  mails  <- tapply(tolower(trimws(report$UserEmail)), .ppac_user_ids(report), function(x) length(unique(stats::na.omit(x))))
  shared <- sum(mails > 1L)
  if (shared > 0L) {
    warning(sprintf("%d user id%s for several e-mails (the part before the @ is the same) and count%s as one user. ",
                    shared, if (shared == 1L) " stands" else "s stand", if (shared == 1L) "s" else ""),
            "Check the user ids of the report.", call. = FALSE)
  }
  report
}

# "Commerce,Finance,SupplyChainManagement" -> "Commerce, Finance, Supply Chain Management".
.ppac_license_list <- function(texts) {
  vapply(texts, function(text) {
    names <- .standard_license_names(trimws(strsplit(dplyr::coalesce(text, ""), ",", fixed = TRUE)[[1]]))
    names <- unique(names[nzchar(names) & !names %in% c("-", .NO_LICENSE, "NotApplicable", "Not Applicable")])
    paste(.order_by_license_priority(names), collapse = .LIST_SEPARATOR)
  }, character(1), USE.NAMES = FALSE)
}
