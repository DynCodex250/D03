# =============================================================================
# The ranking of rank_roles_by_license_cost() from the license graph (basis =
# "graph"). The PPAC report and LICENSINGUSERLICENSESBYROLE name each license of
# a user at one of his roles only; what a user would need without a role follows
# from the objects of his other roles in the graph. PPAC has priority where the
# graph wants more than PPAC bills (.ppac_priority_masks()). What the users pay
# with all their roles stays the billing of PPAC.
# =============================================================================

.RANKING_BASES <- c("ppac", "graph")

.check_ranking_basis <- function(basis) {
  if (!.is_single_string(basis) || !basis %in% .RANKING_BASES) {
    stop("basis must be \"ppac\" (the licenses PPAC names at each role) or \"graph\" (the license graph).",
         call. = FALSE)
  }
  basis
}

# The graph for basis "graph": as given, else read from the database.
.ranking_graph <- function(basis, graph, con) {
  if (basis == "ppac") {
    if (!is.null(graph)) {
      warning("graph is not used with basis = \"ppac\"; pass basis = \"graph\" to rank by it.", call. = FALSE)
    }
    return(NULL)
  }
  if (!is.null(graph)) {
    return(.check_required_columns(graph, .GRAPH_COLUMNS, "graph"))
  }
  if (is.null(con)) {
    stop("basis = \"graph\" needs the license graph: pass graph = read_license_graph(...) or a connection con.",
         call. = FALSE)
  }
  read_license_graph(con = con)
}

# Per user and role family: what he pays (TOTAL, from PPAC) and the costs only because
# of the family by the graph (COST), with the licenses by the graph with all his roles
# (WITH) and without the family (WITHOUT). Roles of the PPAC report are found in the
# graph by name (by_name), roles of the database by their AOT name.
.graph_ranking_costs <- function(rows, graph, prices, cost_of, by_name) {
  skus     <- .graph_license_skus()
  priced   <- skus$SKUNAME[.identifier_key(skus$SKUNAME) %in% .identifier_key(prices$LICENSE)]
  licenses <- .license_cover_function(skus, priced, cost_of)

  rows   <- dplyr::mutate(rows, ROLE_SHOWN = dplyr::coalesce(ROLENAME, ROLE))
  lookup <- dplyr::distinct(tibble::tibble(
    ROLE     = rows$ROLE_SHOWN,
    ROLE_KEY = if (by_name) .identifier_key(rows$ROLE_SHOWN) else rows$ROLE_KEY
  ))
  units <- dplyr::inner_join(.graph_units(graph, skus), .graph_roles_of(lookup, graph)$map, by = "GRAPH_ROLE_KEY",
                             relationship = "many-to-many")
  .warn_on_unpriced_licenses(units, licenses$unpriced)

  role_masks <- dplyr::distinct(units, ROLE, MASK)
  now        <- .current_billing(rows, skus, cost_of)
  masks      <- dplyr::distinct(rows, USER_KEY, ROLE = ROLE_SHOWN, FAMILY_KEY) |>
    dplyr::inner_join(role_masks, by = "ROLE", relationship = "many-to-many") |>
    dplyr::inner_join(dplyr::select(now, USER_KEY, NOW_BITS), by = "USER_KEY") |>
    dplyr::mutate(MASK = .ppac_priority_masks(MASK, NOW_BITS, licenses$needed, skus))

  pairs <- .graph_license_pairs(rows, now, masks, licenses$cover)
  list(
    pairs    = pairs,
    licenses = .graph_role_licenses(rows, role_masks, licenses$cover),
    differs  = dplyr::n_distinct(pairs$USER_KEY[pairs$GRAPH_TOTAL < pairs$TOTAL - .CENT])
  )
}

.graph_license_pairs <- function(rows, now, masks, cover) {
  by_user  <- split(masks[c("FAMILY_KEY", "MASK")], masks$USER_KEY)
  families <- split(rows$FAMILY_KEY, rows$USER_KEY)
  dplyr::bind_rows(lapply(seq_len(nrow(now)), function(i) {
    user    <- now$USER_KEY[[i]]
    own     <- if (is.null(by_user[[user]])) masks[0, c("FAMILY_KEY", "MASK")] else by_user[[user]]
    all     <- cover(own$MASK)
    family  <- unique(families[[user]])
    without <- lapply(family, function(f) cover(own$MASK[own$FAMILY_KEY != f], prefer = all$bits))
    tibble::tibble(
      USER_KEY = user, USERID = now$USERID[[i]], FAMILY_KEY = family, TOTAL = now$COST_NOW[[i]],
      GRAPH_TOTAL = all$cost, COST = round(all$cost - vapply(without, `[[`, numeric(1), "cost"), 2),
      WITH = rep(list(.identifier_key(all$set)), length(family)),
      WITHOUT = lapply(without, function(cover) .identifier_key(cover$set))
    )
  }))
}

# Per role family the licenses its own objects need by the graph, cheapest first.
.graph_role_licenses <- function(rows, role_masks, cover) {
  family_masks <- dplyr::distinct(rows, FAMILY_KEY, ROLE = ROLE_SHOWN) |>
    dplyr::inner_join(role_masks, by = "ROLE", relationship = "many-to-many")
  families <- unique(rows$FAMILY_KEY)
  stats::setNames(vapply(families, function(family) {
    paste(.order_by_license_priority(cover(family_masks$MASK[family_masks$FAMILY_KEY == family])$set),
          collapse = .LIST_SEPARATOR)
  }, character(1), USE.NAMES = FALSE), families)
}

# The calculation behind COST by the graph, in the columns of .cost_breakdown().
.graph_cost_breakdown <- function(pairs, ranking, cost_of) {
  text <- function(sets, what) vapply(sets, cost_of, character(1), what = what, USE.NAMES = FALSE)
  steps <- tibble::tibble(
    USERID          = pairs$USERID,
    FAMILY_KEY      = pairs$FAMILY_KEY,
    BILLED_WITH     = text(pairs$WITH, "billing"),
    CALC_WITH       = text(pairs$WITH, "calc"),
    BILLED_WITHOUT  = text(pairs$WITHOUT, "billing"),
    CALC_WITHOUT    = text(pairs$WITHOUT, "calc"),
    SAVING_PER_USER = pairs$COST,
    DROPPED         = mapply(function(with, without) {
      paste(.order_by_license_priority(setdiff(cost_of(with, "billed"), cost_of(without, "billed"))),
            collapse = .LIST_SEPARATOR)
    }, pairs$WITH, pairs$WITHOUT, USE.NAMES = FALSE)
  )
  .summarise_breakdown(steps, ranking)
}
