#' Security-Rolle detailliert laden
#'
#' Lädt die vollständige Security-Struktur
#' einer Rolle aus UserSecGovRelatedObjects.
#'
#' Im Gegensatz zu
#' load_sql_security_role_objects()
#' werden keine Informationen
#' ausgeblendet.
#'
#' Tabellen und Tabellenfelder werden für die Rollen-XML aufbereitet:
#' \code{ObjektTyp} nennt das XML-Element, \code{Ebene} ist \code{"Entity"}
#' oder \code{"Field"}, ein Feld \code{"TABELLE\\FELD"} wird in
#' \code{Objektname} und \code{Feldname} getrennt.
#'
#' @param con DBI Connection.
#' @param role_identifier Role Identifier oder Role Name.
#'
#' @return Tibble.
#'
#' @export
load_sql_security_role_objects_detailed <- function(
    con,
    role_identifier
){

  # The role goes in as a parameter: a quote in a role name cannot break the query.
  sql <- "
SELECT DISTINCT
    ROLEIDENTIFIER,
    ROLENAME,
    SUBROLEIDENTIFIER,
    DUTYIDENTIFIER,
    PRIVILEGEIDENTIFIER,
    RESOURCE_,
    RESOURCETYPE,
    SECURABLETYPE,
    CREATEACCESS,
    CORRECTACCESS,
    DELETEACCESS,
    INVOKEACCESS,
    UPDATEACCESS,
    READACCESS
FROM
    UserSecGovRelatedObjects
WHERE
       ROLEIDENTIFIER = ?
    OR ROLENAME = ?
"

  rows <- DBI::dbGetQuery(con, sql, params = list(role_identifier, role_identifier))

  # A name can match another role's name or identifier as well
  roles <- unique(rows$ROLEIDENTIFIER)
  if (length(roles) > 1L) {
    stop("'", role_identifier, "' matches several roles: ", paste(roles, collapse = ", "),
         ". Pass the identifier of one of them.", call. = FALSE)
  }

  .shape_security_role_objects(tibble::as_tibble(rows))
}

# The kind of an object: from its type code, which does not depend on the
# language, else from the label in English or German.
.SECURABLE_TYPE_KINDS <- c("1" = "MenuItemDisplay", "2" = "MenuItemOutput", "3" = "MenuItemAction",
                           "67" = "DataEntity", "44" = "Table", "42" = "TableField")
.RESOURCE_TYPE_KINDS  <- c("Menu item display" = "MenuItemDisplay", "Menu item output" = "MenuItemOutput",
                           "Menu item action" = "MenuItemAction", "Data entity" = "DataEntity",
                           "Table" = "Table", "Tabelle" = "Table", "Table Field" = "TableField", "Tabellenfeld" = "TableField")

.resource_kind <- function(rows) {
  by_code <- if ("SECURABLETYPE" %in% names(rows)) unname(.SECURABLE_TYPE_KINDS[as.character(rows$SECURABLETYPE)]) else NA_character_
  dplyr::coalesce(by_code, unname(.RESOURCE_TYPE_KINDS[rows$RESOURCETYPE]), "Other")
}

# The columns the role XML needs. A table field comes as "TABLE\FIELD"; the
# part before the first backslash is the table, the rest the field.
.shape_security_role_objects <- function(rows) {

  # Table or field: the backslash decides, so a code read the other way round does no harm
  has_part <- grepl("\\", rows$RESOURCE_, fixed = TRUE)
  is_any   <- .resource_kind(rows) %in% c("Table", "TableField")
  is_table <- is_any & !has_part
  is_field <- is_any & has_part

  rows |>
    dplyr::mutate(
      ROLELABEL  = ROLENAME,
      ObjektTyp  = dplyr::case_when(
        is_table ~ "AxSecurityDataEntityReference",
        is_field ~ "AxSecurityDataEntityFieldReference",
        TRUE     ~ RESOURCETYPE
      ),
      Objektname = ifelse(has_part, sub("\\\\.*$", "", RESOURCE_), RESOURCE_),
      Ebene      = dplyr::case_when(is_table ~ "Entity", is_field ~ "Field", TRUE ~ RESOURCETYPE),
      Feldname   = ifelse(has_part, sub("^[^\\\\]*\\\\", "", RESOURCE_), ""),
      Create     = CREATEACCESS,
      Correct    = CORRECTACCESS,
      Delete     = DELETEACCESS,
      Invoke     = INVOKEACCESS,
      Update     = UPDATEACCESS,
      Read       = READACCESS
    ) |>
    dplyr::select(
      ROLEIDENTIFIER, ROLELABEL, ROLENAME, SUBROLEIDENTIFIER, DUTYIDENTIFIER, PRIVILEGEIDENTIFIER,
      ObjektTyp, Objektname, Ebene, Feldname, RESOURCE_, RESOURCETYPE, dplyr::any_of("SECURABLETYPE"),
      Create, Correct, Delete, Invoke, Update, Read
    ) |>
    dplyr::arrange(ROLEIDENTIFIER, dplyr::desc(Objektname))
}
