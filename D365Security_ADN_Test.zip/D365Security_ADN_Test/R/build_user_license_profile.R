#' Build the license profile of every user from the telemetry and compare it with PPAC
#'
#' Starts from the users instead of the roles. From the telemetry it works out
#' which licenses the work of each user needs (his license footprint) and sets
#' it against the license report per user of the Power Platform admin center
#' (PPAC): what PPAC expects to be paid for him, what is already assigned and
#' what is not yet assigned. It shows who could lose a license by his
#' telemetry, and which licenses not yet assigned need not be bought. The
#' result is the content of the deliverable D21; see
#' \code{\link{export_user_license_profile}}.
#'
#' @details
#'
#' **The footprint by the telemetry** follows the rule of
#' \code{\link{plan_role_license_cleanup}} (D04), over all roles of the user
#' together: a duty is used when the user opened one of its display menu items
#' in the telemetry; a duty without a display menu item cannot be measured and
#' is kept. The user needs the cheapest licenses that cover the duties he
#' keeps, by the license graph (\code{BY_USAGE}). PPAC has priority where the
#' graph wants more for an object than PPAC bills. Of licenses that cover the
#' same objects at the same cost, for example Finance or Supply Chain
#' Management, the one PPAC expects or has assigned counts.
#' \code{IF_CONFIRMED} drops the duties that cannot be measured too: what the
#' business may confirm as unused.
#'
#' **PPAC.** \code{REQUIRED} (what PPAC expects to be paid), \code{ASSIGNED}
#' (already assigned) and \code{MISSING} (not yet assigned) come from the
#' report per user, \code{\link{read_ppac_license_report}}. The roles of each
#' user come from the detailed report of the same environment
#' (\code{licenses}).
#'
#' **Comparison per user.**
#' \describe{
#'   \item{\code{COULD_GO}}{Licenses PPAC expects that the telemetry does not
#'     need, split into \code{COULD_GO_ASSIGNED} (assigned: they could be
#'     taken back) and \code{COULD_GO_MISSING} (not yet assigned: they need
#'     not be bought, once his roles are cleaned up). A light license beside a
#'     base license the telemetry keeps costs nothing and does not count.}
#'   \item{\code{ADDED}}{Licenses the telemetry needs that PPAC does not
#'     expect, for example Activity instead of Supply Chain Management.}
#'   \item{\code{MISSING_NEEDED}}{Licenses not yet assigned that the telemetry
#'     needs too.}
#'   \item{\code{SAVING}}{\code{REQUIRED_COST} minus \code{COST_BY_USAGE}: what
#'     the user costs less than PPAC expects, once his roles fit his work.}
#'   \item{\code{PURCHASE_BY_USAGE}}{What the assigned licenses lack for the
#'     telemetry, by coverage: the cheapest licenses for the objects of the
#'     kept duties that no assigned license covers, as the cost they add to the
#'     assigned ones. \code{PURCHASE_AVOIDED} is \code{MISSING_COST} minus it.}
#' }
#'
#' **Pseudonyms.** Reports and telemetry are matched by user id. When fewer
#' than half of the users of the report are in the detailed report, or fewer
#' than half of those have telemetry, a warning asks whether all files were
#' pseudonymized with the same key.
#' Costs follow the billing of \code{\link{rank_roles_by_license_cost}}: of
#' Supply Chain Management, Finance and Commerce the first counts at its base
#' price, every further one at its attach price.
#'
#' **Classes.** \code{SAVES} (could lose a license), \code{REVIEW} (less only
#' after review), \code{KEEPS} (the telemetry confirms PPAC),
#' \code{NO_TELEMETRY}, \code{NO_USE} (opened only what needs no license),
#' \code{GRAPH_DIFFERS} (the graph does not explain what PPAC bills),
#' \code{REPORTS_DIFFER} (the report per user and the detailed report bill the
#' user differently), \code{NOT_IN_DETAIL} (no roles in the detailed report)
#' and \code{NOT_IN_REPORT}. Only \code{SAVES}, \code{REVIEW} and
#' \code{KEEPS} have a footprint and are counted; the others are a list to
#' check, never a saving.
#'
#' @param report
#' The license report per user of PPAC, \code{\link{read_ppac_license_report}}.
#'
#' @param licenses
#' The license rows of the same environment, for example
#' \code{read_ppac_license_detail(path, environment = "wibu-produktiv")}.
#'
#' @param graph
#' The license graph, \code{\link{read_license_graph}}.
#'
#' @param usage
#' The telemetry: one row per user and entry point (\code{user_Id},
#' \code{name}, \code{touches}, \code{last_seen}).
#'
#' @param prices
#' Prices per user and month, see \code{\link{read_license_prices}};
#' \code{NULL} = the estimates of the strategy paper, with a warning.
#'
#' @return
#' List:
#' \describe{
#'   \item{\code{Check}}{\code{CREATED}, \code{USERS}, \code{USERS_IN_REPORT},
#'     \code{USERS_IN_DETAIL}, \code{USERS_WITH_TELEMETRY},
#'     \code{USERS_COUNTED}, \code{USERS_COULD_LOSE}, \code{REQUIRED_COST},
#'     \code{ASSIGNED_COST}, \code{MISSING_COST} (all users, per month),
#'     \code{REQUIRED_COST_COUNTED}, \code{COST_BY_USAGE}, \code{SAVING},
#'     \code{SAVING_IF_CONFIRMED}, \code{PURCHASE_AVOIDED} (counted users),
#'     \code{TELEMETRY_FROM}, \code{TELEMETRY_TO},
#'     \code{TELEMETRY_USERS_NOT_IN_LICENSES}, \code{ROLES_NOT_IN_GRAPH},
#'     \code{PRICES_ESTIMATED}.}
#'   \item{\code{Users}}{One row per user: \code{USERID}, \code{ROLES},
#'     \code{ENTRY_POINTS}, \code{LAST_SEEN}, \code{REQUIRED},
#'     \code{REQUIRED_COST}, \code{ASSIGNED}, \code{ASSIGNED_COST},
#'     \code{MISSING}, \code{MISSING_COST}, \code{BY_USAGE},
#'     \code{BILLED_BY_USAGE}, \code{COST_BY_USAGE}, \code{IF_CONFIRMED},
#'     \code{COST_IF_CONFIRMED}, \code{COULD_GO}, \code{COULD_GO_ASSIGNED},
#'     \code{COULD_GO_MISSING}, \code{ADDED}, \code{MISSING_NEEDED},
#'     \code{SAVING}, \code{SAVING_IF_CONFIRMED}, \code{PURCHASE_BY_USAGE},
#'     \code{PURCHASE_AVOIDED}, \code{CLASS}. Licenses as texts, cheapest
#'     first, separated by ", ".}
#'   \item{\code{Classes}}{Per class the users and the sums of the costs.}
#'   \item{\code{Licenses}}{Per license the users who have it in
#'     \code{REQUIRED}, \code{ASSIGNED}, \code{MISSING}, \code{BY_USAGE},
#'     \code{COULD_GO}, \code{COULD_GO_ASSIGNED}, \code{COULD_GO_MISSING} and
#'     \code{ADDED}.}
#'   \item{\code{Prices}}{The prices used.}
#' }
#'
#' @examples
#' \dontrun{
#'
#' report   <- read_ppac_license_report("Input/Finance_And_Operations_Licensing_Report_pseudonymized.csv")
#' licenses <- read_ppac_license_detail("Input/Finance_And_Operations_Licensing_Detailed_Report_pseudonymized.csv",
#'                                      environment = "wibu-produktiv")
#' graph    <- read_license_graph(con = cnn)
#' usage    <- readxl::read_excel("Input/Telemetrie_pseudonymized.xlsx")
#'
#' profile <- build_user_license_profile(report, licenses, graph, usage, prices = "Input/Lizenzpreise.xlsx")
#' profile$Classes
#' export_user_license_profile(profile, "Data/Deliverables/D21_Lizenzprofil_Benutzer.xlsx")
#'
#' }
#'
#' @seealso
#' \code{\link{export_user_license_profile}}
#' \code{\link{plan_role_license_cleanup}}
#' \code{\link{compare_assigned_license_cost}}
#'
#' @export
build_user_license_profile <- function(report, licenses, graph, usage, prices = NULL) {

  .check_profile_report(report)
  base <- .telemetry_license_need(licenses, graph, usage, prices)
  .check_prices_cover(base$price_table$prices,
                      unlist(.split_license_list(c(report$REQUIRED, report$ASSIGNED, report$MISSING))))

  users  <- .profile_users(report, base$need, base$cost_of, .profile_cover(base))
  .warn_on_unmatched_users(users)
  result <- list(
    Check    = .profile_check(users, base),
    Users    = users,
    Classes  = .profile_classes(users),
    Licenses = .profile_licenses(users),
    Prices   = base$price_table$prices
  )
  message(.profile_message(result$Check))
  result
}

.PROFILE_NOT_IN_DETAIL  <- "NOT_IN_DETAIL"
.PROFILE_NOT_IN_REPORT  <- "NOT_IN_REPORT"
.PROFILE_REPORTS_DIFFER <- "REPORTS_DIFFER"
# The classes of plan_role_license_cleanup() (spelled out: this file is loaded before it) and
# the three of the profile.
.PROFILE_COUNTED <- c("SAVES", "REVIEW", "KEEPS")
.PROFILE_CLASSES <- c(.PROFILE_COUNTED, "NO_USE", "NO_TELEMETRY", "GRAPH_DIFFERS", .PROFILE_REPORTS_DIFFER,
                      .PROFILE_NOT_IN_DETAIL, .PROFILE_NOT_IN_REPORT)
.PROFILE_LICENSE_COLUMNS <- c("REQUIRED", "ASSIGNED", "MISSING", "BY_USAGE", "COULD_GO", "COULD_GO_ASSIGNED",
                              "COULD_GO_MISSING", "ADDED")

.check_profile_report <- function(report) {
  if (!is.data.frame(report) || !all(c("USERID", "REQUIRED", "ASSIGNED", "MISSING") %in% names(report))) {
    stop("report must be the license report per user of PPAC, the result of read_ppac_license_report().", call. = FALSE)
  }
  invisible(TRUE)
}

.license_text <- function(set) paste(.order_by_license_priority(as.character(set)), collapse = .LIST_SEPARATOR)

# Per user the report of PPAC next to the need by the telemetry, and the class of the profile.
.profile_join <- function(report, need, cost_of) {
  ppac  <- tibble::tibble(USER_KEY = tolower(trimws(report$USERID)), USERID_PPAC = report$USERID,
                          REQUIRED = report$REQUIRED, ASSIGNED = report$ASSIGNED, MISSING = report$MISSING)
  usage <- dplyr::select(need$users, USER_KEY, USERID, ROLES, BILLED_NOW, ENTRY_POINTS, LAST_SEEN, USAGE_CLASS = CLASS)
  joined <- dplyr::full_join(ppac, usage, by = "USER_KEY")
  billed <- vapply(.split_license_list(joined$REQUIRED), function(set) cost_of(.identifier_key(set), "billing"), character(1))
  dplyr::mutate(
    joined,
    USERID = dplyr::coalesce(USERID_PPAC, USERID),
    CLASS  = dplyr::case_when(
      is.na(USAGE_CLASS)   ~ .PROFILE_NOT_IN_DETAIL,
      is.na(USERID_PPAC)   ~ .PROFILE_NOT_IN_REPORT,
      billed != BILLED_NOW ~ .PROFILE_REPORTS_DIFFER,
      TRUE                 ~ USAGE_CLASS
    )
  )
}

# The cheapest cover of a set of object masks by the priced licenses, as in plan_role_license_cleanup().
.profile_cover <- function(base) {
  skus   <- .graph_license_skus()
  priced <- skus$SKUNAME[.identifier_key(skus$SKUNAME) %in% .identifier_key(base$price_table$prices$LICENSE)]
  .license_cover_function(skus, priced, base$cost_of)$cover
}

# The licenses of the telemetry for one user, ties going to what PPAC expects or has assigned (Finance
# or SCM for the same object), and what the assigned licenses lack for it, by coverage, not by name.
.profile_cover_user <- function(own, required, assigned, cover, skus) {
  if (is.null(own)) own <- tibble::tibble(MASK = integer(), KEEP_USAGE = logical(), KEEP_CONFIRMED = logical())
  prefer    <- .license_bits(c(required, assigned), skus)
  usage     <- cover(own$MASK[own$KEEP_USAGE], prefer = prefer)
  confirmed <- cover(own$MASK[own$KEEP_CONFIRMED], prefer = usage$bits)
  kept      <- own$MASK[own$KEEP_USAGE]
  lacking   <- kept[bitwAnd(kept, .license_bits(assigned, skus)) == 0L]
  list(usage = usage$set, confirmed = confirmed$set,
       lacking = if (length(lacking) == 0L) character() else cover(lacking, prefer = prefer)$set)
}

# A light license costs nothing beside a base license: it cannot go while a base license stays.
.without_free_light <- function(licenses, usage) {
  bases <- .standard_base_licenses()
  if (any(usage %in% bases)) licenses[licenses %in% bases] else licenses
}

# The sets of licenses of each user; by the telemetry only for counted users.
.profile_sets <- function(joined, counted, need, cover) {
  skus     <- .graph_license_skus()
  required <- .split_license_list(joined$REQUIRED)
  assigned <- .split_license_list(joined$ASSIGNED)
  masks    <- split(need$user_masks[c("MASK", "KEEP_USAGE", "KEEP_CONFIRMED")], need$user_masks$USER_KEY)
  covers   <- lapply(seq_len(nrow(joined)), function(i) {
    if (!counted[[i]]) return(list(usage = character(), confirmed = character(), lacking = character()))
    .profile_cover_user(masks[[joined$USER_KEY[[i]]]], required[[i]], assigned[[i]], cover, skus)
  })
  pick  <- function(field) lapply(covers, `[[`, field)
  usage <- pick("usage")
  list(required = required, assigned = assigned, missing = .split_license_list(joined$MISSING), usage = usage,
       confirmed = pick("confirmed"), lacking = pick("lacking"),
       could_go = Map(.without_free_light, Map(setdiff, required, usage), usage))
}

.profile_users <- function(report, need, cost_of, cover) {
  joined  <- .profile_join(report, need, cost_of)
  counted <- joined$CLASS %in% .PROFILE_COUNTED
  in_ppac <- !is.na(joined$USERID_PPAC)
  sets    <- .profile_sets(joined, counted, need, cover)
  cost    <- function(list) vapply(list, function(set) cost_of(.identifier_key(set)), numeric(1))
  billing <- function(list) vapply(list, function(set) cost_of(.identifier_key(set), "billing"), character(1))
  text    <- function(list) ifelse(counted, vapply(list, .license_text, character(1)), NA_character_)
  amount  <- function(values, keep = counted) ifelse(keep, round(values, 2), NA_real_)

  required_cost <- amount(cost(sets$required), in_ppac)
  assigned_cost <- amount(cost(sets$assigned), in_ppac)
  missing_cost  <- amount(pmax(required_cost - assigned_cost, 0), in_ppac)
  usage_cost    <- amount(cost(sets$usage))
  purchase      <- amount(cost(Map(union, sets$assigned, sets$lacking)) - assigned_cost)

  users <- tibble::tibble(
    USERID = joined$USERID, ROLES = joined$ROLES, ENTRY_POINTS = joined$ENTRY_POINTS, LAST_SEEN = joined$LAST_SEEN,
    REQUIRED = joined$REQUIRED, REQUIRED_COST = required_cost, ASSIGNED = joined$ASSIGNED, ASSIGNED_COST = assigned_cost,
    MISSING = joined$MISSING, MISSING_COST = missing_cost,
    BY_USAGE = text(sets$usage), BILLED_BY_USAGE = ifelse(counted, billing(sets$usage), NA_character_),
    COST_BY_USAGE = usage_cost, IF_CONFIRMED = text(sets$confirmed), COST_IF_CONFIRMED = amount(cost(sets$confirmed)),
    COULD_GO = text(sets$could_go), COULD_GO_ASSIGNED = text(Map(intersect, sets$could_go, sets$assigned)),
    COULD_GO_MISSING = text(Map(intersect, sets$could_go, sets$missing)), ADDED = text(Map(setdiff, sets$usage, sets$required)),
    MISSING_NEEDED = text(Map(intersect, sets$missing, sets$usage)),
    SAVING = amount(required_cost - usage_cost), SAVING_IF_CONFIRMED = amount(usage_cost - cost(sets$confirmed)),
    PURCHASE_BY_USAGE = purchase, PURCHASE_AVOIDED = amount(pmax(missing_cost - purchase, 0)),
    CLASS = joined$CLASS
  )
  users[order(match(users$CLASS, .PROFILE_CLASSES), -dplyr::coalesce(users$SAVING, 0), users$USERID), ]
}

# Reports, detailed report and telemetry pseudonymized with different keys match almost no user:
# the run would end with zeros and no word.
.warn_on_unmatched_users <- function(users) {
  in_report <- !is.na(users$REQUIRED)
  in_detail <- users$CLASS != .PROFILE_NOT_IN_DETAIL
  matched   <- sum(in_report & in_detail)
  if (sum(in_report) > 0L && matched < sum(in_report) / 2) {
    warning(sprintf(paste("Only %d of %d users of the report per user are in the detailed report: are both pseudonymized",
                          "with the same key and from the same environment?"), matched, sum(in_report)), call. = FALSE)
  }
  seen <- sum(in_detail & !is.na(users$ENTRY_POINTS))
  if (sum(in_detail) > 0L && seen < sum(in_detail) / 2) {
    warning(sprintf(paste("Only %d of %d users of the detailed report have telemetry: is the telemetry pseudonymized",
                          "with the same key?"), seen, sum(in_detail)), call. = FALSE)
  }
  invisible(users)
}

.profile_check <- function(users, base) {
  need    <- base$need
  counted <- users$CLASS %in% .PROFILE_COUNTED
  total   <- function(values, keep = TRUE) round(sum(values[keep], na.rm = TRUE), 2)
  list(
    CREATED = Sys.Date(), USERS = nrow(users), USERS_IN_REPORT = sum(!is.na(users$REQUIRED)),
    USERS_IN_DETAIL = sum(users$CLASS != .PROFILE_NOT_IN_DETAIL), USERS_WITH_TELEMETRY = sum(!is.na(users$ENTRY_POINTS)),
    USERS_COUNTED = sum(counted), USERS_COULD_LOSE = sum(users$CLASS == .CLEANUP_SAVES),
    REQUIRED_COST = total(users$REQUIRED_COST), ASSIGNED_COST = total(users$ASSIGNED_COST),
    MISSING_COST = total(users$MISSING_COST), REQUIRED_COST_COUNTED = total(users$REQUIRED_COST, counted),
    COST_BY_USAGE = total(users$COST_BY_USAGE, counted), SAVING = total(users$SAVING, counted),
    SAVING_IF_CONFIRMED = total(users$SAVING_IF_CONFIRMED, counted), PURCHASE_AVOIDED = total(users$PURCHASE_AVOIDED, counted),
    TELEMETRY_FROM = need$from, TELEMETRY_TO = need$to, TELEMETRY_USERS_NOT_IN_LICENSES = need$telemetry_only,
    ROLES_NOT_IN_GRAPH = length(need$roles_missing), PRICES_ESTIMATED = base$price_table$estimated
  )
}

.profile_classes <- function(users) {
  sum_or_na <- function(values) if (all(is.na(values))) NA_real_ else round(sum(values, na.rm = TRUE), 2)
  users |>
    dplyr::group_by(CLASS) |>
    dplyr::summarise(USERS = dplyr::n(), REQUIRED_COST = sum_or_na(REQUIRED_COST), ASSIGNED_COST = sum_or_na(ASSIGNED_COST),
                     MISSING_COST = sum_or_na(MISSING_COST), COST_BY_USAGE = sum_or_na(COST_BY_USAGE),
                     SAVING = sum_or_na(SAVING), PURCHASE_AVOIDED = sum_or_na(PURCHASE_AVOIDED), .groups = "drop") |>
    dplyr::arrange(match(CLASS, .PROFILE_CLASSES))
}

.profile_licenses <- function(users) {
  lists    <- lapply(stats::setNames(.PROFILE_LICENSE_COLUMNS, .PROFILE_LICENSE_COLUMNS),
                     function(column) .split_license_list(users[[column]]))
  licenses <- .order_by_license_priority(unique(as.character(unlist(lists))))
  count    <- function(sets) vapply(licenses, function(name) sum(vapply(sets, function(set) name %in% set, logical(1))),
                                    integer(1), USE.NAMES = FALSE)
  tibble::as_tibble(c(list(LICENSE = licenses), lapply(lists, count)))
}

.profile_message <- function(check) {
  sprintf(paste("License profile of %d users: PPAC expects %.2f per month, %.2f assigned, %.2f not yet assigned.",
                "By the telemetry %d users could lose a license: %.2f per month less than expected, %.2f of purchases",
                "avoided; %d of %d users judged by the telemetry%s."),
          check$USERS, check$REQUIRED_COST, check$ASSIGNED_COST, check$MISSING_COST, check$USERS_COULD_LOSE, check$SAVING,
          check$PURCHASE_AVOIDED, check$USERS_COUNTED, check$USERS, if (check$PRICES_ESTIMATED) "; estimated prices" else "")
}
