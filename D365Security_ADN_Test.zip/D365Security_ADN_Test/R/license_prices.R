#' Read the prices of the licenses
#'
#' Reads a price table for \code{\link{rank_roles_by_license_cost}},
#' \code{\link{compare_assigned_license_cost}} and
#' \code{\link{compare_environment_license_cost}} and returns it as one row
#' per license.
#'
#' @details
#'
#' Two layouts are read:
#' \describe{
#'   \item{SKU list}{Columns \code{SKU} and \code{Price}, one row per price,
#'     as in the sheet \code{skuPrices}: \code{"Finance Base"},
#'     \code{"Finance Attach"}, \code{"SCM Base"}, \code{"SCM Attach"},
#'     \code{"Commerce Base"}, \code{"Commerce Attach"}, \code{"Activity"},
#'     \code{"Team Member"}. A row without "Base" or "Attach" is a base price.
#'     A license with an attach price needs its base row. Prices may be
#'     numbers or text such as \code{"168,50 €"}, \code{"1.234,50"} or
#'     \code{"1,234.50"}: of comma and point the later one is the decimal
#'     sign; a lone point is a decimal point.}
#'   \item{One row per license}{Columns \code{LICENSE}, \code{BASE_PRICE}
#'     and \code{ATTACH_PRICE}, the result of this function.}
#' }
#' License names are written as \code{LicensingAllSkus} and the detailed
#' PPAC report write them: SCM becomes Supply Chain Management, Activity
#' Operations - Activity, Team Member Team Members.
#'
#' @param prices
#' A table in one of the two layouts, or the path of an \code{.xlsx} file.
#' From a file the sheet \code{skuPrices} is read when there is one, else the
#' first sheet.
#'
#' @return
#' Tibble with \code{LICENSE}, \code{BASE_PRICE}, \code{ATTACH_PRICE}
#' (\code{NA} for light licenses), per user and month.
#'
#' @examples
#' \dontrun{
#'
#' read_license_prices("C:/Data/Lizenzpreise.xlsx")
#'
#' read_license_prices(data.frame(
#'   SKU   = c("Finance Base", "Finance Attach", "SCM Base", "SCM Attach",
#'             "Commerce Base", "Commerce Attach", "Activity", "Team Member"),
#'   Price = c(168.50, 27.30, 168.50, 27.30, 168.50, 31.20, 46.80, 7.50)
#' ))
#'
#' }
#'
#' @seealso
#' \code{\link{rank_roles_by_license_cost}}
#'
#' @export
read_license_prices <- function(prices) {

  if (.is_single_string(prices)) {
    prices <- .read_price_sheet(prices)
  }
  if (!is.data.frame(prices)) {
    stop("prices must be a table or the path of an .xlsx file.", call. = FALSE)
  }
  if (all(c("SKU", "Price") %in% names(prices))) {
    prices <- .prices_from_sku_list(prices)
  }
  .check_price_table(prices)
}

# Estimates of the strategy paper, October 2026, per user and month: SCM + Finance
# 195.80, SCM + Finance + Commerce 227.00, Activity 46.80, Team Members 7.50.
.ESTIMATED_LICENSE_PRICES <- tibble::tibble(
  LICENSE      = c("Team Members", "Operations - Activity", "Commerce", "Finance", "Supply Chain Management"),
  BASE_PRICE   = c(7.50, 46.80, 164.60, 164.60, 164.60),
  ATTACH_PRICE = c(NA, NA, 31.20, 31.20, 31.20)
)

# A license row without a license: no costs.
.NO_LICENSE <- "None"

# The licenses as LicensingAllSkus holds them, for files read without a database.
.STANDARD_LICENSE_SKUS <- tibble::tribble(
  ~SKUNAME,                          ~PRIORITY, ~GROUPNAME,
  "Team Members",                    20,        NA_character_,
  "Operations - Activity",           30,        NA_character_,
  "Commerce",                        60,        "Base",
  "Finance",                         70,        "Base",
  "Supply Chain Management",         80,        "Base",
  "Finance Premium",                 90,        "Base",
  "Supply Chain Management Premium", 100,       "Base"
)

# Other spellings of the license names, by their letters in lower case: the PPAC report
# per user writes SupplyChainManagement, the price list SCM and Team Member.
.LICENSE_NAME_ALIASES <- c(
  commerce = "Commerce", com = "Commerce",
  finance = "Finance", fin = "Finance",
  supplychainmanagement = "Supply Chain Management", scm = "Supply Chain Management",
  financepremium = "Finance Premium", finp = "Finance Premium",
  supplychainmanagementpremium = "Supply Chain Management Premium", scmp = "Supply Chain Management Premium",
  operationsactivity = "Operations - Activity", activity = "Operations - Activity", act = "Operations - Activity",
  teammembers = "Team Members", teammember = "Team Members", tm = "Team Members",
  none = "None"
)

.standard_license_names <- function(names) {
  standard <- unname(.LICENSE_NAME_ALIASES[tolower(gsub("[^A-Za-z]", "", names))])
  ifelse(is.na(standard), trimws(names), standard)
}

.standard_base_licenses <- function() {
  .STANDARD_LICENSE_SKUS$SKUNAME[.is_base_group(.STANDARD_LICENSE_SKUS$GROUPNAME, "^Base")]
}

# Cheapest first, as LicensingAllSkus orders them; unknown names at the end.
.order_by_license_priority <- function(licenses) {
  licenses[order(match(licenses, .STANDARD_LICENSE_SKUS$SKUNAME), licenses)]
}

.read_price_sheet <- function(path) {
  if (!file.exists(path)) {
    stop("prices: file not found: ", path, call. = FALSE)
  }
  sheets <- readxl::excel_sheets(path)
  readxl::read_excel(path, sheet = if ("skuPrices" %in% sheets) "skuPrices" else 1L)
}

# A number, or text such as "168,50 €", "1.234,50" or "1,234.50": of comma and point the
# later one is the decimal sign, the other separates thousands. A lone point is a decimal
# point, so "1.234" reads as 1.234.
.price_number <- function(price) {
  if (is.numeric(price)) {
    return(as.numeric(price))
  }
  text          <- gsub("[^0-9,.-]", "", as.character(price))
  decimal_comma <- regexpr(",[^,]*$", text) > regexpr("\\.[^.]*$", text)
  text <- ifelse(decimal_comma, sub(",", ".", gsub(".", "", text, fixed = TRUE), fixed = TRUE),
                 gsub(",", "", text, fixed = TRUE))
  suppressWarnings(as.numeric(text))
}

.prices_from_sku_list <- function(list) {

  sku   <- trimws(as.character(list$SKU))
  price <- .price_number(list$Price)
  bad   <- is.na(sku) | !nzchar(sku) | is.na(price) | price < 0
  if (any(bad)) {
    stop("prices: every row needs a SKU and a Price of at least 0. Check the rows ", paste(which(bad), collapse = ", "),
         ".", call. = FALSE)
  }

  is_attach <- grepl("\\s+attach$", sku, ignore.case = TRUE)
  license   <- .standard_license_names(sub("\\s+(base|attach)$", "", sku, ignore.case = TRUE))
  twice     <- duplicated(paste(license, is_attach))
  if (any(twice)) {
    stop("prices: listed twice: ", paste(unique(sku[twice]), collapse = .LIST_SEPARATOR), ". Keep one row per SKU.",
         call. = FALSE)
  }

  licenses <- .order_by_license_priority(unique(license))
  pick     <- function(attach) vapply(licenses, function(name) {
    found <- price[license == name & is_attach == attach]
    if (length(found) == 0L) NA_real_ else found[[1]]
  }, numeric(1), USE.NAMES = FALSE)
  table <- tibble::tibble(LICENSE = licenses, BASE_PRICE = pick(FALSE), ATTACH_PRICE = pick(TRUE))

  if (anyNA(table$BASE_PRICE)) {
    stop(paste(table$LICENSE[is.na(table$BASE_PRICE)], collapse = .LIST_SEPARATOR),
         " has an attach price but no base price. Add a row \"<license> Base\" to the price list.", call. = FALSE)
  }
  table
}

.check_price_table <- function(prices) {

  if (!all(c("LICENSE", "BASE_PRICE") %in% names(prices))) {
    stop("prices needs the columns LICENSE, BASE_PRICE and, for base licenses, ATTACH_PRICE, or the columns SKU and ",
         "Price; found: ", paste(names(prices), collapse = ", "), ".", call. = FALSE)
  }

  table <- tibble::tibble(
    LICENSE      = trimws(as.character(prices$LICENSE)),
    BASE_PRICE   = suppressWarnings(as.numeric(prices$BASE_PRICE)),
    ATTACH_PRICE = if ("ATTACH_PRICE" %in% names(prices)) suppressWarnings(as.numeric(prices$ATTACH_PRICE)) else NA_real_
  )
  valid <- !is.na(table$LICENSE) & nzchar(table$LICENSE) & !is.na(table$BASE_PRICE) & table$BASE_PRICE >= 0 &
    (is.na(table$ATTACH_PRICE) | table$ATTACH_PRICE >= 0)
  if (!all(valid)) {
    stop("prices: every row needs a LICENSE and a BASE_PRICE of at least 0; ATTACH_PRICE is a number of at least 0 ",
         "or empty. Check the rows ", paste(which(!valid), collapse = ", "), ".", call. = FALSE)
  }
  .stop_on_same_names(table$LICENSE, "prices")
  table
}

# The prices given, or the estimates of the strategy paper with a warning.
.license_prices <- function(prices) {

  if (is.null(prices)) {
    warning("No prices given: the estimates of the strategy paper (October 2026) are used, per user and month: ",
            "base license 164.60, attach 31.20, Operations - Activity 46.80, Team Members 7.50. ",
            "Pass prices for current prices.", call. = FALSE)
    return(list(prices = .ESTIMATED_LICENSE_PRICES, estimated = TRUE))
  }
  list(prices = read_license_prices(prices), estimated = FALSE)
}

.check_prices_cover <- function(prices, licenses) {
  licenses <- unique(licenses[!is.na(licenses) & licenses != .NO_LICENSE])
  missing  <- licenses[!.identifier_key(licenses) %in% .identifier_key(prices$LICENSE)]
  if (length(missing) > 0L) {
    stop("prices has no price for: ", paste(sort(missing), collapse = ", "), ". Add a row per license with LICENSE, ",
         "BASE_PRICE and, for a base license, ATTACH_PRICE.", call. = FALSE)
  }
  invisible(licenses)
}

# The order in which WIBU bills the base licenses (decided 2026-10-28): the first of them a
# user needs is the base license, every further one an attach license. SCM + Finance is
# "SCM Base + Finance Attach", Commerce + Finance "Finance Base + Commerce Attach".
.BASE_LICENSE_ORDER <- c("Supply Chain Management", "Finance", "Commerce")

# Names as the price list writes them, for "SCM Base + Finance Attach".
.BILLING_NAMES <- c("Supply Chain Management" = "SCM", "Operations - Activity" = "Activity",
                    "Team Members" = "Team Member")

# For a set of licenses, given by their keys: the costs (what = "cost"), how they are
# billed ("billing", for example "SCM Base + Finance Attach"), the calculation ("calc",
# "168.50 + 27.30 = 195.80") or the licenses billed ("billed"). Users share few sets, so
# each answer is computed once.
.license_cost_function <- function(prices, base) {
  keys      <- .identifier_key(prices$LICENSE)
  full      <- stats::setNames(prices$BASE_PRICE, keys)
  attach    <- stats::setNames(dplyr::coalesce(prices$ATTACH_PRICE, prices$BASE_PRICE), keys)
  names     <- stats::setNames(prices$LICENSE, keys)
  base_keys <- .identifier_key(base)
  none_key  <- .identifier_key(.NO_LICENSE)
  known     <- new.env(parent = emptyenv())

  function(license_keys, what = "cost") {
    set <- sort(unique(license_keys[!is.na(license_keys) & license_keys != none_key]))
    id  <- paste0(what, "#", paste(set, collapse = "|"))
    if (is.null(known[[id]])) {
      known[[id]] <- switch(
        what,
        cost    = .license_set_cost(set, full, attach, base_keys),
        billing = .license_billing_text(.license_set_billing(set, full, base_keys), names),
        calc    = .license_billing_calc(.license_set_billing(set, full, base_keys), full, attach),
        billed  = unname(names[unlist(.license_set_billing(set, full, base_keys), use.names = FALSE)]),
        stop("what must be cost, billing, calc or billed.", call. = FALSE)
      )
    }
    known[[id]]
  }
}

# Which license of a set is billed as base license, which as attach licenses, and without
# a base license the light license that counts (the dearest). Base licenses outside
# .BASE_LICENSE_ORDER, such as Premium, come after it, the dearest first.
.license_set_billing <- function(set, full, base_keys) {
  base <- set[set %in% base_keys]
  if (length(base) == 0L) {
    return(list(base = character(), attach = character(), light = set[which.max(full[set])]))
  }
  position <- match(base, .identifier_key(.BASE_LICENSE_ORDER))
  base     <- base[order(is.na(position), position, -full[base])]
  list(base = base[[1]], attach = base[-1], light = character())
}

.license_set_cost <- function(set, full, attach, base_keys) {
  if (length(set) == 0L) {
    return(0)
  }
  billed <- .license_set_billing(set, full, base_keys)
  round(unname(sum(full[c(billed$base, billed$light)]) + sum(attach[billed$attach])), 2)
}

# "168.50 + 27.30 + 31.20 = 227.00"; one license without the sum, none as "0.00".
.license_billing_calc <- function(billed, full, attach) {
  amounts <- unname(c(full[billed$base], attach[billed$attach], full[billed$light]))
  if (length(amounts) == 0L) {
    return("0.00")
  }
  text <- sprintf("%.2f", amounts)
  if (length(amounts) == 1L) text else paste0(paste(text, collapse = " + "), " = ", sprintf("%.2f", round(sum(amounts), 2)))
}

.license_billing_text <- function(billed, names) {
  short <- function(keys) {
    long <- unname(names[keys])
    dplyr::coalesce(unname(.BILLING_NAMES[long]), long)
  }
  parts <- c(if (length(billed$base) > 0L) paste(short(billed$base), "Base"),
             if (length(billed$attach) > 0L) paste(short(billed$attach), "Attach"),
             short(billed$light))
  paste(parts, collapse = " + ")
}
