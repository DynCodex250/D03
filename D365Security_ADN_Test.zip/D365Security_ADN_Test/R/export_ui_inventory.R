#' Write the inventory of the UI objects as deliverable D24
#'
#' Writes the result of \code{\link{inventory_ui_objects}} as the Excel
#' workbook of the deliverable D24, in German and in the layout of the other
#' deliverables: one row per UI object and place, in the columns UI
#' identifier, UI name, type, the place, the type of the place, then its name,
#' whether the place is itself a UI object, the AOT counterpart and the
#' proposed action.
#'
#' @details
#'
#' **Sheets.** \code{Anleitung}; \code{Fundstellen} (one row per UI object
#' and place; white columns of the team: \code{Entscheidung},
#' \code{Ersetzt am}, \code{Status}, \code{Bemerkung}); \code{UI_Objekte}
#' (one row per UI object with the number of its places); \code{Listen}. No
#' user ids.
#'
#' **An earlier D24.** With \code{previous}, the white columns carry over by
#' UI object and place.
#'
#' @param inventory
#' Result of \code{\link{inventory_ui_objects}}.
#'
#' @param path
#' Path of the workbook to write, in an existing folder.
#'
#' @param previous
#' Optional path of an earlier D24 whose white columns carry over.
#'
#' @param overwrite
#' \code{TRUE} = replace an existing file at \code{path}. Default \code{FALSE}.
#'
#' @return
#' Invisibly \code{path}.
#'
#' @examples
#' \dontrun{
#'
#' export_ui_inventory(inventory_ui_objects(cnn), "Output/D24_UI_Inventur.xlsx")
#'
#' }
#'
#' @seealso
#' \code{\link{inventory_ui_objects}}
#' \code{\link{export_ui_counterparts}}
#'
#' @export
export_ui_inventory <- function(inventory, path, previous = NULL, overwrite = FALSE) {

  if (!is.list(inventory) || !all(c("Places", "Objects", "Check") %in% names(inventory))) {
    stop("inventory must be the result of inventory_ui_objects().", call. = FALSE)
  }
  .check_deliverable_paths(path, previous, overwrite, "An existing D24 holds the steps of the team")
  earlier <- if (is.null(previous)) NULL else
    .read_previous_sheet(previous, "Fundstellen", c("UI-Bezeichner", "Enthalten in (Bezeichner)"), .UI_INVENTORY_DATES)
  places <- .ui_place_sheet(inventory$Places, earlier)

  wb <- openxlsx::createWorkbook()
  .add_ui_inventory_instructions(wb, inventory$Check)
  .add_deliverable_sheet(wb, "Fundstellen", places, it = setdiff(names(places), .UI_INVENTORY_MANUAL))
  .add_deliverable_sheet(wb, "UI_Objekte", .ui_object_sheet(inventory$Objects), all_it = TRUE)
  .add_deliverable_sheet(wb, "Listen", .list_frame(.ui_inventory_lists()))
  .add_list_validation(wb, "Fundstellen", places, .ui_inventory_lists())

  openxlsx::saveWorkbook(wb, path, overwrite = TRUE)
  message(sprintf("D24 written: %s (%d places of %d UI objects).", path, inventory$Check$PLACES, nrow(inventory$Objects)))
  invisible(path)
}

.UI_INVENTORY_MANUAL <- c("Entscheidung", "Ersetzt am", "Status", "Bemerkung")
.UI_INVENTORY_DATES  <- "Ersetzt am"
.UI_TYPE_TEXTS       <- c(ROLE = "Rolle", DUTY = "Aufgabe", PRIVILEGE = "Recht")

# What to do with one place: replace by the counterpart, create one first, or choose one; a UI
# object that sits nowhere is removed, a UI role that is no sub-role is a matter of D20.
.ui_place_actions <- function(places) {
  dplyr::case_when(
    is.na(places$CONTAINER_IDENTIFIER) & places$TYPE == "ROLE" ~ "Nirgends als Unterrolle verwendet (Zuweisungen: D20)",
    is.na(places$CONTAINER_IDENTIFIER)                         ~ "Nirgends verwendet: entfernen",
    places$MATCH %in% c("NAME", "MANUAL")                      ~ "Durch AOT-Pendant ersetzen",
    places$MATCH == "SEVERAL"                                  ~ "Pendant wählen, dann ersetzen",
    TRUE                                                       ~ "AOT-Objekt anlegen, dann ersetzen"
  )
}

.ui_place_sheet <- function(places, earlier) {
  sheet <- data.frame(
    "UI-Bezeichner" = places$UI_IDENTIFIER, "UI-Name" = places$UI_NAME, "Typ" = unname(.UI_TYPE_TEXTS[places$TYPE]),
    "Enthalten in (Bezeichner)" = places$CONTAINER_IDENTIFIER, "Typ der Fundstelle" = unname(.UI_TYPE_TEXTS[places$CONTAINER_TYPE]),
    "Enthalten in (Name)" = places$CONTAINER_NAME,
    "Fundstelle ist UI-Objekt" = ifelse(is.na(places$CONTAINER_UI), NA_character_, ifelse(places$CONTAINER_UI, "Ja", "Nein")),
    "AOT-Pendant" = places$COUNTERPART, "AOT-Pendant (Name)" = places$COUNTERPART_NAME,
    "Zuordnung" = unname(.UI_MATCH_TEXTS[places$MATCH]), "Maßnahme (Vorschlag)" = .ui_place_actions(places),
    check.names = FALSE, stringsAsFactors = FALSE
  )
  keys  <- .deliverable_key(places$UI_IDENTIFIER, places$CONTAINER_IDENTIFIER)
  sheet <- .carry_over_columns(sheet, keys, earlier, earlier$KEY, .UI_INVENTORY_MANUAL)
  if (!is.null(earlier)) {
    .warn_on_gone_entries(earlier, keys, .UI_INVENTORY_MANUAL, "places", c("UI-Bezeichner", "Enthalten in (Bezeichner)"))
    .warn_on_dropped_columns(earlier, names(sheet), "D24")
  }
  sheet
}

.ui_object_sheet <- function(objects) {
  data.frame(
    "UI-Bezeichner" = objects$UI_IDENTIFIER, "UI-Name" = objects$UI_NAME, "Typ" = unname(.UI_TYPE_TEXTS[objects$TYPE]),
    "Fundstellen" = objects$PLACES, "AOT-Pendant" = objects$COUNTERPART, "AOT-Pendant (Name)" = objects$COUNTERPART_NAME,
    "Zuordnung" = unname(.UI_MATCH_TEXTS[objects$MATCH]), check.names = FALSE, stringsAsFactors = FALSE
  )
}

.ui_inventory_lists <- function() {
  list("Entscheidung" = c("Durch Pendant ersetzen", "AOT-Objekt anlegen", "Entfernen", "Behalten"),
       "Status" = c("offen", "in Arbeit", "erledigt"))
}

.add_ui_inventory_instructions <- function(wb, check) {
  text <- c(
    "D24 Inventur der UI-Objekte: wo UI-Rollen, UI-Aufgaben und UI-Rechte stecken",
    paste0("Erzeugt am ", format(Sys.Date(), "%d.%m.%Y")),
    "",
    "Worum es geht",
    "Rollen, Aufgaben und Rechte, die in der Oberfläche angelegt wurden, haben eine GUID als Bezeichner. Sie sollen überall durch ihr AOT-Pendant ersetzt werden. Dafür zeigt diese Inventur, wo jedes UI-Objekt steckt: eine UI-Rolle als Unterrolle in einer Rolle, eine UI-Aufgabe in einer Rolle, ein UI-Recht in einer Aufgabe oder direkt in einer Rolle.",
    "",
    "Kennzahlen",
    sprintf("%d UI-Rollen, %d UI-Aufgaben, %d UI-Rechte an %d Fundstellen; %d davon stecken in einem anderen UI-Objekt. %d UI-Objekte stecken nirgends.",
            check$ROLES, check$DUTIES, check$PRIVILEGES, check$PLACES, check$IN_UI_CONTAINERS, check$NOWHERE),
    sprintf("AOT-Pendant mit gleichem Namen: %d eindeutig, %d mehrdeutig, %d ohne Pendant.",
            check$WITH_COUNTERPART, check$SEVERAL, check$WITHOUT_COUNTERPART),
    "",
    "So lesen Sie das Blatt „Fundstellen“",
    "Eine Zeile je UI-Objekt und Fundstelle: Bezeichner, Name und Typ des UI-Objekts, dann wo es steckt (Bezeichner, Typ und Name der Fundstelle). „Fundstelle ist UI-Objekt“ = Ja: Die Fundstelle wird selbst ersetzt. Das AOT-Pendant ist das AOT-Objekt mit gleichem Namen; ob beide gleich sind, sagen D20 (Rollen), D22 (Aufgaben) und D23 (Rechte).",
    "",
    "Was zu tun ist",
    "1. Von oben nach unten ersetzen: zuerst Rollen (D20), dann Aufgaben, dann Rechte. Steckt ein UI-Objekt in einer Fundstelle, die selbst ersetzt wird, entfällt diese Zeile mit ihr. Das betrifft nur den Austausch bestehender Objekte; neue Rollen werden weiterhin von unten aus Aufgaben gebaut (Strategie).",
    "2. Je Fundstelle das UI-Objekt durch sein AOT-Pendant ersetzen; ohne Pendant zuerst ein AOT-Objekt anlegen. Entscheidung und Datum („Ersetzt am“) eintragen.",
    "3. UI-Objekte, die nirgends stecken, entfernen; UI-Rollen ohne Fundstelle sind Benutzern zugewiesen und laufen über D20.",
    "",
    "Hinweis für die Weiterverarbeitung",
    "Blau markierte Spalten und Blätter füllt das Werkzeug; die weißen Spalten pflegt das Team. Beim nächsten Lauf übernimmt das Werkzeug die weißen Spalten je UI-Objekt und Fundstelle. Blätter und Kopfzeilen bitte nicht umbenennen. Die Datei enthält keine Benutzerdaten."
  )
  .add_instruction_sheet(wb, text, c("Worum es geht", "Kennzahlen", "So lesen Sie das Blatt „Fundstellen“", "Was zu tun ist",
                                     "Hinweis für die Weiterverarbeitung"))
}
