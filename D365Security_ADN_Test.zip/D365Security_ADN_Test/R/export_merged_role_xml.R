#' Merge two or more roles into one and export it as role XML
#'
#' Loads two or more roles from the table \code{UserSecGovRelatedObjects} --
#' AOT roles, roles created in the user interface, or both -- merges them into
#' one role and writes it like \code{\link{export_role_xml}}: as an AOT role
#' file for Visual Studio with its zip, and as the two files for the import in
#' the browser. The merged role grants everything one of the roles grants.
#'
#' @details
#'
#' **Name.** The merged role is named after the AOT role with the suffix
#' \code{_MERGED}, whatever the order of \code{roles}: an AOT role and its UI
#' copy give \code{<AOT name>_MERGED}. Of two AOT roles, or of two UI roles,
#' the first in \code{roles} gives the name. A UI role has a GUID as name; the
#' merged role then takes the AOT form of its label: umlauts spelled out
#' (ae, oe, ue, ss), every other character outside letters, digits and
#' underscores replaced by an underscore. The label is the label of that role
#' with the same suffix. \code{name} and \code{label} replace the rule.
#'
#' **Content.** The merged role holds the own duties, privileges and sub-roles
#' of every role, each once (in the spelling met first, capitals or not). A
#' sub-role that is one of the merged roles is left out: its content is in the
#' merged role already. Sub-roles of the user interface are replaced by their
#' AOT counterparts as in \code{\link{export_role_xml}}, with the same warnings.
#' A direct access permission on the same object or field in several roles
#' (capitals do not count) becomes one, with the strongest right of each kind:
#' a denial over a grant, a grant over nothing. So no denial of one of the
#' roles is lost in the merged role.
#'
#' **Licenses.** The merge does not look at licenses: the merged role grants
#' what the roles grant, whatever license that needs. The functions of the
#' license analysis show the license of the merged role once it exists.
#'
#' **Files.** As \code{\link{export_role_xml}}: the XML in
#' \code{<output_folder>/AxSecurityRole/<name>.xml}, the zip
#' \code{<output_folder>/<name>.zip}, and the files for the browser in
#' \code{SecurityGovernance} and \code{SecurityConfiguration}. For the browser
#' the merged role is a new role; under the name of one of the merged AOT
#' roles (\code{name}) it is a change of that role, which the import replaces.
#' The description of the role names the merged roles.
#'
#' @param con
#' Database connection. Result of \code{get_connection()}.
#'
#' @param roles
#' AOT names or GUIDs of the roles to merge, at least two, each once.
#'
#' @param output_folder
#' Folder for the files; it is created when missing.
#'
#' @param name
#' AOT name of the merged role. \code{NULL} = by the rule, see Details.
#'
#' @param label
#' Label of the merged role. \code{NULL} = by the rule, see Details.
#'
#' @param zip,replace_ui_subroles,browser_files
#' As in \code{\link{export_role_xml}}.
#'
#' @return
#' Invisibly the list of \code{\link{export_role_xml}} (\code{xml}, \code{zip},
#' \code{security_governance}, \code{security_configuration}, \code{role},
#' \code{subroles}) with \code{sources}: one row per merged role with
#' \code{ROLE} (as given), \code{NAME} (as written), \code{LABEL}, \code{KIND}
#' (\code{"AOT"} or \code{"UI"}) and the counts of its own \code{DUTIES},
#' \code{PRIVILEGES}, \code{SUBROLES} and \code{DIRECT_ACCESS} permissions on
#' objects, for example:
#' \preformatted{
#' ROLE                                  NAME                                  KIND DUTIES PRIVILEGES
#' _WIBU_VERKAUF_INNENDIENST_MITARBEITER _WIBU_Verkauf_Innendienst_Mitarbeiter AOT  42     17
#' 32B63442-1415-459D-8FF0-399780947265  32B63442-1415-459D-8FF0-399780947265  UI   45     19
#' }
#'
#' @examples
#' \dontrun{
#'
#' merged <- export_merged_role_xml(
#'   cnn,
#'   roles         = c("_WIBU_VERKAUF_INNENDIENST_MITARBEITER", "32B63442-1415-459D-8FF0-399780947265"),
#'   output_folder = "Output/Merged"
#' )
#' merged$role$role_name   # "_WIBU_Verkauf_Innendienst_Mitarbeiter_MERGED"
#' merged$sources
#'
#' }
#'
#' @seealso
#' \code{\link{export_role_xml}}
#' \code{\link{compare_role_versions}}
#' \code{\link{create_d365fo_security_configuration_xml}}
#'
#' @export
export_merged_role_xml <- function(con, roles, output_folder, name = NULL, label = NULL, zip = TRUE,
                                   replace_ui_subroles = TRUE, browser_files = TRUE) {

  .check_roles_to_merge(roles)
  if (!.is_single_string(output_folder)) {
    stop("output_folder must be the path of one folder.", call. = FALSE)
  }
  if (!is.null(name)) .check_aot_name(name)
  if (!is.null(label) && !.is_single_string(label)) {
    stop("label must be one text.", call. = FALSE)
  }

  sources <- lapply(roles, function(role) .load_role_to_export(con, role))
  named   <- .merged_role_names(sources)
  role    <- .merge_roles(sources,
                          name  = if (is.null(name)) named$name else name,
                          label = if (is.null(label)) named$label else label)
  .check_aot_name(role$role_name)

  # a UI sub-role can have one of the merged roles as counterpart
  resolved <- .resolve_role_subroles(con, role, replace_ui_subroles)
  role     <- .without_merged_roles(resolved$role, sources)
  files    <- .write_role_files(role, output_folder, zip, browser_files, .merged_stored_name(role, sources))

  message(sprintf(
    "Merged role %s written from %d roles: %d duties, %d privileges, %d sub-roles, %d direct access permissions.",
    role$role_name, length(sources), length(role$duties), length(role$privileges), length(role$subroles),
    .direct_access_count(role)
  ))

  invisible(c(files, list(role = role, subroles = resolved$subroles, sources = .merge_sources(roles, sources))))
}

.MERGED_SUFFIX <- "_MERGED"

.UMLAUTS <- c("ä" = "ae", "ö" = "oe", "ü" = "ue",
              "Ä" = "Ae", "Ö" = "Oe", "Ü" = "Ue", "ß" = "ss")

.check_roles_to_merge <- function(roles) {
  if (!is.character(roles) || length(roles) < 2L || any(.is_blank(roles))) {
    stop("roles must name at least two roles, each by its AOT name or by the GUID of a role created ",
         "in the user interface.", call. = FALSE)
  }
  twice <- duplicated(.identifier_key(roles))
  if (any(twice)) {
    stop("roles names a role twice: ", paste(unique(roles[twice]), collapse = ", "), ".", call. = FALSE)
  }
  invisible(roles)
}

.role_names_of <- function(roles) vapply(roles, function(role) role$role_name, character(1))

# The first AOT role names the merged role; without one, the first role.
.merged_role_names <- function(roles) {
  is_ui <- is_guid_name(.role_names_of(roles))
  base  <- roles[[if (all(is_ui)) 1L else which(!is_ui)[[1]]]]
  name  <- if (is_guid_name(base$role_name)) .aot_name_from_label(base) else base$role_name
  label <- if (.is_single_string(base$role_label) && nzchar(trimws(base$role_label))) base$role_label else name
  list(name = paste0(name, .MERGED_SUFFIX), label = paste0(label, .MERGED_SUFFIX))
}

# "_WIBU Verkauf / Kopie" gives "_WIBU_Verkauf_Kopie"; an umlaut gives its two letters.
.aot_name_from_label <- function(role) {
  name <- enc2utf8(as.character(role$role_label))
  for (umlaut in names(.UMLAUTS)) {
    name <- gsub(umlaut, .UMLAUTS[[umlaut]], name, fixed = TRUE)
  }
  name <- sub("_+$", "", gsub("[^A-Za-z0-9_]+", "_", trimws(name)))
  if (length(name) != 1L || is.na(name) || !nzchar(name)) {
    stop("The role ", role$role_name, " of the user interface has no label to name the merged role after. ",
         "Give the name with name = \"...\".", call. = FALSE)
  }
  name
}

.merge_roles <- function(sources, name, label) {
  each <- function(part) .unique_by_key(unlist(lapply(sources, function(role) role[[part]]), use.names = FALSE))
  role <- list(
    role_name                 = name,
    role_description          = paste0("Merged from ", paste(.role_names_of(sources), collapse = ", "), "."),
    role_label                = label,
    duties                    = each("duties"),
    privileges                = each("privileges"),
    subroles                  = each("subroles"),
    direct_access_permissions = .merge_direct_access_permissions(
      lapply(sources, function(role) role$direct_access_permissions)
    )
  )
  role$duty_count                    <- length(role$duties)
  role$privilege_count               <- length(role$privileges)
  role$has_direct_access_permissions <- nrow(role$direct_access_permissions) > 0L
  .without_merged_roles(role, sources)
}

# Each name once, in the spelling met first; capitals do not count.
.unique_by_key <- function(x) {
  x <- x[!.is_blank(x)]
  x[!duplicated(.identifier_key(x))]
}

.without_merged_roles <- function(role, sources) {
  inside <- .identifier_key(role$subroles) %in% .identifier_key(.role_names_of(sources))
  if (any(inside)) {
    message("Sub-roles left out, their content is merged already: ", paste(role$subroles[inside], collapse = ", "), ".")
  }
  role$subroles      <- role$subroles[!inside]
  role$subrole_count <- length(role$subroles)
  role
}

# One row per object or field, in the order and spelling met first, with the
# strongest right of each kind; capitals do not count.
.merge_direct_access_permissions <- function(tables) {
  all <- dplyr::mutate(
    dplyr::bind_rows(tables),
    .object = .identifier_key(Objektname),
    .field  = .identifier_key(Feldname)
  )
  merged <- dplyr::summarise(
    all,
    Objektname = dplyr::first(Objektname),
    Feldname   = dplyr::first(Feldname),
    dplyr::across(dplyr::all_of(.ACCESS_RIGHTS), .strongest_right),
    .by = c("ObjektTyp", ".object", "Ebene", ".field")
  )
  dplyr::select(merged, dplyr::all_of(names(tables[[1]])))
}

.ACCESS_RIGHTS <- c("Create", "Correct", "Delete", "Invoke", "Read", "Update")

.strongest_right <- function(values) {
  if (any(values %in% "Deny")) "Deny" else if (any(values %in% "Allow")) "Allow" else ""
}

# The merged role under the name of a merged AOT role is a change of that role.
.merged_stored_name <- function(role, sources) {
  names_of <- .role_names_of(sources)
  same     <- names_of[.identifier_key(names_of) == .identifier_key(role$role_name) & !is_guid_name(names_of)]
  if (length(same) == 0L) "" else same[[1]]
}

.merge_sources <- function(roles, sources) {
  count    <- function(part) vapply(sources, function(role) length(role[[part]]), integer(1))
  names_of <- .role_names_of(sources)
  tibble::tibble(
    ROLE          = roles,
    NAME          = names_of,
    LABEL         = vapply(sources, function(role) role$role_label, character(1)),
    KIND          = ifelse(is_guid_name(names_of), "UI", "AOT"),
    DUTIES        = count("duties"),
    PRIVILEGES    = count("privileges"),
    SUBROLES      = count("subroles"),
    DIRECT_ACCESS = vapply(sources, .direct_access_count, integer(1))
  )
}
