# =============================================================================
# Object lists that D365FO exports from the license view of a role
#
# Used by compare_role_license_with_d365(). One file holds the objects of one
# role for one license. The license is not written inside the file, so it
# comes from the file name or from the caller.
# =============================================================================

# The seven columns of an export, in their fixed order. The headers depend on
# the language of the user interface and are not used.
.D365_EXPORT_COLUMNS <- c(
  "D365_TYPE", "OBJECT", "CHILD_NAME", "ACCESS", "ENTITLED", "NOT_ENTITLED", "NOT_REQUIRED"
)

.D365_YES <- c("ja", "yes", "true", "1")
.D365_NO  <- c("nein", "no", "false", "0")

# Short forms at the end of a file name, as in "..._Objects_TM.xlsx".
.D365_LICENSE_ALIASES <- c(
  TM       = "Team Members",
  ACTIVITY = "Operations - Activity",
  SCM      = "Supply Chain Management"
)

# D365FO shows the access level in these words in every language.
.ACCESS_LABELS <- c("Read", "Write")

# "Read" for level 1, "Write" for level 2 and above.
.access_label <- function(level) {
  dplyr::case_when(
    is.na(level) ~ NA_character_,
    level >= 2   ~ .ACCESS_LABELS[[2]],
    level >= 1   ~ .ACCESS_LABELS[[1]],
    TRUE         ~ NA_character_
  )
}

# Reads all exports of a role. Returns the files, the objects (one row per
# type, name and child name), the coverage per object and license, and one
# row per license with its file and the number of objects it does not cover.
.read_d365_license_exports <- function(d365_exports) {

  files   <- .d365_export_files(d365_exports)
  exports <- Map(.read_d365_license_export, files, names(files))

  reference <- exports[[1]]
  for (license in names(exports)[-1]) {
    .check_same_d365_objects(reference, exports[[license]], names(exports)[[1]], license)
  }

  list(
    files    = files,
    objects  = dplyr::select(reference, ROW_KEY, OBJECT_KEY, OBJECT, D365_TYPE, CHILD_NAME, ACCESS_D365),
    coverage = dplyr::select(dplyr::bind_rows(exports), ROW_KEY, LICENSE, D365_COVERS),
    licenses = tibble::tibble(
      LICENSE           = names(files),
      FILE              = basename(files),
      D365_NOT_ENTITLED = vapply(exports, function(export) sum(!export$D365_COVERS), integer(1), USE.NAMES = FALSE)
    )
  )
}

# Export files named by license: from a folder, or as given by the caller.
.d365_export_files <- function(d365_exports) {

  files <- d365_exports

  if (.is_single_string(d365_exports) && dir.exists(d365_exports)) {
    files <- list.files(d365_exports, pattern = "[.]xlsx$", full.names = TRUE, ignore.case = TRUE)
    # Excel keeps a lock file "~$name.xlsx" next to an open workbook
    files <- files[!startsWith(basename(files), "~$")]

    if (length(files) == 0L) {
      stop("d365_exports: the folder holds no .xlsx file: ", d365_exports)
    }
    names(files) <- .license_from_file_name(files)
  } else if (.is_single_string(d365_exports) && is.null(names(d365_exports)) && !file.exists(d365_exports)) {
    stop(
      "d365_exports: folder not found: ", d365_exports, ". It must exist and hold one export per license, ",
      "with the license at the end of the file name, for example ..._Objects_Commerce.xlsx or ..._Objects_TM.xlsx."
    )
  }

  is_named_files <- is.character(files) && length(files) > 0L && !anyNA(files) &&
    !is.null(names(files)) && all(nzchar(names(files)))

  if (!is_named_files) {
    stop(
      "d365_exports must be a folder with one export per license, or a character ",
      "vector of files named by license, for example c(Commerce = \"...xlsx\")."
    )
  }

  names(files) <- .full_license_name(names(files))

  if (anyDuplicated(names(files)) > 0L) {
    stop(
      "d365_exports names a license twice: ",
      paste(unique(names(files)[duplicated(names(files))]), collapse = .LIST_SEPARATOR)
    )
  }
  if (!all(file.exists(files))) {
    stop("d365_exports: file not found: ", paste(files[!file.exists(files)], collapse = .LIST_SEPARATOR))
  }

  files
}

# License from the end of a file name: "..._Objects_TM.xlsx" is Team Members,
# "..._Commerce.xlsx" is Commerce.
.license_from_file_name <- function(files) {
  .full_license_name(sub("^.*_", "", sub("[.][^.]*$", "", basename(files))))
}

# The full name behind a short form such as "TM"; any other name as it is.
.full_license_name <- function(license) {

  license <- trimws(license)
  alias   <- unname(.D365_LICENSE_ALIASES[toupper(license)])

  ifelse(is.na(alias), license, alias)
}

# The rows of one export under fixed column names, without empty rows.
.read_d365_export_rows <- function(path, license) {

  export <- readxl::read_excel(path, col_types = "text")

  if (ncol(export) < length(.D365_EXPORT_COLUMNS)) {
    stop(
      "The export for '", license, "' (", basename(path), ") has ", ncol(export),
      " columns. Expected are seven: type, AOT name, child name, access level, ",
      "entitled, not entitled, not required."
    )
  }

  export        <- export[seq_along(.D365_EXPORT_COLUMNS)]
  names(export) <- .D365_EXPORT_COLUMNS
  export        <- export[!is.na(export$OBJECT), ]

  if (nrow(export) == 0L) {
    stop("The export for '", license, "' (", basename(path), ") lists no objects.")
  }

  export
}

.read_d365_license_export <- function(path, license) {

  export       <- .read_d365_export_rows(path, license)
  not_entitled <- tolower(trimws(export$NOT_ENTITLED))
  access_level <- match(tolower(trimws(export$ACCESS)), tolower(.ACCESS_LABELS))

  if (!all(not_entitled %in% c(.D365_YES, .D365_NO)) || anyNA(access_level)) {
    stop(
      "The export for '", license, "' (", basename(path), ") does not look like an ",
      "object list of the role license view: the fourth column must hold Read or ",
      "Write, the sixth yes or no."
    )
  }

  objects <- tibble::tibble(
    OBJECT_KEY  = toupper(trimws(export$OBJECT)),
    OBJECT      = trimws(export$OBJECT),
    D365_TYPE   = export$D365_TYPE,
    CHILD_NAME  = export$CHILD_NAME,
    ACCESS_D365 = as.numeric(access_level),
    LICENSE     = license,
    D365_COVERS = !not_entitled %in% .D365_YES
  ) |>
    dplyr::mutate(
      ROW_KEY = paste(D365_TYPE, OBJECT_KEY, toupper(dplyr::coalesce(CHILD_NAME, "")), sep = "|")
    )

  if (anyDuplicated(objects$ROW_KEY) > 0L) {
    stop("The export for '", license, "' (", basename(path), ") lists an object twice.")
  }

  objects
}

# All exports of a role list the same objects with the same access. A file
# that differs belongs to another role, another environment or another day.
.check_same_d365_objects <- function(reference, export, reference_license, license) {

  only_one_side <- union(setdiff(reference$ROW_KEY, export$ROW_KEY), setdiff(export$ROW_KEY, reference$ROW_KEY))
  other_access  <- export$ACCESS_D365 != reference$ACCESS_D365[match(export$ROW_KEY, reference$ROW_KEY)]

  if (length(only_one_side) == 0L && !any(other_access, na.rm = TRUE)) {
    return(invisible(export))
  }

  stop(
    "The export for '", license, "' does not list the same objects as the export for '",
    reference_license, "': ", length(only_one_side), " object(s) are in only one of them, ",
    sum(other_access, na.rm = TRUE), " have another access level. All exports must come ",
    "from the same role and the same environment."
  )
}
