#' Compare the license costs of two environments
#'
#' Uses the detailed license report of the Power Platform admin center
#' (\code{\link{read_ppac_license_detail}}) to compare the license costs per
#' month of two environments, per user and per role. Typical use: roles were
#' changed in INT, and the comparison with production shows what the change
#' would save or cost.
#'
#' @details
#'
#' In a sandbox the report counts no license; it names the license a role
#' would need in production (\code{Not Applicable (<license>)}), and that is
#' the license compared here.
#'
#' The costs of a user and the costs only because of a role are computed as in
#' \code{\link{rank_roles_by_license_cost}}, in each environment on its own.
#' The totals and the roles take only the users who are in both environments,
#' so that a user who exists in one of them only does not count as a change.
#' Those users are listed in \code{Users} with \code{IN} \code{FROM_ONLY} or
#' \code{TO_ONLY}.
#'
#' @param licenses
#' The result of \code{\link{read_ppac_license_detail}} with both
#' environments.
#'
#' @param to
#' The environment that was changed, as in \code{EnvironmentName}, for example
#' \code{"wibu-int"}.
#'
#' @param from
#' The environment to compare with. \code{NULL} = the production environment
#' of the report.
#'
#' @param prices
#' Prices, see \code{\link{read_license_prices}}. \code{NULL} = the estimates
#' of the strategy paper, with a warning.
#'
#' @param export_path
#' Path of an \code{.xlsx} file; \code{NULL} = no file. The sheet Users holds
#' user ids.
#'
#' @param language
#' Language of the workbook: \code{"de"} or \code{"en"}.
#'
#' @return
#' List:
#' \describe{
#'   \item{\code{Check}}{\code{CREATED}, \code{FROM}, \code{TO},
#'     \code{REFRESHED_FROM}, \code{REFRESHED_TO}, \code{USERS_BOTH},
#'     \code{USERS_FROM_ONLY}, \code{USERS_TO_ONLY}, \code{COST_FROM},
#'     \code{COST_TO} (per month, users in both), \code{DIFFERENCE}
#'     (\code{COST_TO} minus \code{COST_FROM}), \code{PRICES_ESTIMATED}.}
#'   \item{\code{Users}}{One row per user, largest change first:
#'     \code{USERID}, \code{IN} (\code{BOTH}, \code{FROM_ONLY},
#'     \code{TO_ONLY}), \code{LICENSES_FROM}, \code{LICENSES_TO},
#'     \code{COST_FROM}, \code{COST_TO}, \code{DIFFERENCE}.}
#'   \item{\code{Roles}}{One row per role, largest change first, over the
#'     users in both: \code{ROLE}, \code{USERS_FROM}, \code{USERS_TO},
#'     \code{LICENSES_FROM}, \code{LICENSES_TO}, \code{COST_FROM},
#'     \code{COST_TO} (costs only because of the role), \code{DIFFERENCE}.}
#'   \item{\code{Prices}}{The prices used.}
#' }
#'
#' @examples
#' \dontrun{
#'
#' licenses <- read_ppac_license_detail("Input/Finance_And_Operations_Licensing_Detailed_Report_20261027_pseudonymized.csv")
#' result   <- compare_environment_license_cost(licenses, to = "wibu-int", prices = "Data/Lizenzpreise.xlsx",
#'                                              export_path = "Output/Lizenzkosten_INT_gegen_Prod.xlsx")
#' result$Check$DIFFERENCE
#' head(result$Roles)
#'
#' }
#'
#' @seealso
#' \code{\link{read_ppac_license_detail}}
#' \code{\link{rank_roles_by_license_cost}}
#' \code{\link{compare_assigned_license_cost}}
#'
#' @export
compare_environment_license_cost <- function(licenses, to, from = NULL, prices = NULL, export_path = NULL,
                                             language = "de") {

  language <- .check_report_language(language)
  if (!is.null(export_path)) .check_xlsx_path(export_path)
  columns <- c("ENVIRONMENT", "ENVIRONMENT_TYPE", "USERID", "USERENABLED", "ROLEIDENTIFIER", "SECURITYROLENAME", "SKUNAME")
  if (!is.data.frame(licenses) || !all(columns %in% names(licenses))) {
    stop("licenses must be the result of read_ppac_license_detail() with both environments.", call. = FALSE)
  }
  pair        <- .environment_pair(licenses, from, to)
  price_table <- .license_prices(prices)
  .check_prices_cover(price_table$prices, licenses$SKUNAME[licenses$ENVIRONMENT %in% pair])
  cost_of     <- .license_cost_function(price_table$prices, .standard_base_licenses())

  sides <- stats::setNames(lapply(pair, function(environment) {
    rows <- .cost_rows(licenses[licenses$ENVIRONMENT == environment, ], NULL)
    list(rows = rows, user_roles = .user_role_costs(rows, cost_of))
  }), c("from", "to"))
  both <- intersect(sides$from$rows$USER_KEY, sides$to$rows$USER_KEY)
  if (length(both) == 0L) {
    stop(pair[[1]], " and ", pair[[2]], " have no user in common, so their costs cannot be compared.", call. = FALSE)
  }

  users  <- .environment_users(sides)
  common <- users[users$IN == "BOTH", ]
  refreshed <- function(environment) {
    if ("REFRESHEDON" %in% names(licenses)) .latest(licenses$REFRESHEDON[licenses$ENVIRONMENT == environment]) else NA
  }
  result <- list(
    Check  = list(CREATED = Sys.Date(), FROM = pair[[1]], TO = pair[[2]],
                  REFRESHED_FROM = refreshed(pair[[1]]), REFRESHED_TO = refreshed(pair[[2]]),
                  USERS_BOTH = nrow(common), USERS_FROM_ONLY = sum(users$IN == "FROM_ONLY"),
                  USERS_TO_ONLY = sum(users$IN == "TO_ONLY"), COST_FROM = sum(common$COST_FROM),
                  COST_TO = sum(common$COST_TO), DIFFERENCE = round(sum(common$COST_TO) - sum(common$COST_FROM), 2),
                  PRICES_ESTIMATED = price_table$estimated),
    Users  = users,
    Roles  = .environment_roles(sides, both),
    Prices = price_table$prices
  )

  if (!is.null(export_path)) {
    .export_environment_license_cost(result, export_path, language)
  }
  check <- result$Check
  message(sprintf("License costs of the %d users in both %s and %s: %.2f and %.2f per month, difference %+.2f. %d users only in %s, %d only in %s.",
                  check$USERS_BOTH, check$FROM, check$TO, check$COST_FROM, check$COST_TO, check$DIFFERENCE,
                  check$USERS_FROM_ONLY, check$FROM, check$USERS_TO_ONLY, check$TO))
  result
}

# from (default: the production environment) and to, both in the report and not the same.
.environment_pair <- function(licenses, from, to) {
  available <- sort(unique(licenses$ENVIRONMENT))
  names_one <- function(value, name) {
    if (!.is_single_string(value)) {
      stop(name, " must name one environment of the report: ", paste(available, collapse = .LIST_SEPARATOR), ".",
           call. = FALSE)
    }
  }
  names_one(to, "to")
  if (!is.null(from)) names_one(from, "from")
  if (is.null(from)) {
    production <- unique(licenses$ENVIRONMENT[tolower(licenses$ENVIRONMENT_TYPE) == "production"])
    if (length(production) != 1L) {
      stop("from: name the environment to compare with; the report holds: ", paste(available, collapse = .LIST_SEPARATOR),
           ".", call. = FALSE)
    }
    from <- production
  }
  .ppac_environments(available, c(from, to))
  if (identical(from, to)) {
    stop("Compare two different environments: from and to are both ", from, ".", call. = FALSE)
  }
  c(from, to)
}

.environment_users <- function(sides) {
  per_side <- function(side, suffix) {
    licenses <- side$rows |>
      dplyr::group_by(USER_KEY) |>
      dplyr::summarise(LICENSES = .licenses_by_priority(SKUNAME, .STANDARD_LICENSE_SKUS), .groups = "drop")
    dplyr::distinct(side$user_roles, USER_KEY, USERID, COST = TOTAL) |>
      dplyr::left_join(licenses, by = "USER_KEY") |>
      dplyr::rename_with(function(name) paste0(name, suffix), -USER_KEY)
  }

  dplyr::full_join(per_side(sides$from, "_FROM"), per_side(sides$to, "_TO"), by = "USER_KEY") |>
    dplyr::mutate(
      USERID     = dplyr::coalesce(USERID_FROM, USERID_TO),
      IN         = dplyr::case_when(!is.na(COST_FROM) & !is.na(COST_TO) ~ "BOTH", !is.na(COST_FROM) ~ "FROM_ONLY",
                                    TRUE ~ "TO_ONLY"),
      DIFFERENCE = round(COST_TO - COST_FROM, 2)
    ) |>
    dplyr::arrange(dplyr::desc(abs(DIFFERENCE)), USERID) |>
    dplyr::select(USERID, IN, LICENSES_FROM, LICENSES_TO, COST_FROM, COST_TO, DIFFERENCE)
}

.environment_roles <- function(sides, both) {
  per_side <- function(side, suffix) {
    .cost_ranking(side$rows[side$rows$USER_KEY %in% both, ], side$user_roles[side$user_roles$USER_KEY %in% both, ],
                  .STANDARD_LICENSE_SKUS) |>
      dplyr::select(ROLE_KEY, ROLE, USERS, LICENSES, COST) |>
      dplyr::rename_with(function(name) paste0(name, suffix), -ROLE_KEY)
  }

  dplyr::full_join(per_side(sides$from, "_FROM"), per_side(sides$to, "_TO"), by = "ROLE_KEY") |>
    dplyr::mutate(
      ROLE          = dplyr::coalesce(ROLE_FROM, ROLE_TO),
      USERS_FROM    = dplyr::coalesce(USERS_FROM, 0L),
      USERS_TO      = dplyr::coalesce(USERS_TO, 0L),
      LICENSES_FROM = dplyr::coalesce(LICENSES_FROM, ""),
      LICENSES_TO   = dplyr::coalesce(LICENSES_TO, ""),
      COST_FROM     = dplyr::coalesce(COST_FROM, 0),
      COST_TO       = dplyr::coalesce(COST_TO, 0),
      DIFFERENCE    = round(COST_TO - COST_FROM, 2)
    ) |>
    dplyr::arrange(dplyr::desc(abs(DIFFERENCE)), dplyr::desc(COST_FROM), ROLE) |>
    dplyr::select(ROLE, USERS_FROM, USERS_TO, LICENSES_FROM, LICENSES_TO, COST_FROM, COST_TO, DIFFERENCE)
}
