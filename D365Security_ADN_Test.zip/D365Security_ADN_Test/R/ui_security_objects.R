# =============================================================================
# Security objects made in the user interface and their AOT counterparts
#
# Roles, duties and privileges created in the user interface have a GUID as
# identifier and the typed name as name; objects of development have a
# readable identifier. The counterpart of a UI object is the AOT object of the
# same type and the same name; an AOT role writes its name as
# "<label> (<AOT name>)", so the part in brackets is left aside. Used by
# plan_ui_counterparts() (D22, D23) and inventory_ui_objects() (D24).
# =============================================================================

.UI_OBJECT_SQL <- c(
  ROLE      = "SELECT AOTNAME AS IDENTIFIER, NAME FROM SECURITYROLE",
  DUTY      = "SELECT IDENTIFIER, NAME FROM SECURITYDUTY",
  PRIVILEGE = "SELECT IDENTIFIER, NAME FROM SECURITYPRIVILEGE"
)

# The structure, read once and in few columns: the own parts of every role (its duties and the
# privileges outside any duty), the privileges of every duty, the entry points of every
# privilege with their rights, and the sub-roles.
.UI_STRUCTURE_SQL <- c(
  role_parts      = paste("SELECT DISTINCT ROLEIDENTIFIER, DUTYIDENTIFIER, PRIVILEGEIDENTIFIER FROM UserSecGovRelatedObjects",
                          "WHERE SUBROLEIDENTIFIER IS NULL OR SUBROLEIDENTIFIER = ''"),
  duty_privileges = paste("SELECT DISTINCT DUTYIDENTIFIER, PRIVILEGEIDENTIFIER FROM UserSecGovRelatedObjects",
                          "WHERE DUTYIDENTIFIER <> '' AND PRIVILEGEIDENTIFIER <> ''"),
  grants          = paste("SELECT DISTINCT PRIVILEGEIDENTIFIER, RESOURCE_, RESOURCETYPE, CREATEACCESS, CORRECTACCESS,",
                          "DELETEACCESS, INVOKEACCESS, UPDATEACCESS, READACCESS FROM UserSecGovRelatedObjects",
                          "WHERE PRIVILEGEIDENTIFIER <> ''"),
  subroles        = "SELECT SECURITYROLEIDENTIFIER, SECURITYSUBROLEIDENTIFIER FROM SYSTEMSECURITYSUBROLEENTITY"
)

.check_ui_pairs <- function(pairs) {
  if (!is.null(pairs) && (!is.data.frame(pairs) || !all(c("UI_IDENTIFIER", "AOT_IDENTIFIER") %in% names(pairs)))) {
    stop("pairs must be a table with the columns UI_IDENTIFIER and AOT_IDENTIFIER, or NULL.", call. = FALSE)
  }
  invisible(TRUE)
}

# "_WIBU Verkauf (_WIBU_Verkauf)" -> "_WIBU Verkauf": the name without its identifier in brackets.
.label_without_identifier <- function(name, identifier) {
  name   <- trimws(name)
  suffix <- paste0(" (", toupper(trimws(identifier)), ")")
  ends   <- endsWith(toupper(name), suffix)
  ifelse(ends, trimws(substr(name, 1L, nchar(name) - nchar(suffix))), name)
}

# All objects of one type: identifier, name, keys, and whether it was made in the user interface.
.load_security_objects <- function(con, type) {
  rows <- tibble::as_tibble(DBI::dbGetQuery(con, .UI_OBJECT_SQL[[type]]))
  rows <- rows[!.is_blank(rows$IDENTIFIER), ]
  name <- dplyr::coalesce(as.character(rows$NAME), as.character(rows$IDENTIFIER))
  tibble::tibble(
    TYPE       = type,
    IDENTIFIER = as.character(rows$IDENTIFIER),
    NAME       = name,
    KEY        = .identifier_key(rows$IDENTIFIER),
    LABEL_KEY  = .identifier_key(.label_without_identifier(name, rows$IDENTIFIER)),
    UI         = is_guid_name(trimws(rows$IDENTIFIER))
  ) |>
    dplyr::distinct(KEY, .keep_all = TRUE)
}

# Per UI object of one type its AOT counterparts of the same name; pairs given by hand win.
.ui_counterparts <- function(objects, pairs = NULL) {
  ui    <- objects[objects$UI, ]
  aot   <- objects[!objects$UI, ]
  found <- lapply(ui$LABEL_KEY, function(label) aot$IDENTIFIER[aot$LABEL_KEY == label])
  kind  <- ifelse(lengths(found) == 0L, "NONE", ifelse(lengths(found) == 1L, "NAME", "SEVERAL"))
  if (!is.null(pairs)) {
    at     <- match(ui$KEY, .identifier_key(pairs$UI_IDENTIFIER))
    manual <- !is.na(at)
    found[manual] <- as.list(as.character(pairs$AOT_IDENTIFIER[at[manual]]))
    kind[manual]  <- "MANUAL"
  }
  joined <- function(ids, values) {
    if (length(ids) == 0L) NA_character_ else paste(sort(unique(stats::na.omit(values))), collapse = .LIST_SEPARATOR)
  }
  tibble::tibble(
    TYPE = ui$TYPE, UI_IDENTIFIER = ui$IDENTIFIER, UI_NAME = ui$NAME, UI_KEY = ui$KEY,
    AOT_IDENTIFIER = vapply(found, function(ids) joined(ids, ids), character(1)),
    AOT_NAME       = vapply(found, function(ids) joined(ids, aot$NAME[match(.identifier_key(ids), aot$KEY)]), character(1)),
    AOT_KEY        = vapply(found, function(ids) if (length(ids) == 1L) .identifier_key(ids) else NA_character_, character(1)),
    MATCH          = kind
  )
}

# Pairs by hand: a UI identifier that is no UI object of the types read is left out, with a
# warning; an AOT identifier that is no AOT object of the same type stops, for a typo would
# otherwise become a result.
.validate_ui_pairs <- function(pairs, objects, what) {
  if (is.null(pairs)) return(NULL)
  ui      <- objects[objects$UI, ]
  aot     <- objects[!objects$UI, ]
  ui_type <- ui$TYPE[match(.identifier_key(pairs$UI_IDENTIFIER), ui$KEY)]
  unknown <- is.na(ui_type)
  if (any(unknown)) {
    warning("pairs name objects that are no ", what, ": ", paste(pairs$UI_IDENTIFIER[unknown], collapse = .LIST_SEPARATOR),
            ". They are left out.", call. = FALSE)
  }
  found <- match(paste(ui_type, .identifier_key(pairs$AOT_IDENTIFIER)), paste(aot$TYPE, aot$KEY))
  bad   <- !unknown & is.na(found)
  if (any(bad)) {
    stop("pairs name AOT identifiers that are no AOT object of the same type: ",
         paste(pairs$UI_IDENTIFIER[bad], "->", pairs$AOT_IDENTIFIER[bad], collapse = "; "), ".", call. = FALSE)
  }
  pairs[!unknown, , drop = FALSE]
}

# Without the structure every UI object would look unused or unreadable, without a word.
.load_ui_structure <- function(con, parts) {
  loaded <- lapply(stats::setNames(parts, parts), function(part) tibble::as_tibble(DBI::dbGetQuery(con, .UI_STRUCTURE_SQL[[part]])))
  labels <- c(role_parts = "own parts of roles", duty_privileges = "privileges of duties")
  empty  <- intersect(names(labels), names(loaded)[vapply(loaded, nrow, integer(1)) == 0L])
  if (length(empty) > 0L) {
    warning("UserSecGovRelatedObjects returned no ", paste(labels[empty], collapse = " and "), ": is it filled in this ",
            "environment? Without it every UI object counts as not readable or as sitting nowhere.", call. = FALSE)
  }
  loaded
}

# The own duties and the own privileges outside any duty of every role, by key.
.role_part_keys <- function(role_parts) {
  no_duty   <- .is_blank(role_parts$DUTYIDENTIFIER)
  privilege <- no_duty & !.is_blank(role_parts$PRIVILEGEIDENTIFIER)
  list(
    duties     = dplyr::distinct(tibble::tibble(ROLE = role_parts$ROLEIDENTIFIER[!no_duty],
                                                CHILD_KEY = .identifier_key(role_parts$DUTYIDENTIFIER[!no_duty]))),
    privileges = dplyr::distinct(tibble::tibble(ROLE = role_parts$ROLEIDENTIFIER[privilege],
                                                CHILD_KEY = .identifier_key(role_parts$PRIVILEGEIDENTIFIER[privilege])))
  )
}

.duty_privilege_keys <- function(duty_privileges) {
  dplyr::distinct(tibble::tibble(DUTY = duty_privileges$DUTYIDENTIFIER,
                                 DUTY_KEY = .identifier_key(duty_privileges$DUTYIDENTIFIER),
                                 PRIVILEGE_KEY = .identifier_key(duty_privileges$PRIVILEGEIDENTIFIER)))
}

# "Delete=Allow, Read=Allow, Update=Allow" from the access columns: 1 = Allow, 2 = Deny.
.grant_text <- function(grants) {
  if (nrow(grants) == 0L) return(character())
  columns <- c(Create = "CREATEACCESS", Correct = "CORRECTACCESS", Delete = "DELETEACCESS", Invoke = "INVOKEACCESS",
               Read = "READACCESS", Update = "UPDATEACCESS")
  values  <- vapply(columns, function(column) suppressWarnings(as.integer(grants[[column]])), integer(nrow(grants)))
  values  <- matrix(values, nrow = nrow(grants), dimnames = list(NULL, names(columns)))
  apply(values, 1L, function(row) {
    text <- ifelse(is.na(row), "", ifelse(row == 1L, "Allow", ifelse(row == 2L, "Deny", "")))
    paste(paste0(names(row)[nzchar(text)], "=", text[nzchar(text)]), collapse = .LIST_SEPARATOR)
  })
}
