#' Write the license profile of every user as deliverable D21
#'
#' Writes the result of \code{\link{build_user_license_profile}} as the Excel
#' workbook of the deliverable D21 (Lizenzprofil je Benutzer), in German and in
#' the layout of the other deliverables: one row per user with what PPAC
#' expects, what is assigned and not yet assigned, what the telemetry needs,
#' and what could go.
#'
#' @details
#'
#' **Sheets.** \code{Anleitung}; \code{Benutzer} (one row per user; blue
#' columns are filled by the tool, the white ones by the team:
#' \code{Entscheidung}, \code{Geprüft am}, \code{Status}, \code{Bemerkung});
#' \code{Ergebnisse} (users and costs per result, with its meaning);
#' \code{Lizenzen} (users per license); \code{Preise}; \code{Listen}. The
#' sheet \code{Benutzer} holds user ids, pseudonymized when the reports and
#' the telemetry were.
#'
#' **An earlier D21.** With \code{previous}, the white columns carry over by
#' user. Users of the earlier D21 with entries of the team that are no longer
#' in \code{profile} are named in a warning.
#'
#' @param profile
#' Result of \code{\link{build_user_license_profile}}.
#'
#' @param path
#' Path of the workbook to write, in an existing folder.
#'
#' @param previous
#' Optional path of an earlier D21 whose white columns carry over.
#'
#' @param overwrite
#' \code{TRUE} = replace an existing file at \code{path}. Default \code{FALSE}:
#' an existing D21 holds the decisions of the team.
#'
#' @return
#' Invisibly \code{path}.
#'
#' @examples
#' \dontrun{
#'
#' profile <- build_user_license_profile(report, licenses, graph, usage, prices = "Input/Lizenzpreise.xlsx")
#' export_user_license_profile(profile, "Output/D21_Lizenzprofil_Benutzer.xlsx")
#'
#' }
#'
#' @seealso
#' \code{\link{build_user_license_profile}}
#'
#' @export
export_user_license_profile <- function(profile, path, previous = NULL, overwrite = FALSE) {

  .check_profile_export(profile, path, previous, overwrite)
  earlier <- if (is.null(previous)) NULL else .read_previous_sheet(previous, "Benutzer", "Benutzer", .D21_DATES)
  users   <- .d21_users(profile$Users, earlier)

  wb <- openxlsx::createWorkbook()
  .add_d21_instructions(wb, profile$Check)
  .add_deliverable_sheet(wb, "Benutzer", users, it = setdiff(names(users), .D21_MANUAL))
  .add_deliverable_sheet(wb, "Ergebnisse", .d21_classes(profile$Classes), all_it = TRUE)
  .add_deliverable_sheet(wb, "Lizenzen", .d21_licenses(profile$Licenses), all_it = TRUE)
  .add_deliverable_sheet(wb, "Preise", .d21_prices(profile$Prices), all_it = TRUE)
  .add_deliverable_sheet(wb, "Listen", .list_frame(.d21_lists()))
  .add_list_validation(wb, "Benutzer", users, .d21_lists())

  openxlsx::saveWorkbook(wb, path, overwrite = TRUE)
  message(sprintf("D21 written: %s (%d users, %d could lose a license).", path, profile$Check$USERS,
                  profile$Check$USERS_COULD_LOSE))
  invisible(path)
}

.D21_MANUAL <- c("Entscheidung", "Geprüft am", "Status", "Bemerkung")
.D21_DATES  <- "Geprüft am"

.D21_CLASSES <- c(
  SAVES          = "Könnte Lizenz verlieren",
  REVIEW         = "Nach Prüfung weniger",
  KEEPS          = "Telemetrie bestätigt PPAC",
  NO_USE         = "Nur lizenzfreie Nutzung: prüfen",
  NO_TELEMETRY   = "Keine Telemetrie: prüfen",
  GRAPH_DIFFERS  = "Graph erklärt PPAC nicht",
  REPORTS_DIFFER = "Berichte von PPAC weichen ab",
  NOT_IN_DETAIL  = "Nicht im Detailbericht",
  NOT_IN_REPORT  = "Nicht im Bericht je Benutzer"
)

.D21_MEANINGS <- c(
  SAVES          = "Die Telemetrie braucht weniger, als PPAC erwartet. Werden die Rollen des Benutzers bereinigt, entfällt die Lizenz.",
  REVIEW         = "Laut Telemetrie gleich; weniger nur, wenn der Fachbereich bestätigt, dass die nicht messbaren Aufgaben ungenutzt sind.",
  KEEPS          = "Die Telemetrie bestätigt, was PPAC erwartet.",
  NO_USE         = "Nur geöffnet, was keine Lizenz braucht (z. B. die Startseite). Arbeitet vielleicht über die Lager-App oder eine Schnittstelle: prüfen, keine Einsparung.",
  NO_TELEMETRY   = "Im Zeitraum der Telemetrie nichts geöffnet: prüfen (Lager-App, Schnittstelle, Abwesenheit), keine Einsparung.",
  GRAPH_DIFFERS  = "PPAC rechnet mehr ab, als der Lizenzgraph aus den Rollen erklärt: Rollen und Graph prüfen, keine Einsparung.",
  REPORTS_DIFFER = "Der Bericht je Benutzer und der Detailbericht rechnen den Benutzer verschieden ab: Berichte vom selben Tag nehmen.",
  NOT_IN_DETAIL  = "Steht im Bericht je Benutzer, hat aber keine Rollen im Detailbericht: Zuweisungen prüfen.",
  NOT_IN_REPORT  = "Hat Rollen im Detailbericht, steht aber nicht im Bericht je Benutzer."
)

.check_profile_export <- function(profile, path, previous, overwrite) {
  if (!is.list(profile) || !all(c("Check", "Users", "Classes", "Licenses", "Prices") %in% names(profile))) {
    stop("profile must be the result of build_user_license_profile().", call. = FALSE)
  }
  .check_deliverable_paths(path, previous, overwrite, "An existing D21 holds the decisions of the team")
}

.d21_date <- function(values) ifelse(is.na(values), NA_character_, format(as.Date(values), "%d.%m.%Y"))

.d21_users <- function(users, earlier) {
  sheet <- data.frame(
    "Benutzer" = users$USERID, "Rollen" = users$ROLES, "Geöffnete Einstiegspunkte" = users$ENTRY_POINTS,
    "Zuletzt gesehen" = .d21_date(users$LAST_SEEN),
    "Erwartet laut PPAC" = users$REQUIRED, "Erwartet (€/Monat)" = users$REQUIRED_COST,
    "Bereits zugewiesen" = users$ASSIGNED, "Zugewiesen (€/Monat)" = users$ASSIGNED_COST,
    "Noch nicht zugewiesen" = users$MISSING, "Nachkauf laut PPAC (€/Monat)" = users$MISSING_COST,
    "Nötig laut Telemetrie" = users$BY_USAGE, "Abrechnung laut Telemetrie" = users$BILLED_BY_USAGE,
    "Laut Telemetrie (€/Monat)" = users$COST_BY_USAGE, "Nach Prüfung nötig" = users$IF_CONFIRMED,
    "Nach Prüfung (€/Monat)" = users$COST_IF_CONFIRMED,
    "Könnte entfallen" = users$COULD_GO, "davon bereits zugewiesen" = users$COULD_GO_ASSIGNED,
    "davon noch nicht zugewiesen" = users$COULD_GO_MISSING, "Käme hinzu" = users$ADDED,
    "Fehlend und laut Telemetrie nötig" = users$MISSING_NEEDED,
    "Mögliche Einsparung (€/Monat)" = users$SAVING, "Weitere Einsparung nach Prüfung (€/Monat)" = users$SAVING_IF_CONFIRMED,
    "Nachkauf laut Telemetrie (€/Monat)" = users$PURCHASE_BY_USAGE, "Vermiedener Nachkauf (€/Monat)" = users$PURCHASE_AVOIDED,
    "Ergebnis" = unname(.D21_CLASSES[users$CLASS]),
    check.names = FALSE, stringsAsFactors = FALSE
  )
  keys  <- .deliverable_key(users$USERID)
  sheet <- .carry_over_columns(sheet, keys, earlier, earlier$KEY, .D21_MANUAL)
  if (!is.null(earlier)) {
    .warn_on_gone_entries(earlier, keys, .D21_MANUAL, "users", "Benutzer")
    .warn_on_dropped_columns(earlier, names(sheet), "D21")
  }
  sheet
}

.d21_classes <- function(classes) {
  data.frame(
    "Ergebnis" = unname(.D21_CLASSES[classes$CLASS]), "Benutzer" = classes$USERS,
    "Erwartet (€/Monat)" = classes$REQUIRED_COST, "Zugewiesen (€/Monat)" = classes$ASSIGNED_COST,
    "Nachkauf laut PPAC (€/Monat)" = classes$MISSING_COST, "Laut Telemetrie (€/Monat)" = classes$COST_BY_USAGE,
    "Mögliche Einsparung (€/Monat)" = classes$SAVING, "Vermiedener Nachkauf (€/Monat)" = classes$PURCHASE_AVOIDED,
    "Bedeutung" = unname(.D21_MEANINGS[classes$CLASS]), check.names = FALSE, stringsAsFactors = FALSE
  )
}

.d21_licenses <- function(licenses) {
  data.frame(
    "Lizenz" = licenses$LICENSE, "Erwartet laut PPAC" = licenses$REQUIRED, "Bereits zugewiesen" = licenses$ASSIGNED,
    "Noch nicht zugewiesen" = licenses$MISSING, "Nötig laut Telemetrie" = licenses$BY_USAGE,
    "Könnte entfallen" = licenses$COULD_GO, "davon bereits zugewiesen" = licenses$COULD_GO_ASSIGNED,
    "davon noch nicht zugewiesen" = licenses$COULD_GO_MISSING, "Käme hinzu" = licenses$ADDED,
    check.names = FALSE, stringsAsFactors = FALSE
  )
}

.d21_prices <- function(prices) {
  data.frame("Lizenz" = prices$LICENSE, "Grundpreis (€/Monat)" = prices$BASE_PRICE,
             "Attach-Preis (€/Monat)" = prices$ATTACH_PRICE, check.names = FALSE, stringsAsFactors = FALSE)
}

.d21_lists <- function() {
  list("Entscheidung" = c("Rollen bereinigen", "Lizenz anpassen", "Lizenz behalten", "Mit Fachbereich klären"),
       "Status" = c("offen", "in Arbeit", "erledigt"))
}

.d21_euro <- function(amount) format(round(amount, 2), big.mark = ".", decimal.mark = ",", nsmall = 2)

.add_d21_instructions <- function(wb, check) {
  period <- if (is.na(check$TELEMETRY_FROM)) "ohne Datum" else
    paste(format(as.Date(check$TELEMETRY_FROM), "%d.%m.%Y"), "bis", format(as.Date(check$TELEMETRY_TO), "%d.%m.%Y"))
  text <- c(
    "D21 Lizenzprofil je Benutzer: Telemetrie gegen PPAC",
    paste0("Erzeugt am ", format(Sys.Date(), "%d.%m.%Y"), "; Telemetrie ", period,
           if (isTRUE(check$PRICES_ESTIMATED)) "; geschätzte Preise" else ""),
    "",
    "Worum es geht",
    "Je Benutzer zeigt die Datei, welche Lizenzen seine Arbeit laut Telemetrie braucht (sein Lizenzprofil), und stellt es dem Bericht des Power Platform Admin Center (PPAC) gegenüber: was PPAC für ihn erwartet, was schon zugewiesen ist und was noch nicht. So sieht man, wer laut Telemetrie eine Lizenz verlieren könnte und welche noch nicht zugewiesenen Lizenzen nicht gekauft werden müssen.",
    "",
    "Kennzahlen",
    sprintf("%d Benutzer. PPAC erwartet %s € im Monat; zugewiesen sind %s €, noch nicht zugewiesen %s €.",
            check$USERS, .d21_euro(check$REQUIRED_COST), .d21_euro(check$ASSIGNED_COST), .d21_euro(check$MISSING_COST)),
    sprintf(paste("Laut Telemetrie beurteilt: %d Benutzer; sie kosten laut PPAC %s €, laut Telemetrie %s €. %d Benutzer",
                  "könnten eine Lizenz verlieren: %s € im Monat weniger als erwartet, davon %s € vermiedener Nachkauf;",
                  "nach Prüfung der nicht messbaren Aufgaben weitere %s €."),
            check$USERS_COUNTED, .d21_euro(check$REQUIRED_COST_COUNTED), .d21_euro(check$COST_BY_USAGE), check$USERS_COULD_LOSE,
            .d21_euro(check$SAVING), .d21_euro(check$PURCHASE_AVOIDED), .d21_euro(check$SAVING_IF_CONFIRMED)),
    "",
    "So lesen Sie das Blatt „Benutzer“",
    "„Erwartet laut PPAC“, „Bereits zugewiesen“ und „Noch nicht zugewiesen“ stammen aus dem Bericht je Benutzer. „Nötig laut Telemetrie“ sind die günstigsten Lizenzen für die Aufgaben, die der Benutzer nutzt. „Könnte entfallen“ sind erwartete Lizenzen, die die Telemetrie nicht braucht: bereits zugewiesene könnten zurückgenommen, noch nicht zugewiesene müssen nicht gekauft werden. „Käme hinzu“ nennt eine kleinere Lizenz statt der großen, zum Beispiel Activity statt SCM.",
    "",
    "Regeln",
    "Eine Aufgabe gilt als genutzt, wenn der Benutzer einen ihrer Menüpunkte geöffnet hat; Aufgaben ohne Menüpunkt (Aktionen, Datenentitäten) lassen sich nicht messen und bleiben. Betrachtet werden alle Rollen eines Benutzers zusammen. Wo der Lizenzgraph mehr verlangt, als PPAC abrechnet, gilt PPAC.",
    "Benutzer ohne Telemetrie oder nur mit lizenzfreier Nutzung sind eine Prüfliste, keine Einsparung. Die Telemetrie deckt nur ihren Zeitraum ab: Was einmal im Jahr anfällt (Jahresabschluss, Inventur), fehlt darin vielleicht.",
    "",
    "Was zu tun ist",
    "1. Benutzer mit „Könnte Lizenz verlieren“ mit dem Fachbereich durchgehen: Braucht er die Funktionen wirklich nicht? Entscheidung und Datum eintragen.",
    "2. Die Lizenz entfällt erst, wenn die Rollen des Benutzers bereinigt sind, denn PPAC rechnet nach den Rollen (Bereinigungsplan D04, Arbeitsgrundlage aus D20).",
    "3. Noch nicht zugewiesene Lizenzen, die laut Telemetrie entfallen könnten, vor dem Kauf klären.",
    "4. Die Prüflisten klären: keine Telemetrie, nur lizenzfreie Nutzung, Abweichungen zwischen den Berichten oder zum Graphen.",
    "",
    "Hinweis für die Weiterverarbeitung",
    "Blau markierte Spalten und Blätter füllt das Werkzeug; die weißen Spalten pflegt das Team. Beim nächsten Lauf übernimmt das Werkzeug die weißen Spalten je Benutzer. Das Blatt „Benutzer“ enthält Benutzer-IDs: nicht weitergeben. Die Auswertung dient nur Rollen und Lizenzen, nicht der Kontrolle von Leistung oder Verhalten (D02, Abschnitt 5)."
  )
  .add_instruction_sheet(wb, text, c("Worum es geht", "Kennzahlen", "So lesen Sie das Blatt „Benutzer“", "Regeln",
                                     "Was zu tun ist", "Hinweis für die Weiterverarbeitung"))
}
