# =============================================================================
# Parts of plan_role_license_cleanup(): the costs and class of each user, the
# duties that make a license go, the actions, the order of the roles, and the
# tables of the result.
# =============================================================================

# Per user today's billing, from PPAC, and the licenses PPAC bills as a bit mask.
.current_billing <- function(rows, skus, cost_of) {
  rows |>
    dplyr::group_by(USER_KEY) |>
    dplyr::summarise(USERID = dplyr::first(USERID), ROLES = .sorted_list(ROLE_SHOWN),
                     BILLED_NOW = cost_of(SKU_KEY, "billing"), COST_NOW = cost_of(SKU_KEY),
                     NOW_BITS = .license_bits(.standard_license_names(SKUNAME), skus), .groups = "drop")
}

# The license masks of the duties of each user, PPAC having priority
# (.ppac_priority_masks()). GRAPH_MASK keeps what the graph says.
.user_masks <- function(user_units, units, now, needed, skus) {
  user_units |>
    dplyr::select(USER_KEY, ROLE, UNIT, UNIT_ID, UNIT_NAME, OPENED, KEEP_USAGE, KEEP_CONFIRMED) |>
    dplyr::inner_join(dplyr::distinct(units, ROLE, UNIT, MASK, LICENSE), by = c("ROLE", "UNIT"),
                      relationship = "many-to-many") |>
    dplyr::inner_join(dplyr::select(now, USER_KEY, NOW_BITS), by = "USER_KEY") |>
    dplyr::mutate(
      GRAPH_MASK = MASK,
      ABOVE_PPAC = needed(MASK) & bitwAnd(MASK, NOW_BITS) == 0L,
      MASK       = .ppac_priority_masks(MASK, NOW_BITS, needed, skus)
    ) |>
    dplyr::select(-NOW_BITS)
}

# Per user the cheapest licenses for all objects of his roles, for the duties he keeps by
# the telemetry, and for those he keeps after review.
.user_license_costs <- function(now, user_masks, touches, licenses) {
  masks   <- dplyr::select(user_masks, USER_KEY, MASK, KEEP_USAGE, KEEP_CONFIRMED)
  by_user <- split(masks, masks$USER_KEY)
  covers  <- lapply(now$USER_KEY, function(user) {
    own       <- if (is.null(by_user[[user]])) masks[0, ] else by_user[[user]]
    all       <- licenses$cover(own$MASK)
    usage     <- licenses$cover(own$MASK[own$KEEP_USAGE], prefer = all$bits)
    confirmed <- licenses$cover(own$MASK[own$KEEP_CONFIRMED], prefer = usage$bits)
    list(all = all, usage = usage, confirmed = confirmed)
  })
  covered <- function(scenario, field, type) vapply(covers, function(cover) cover[[scenario]][[field]], type)
  seen <- touches |>
    dplyr::group_by(USER_KEY) |>
    dplyr::summarise(ENTRY_POINTS = dplyr::n_distinct(ENTRYPOINT_KEY), LAST_SEEN = .max_date(LAST_SEEN), .groups = "drop")

  now |>
    dplyr::mutate(
      BILLED_GRAPH        = covered("all", "billing", character(1)),
      COST_GRAPH          = covered("all", "cost", numeric(1)),
      BILLED_BY_USAGE     = covered("usage", "billing", character(1)),
      COST_BY_USAGE       = covered("usage", "cost", numeric(1)),
      USAGE_BITS          = covered("usage", "bits", integer(1)),
      BILLED_IF_CONFIRMED = covered("confirmed", "billing", character(1)),
      COST_IF_CONFIRMED   = covered("confirmed", "cost", numeric(1)),
      CONFIRMED_BITS      = covered("confirmed", "bits", integer(1))
    ) |>
    dplyr::left_join(seen, by = "USER_KEY") |>
    .classify_cleanup_users()
}

# Savings count only for users with telemetry whose graph gives today's billing; after the
# priority of PPAC the graph can only need less, and then it lacks something. A user
# who opened only what needs no license would lose every license: he is checked first,
# like a user without telemetry, for he may work in the warehouse app.
.classify_cleanup_users <- function(users) {
  dplyr::mutate(
    users,
    HAS_TELEMETRY = !is.na(ENTRY_POINTS),
    GRAPH_DIFFERS = abs(COST_GRAPH - COST_NOW) > .CENT,
    CLASS = dplyr::case_when(
      !HAS_TELEMETRY                            ~ .CLEANUP_NO_TELEMETRY,
      GRAPH_DIFFERS                             ~ .CLEANUP_GRAPH_DIFFERS,
      COST_NOW > .CENT & COST_BY_USAGE < .CENT  ~ .CLEANUP_NO_USE,
      COST_NOW - COST_BY_USAGE > .CENT          ~ .CLEANUP_SAVES,
      COST_BY_USAGE - COST_IF_CONFIRMED > .CENT ~ .CLEANUP_REVIEW,
      TRUE                                      ~ .CLEANUP_KEEPS
    ),
    COUNTED             = CLASS %in% c(.CLEANUP_SAVES, .CLEANUP_REVIEW, .CLEANUP_KEEPS),
    SAVING              = ifelse(COUNTED, round(COST_NOW - COST_BY_USAGE, 2), NA_real_),
    SAVING_IF_CONFIRMED = ifelse(COUNTED, round(COST_BY_USAGE - COST_IF_CONFIRMED, 2), NA_real_),
    dplyr::across(c(BILLED_BY_USAGE, BILLED_IF_CONFIRMED), function(billed) ifelse(COUNTED, billed, NA_character_)),
    dplyr::across(c(COST_BY_USAGE, COST_IF_CONFIRMED), function(cost) ifelse(COUNTED, cost, NA_real_))
  )
}

# The duties a user does not open whose objects need a license he would no longer have:
# proven (KIND SAVES), or only after review (KIND REVIEW, not already proven).
.cleanup_drivers <- function(user_masks, users, needed) {
  candidates <- users |>
    dplyr::filter(CLASS %in% c(.CLEANUP_SAVES, .CLEANUP_REVIEW)) |>
    dplyr::select(USER_KEY, CLASS, SAVING_IF_CONFIRMED, USAGE_BITS, CONFIRMED_BITS)
  rows <- user_masks |>
    dplyr::filter(!OPENED) |>
    dplyr::inner_join(candidates, by = "USER_KEY") |>
    dplyr::filter(needed(MASK)) |>
    dplyr::mutate(
      PROVEN       = CLASS == .CLEANUP_SAVES & !KEEP_USAGE & bitwAnd(MASK, USAGE_BITS) == 0L,
      AFTER_REVIEW = SAVING_IF_CONFIRMED > .CENT & bitwAnd(MASK, CONFIRMED_BITS) == 0L
    )
  proven <- dplyr::mutate(rows[rows$PROVEN, ], KIND = .CLEANUP_SAVES)
  review <- rows[rows$AFTER_REVIEW, ] |>
    dplyr::anti_join(proven, by = c("USER_KEY", "ROLE", "UNIT")) |>
    dplyr::mutate(KIND = .CLEANUP_REVIEW)
  dplyr::distinct(dplyr::bind_rows(proven, review), USER_KEY, ROLE, UNIT, UNIT_ID, UNIT_NAME, KIND, LICENSE)
}

# One row per user, role and kind of change. A role the user opened nothing of, and whose
# duties can all be measured, goes; otherwise a variant without the duties.
.cleanup_actions <- function(need) {
  state <- need$user_units |>
    dplyr::group_by(USER_KEY, ROLE) |>
    dplyr::summarise(ROLE_OPENED = any(OPENED), ROLE_UNMEASURABLE = any(!MEASURABLE), .groups = "drop")
  savings <- dplyr::select(need$users, USER_KEY, USERID, USER_SAVING = SAVING, USER_REVIEW = SAVING_IF_CONFIRMED)

  need$drivers |>
    dplyr::group_by(USER_KEY, ROLE, KIND) |>
    dplyr::summarise(DUTIES = .sorted_list(UNIT_NAME), LICENSES = .sorted_list(LICENSE), .groups = "drop") |>
    dplyr::left_join(state, by = c("USER_KEY", "ROLE")) |>
    dplyr::left_join(savings, by = "USER_KEY") |>
    dplyr::mutate(
      ACTION = dplyr::case_when(
        KIND == .CLEANUP_REVIEW              ~ "REVIEW",
        !ROLE_OPENED & !ROLE_UNMEASURABLE    ~ "REMOVE_ROLE",
        TRUE                                 ~ "VARIANT"
      ),
      WAVE   = dplyr::if_else(KIND == .CLEANUP_REVIEW, 3L, 1L),
      SAVING = dplyr::if_else(KIND == .CLEANUP_REVIEW, USER_REVIEW, USER_SAVING)
    ) |>
    dplyr::arrange(WAVE, dplyr::desc(SAVING), USERID, ROLE)
}

# The roles of wave 1 in the order that completes the most savings at each step: a user
# saves only when all his roles have changed. When no role completes a saving, the role
# with the most pending savings comes next.
.cleanup_order <- function(proven) {
  per_user <- split(proven$ROLE, proven$USER_KEY)
  first    <- proven[!duplicated(proven$USER_KEY), ]
  saving   <- stats::setNames(first$SAVING, first$USER_KEY)[names(per_user)]
  roles    <- sort(unique(proven$ROLE), method = "radix")
  selected <- character()
  gains    <- numeric()
  while (length(roles) > 0L) {
    open  <- !vapply(per_user, function(needed) all(needed %in% selected), logical(1))
    gain  <- vapply(roles, function(role) {
      sum(saving[open & vapply(per_user, function(needed) all(needed %in% c(selected, role)), logical(1))])
    }, numeric(1))
    share <- vapply(roles, function(role) sum(saving[open & vapply(per_user, `%in%`, logical(1), x = role)]), numeric(1))
    next_role <- order(-gain, -share, roles, method = "radix")[[1]]
    selected  <- c(selected, roles[[next_role]])
    gains     <- c(gains, gain[[next_role]])
    roles     <- roles[-next_role]
  }
  tibble::tibble(ROLE = selected, STEP = seq_along(selected), GAIN = round(gains, 2),
                 SAVING_CUMULATIVE = round(cumsum(gains), 2))
}

.cleanup_plan <- function(actions, need) {
  proven <- actions[actions$WAVE == 1L, ]
  review <- actions[actions$WAVE == 3L, ]
  order  <- .cleanup_order(proven)
  later  <- review[!review$ROLE %in% order$ROLE, ] |>
    dplyr::group_by(ROLE) |>
    dplyr::summarise(SAVING = sum(SAVING), .groups = "drop") |>
    dplyr::arrange(dplyr::desc(SAVING), ROLE)
  duties <- function(kind, column) {
    need$drivers[need$drivers$KIND == kind, ] |>
      dplyr::group_by(ROLE) |>
      dplyr::summarise(!!column := .sorted_list(UNIT_NAME), .groups = "drop")
  }

  tibble::tibble(ROLE = c(order$ROLE, later$ROLE)) |>
    dplyr::left_join(order, by = "ROLE") |>
    dplyr::left_join(dplyr::count(need$user_roles, ROLE, name = "USERS"), by = "ROLE") |>
    dplyr::left_join(proven |>
                       dplyr::group_by(ROLE) |>
                       dplyr::summarise(USERS_TO_CHANGE = dplyr::n_distinct(USER_KEY),
                                        REMOVE_ROLE = sum(ACTION == "REMOVE_ROLE"), VARIANT = sum(ACTION == "VARIANT"),
                                        .groups = "drop"), by = "ROLE") |>
    dplyr::left_join(duties(.CLEANUP_SAVES, "DUTIES"), by = "ROLE") |>
    dplyr::left_join(review |>
                       dplyr::group_by(ROLE) |>
                       dplyr::summarise(USERS_REVIEW = dplyr::n_distinct(USER_KEY), SAVING_REVIEW = round(sum(SAVING), 2),
                                        .groups = "drop"), by = "ROLE") |>
    dplyr::left_join(duties(.CLEANUP_REVIEW, "REVIEW_DUTIES"), by = "ROLE") |>
    dplyr::mutate(
      WAVE = dplyr::if_else(is.na(STEP), 3L, 1L),
      GAIN = dplyr::coalesce(GAIN, 0),
      dplyr::across(c(USERS, USERS_TO_CHANGE, REMOVE_ROLE, VARIANT, USERS_REVIEW), function(n) dplyr::coalesce(n, 0L)),
      dplyr::across(c(DUTIES, REVIEW_DUTIES), function(text) dplyr::coalesce(text, "")),
      SAVING_REVIEW = dplyr::coalesce(SAVING_REVIEW, 0)
    ) |>
    dplyr::select(WAVE, STEP, ROLE, USERS, USERS_TO_CHANGE, REMOVE_ROLE, VARIANT, DUTIES, GAIN, SAVING_CUMULATIVE,
                  USERS_REVIEW, REVIEW_DUTIES, SAVING_REVIEW)
}

.cleanup_duties <- function(need) {
  counts <- need$drivers |>
    dplyr::group_by(ROLE, UNIT) |>
    dplyr::summarise(LICENSE = .sorted_list(LICENSE),
                     USERS_TO_DROP = dplyr::n_distinct(USER_KEY[KIND == .CLEANUP_SAVES]),
                     USERS_REVIEW = dplyr::n_distinct(USER_KEY[KIND == .CLEANUP_REVIEW]), .groups = "drop")
  need$user_units |>
    dplyr::semi_join(counts, by = c("ROLE", "UNIT")) |>
    dplyr::group_by(ROLE, UNIT) |>
    dplyr::summarise(DUTY = dplyr::first(UNIT_ID), DUTY_NAME = dplyr::first(UNIT_NAME), MEASURABLE = any(MEASURABLE),
                     USERS_WITH_ROLE = dplyr::n_distinct(USER_KEY), USERS_OPENED = dplyr::n_distinct(USER_KEY[OPENED]),
                     .groups = "drop") |>
    dplyr::inner_join(counts, by = c("ROLE", "UNIT")) |>
    dplyr::arrange(ROLE, dplyr::desc(USERS_TO_DROP), dplyr::desc(USERS_REVIEW), DUTY) |>
    dplyr::select(ROLE, DUTY, DUTY_NAME, LICENSE, MEASURABLE, USERS_WITH_ROLE, USERS_OPENED, USERS_TO_DROP, USERS_REVIEW)
}

# The objects for which the graph wants more than the licenses PPAC bills, per role and
# license of the graph, with that billing: there PPAC decided.
.CLEANUP_EXAMPLES <- 5L

.cleanup_differences <- function(need) {
  need$user_masks |>
    dplyr::filter(ABOVE_PPAC) |>
    dplyr::distinct(USER_KEY, ROLE, UNIT, GRAPH_MASK, LICENSE) |>
    dplyr::inner_join(dplyr::distinct(need$units, ROLE, UNIT, GRAPH_MASK = MASK, LICENSE, OBJECT),
                      by = c("ROLE", "UNIT", "GRAPH_MASK", "LICENSE"), relationship = "many-to-many") |>
    dplyr::left_join(dplyr::select(need$users, USER_KEY, BILLED_NOW), by = "USER_KEY") |>
    dplyr::group_by(ROLE, LICENSE) |>
    dplyr::summarise(BILLED_NOW = .sorted_list(BILLED_NOW), USERS = dplyr::n_distinct(USER_KEY),
                     OBJECTS = dplyr::n_distinct(OBJECT),
                     EXAMPLES = paste(utils::head(sort(unique(OBJECT), method = "radix"), .CLEANUP_EXAMPLES),
                                      collapse = .LIST_SEPARATOR),
                     .groups = "drop") |>
    dplyr::arrange(dplyr::desc(USERS), ROLE, LICENSE)
}

.cleanup_users <- function(users) {
  users |>
    dplyr::arrange(dplyr::desc(dplyr::coalesce(SAVING, -Inf)), dplyr::desc(dplyr::coalesce(SAVING_IF_CONFIRMED, -Inf)),
                   USERID) |>
    dplyr::select(USERID, ROLES, BILLED_NOW, COST_NOW, BILLED_GRAPH, COST_GRAPH, BILLED_BY_USAGE, COST_BY_USAGE, SAVING,
                  BILLED_IF_CONFIRMED, COST_IF_CONFIRMED, SAVING_IF_CONFIRMED, CLASS, ENTRY_POINTS, LAST_SEEN)
}

.cleanup_check <- function(need, source, estimated) {
  users <- need$users
  list(
    CREATED = Sys.Date(), SOURCE = source, GRAPH_ROWS = need$graph_rows, GRAPH_ROLES = need$graph_roles,
    GRAPH_ROWS_WITHOUT_ROLE = need$rows_without_role, TELEMETRY_FROM = need$from, TELEMETRY_TO = need$to,
    USERS = nrow(users), USERS_WITH_TELEMETRY = sum(users$HAS_TELEMETRY),
    USERS_WITHOUT_TELEMETRY = sum(!users$HAS_TELEMETRY), USERS_WITHOUT_LICENSED_USE = sum(users$CLASS == .CLEANUP_NO_USE),
    TELEMETRY_USERS_NOT_IN_LICENSES = need$telemetry_only,
    USERS_GRAPH_DIFFERS = sum(users$GRAPH_DIFFERS), ROLES_NOT_IN_GRAPH = need$roles_missing,
    COST_NOW = round(sum(users$COST_NOW), 2), SAVING = round(sum(users$SAVING, na.rm = TRUE), 2),
    SAVING_IF_CONFIRMED = round(sum(users$SAVING_IF_CONFIRMED, na.rm = TRUE), 2),
    COST_WITHOUT_TELEMETRY = round(sum(users$COST_NOW[!users$HAS_TELEMETRY]), 2),
    COST_WITHOUT_USE = round(sum(users$COST_NOW[users$CLASS %in% c(.CLEANUP_NO_TELEMETRY, .CLEANUP_NO_USE)]), 2),
    PRICES_ESTIMATED = estimated
  )
}

.cleanup_message <- function(result) {
  check <- result$Check
  sprintf(paste("Cleanup plan over %d users: %.2f per month proven by the telemetry of %s to %s, %.2f more after review.",
                "%d users without telemetry or licensed use (%.2f per month) to check; %d whose license graph differs",
                "from the licenses."),
          check$USERS, check$SAVING, format(check$TELEMETRY_FROM), format(check$TELEMETRY_TO), check$SAVING_IF_CONFIRMED,
          check$USERS_WITHOUT_TELEMETRY + check$USERS_WITHOUT_LICENSED_USE, check$COST_WITHOUT_USE,
          check$USERS_GRAPH_DIFFERS)
}

# Sorted by character codes, so that every machine lists the same: "System user" before
# "_WIBU Lager". That sort needs UTF-8; files read in the native encoding are converted.
.sorted_list <- function(values) {
  values <- enc2utf8(as.character(values[!is.na(values)]))
  paste(sort(unique(values), method = "radix"), collapse = .LIST_SEPARATOR)
}
