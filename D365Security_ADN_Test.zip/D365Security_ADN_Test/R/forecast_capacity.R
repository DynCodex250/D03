#' Read one state of the capacity forecast
#'
#' Reads the input workbook of one state of the database capacity forecast
#' (deliverable D17). There is one workbook per state, for example
#' \code{Data/Input/PPAC/Capacity_2026-10-20.xlsx}, with the numbers of
#' the Power Platform admin center on that day and the assumptions of the
#' forecast.
#'
#' @details
#'
#' **Sheet \code{Stand}.** Columns \code{Feld}, \code{Wert} and
#' \code{Bemerkung}, one row per field; every field below needs a value:
#' \code{Stichtag}, \code{Kontingent (GB)}, \code{Belegt (GB)}, \code{Go-Live},
#' \code{Löschung PRJ und Migrationssandbox}, \code{Migrationssandbox ab},
#' \code{Maßnahmen wirken ab}, \code{Prognose bis},
#' \code{Wachstum Prod vor dem Go-Live (GB je Woche)},
#' \code{Wachstum Prod nach dem Go-Live (GB je Woche)},
#' \code{Option: Anteil am Kontingent}, \code{Option: Tage je Fenster},
#' \code{Option: Fenster je Kalenderjahr}, \code{Option läuft bis},
#' \code{Neue Lizenzen ab Go-Live (GB)}, \code{Weniger mit Team Member (GB)},
#' \code{Zukauf (€ je GB und Monat)}. Dates as Excel dates, as
#' \code{2026-10-20} or as \code{20.10.2026}; numbers with a point or a comma.
#'
#' **Sheet \code{Umgebungen}.** Columns \code{Umgebung}, \code{GB},
#' \code{Datenstand} (optional). The rows \code{Prod}, \code{INT}, \code{TST}
#' and \code{PRJ} are needed. Once the migration sandbox exists, a row
#' \code{Migrationssandbox} gives its size; until then its size is the size of
#' Prod on the day it is made.
#'
#' @param path
#' Path of the input workbook.
#'
#' @return
#' A list: \code{Facts}, the fields by name (\code{STATUS_DATE},
#' \code{QUOTA_GB}, \code{USED_GB}, \code{GO_LIVE}, \code{DELETION},
#' \code{MIGRATION_START}, \code{MEASURES_FROM}, \code{FORECAST_END},
#' \code{GROWTH_BEFORE}, \code{GROWTH_AFTER}, \code{OPTION_SHARE},
#' \code{OPTION_DAYS}, \code{OPTION_PER_YEAR}, \code{OPTION_UNTIL},
#' \code{NEW_LICENSE_GB}, \code{TEAM_MEMBER_LESS_GB}, \code{PRICE_GB}), and
#' \code{Environments}, a tibble with \code{ENVIRONMENT}, \code{GB},
#' \code{NOTE}.
#'
#' @examples
#' \dontrun{
#'
#' status <- read_capacity_status("Data/Input/PPAC/Capacity_2026-10-20.xlsx")
#' status$Facts$QUOTA_GB
#'
#' }
#'
#' @seealso
#' \code{\link{forecast_capacity}}
#' \code{\link{export_capacity_forecast}}
#'
#' @export
read_capacity_status <- function(path) {

  if (!.is_single_string(path) || !file.exists(path)) {
    stop("The input workbook '", paste(path, collapse = ", "), "' was not found.", call. = FALSE)
  }
  missing_sheets <- setdiff(c("Stand", "Umgebungen"), readxl::excel_sheets(path))
  if (length(missing_sheets) > 0L) {
    stop("'", path, "' lacks the sheet(s) ", paste(missing_sheets, collapse = .LIST_SEPARATOR), ".", call. = FALSE)
  }
  facts        <- .read_capacity_facts(path)
  environments <- .read_capacity_environments(path)
  .check_capacity_values(facts, environments, path)
  list(Facts = facts, Environments = environments)
}

# A share above this is a percentage typed by mistake: 0.67 is plus two thirds, 1 a doubling.
.CAPACITY_MAX_OPTION_SHARE <- 2
# An Excel serial number before this day is a plain number, not a date.
.CAPACITY_EARLIEST_DATE    <- as.Date("2000-01-01")
# The first day of the forecast may differ from the reported usage by rounding only.
.CAPACITY_START_TOLERANCE_GB <- 0.5

.CAPACITY_DATE_FIELDS <- c(
  STATUS_DATE = "Stichtag", GO_LIVE = "Go-Live", DELETION = "Löschung PRJ und Migrationssandbox",
  MIGRATION_START = "Migrationssandbox ab", MEASURES_FROM = "Maßnahmen wirken ab", FORECAST_END = "Prognose bis",
  OPTION_UNTIL = "Option läuft bis"
)

.CAPACITY_NUMBER_FIELDS <- c(
  QUOTA_GB = "Kontingent (GB)", USED_GB = "Belegt (GB)",
  GROWTH_BEFORE = "Wachstum Prod vor dem Go-Live (GB je Woche)", GROWTH_AFTER = "Wachstum Prod nach dem Go-Live (GB je Woche)",
  OPTION_SHARE = "Option: Anteil am Kontingent", OPTION_DAYS = "Option: Tage je Fenster",
  OPTION_PER_YEAR = "Option: Fenster je Kalenderjahr", NEW_LICENSE_GB = "Neue Lizenzen ab Go-Live (GB)",
  TEAM_MEMBER_LESS_GB = "Weniger mit Team Member (GB)", PRICE_GB = "Zukauf (€ je GB und Monat)"
)

.CAPACITY_ENVIRONMENTS <- c("Prod", "INT", "TST", "PRJ")
.CAPACITY_MIGRATION    <- "Migrationssandbox"
.CAPACITY_UNASSIGNED   <- "Nicht zugeordnet"

.read_capacity_facts <- function(path) {
  sheet <- readxl::read_excel(path, sheet = "Stand", col_types = "text")
  if (!all(c("Feld", "Wert") %in% names(sheet))) {
    stop("The sheet Stand of '", path, "' needs the columns Feld and Wert.", call. = FALSE)
  }
  value_of <- function(label) {
    value <- trimws(sheet$Wert[match(label, trimws(sheet$Feld))])
    if (is.na(value) || !nzchar(value)) {
      stop("The sheet Stand of '", path, "' has no value for '", label, "'.", call. = FALSE)
    }
    value
  }
  dates   <- lapply(.CAPACITY_DATE_FIELDS, function(label) .capacity_date(value_of(label), label))
  numbers <- lapply(.CAPACITY_NUMBER_FIELDS, function(label) .capacity_number(value_of(label), label))
  c(dates, numbers)
}

.read_capacity_environments <- function(path) {
  sheet <- readxl::read_excel(path, sheet = "Umgebungen", col_types = "text")
  if (!all(c("Umgebung", "GB") %in% names(sheet))) {
    stop("The sheet Umgebungen of '", path, "' needs the columns Umgebung and GB.", call. = FALSE)
  }
  sheet <- sheet[!is.na(sheet$Umgebung) & nzchar(trimws(sheet$Umgebung)), ]
  names_found  <- trimws(sheet$Umgebung)
  missing_rows <- setdiff(.CAPACITY_ENVIRONMENTS, names_found)
  if (length(missing_rows) > 0L) {
    stop("The sheet Umgebungen of '", path, "' lacks the row(s) ", paste(missing_rows, collapse = .LIST_SEPARATOR), ".",
         call. = FALSE)
  }
  notes <- if ("Datenstand" %in% names(sheet)) dplyr::coalesce(sheet$Datenstand, "") else rep("", nrow(sheet))
  tibble::tibble(ENVIRONMENT = names_found, GB = vapply(seq_along(names_found), function(i) {
    .capacity_number(sheet$GB[[i]], paste("GB von", names_found[[i]]))
  }, numeric(1)), NOTE = notes)
}

# A date as Excel, a person or a program writes it: serial number, 20.10.2026 or 2026-10-20.
.capacity_date <- function(value, label) {
  force(value)
  date <- tryCatch({
    if (grepl("^[0-9]+([.][0-9]+)?$", value)) {
      as.Date(floor(as.numeric(value)), origin = "1899-12-30")
    } else if (grepl("^[0-9]{1,2}[.][0-9]{1,2}[.][0-9]{4}$", value)) {
      as.Date(value, format = "%d.%m.%Y")
    } else {
      as.Date(substr(value, 1L, 10L), format = "%Y-%m-%d")
    }
  }, error = function(e) as.Date(NA))
  if (is.na(date) || date < .CAPACITY_EARLIEST_DATE) stop("'", label, "' is no date: '", value, "'.", call. = FALSE)
  date
}

.capacity_number <- function(value, label) {
  number <- suppressWarnings(as.numeric(sub(",", ".", trimws(value), fixed = TRUE)))
  if (length(number) != 1L || is.na(number)) stop("'", label, "' is no number: '", value, "'.", call. = FALSE)
  number
}

.check_capacity_values <- function(facts, environments, path) {
  stopping <- function(...) stop("'", path, "': ", ..., call. = FALSE)
  numbers  <- unlist(facts[names(.CAPACITY_NUMBER_FIELDS)])
  if (any(numbers < 0)) {
    stopping("these values may not be negative: ",
             paste(.CAPACITY_NUMBER_FIELDS[names(numbers)[numbers < 0]], collapse = .LIST_SEPARATOR), ".")
  }
  if (facts$OPTION_SHARE > .CAPACITY_MAX_OPTION_SHARE) {
    stopping("'Option: Anteil am Kontingent' is ", facts$OPTION_SHARE, "; give it as a share, 0.67 for two thirds.")
  }
  if (facts$OPTION_DAYS < 1) stopping("'Option: Tage je Fenster' must be at least 1.")
  if (any(c(facts$OPTION_DAYS, facts$OPTION_PER_YEAR) %% 1 != 0)) {
    stopping("'Option: Tage je Fenster' and 'Option: Fenster je Kalenderjahr' must be whole numbers.")
  }
  if (facts$DELETION <= facts$GO_LIVE) stopping("'Löschung PRJ und Migrationssandbox' must lie after the 'Go-Live'.")
  if (facts$FORECAST_END < facts$DELETION) stopping("'Prognose bis' must not lie before 'Löschung PRJ und Migrationssandbox'.")

  twice <- unique(environments$ENVIRONMENT[duplicated(environments$ENVIRONMENT)])
  if (length(twice) > 0L) {
    stopping("the sheet Umgebungen names an environment twice: ", paste(twice, collapse = .LIST_SEPARATOR), ".")
  }
  if (any(environments$GB < 0)) stopping("the sheet Umgebungen holds a negative size.")
  if (environments$GB[environments$ENVIRONMENT == "Prod"] <= 0) stopping("Prod needs a size above 0 GB.")
  if (sum(environments$GB) > facts$USED_GB) {
    stopping("the environments add up to ", sum(environments$GB), " GB, more than 'Belegt (GB)' with ", facts$USED_GB, " GB.")
  }
  invisible(NULL)
}

#' Forecast the database capacity from one state
#'
#' Computes the forecast of deliverable D17 day by day: what Prod and the
#' sandboxes will take, what the quota allows, and what follows in three
#' scenarios for the project environment PRJ and the migration sandbox.
#'
#' @details
#'
#' **Consumption.** Prod grows by \code{GROWTH_BEFORE} GB a week until the
#' go-live and by \code{GROWTH_AFTER} GB after it. INT and TST keep their
#' share of Prod (a simplification: in fact they jump at a refresh). PRJ and
#' the migration sandbox stay at their size until \code{DELETION}. What no
#' environment explains (\code{USED_GB} minus their sum) stays the same.
#'
#' **Scenarios.** They differ from \code{MEASURES_FROM} on. S1: PRJ and the
#' migration sandbox as full copies of Prod. S2: both cleaned up like INT, at
#' the share of INT. S3: as S2, the migration sandbox without transactions,
#' at the share of TST. When \code{MEASURES_FROM} is not after the state, the
#' reported sizes hold the measures already, and the three scenarios are equal.
#'
#' **Quota.** \code{QUOTA_GB} plus \code{NEW_LICENSE_GB} from the go-live on.
#' The option adds \code{OPTION_SHARE} of \code{QUOTA_GB} until
#' \code{OPTION_UNTIL} and in the windows of the year of the go-live, which lie
#' gaplessly backwards from the day before the go-live.
#'
#' @param status
#' Result of \code{\link{read_capacity_status}}.
#'
#' @return
#' A list:
#' \describe{
#'   \item{\code{Facts}}{The fields of the state.}
#'   \item{\code{Sizes}}{\code{int_share} and \code{tst_share} (of Prod),
#'     \code{prj_gb}, \code{migration_gb}, \code{unassigned}.}
#'   \item{\code{Environments}}{\code{ENVIRONMENT}, \code{GB}, \code{NOTE},
#'     with a last row for what no environment explains.}
#'   \item{\code{Days}}{One row per day: \code{DATE}, \code{PROD}, \code{S1},
#'     \code{S2}, \code{S3}, \code{QUOTA}, \code{QUOTA_TEAM_MEMBER},
#'     \code{QUOTA_OPTION}.}
#'   \item{\code{Windows}}{The windows of the option still to come:
#'     \code{WINDOW}, \code{FROM}, \code{TO}.}
#'   \item{\code{Milestones}}{\code{DATE}, \code{EVENT}, \code{S1}, \code{S2},
#'     \code{S3}, \code{QUOTA}, \code{QUOTA_OPTION}.}
#'   \item{\code{Figures}}{One row per scenario: \code{ID},
#'     \code{MISSING_BEFORE_GO_LIVE} (GB over the quota without the option on
#'     the day before the go-live), \code{DAYS_UNCOVERED} (days before the
#'     go-live above the quota with the option), \code{GAP_MAX},
#'     \code{PURCHASE_MONTH}, \code{RESERVE_GO_LIVE},
#'     \code{RESERVE_AFTER_DELETION}, \code{EXHAUSTED_ACTIVITY},
#'     \code{MISSING_TEAM_MEMBER}, \code{EXHAUSTED_TEAM_MEMBER}. A date that
#'     lies before the state gives \code{NA}.}
#' }
#'
#' @examples
#' \dontrun{
#'
#' forecast <- forecast_capacity(read_capacity_status("Data/Input/PPAC/Capacity_2026-10-20.xlsx"))
#' forecast$Figures
#'
#' }
#'
#' @seealso
#' \code{\link{read_capacity_status}}
#' \code{\link{capacity_tables}}
#' \code{\link{export_capacity_forecast}}
#'
#' @export
forecast_capacity <- function(status) {

  if (!is.list(status) || is.null(status$Facts$STATUS_DATE) || !is.data.frame(status$Environments)) {
    stop("status must be the result of read_capacity_status().", call. = FALSE)
  }
  facts <- status$Facts
  if (facts$FORECAST_END <= facts$STATUS_DATE) {
    stop("'Prognose bis' must lie after the 'Stichtag'.", call. = FALSE)
  }
  days    <- seq(facts$STATUS_DATE, facts$FORECAST_END, by = "day")
  prod    <- .capacity_prod(days, facts, .capacity_size(status, "Prod"))
  windows <- .capacity_windows(facts)
  sizes   <- .capacity_sizes(status, days, prod)
  series  <- tibble::tibble(DATE = days, PROD = prod, !!!.capacity_consumption(days, prod, facts, sizes),
                            !!!.capacity_quotas(days, facts, windows))
  .check_capacity_start(series, facts)
  list(
    Facts        = facts,
    Sizes        = sizes,
    Environments = .capacity_environment_table(status, sizes),
    Days         = series,
    Windows      = windows,
    Milestones   = .capacity_milestones(series, facts),
    Figures      = .capacity_figures(series, facts)
  )
}

# The day of the state must give what the state reports, else every later day is off by the same amount.
.check_capacity_start <- function(series, facts) {
  start <- series$S1[[1]]
  if (abs(start - facts$USED_GB) < .CAPACITY_START_TOLERANCE_GB) return(invisible(NULL))
  stop(sprintf(paste0(
    "The forecast starts at %.0f GB, but 'Belegt (GB)' says %.0f GB. Check the sheet Umgebungen against the dates: ",
    "a row Migrationssandbox is needed from 'Migrationssandbox ab' on, and it must not stand there before; ",
    "PRJ has 0 GB from 'Löschung PRJ und Migrationssandbox' on."), start, facts$USED_GB), call. = FALSE)
}

.capacity_size <- function(status, environment) {
  sum(status$Environments$GB[status$Environments$ENVIRONMENT == environment])
}

.capacity_prod <- function(days, facts, prod_gb) {
  weeks_before <- pmax(as.numeric(pmin(days, facts$GO_LIVE) - facts$STATUS_DATE), 0) / 7
  weeks_after  <- as.numeric(pmax(days, facts$GO_LIVE) - max(facts$GO_LIVE, facts$STATUS_DATE)) / 7
  prod_gb + facts$GROWTH_BEFORE * weeks_before + facts$GROWTH_AFTER * weeks_after
}

.capacity_sizes <- function(status, days, prod) {
  prod_gb  <- .capacity_size(status, "Prod")
  reported <- any(status$Environments$ENVIRONMENT == .CAPACITY_MIGRATION)
  made_on  <- max(status$Facts$MIGRATION_START, status$Facts$STATUS_DATE)
  list(
    int_share    = .capacity_size(status, "INT") / prod_gb,
    tst_share    = .capacity_size(status, "TST") / prod_gb,
    prj_gb       = .capacity_size(status, "PRJ"),
    migration_gb = if (reported) .capacity_size(status, .CAPACITY_MIGRATION) else dplyr::coalesce(prod[match(made_on, days)], 0),
    unassigned   = status$Facts$USED_GB - sum(status$Environments$GB)
  )
}

.capacity_measures_ahead <- function(facts) facts$MEASURES_FROM > facts$STATUS_DATE

.capacity_scenarios <- function(sizes) {
  tibble::tibble(
    ID = c("S1", "S2", "S3"),
    FACTOR_PRJ = c(1, sizes$int_share, sizes$int_share),
    FACTOR_MIGRATION = c(1, sizes$int_share, sizes$tst_share)
  )
}

.capacity_consumption <- function(days, prod, facts, sizes) {
  prj_there       <- days < facts$DELETION
  migration_there <- days >= facts$MIGRATION_START & days < facts$DELETION
  # Measures of the past are in the reported sizes already and must not count twice.
  measures        <- days >= facts$MEASURES_FROM & .capacity_measures_ahead(facts)
  scenarios       <- .capacity_scenarios(sizes)
  consumption <- lapply(seq_len(nrow(scenarios)), function(i) {
    prod * (1 + sizes$int_share + sizes$tst_share) +
      prj_there * sizes$prj_gb * ifelse(measures, scenarios$FACTOR_PRJ[[i]], 1) +
      migration_there * sizes$migration_gb * ifelse(measures, scenarios$FACTOR_MIGRATION[[i]], 1) +
      sizes$unassigned
  })
  stats::setNames(consumption, scenarios$ID)
}

# The windows lie gaplessly backwards from the day before the go-live, within its calendar year.
.capacity_windows <- function(facts) {
  year_start <- as.Date(paste0(format(facts$GO_LIVE, "%Y"), "-01-01"))
  starts     <- facts$GO_LIVE - facts$OPTION_DAYS * rev(seq_len(facts$OPTION_PER_YEAR))
  windows    <- tibble::tibble(FROM = pmax(starts, year_start), TO = starts + facts$OPTION_DAYS - 1)
  windows    <- windows[windows$TO >= max(year_start, facts$STATUS_DATE), ]
  tibble::tibble(WINDOW = seq_len(nrow(windows)), FROM = windows$FROM, TO = windows$TO)
}

.capacity_quotas <- function(days, facts, windows) {
  after_go_live <- days >= facts$GO_LIVE
  quota         <- facts$QUOTA_GB + after_go_live * facts$NEW_LICENSE_GB
  option_on     <- days <= facts$OPTION_UNTIL
  for (i in seq_len(nrow(windows))) option_on <- option_on | (days >= windows$FROM[[i]] & days <= windows$TO[[i]])
  list(
    QUOTA             = quota,
    QUOTA_TEAM_MEMBER = quota - after_go_live * facts$TEAM_MEMBER_LESS_GB,
    QUOTA_OPTION      = quota + option_on * facts$QUOTA_GB * facts$OPTION_SHARE
  )
}

.capacity_environment_table <- function(status, sizes) {
  dplyr::bind_rows(
    status$Environments,
    tibble::tibble(ENVIRONMENT = .CAPACITY_UNASSIGNED, GB = sizes$unassigned,
                   NOTE = "Differenz zwischen gemeldeter Belegung und Summe der Umgebungen")
  )
}

.capacity_milestones <- function(series, facts) {
  year  <- format(facts$GO_LIVE, "%Y")
  marks <- tibble::tibble(
    DATE = c(facts$STATUS_DATE, facts$MIGRATION_START, as.Date(paste0(year, "-01-01")), facts$GO_LIVE - 1, facts$GO_LIVE,
             facts$DELETION, as.Date(paste0(year, "-12-31"))),
    EVENT = c("Stichtag", "Migrationssandbox bereitgestellt", "Jahreswechsel", "Tag vor dem Go-Live", "Go-Live, neue Lizenzen",
              "PRJ und Migrationssandbox gelöscht", paste("Jahresende", year))
  )
  marks <- marks[marks$DATE %in% series$DATE, ]
  marks <- marks[order(marks$DATE), ]
  rows  <- match(marks$DATE, series$DATE)
  dplyr::bind_cols(marks, series[rows, c("S1", "S2", "S3", "QUOTA", "QUOTA_OPTION")])
}

.capacity_figures <- function(series, facts) {
  days           <- series$DATE
  after_go_live  <- days >= facts$GO_LIVE
  until_deletion <- after_go_live & days < facts$DELETION
  after_deletion <- days >= facts$DELETION
  at    <- function(values, date) values[match(date, days)]
  first <- function(condition) if (any(condition)) min(days[condition]) else as.Date(NA)
  rows  <- lapply(c("S1", "S2", "S3"), function(id) {
    used      <- series[[id]]
    uncovered <- !after_go_live & used > series$QUOTA_OPTION
    gap_max   <- if (any(uncovered)) max((used - series$QUOTA_OPTION)[uncovered]) else 0
    tibble::tibble(
      ID = id, MISSING_BEFORE_GO_LIVE = at(used - facts$QUOTA_GB, facts$GO_LIVE - 1), DAYS_UNCOVERED = sum(uncovered),
      GAP_MAX = gap_max, PURCHASE_MONTH = gap_max * facts$PRICE_GB, RESERVE_GO_LIVE = at(series$QUOTA - used, facts$GO_LIVE),
      RESERVE_AFTER_DELETION = at(series$QUOTA - used, facts$DELETION),
      EXHAUSTED_ACTIVITY = first(after_deletion & used > series$QUOTA),
      MISSING_TEAM_MEMBER = max(0, (used - series$QUOTA_TEAM_MEMBER)[until_deletion]),
      EXHAUSTED_TEAM_MEMBER = first(after_deletion & used > series$QUOTA_TEAM_MEMBER)
    )
  })
  dplyr::bind_rows(rows)
}

#' The tables of a capacity forecast in German
#'
#' Prepares the result of \code{\link{forecast_capacity}} for the deliverable
#' D17: the same tables go to the workbook and to the Word summary.
#'
#' @param forecast
#' Result of \code{\link{forecast_capacity}}.
#'
#' @return
#' A list of data frames with German headers: \code{Figures} (\code{Kennzahl},
#' \code{S1}, \code{S2}, \code{S3}, as text), \code{Milestones} (\code{Datum},
#' \code{Ereignis}, the scenarios, \code{Kontingent}, \code{Mit Option}),
#' \code{Environments} (\code{Umgebung}, \code{GB}, \code{Datenstand}),
#' \code{Assumptions} (\code{Annahme}, \code{Wert}) and \code{Windows}
#' (\code{Fenster}, \code{Beginn}, \code{Ende}; the first row is the option
#' that runs on the day of the state).
#'
#' @seealso
#' \code{\link{forecast_capacity}}
#' \code{\link{export_capacity_forecast}}
#'
#' @export
capacity_tables <- function(forecast) {
  .check_capacity_forecast(forecast)
  list(
    Figures      = .capacity_figure_table(forecast),
    Milestones   = .capacity_milestone_table(forecast),
    Environments = data.frame("Umgebung" = forecast$Environments$ENVIRONMENT, "GB" = round(forecast$Environments$GB),
                              "Datenstand" = forecast$Environments$NOTE, check.names = FALSE, stringsAsFactors = FALSE),
    Assumptions  = .capacity_assumption_table(forecast),
    Windows      = .capacity_window_table(forecast)
  )
}

.check_capacity_forecast <- function(forecast) {
  if (!is.list(forecast) || !all(c("Facts", "Days", "Figures", "Windows", "Milestones", "Environments") %in% names(forecast))) {
    stop("forecast must be the result of forecast_capacity().", call. = FALSE)
  }
  invisible(forecast)
}

.capacity_german_number <- function(x) {
  ifelse(is.na(x), "–", formatC(x, format = "f", digits = 0, big.mark = ".", decimal.mark = ","))
}

.capacity_german_date <- function(x) format(x, "%d.%m.%Y")

.capacity_figure_table <- function(forecast) {
  end    <- paste("nach", format(forecast$Facts$FORECAST_END, "%Y"))
  month  <- function(x) ifelse(is.na(x), end, format(x, "%m/%Y"))
  number <- .capacity_german_number
  values <- lapply(seq_len(nrow(forecast$Figures)), function(i) {
    f <- forecast$Figures[i, ]
    c(number(f$MISSING_BEFORE_GO_LIVE), number(f$DAYS_UNCOVERED), number(f$GAP_MAX), number(f$PURCHASE_MONTH),
      number(f$RESERVE_GO_LIVE), number(f$RESERVE_AFTER_DELETION), month(f$EXHAUSTED_ACTIVITY),
      number(f$MISSING_TEAM_MEMBER), month(f$EXHAUSTED_TEAM_MEMBER))
  })
  data.frame(
    "Kennzahl" = c("Fehlmenge am Tag vor dem Go-Live ohne Option (GB)", "Tage bis zum Go-Live ohne Deckung trotz der Fenster",
                   "Höchste Fehlmenge an diesen Tagen (GB)", "Zukauf dafür für einen Monat (€)",
                   "Reserve am Go-Live mit neuen Lizenzen (GB)", "Reserve nach Löschung von PRJ und Migrationssandbox (GB)",
                   "Kontingent erschöpft ab (Techniker mit Activity)",
                   "Fehlmenge zwischen Go-Live und Löschung, Techniker mit Team Member (GB)",
                   "Kontingent erschöpft ab (Techniker mit Team Member)"),
    stats::setNames(values, forecast$Figures$ID), check.names = FALSE, stringsAsFactors = FALSE
  )
}

.capacity_milestone_table <- function(forecast) {
  m <- forecast$Milestones
  data.frame("Datum" = .capacity_german_date(m$DATE), "Ereignis" = m$EVENT, "S1" = round(m$S1), "S2" = round(m$S2),
             "S3" = round(m$S3), "Kontingent" = round(m$QUOTA), "Mit Option" = round(m$QUOTA_OPTION),
             check.names = FALSE, stringsAsFactors = FALSE)
}

.capacity_assumption_table <- function(forecast) {
  f      <- forecast$Facts
  gb     <- function(environment) forecast$Environments$GB[forecast$Environments$ENVIRONMENT == environment]
  date   <- .capacity_german_date
  number <- .capacity_german_number
  share  <- function(environment) paste0(number(100 * gb(environment) / gb("Prod")), " % von Prod")
  migration <- if (.CAPACITY_MIGRATION %in% forecast$Environments$ENVIRONMENT) paste0(number(gb(.CAPACITY_MIGRATION)), " GB") else
    paste0("Kopie von Prod ab ", date(f$MIGRATION_START))
  data.frame(
    "Annahme" = c("Stichtag", "Kontingent", "Belegt", "Go-Live", "Neue Lizenzen ab Go-Live", "Prod", "INT", "TST", "PRJ",
                  "Migrationssandbox", "Nicht zugeordnet", "Übergangsoption", "Maßnahmen in S2 und S3", "Zukauf", "Vereinfachung"),
    "Wert" = c(
      date(f$STATUS_DATE), paste(number(f$QUOTA_GB), "GB"), paste(number(f$USED_GB), "GB"), date(f$GO_LIVE),
      paste0("+", number(f$NEW_LICENSE_GB), " GB"),
      paste0(number(gb("Prod")), " GB; +", f$GROWTH_BEFORE, " GB je Woche bis zum Go-Live, danach +", f$GROWTH_AFTER, " GB je Woche"),
      share("INT"), share("TST"), paste0(number(gb("PRJ")), " GB, kein Refresh, gelöscht am ", date(f$DELETION)),
      paste0(migration, ", kein Refresh, gelöscht am ", date(f$DELETION)),
      paste0(number(gb(.CAPACITY_UNASSIGNED)), " GB, gleichbleibend"),
      paste0("+", number(f$QUOTA_GB * f$OPTION_SHARE), " GB für je ", f$OPTION_DAYS, " Tage, ", f$OPTION_PER_YEAR,
             "-mal je Kalenderjahr; läuft bis ", date(f$OPTION_UNTIL)),
      if (.capacity_measures_ahead(f)) paste0("wirken ab ", date(f$MEASURES_FROM)) else "in den Größen dieses Stands enthalten",
      paste(number(f$PRICE_GB), "€ je GB und Monat"),
      "Sandboxen folgen Prod laufend; in Wirklichkeit springen sie beim Refresh."
    ),
    check.names = FALSE, stringsAsFactors = FALSE
  )
}

.capacity_window_table <- function(forecast) {
  f       <- forecast$Facts
  windows <- forecast$Windows
  year    <- format(f$GO_LIVE, "%Y")
  running <- ifelse(windows$FROM < f$STATUS_DATE, " (läuft)", "")
  rows    <- data.frame("Fenster" = if (nrow(windows) > 0L) paste0(year, " / ", windows$WINDOW) else character(),
                        "Beginn" = paste0(.capacity_german_date(windows$FROM), running),
                        "Ende" = .capacity_german_date(windows$TO),
                        check.names = FALSE, stringsAsFactors = FALSE)
  if (f$OPTION_UNTIL < f$STATUS_DATE) return(rows)
  rbind(data.frame("Fenster" = format(f$OPTION_UNTIL, "%Y"), "Beginn" = "laufend", "Ende" = .capacity_german_date(f$OPTION_UNTIL),
                   check.names = FALSE, stringsAsFactors = FALSE), rows)
}

#' German sentences on a capacity forecast
#'
#' Gives the sentences of the Word summary of deliverable D17 that depend on
#' the figures, so that they hold for every state and not only for the first.
#'
#' @param forecast
#' Result of \code{\link{forecast_capacity}}.
#'
#' @return
#' A list of German text: \code{BEFORE_GO_LIVE}, \code{AT_GO_LIVE},
#' \code{AFTER_DELETION} and \code{WINDOWS}, one string each; \code{WAYS}, the
#' ways to close the gap until the go-live, one string per way and none without
#' a gap; \code{POSTPONED}, what a later go-live means, empty when a window is
#' left in that year or the go-live has passed.
#'
#' @examples
#' \dontrun{
#'
#' capacity_texts(forecast)$BEFORE_GO_LIVE
#'
#' }
#'
#' @seealso
#' \code{\link{forecast_capacity}}
#' \code{\link{capacity_tables}}
#'
#' @export
capacity_texts <- function(forecast) {
  .check_capacity_forecast(forecast)
  list(
    BEFORE_GO_LIVE = .capacity_text_before(forecast$Figures),
    AT_GO_LIVE     = .capacity_text_at_go_live(forecast$Facts, forecast$Figures),
    AFTER_DELETION = .capacity_text_after_deletion(forecast$Facts, forecast$Figures),
    WINDOWS        = .capacity_text_windows(forecast),
    WAYS           = .capacity_text_ways(forecast$Facts, forecast$Figures),
    POSTPONED      = .capacity_text_postponed(forecast$Facts)
  )
}

# "332 GB in S1, nichts in S2 und nichts in S3"
.capacity_shortages <- function(ids, amounts) {
  parts <- ifelse(amounts > 0, paste0(.capacity_german_number(amounts), " GB in ", ids), paste("nichts in", ids))
  paste0(paste(parts[-length(parts)], collapse = ", "), " und ", parts[[length(parts)]])
}

.capacity_text_before <- function(figures) {
  missing <- figures$MISSING_BEFORE_GO_LIVE
  if (is.na(missing[[1]])) return("Der Go-Live liegt vor diesem Stand.")
  if (all(missing <= 0)) return("Am Tag vor dem Go-Live reicht das Kontingent auch ohne die Option.")
  paste0("Ohne die Option liegt die Belegung am Tag vor dem Go-Live über dem Kontingent. Es fehlen ",
         .capacity_shortages(figures$ID, missing), ".")
}

.capacity_text_at_go_live <- function(facts, figures) {
  licenses <- paste0("Die neuen Lizenzen bringen ", .capacity_german_number(facts$NEW_LICENSE_GB), " GB.")
  reserve  <- figures$RESERVE_GO_LIVE
  if (is.na(reserve[[1]])) return(licenses)
  if (any(reserve < 0)) {
    return(paste0(licenses, " Am Go-Live reicht das nicht: Es fehlen ", .capacity_shortages(figures$ID, -reserve), "."))
  }
  paste0(licenses, " Die Reserve am Go-Live beträgt je nach Szenario ", .capacity_german_number(min(reserve)), " bis ",
         .capacity_german_number(max(reserve)), " GB.")
}

.capacity_text_after_deletion <- function(facts, figures) {
  reserve <- figures$RESERVE_AFTER_DELETION[[1]]
  if (is.na(reserve)) return("Die Löschung von PRJ und Migrationssandbox liegt vor diesem Stand.")
  same <- "Sind PRJ und Migrationssandbox gelöscht, verlaufen alle Szenarien gleich."
  if (reserve < 0) return(paste0(same, " Es fehlen dann ", .capacity_german_number(-reserve), " GB."))
  until <- function(date) {
    if (is.na(date)) paste0("über ", format(facts$FORECAST_END, "%m/%Y"), " hinaus") else paste("bis", format(date, "%m/%Y"))
  }
  paste0(same, " Die Reserve von ", .capacity_german_number(reserve), " GB reicht mit Activity für die Servicetechniker ",
         until(figures$EXHAUSTED_ACTIVITY[[1]]), ", mit Team Member ", until(figures$EXHAUSTED_TEAM_MEMBER[[1]]), ".")
}

.capacity_text_windows <- function(forecast) {
  facts <- forecast$Facts
  if (facts$STATUS_DATE >= facts$GO_LIVE) return("Der Go-Live liegt vor diesem Stand; die Option spielt keine Rolle mehr.")
  placed <- if (nrow(forecast$Windows) > 0L) "Die Fenster liegen lückenlos rückwärts ab dem Tag vor dem Go-Live. " else ""
  days   <- forecast$Figures$DAYS_UNCOVERED[[1]]
  if (days == 0L) return(paste0(placed, "Die Zeit bis zum Go-Live ist in S1 gedeckt."))
  last_day <- forecast$Days[forecast$Days$DATE == facts$GO_LIVE - 1, ]
  if (last_day$S1 <= last_day$QUOTA_OPTION) {
    return(paste0(placed, "Die Spitze vor dem Go-Live ist gedeckt; in S1 bleiben ", days, " Tage davor ohne Deckung."))
  }
  paste0(placed, "In S1 bleiben ", days, " Tage ohne Deckung, darunter der Tag vor dem Go-Live.")
}

.capacity_text_ways <- function(facts, figures) {
  if (figures$DAYS_UNCOVERED[[1]] == 0L) return(character())
  gap  <- .capacity_german_number(figures$GAP_MAX)
  cost <- .capacity_german_number(figures$PURCHASE_MONTH)
  buy  <- sprintf("**Kapazität für einen Monat zukaufen:** Das kostet in S1 %s €, in S2 %s €, in S3 %s €.", cost[[1]], cost[[2]], cost[[3]])
  if (!.capacity_measures_ahead(facts)) {
    return(sprintf("**Kapazität für einen Monat zukaufen:** Das kostet %s €; die Maßnahmen sind in den Größen dieses Stands enthalten.", cost[[1]]))
  }
  c(sprintf("**Maßnahmen aus S2 oder S3 umsetzen:** Die Fehlmenge sinkt dann von %s auf %s bzw. %s GB.", gap[[1]], gap[[2]], gap[[3]]), buy)
}

.capacity_text_postponed <- function(facts) {
  year_start <- as.Date(paste0(format(facts$GO_LIVE, "%Y"), "-01-01"))
  all_used   <- facts$OPTION_PER_YEAR > 0 && facts$OPTION_PER_YEAR * facts$OPTION_DAYS <= as.numeric(facts$GO_LIVE - year_start)
  if (facts$STATUS_DATE >= facts$GO_LIVE || !all_used) return("")
  paste("Verschiebt sich der Go-Live, ist im selben Jahr kein Fenster mehr frei, und die neuen Lizenzen sind noch nicht aktiv.",
        "Der Lizenzbeginn wird deshalb unabhängig vom Go-Live-Termin festgelegt, oder ein Fenster bleibt in Reserve.")
}

#' Draw a capacity forecast
#'
#' Draws the consumption of the three scenarios against the quota, with and
#' without the option, on the current graphics device.
#'
#' @param forecast
#' Result of \code{\link{forecast_capacity}}.
#'
#' @return
#' Invisibly \code{NULL}.
#'
#' @examples
#' \dontrun{
#'
#' plot_capacity_forecast(forecast)
#'
#' }
#'
#' @seealso
#' \code{\link{forecast_capacity}}
#'
#' @export
plot_capacity_forecast <- function(forecast) {

  .check_capacity_forecast(forecast)
  series  <- forecast$Days
  facts   <- forecast$Facts
  colours <- c(S1 = "#2a78d6", S2 = "#eb6834", S3 = "#1baf7a")
  ink     <- c(main = "#0b0b0b", second = "#52514e", grid = "#e1e0d9", axis = "#c3c2b7")
  values  <- c(series$S1, series$S2, series$S3, series$QUOTA_OPTION)
  y_low   <- floor(min(values) / 200) * 200
  y_high  <- ceiling(max(values) / 200) * 200
  y_marks <- seq(y_low, y_high, by = 200)
  x_marks <- seq(as.Date(format(min(series$DATE), "%Y-%m-01")), max(series$DATE) + 92, by = "3 months")
  events  <- c(facts$GO_LIVE, facts$DELETION)
  events  <- events[events >= min(series$DATE) & events <= max(series$DATE)]
  labels  <- c("Go-Live", "Löschung")[c(facts$GO_LIVE, facts$DELETION) %in% events]

  previous <- graphics::par(mar = c(3, 4.5, 1.5, 1), las = 1)
  on.exit(graphics::par(previous))
  graphics::plot(series$DATE, series$S1, type = "n", ylim = c(y_low, y_high), axes = FALSE, xlab = "", ylab = "GB",
                 col.lab = ink[["second"]])
  graphics::abline(h = y_marks, col = ink[["grid"]], lwd = 1)
  graphics::abline(v = as.numeric(events), col = ink[["axis"]], lty = 3)
  graphics::axis(2, at = y_marks, labels = .capacity_german_number(y_marks), col = ink[["axis"]], col.axis = ink[["second"]],
                 cex.axis = 0.8)
  graphics::axis.Date(1, at = x_marks, format = "%m/%Y", col = ink[["axis"]], col.axis = ink[["second"]], cex.axis = 0.8)
  if (length(events) > 0L) {
    graphics::mtext(labels, side = 3, at = as.numeric(events), adj = c(1, 0)[seq_along(events)], line = 0.2, cex = 0.7,
                    col = ink[["second"]])
  }
  graphics::lines(series$DATE, series$QUOTA_OPTION, type = "s", col = ink[["second"]], lwd = 1.5, lty = 2)
  graphics::lines(series$DATE, series$QUOTA, type = "s", col = ink[["main"]], lwd = 2)
  for (id in c("S3", "S2", "S1")) graphics::lines(series$DATE, series[[id]], col = colours[[id]], lwd = 2)
  graphics::legend("bottomright", legend = c("S1: wie geplant", "S2: PRJ und Migrationssandbox bereinigt wie INT",
                                             "S3: wie S2, Migrationssandbox transaktionslos", "Kontingent",
                                             "Kontingent mit Option"),
                   col = c(colours, ink[["main"]], ink[["second"]]), lty = c(1, 1, 1, 1, 2), lwd = 2, bty = "n", cex = 0.75,
                   text.col = ink[["main"]])
  invisible(NULL)
}
