#' Is a role identifier a GUID?
#'
#' A role created in the user interface of D365FO has a GUID as identifier
#' (\code{AOTNAME}); a role from development has a readable AOT name. The
#' package tells UI roles from AOT roles this way.
#'
#' @param name
#' Character vector of role identifiers, for example
#' \code{c("_WIBU_VERKAUF_INNENDIENST_MITARBEITER", "32B63442-1415-459D-8FF0-399780947265")}.
#' Upper and lower case are both accepted.
#'
#' @return
#' Logical vector of the same length: \code{TRUE} for a GUID of the form
#' 8-4-4-4-12 hexadecimal digits, \code{FALSE} for anything else, \code{NA}
#' included.
#'
#' @examples
#' is_guid_name(c("_WIBU_VERKAUF_INNENDIENST_MITARBEITER", "32B63442-1415-459D-8FF0-399780947265"))
#' # FALSE TRUE
#'
#' @seealso
#' \code{\link{load_role_mapping}}
#' \code{\link{compare_role_versions}}
#'
#' @export
is_guid_name <- function(name){

  grepl("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$",name)
}
