#' Find the AOT counterparts of the duties or privileges made in the user interface
#'
#' The counterpart of \code{\link{plan_role_consolidation}} for duties and
#' privileges: duties and privileges created in the user interface have a
#' GUID as identifier. The function looks for the AOT duty or AOT privilege
#' of the same name, compares both, and proposes what to do, so that every UI
#' object can be replaced by its AOT counterpart. Its result is the content of
#' the deliverables D22 (duties) and D23 (privileges); see
#' \code{\link{export_ui_counterparts}}. Where the UI objects sit is the task
#' of \code{\link{inventory_ui_objects}} (D24).
#'
#' @details
#'
#' **Counterpart.** The AOT object of the same type whose name equals the name
#' of the UI object (capitals and outer spaces do not count; an AOT role writes
#' "\code{<label> (<AOT name>)}", the part in brackets is left aside). With
#' \code{pairs} a counterpart can be set by hand.
#'
#' **Comparison.** A duty is compared by its privileges; a UI privilege in it
#' counts as its AOT counterpart when it has exactly one, so a UI duty that
#' holds the UI copy of an AOT privilege still equals the AOT duty. A privilege
#' is compared by its entry points with their rights (Create, Correct, Delete,
#' Invoke, Read, Update: Allow or Deny). Duties, privileges and entry points
#' come from \code{UserSecGovRelatedObjects}, the structure of the roles.
#'
#' **Results.** \code{SAME}, \code{DIFFERENT}, \code{NO_COUNTERPART} (no AOT
#' object of the name: create one), \code{SEVERAL} (several AOT objects of the
#' name: choose one) and \code{NOT_READABLE} (the UI object or its
#' counterpart sits in no role, so its content is not known).
#'
#' **Pairs by hand** must name an AOT object of the same type; otherwise the
#' function stops. A pair for an object that is no UI object of the type is
#' left out, with a warning.
#'
#' @param con
#' Database connection. Result of \code{get_connection()}.
#'
#' @param type
#' \code{"duty"} or \code{"privilege"}. UI roles are the task of
#' \code{\link{plan_role_consolidation}}.
#'
#' @param pairs
#' Optional table with \code{UI_IDENTIFIER} and \code{AOT_IDENTIFIER}:
#' counterparts set by hand. They win over the name.
#'
#' @return
#' A list:
#' \describe{
#'   \item{\code{Objects}}{One row per UI object: \code{TYPE},
#'     \code{UI_IDENTIFIER}, \code{UI_NAME}, \code{AOT_IDENTIFIER} (several
#'     separated by ", "), \code{AOT_NAME}, \code{MATCH} (\code{NAME},
#'     \code{MANUAL}, \code{NONE}, \code{SEVERAL}), \code{RESULT},
#'     \code{ONLY_UI}, \code{ONLY_AOT}, \code{OTHER_RIGHTS} (counts of the
#'     differences), \code{VIA_COUNTERPART} (duties: UI privileges counted as
#'     their AOT counterpart; whether those equal it says D23),
#'     \code{IN_ROLES} (roles that hold it directly),
#'     \code{IN_DUTIES} (privileges: duties that hold it).}
#'   \item{\code{Differences}}{One row per difference: \code{UI_IDENTIFIER},
#'     \code{UI_NAME}, \code{AOT_IDENTIFIER}, \code{ELEMENT}
#'     (\code{PRIVILEGE} or \code{ENTRY_POINT}), \code{NAME}, \code{LABEL},
#'     \code{SIDE} (\code{ONLY_UI}, \code{ONLY_AOT}, \code{OTHER_RIGHTS}),
#'     \code{RIGHTS_UI}, \code{RIGHTS_AOT}.}
#'   \item{\code{Check}}{\code{CREATED}, \code{TYPE}, \code{OBJECTS} and the
#'     number per result, \code{USED} (UI objects in a role or duty).}
#' }
#'
#' @examples
#' \dontrun{
#'
#' duties <- plan_ui_counterparts(cnn, "duty")
#' table(duties$Objects$RESULT)
#' export_ui_counterparts(duties, "Data/Deliverables/D22_UI_Aufgaben.xlsx")
#'
#' }
#'
#' @seealso
#' \code{\link{export_ui_counterparts}}
#' \code{\link{inventory_ui_objects}}
#' \code{\link{plan_role_consolidation}}
#'
#' @export
plan_ui_counterparts <- function(con, type, pairs = NULL) {

  type <- .check_ui_type(type)
  .check_ui_pairs(pairs)
  objects      <- .load_security_objects(con, type)
  pairs        <- .validate_ui_pairs(pairs, objects, if (type == "DUTY") "UI duties" else "UI privileges")
  counterparts <- .ui_counterparts(objects, pairs)
  structure    <- .load_ui_structure(con, c("role_parts", "duty_privileges", if (type == "PRIVILEGE") "grants"))
  contents     <- if (type == "DUTY") .duty_contents(con, structure) else .privilege_contents(structure)

  compared <- lapply(seq_len(nrow(counterparts)), function(i) .compare_ui_object(counterparts[i, ], contents, type))
  objects  <- .ui_objects_table(counterparts, compared, .ui_usage(counterparts$UI_KEY, type, structure))
  result   <- list(
    Objects     = objects,
    Differences = dplyr::bind_rows(c(list(.EMPTY_UI_DIFFERENCES), lapply(compared, `[[`, "differences"))),
    Check       = .ui_counterpart_check(objects, type)
  )
  message(.ui_counterpart_message(result$Check))
  result
}

.UI_TYPES   <- c(duty = "DUTY", privilege = "PRIVILEGE")
.UI_RESULTS <- c("SAME", "DIFFERENT", "NOT_READABLE", "SEVERAL", "NO_COUNTERPART")

.EMPTY_UI_DIFFERENCES <- tibble::tibble(
  UI_IDENTIFIER = character(), UI_NAME = character(), AOT_IDENTIFIER = character(), ELEMENT = character(),
  NAME = character(), LABEL = character(), SIDE = character(), RIGHTS_UI = character(), RIGHTS_AOT = character()
)

.check_ui_type <- function(type) {
  if (!.is_single_string(type) || !tolower(type) %in% names(.UI_TYPES)) {
    stop("type must be \"duty\" or \"privilege\"; UI roles are the task of plan_role_consolidation().", call. = FALSE)
  }
  unname(.UI_TYPES[[tolower(type)]])
}

# The privileges of every duty, by key; a UI privilege counts as its one AOT counterpart of the same name.
.duty_contents <- function(con, structure) {
  privileges <- .load_security_objects(con, "PRIVILEGE")
  mapped     <- .ui_counterparts(privileges)
  mapped     <- mapped[!is.na(mapped$AOT_KEY), ]
  pairs      <- .duty_privilege_keys(structure$duty_privileges)
  item       <- dplyr::coalesce(mapped$AOT_KEY[match(pairs$PRIVILEGE_KEY, mapped$UI_KEY)], pairs$PRIVILEGE_KEY)
  items      <- tibble::tibble(
    OWNER_KEY = pairs$DUTY_KEY, ITEM_KEY = item,
    NAME      = dplyr::coalesce(privileges$IDENTIFIER[match(item, privileges$KEY)], item),
    LABEL     = privileges$NAME[match(item, privileges$KEY)], RIGHTS = NA_character_,
    MAPPED    = item != pairs$PRIVILEGE_KEY
  )
  list(items = dplyr::distinct(items, OWNER_KEY, ITEM_KEY, .keep_all = TRUE),
       known = unique(c(pairs$DUTY_KEY, .role_part_keys(structure$role_parts)$duties$CHILD_KEY)))
}

# The entry points of every privilege with their rights, by key.
.privilege_contents <- function(structure) {
  grants <- structure$grants
  items  <- tibble::tibble(
    OWNER_KEY = .identifier_key(grants$PRIVILEGEIDENTIFIER),
    ITEM_KEY  = paste(.identifier_key(grants$RESOURCETYPE), .identifier_key(grants$RESOURCE_), sep = "|"),
    NAME      = as.character(grants$RESOURCE_), LABEL = as.character(grants$RESOURCETYPE), RIGHTS = .grant_text(grants)
  ) |>
    dplyr::group_by(OWNER_KEY, ITEM_KEY) |>
    dplyr::summarise(NAME = dplyr::first(NAME), LABEL = dplyr::first(LABEL),
                     RIGHTS = paste(sort(unique(RIGHTS)), collapse = " | "), .groups = "drop") |>
    dplyr::mutate(MAPPED = FALSE)
  list(items = items, known = unique(items$OWNER_KEY))
}

.compare_ui_object <- function(object, contents, type) {
  # A duty or privilege that sits in no role is not in UserSecGovRelatedObjects: its content is
  # not known, on either side.
  unknown <- !object$UI_KEY %in% contents$known || !object$AOT_KEY %in% contents$known
  open    <- dplyr::case_when(object$MATCH == "NONE" ~ "NO_COUNTERPART", object$MATCH == "SEVERAL" ~ "SEVERAL",
                              unknown ~ "NOT_READABLE", TRUE ~ NA_character_)
  if (!is.na(open)) {
    return(list(result = open, counts = rep(NA_integer_, 4L), differences = NULL))
  }
  ui       <- contents$items[contents$items$OWNER_KEY == object$UI_KEY, ]
  aot      <- contents$items[contents$items$OWNER_KEY == object$AOT_KEY, ]
  only_ui  <- ui[!ui$ITEM_KEY %in% aot$ITEM_KEY, ]
  only_aot <- aot[!aot$ITEM_KEY %in% ui$ITEM_KEY, ]
  both     <- dplyr::inner_join(ui, aot, by = "ITEM_KEY", suffix = c("_UI", "_AOT"))
  other    <- both[dplyr::coalesce(both$RIGHTS_UI != both$RIGHTS_AOT, FALSE), ]
  element  <- if (type == "DUTY") "PRIVILEGE" else "ENTRY_POINT"
  differences <- dplyr::bind_rows(
    tibble::tibble(ELEMENT = element, NAME = only_ui$NAME, LABEL = only_ui$LABEL, SIDE = "ONLY_UI",
                   RIGHTS_UI = only_ui$RIGHTS, RIGHTS_AOT = NA_character_),
    tibble::tibble(ELEMENT = element, NAME = only_aot$NAME, LABEL = only_aot$LABEL, SIDE = "ONLY_AOT",
                   RIGHTS_UI = NA_character_, RIGHTS_AOT = only_aot$RIGHTS),
    tibble::tibble(ELEMENT = element, NAME = other$NAME_UI, LABEL = other$LABEL_UI, SIDE = "OTHER_RIGHTS",
                   RIGHTS_UI = other$RIGHTS_UI, RIGHTS_AOT = other$RIGHTS_AOT)
  )
  differences <- dplyr::mutate(differences, UI_IDENTIFIER = object$UI_IDENTIFIER, UI_NAME = object$UI_NAME,
                               AOT_IDENTIFIER = object$AOT_IDENTIFIER, .before = 1)
  list(result = if (nrow(differences) == 0L) "SAME" else "DIFFERENT",
       counts = c(nrow(only_ui), nrow(only_aot), nrow(other), sum(ui$MAPPED)), differences = differences)
}

# How often each UI object sits directly in a role and, for a privilege, in a duty.
.ui_usage <- function(keys, type, structure) {
  parts    <- .role_part_keys(structure$role_parts)
  in_roles <- if (type == "DUTY") parts$duties else parts$privileges
  roles    <- vapply(keys, function(key) length(unique(.identifier_key(in_roles$ROLE[in_roles$CHILD_KEY == key]))), integer(1))
  duties   <- if (type == "PRIVILEGE") {
    pairs <- .duty_privilege_keys(structure$duty_privileges)
    vapply(keys, function(key) length(unique(pairs$DUTY_KEY[pairs$PRIVILEGE_KEY == key])), integer(1))
  } else {
    rep(NA_integer_, length(keys))
  }
  tibble::tibble(IN_ROLES = unname(roles), IN_DUTIES = unname(duties))
}

.ui_objects_table <- function(counterparts, compared, usage) {
  counts <- if (length(compared) == 0L) matrix(integer(), 0L, 4L) else do.call(rbind, lapply(compared, `[[`, "counts"))
  objects <- tibble::tibble(
    TYPE = counterparts$TYPE, UI_IDENTIFIER = counterparts$UI_IDENTIFIER, UI_NAME = counterparts$UI_NAME,
    AOT_IDENTIFIER = counterparts$AOT_IDENTIFIER, AOT_NAME = counterparts$AOT_NAME, MATCH = counterparts$MATCH,
    RESULT = vapply(compared, `[[`, character(1), "result"),
    ONLY_UI = as.integer(counts[, 1]), ONLY_AOT = as.integer(counts[, 2]), OTHER_RIGHTS = as.integer(counts[, 3]),
    VIA_COUNTERPART = as.integer(counts[, 4]), IN_ROLES = usage$IN_ROLES, IN_DUTIES = usage$IN_DUTIES
  )
  objects[order(match(objects$RESULT, .UI_RESULTS), objects$UI_NAME, objects$UI_IDENTIFIER), ]
}

.ui_counterpart_check <- function(objects, type) {
  count <- function(result) sum(objects$RESULT == result)
  list(CREATED = Sys.Date(), TYPE = type, OBJECTS = nrow(objects), SAME = count("SAME"), DIFFERENT = count("DIFFERENT"),
       NO_COUNTERPART = count("NO_COUNTERPART"), SEVERAL = count("SEVERAL"), NOT_READABLE = count("NOT_READABLE"),
       USED = sum(objects$IN_ROLES > 0L | dplyr::coalesce(objects$IN_DUTIES, 0L) > 0L))
}

.ui_counterpart_message <- function(check) {
  sprintf(paste("UI %s: %d objects; %d equal their AOT counterpart, %d differ, %d have none, %d have several,",
                "%d cannot be read; %d in use."),
          if (check$TYPE == "DUTY") "duties" else "privileges", check$OBJECTS, check$SAME, check$DIFFERENT,
          check$NO_COUNTERPART, check$SEVERAL, check$NOT_READABLE, check$USED)
}
