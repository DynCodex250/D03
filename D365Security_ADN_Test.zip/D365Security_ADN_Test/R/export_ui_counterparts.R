#' Write the AOT counterparts of the UI duties (D22) or UI privileges (D23)
#'
#' Writes the result of \code{\link{plan_ui_counterparts}} as the Excel
#' workbook of the deliverable D22 (UI duties) or D23 (UI privileges), in
#' German and in the layout of the other deliverables: one row per UI object
#' with its AOT counterpart, the result of the comparison, the proposed action
#' and the columns of the team.
#'
#' @details
#'
#' **Sheets.** \code{Anleitung}; \code{Aufgaben} or \code{Rechte} (one row per
#' UI object; white columns of the team: \code{Entscheidung},
#' \code{Erledigt am}, \code{Status}, \code{Bemerkung}); \code{Unterschiede}
#' (the privileges or entry points only one side holds, or with other
#' rights); \code{Listen}. No user ids.
#'
#' **Proposed action.** Equal: replace by the AOT counterpart. Different:
#' clear the differences, then replace. No counterpart: create an AOT object,
#' then replace. Several counterparts: choose one. Not readable: check the
#' content, then replace. A UI object that sits nowhere: remove it.
#'
#' **An earlier version.** With \code{previous}, the white columns carry over
#' by UI object.
#'
#' @param plan
#' Result of \code{\link{plan_ui_counterparts}}.
#'
#' @param path
#' Path of the workbook to write, in an existing folder.
#'
#' @param previous
#' Optional path of an earlier D22 or D23 whose white columns carry over.
#'
#' @param overwrite
#' \code{TRUE} = replace an existing file at \code{path}. Default \code{FALSE}.
#'
#' @return
#' Invisibly \code{path}.
#'
#' @examples
#' \dontrun{
#'
#' export_ui_counterparts(plan_ui_counterparts(cnn, "duty"), "Output/D22_UI_Aufgaben.xlsx")
#' export_ui_counterparts(plan_ui_counterparts(cnn, "privilege"), "Output/D23_UI_Rechte.xlsx")
#'
#' }
#'
#' @seealso
#' \code{\link{plan_ui_counterparts}}
#' \code{\link{export_ui_inventory}}
#'
#' @export
export_ui_counterparts <- function(plan, path, previous = NULL, overwrite = FALSE) {

  if (!is.list(plan) || !all(c("Objects", "Differences", "Check") %in% names(plan)) ||
      !isTRUE(plan$Check$TYPE %in% c("DUTY", "PRIVILEGE"))) {
    stop("plan must be the result of plan_ui_counterparts().", call. = FALSE)
  }
  type   <- plan$Check$TYPE
  number <- if (type == "DUTY") "D22" else "D23"
  sheet  <- if (type == "DUTY") "Aufgaben" else "Rechte"
  .check_deliverable_paths(path, previous, overwrite, paste("An existing", number, "holds the steps of the team"))
  earlier <- if (is.null(previous)) NULL else .read_previous_sheet(previous, sheet, "UI-Bezeichner", .UI_COUNTERPART_DATES)
  objects <- .ui_counterpart_sheet(plan$Objects, type, earlier, number)

  wb <- openxlsx::createWorkbook()
  .add_ui_counterpart_instructions(wb, plan$Check, number)
  .add_deliverable_sheet(wb, sheet, objects, it = setdiff(names(objects), .UI_COUNTERPART_MANUAL))
  .add_deliverable_sheet(wb, "Unterschiede", .ui_difference_sheet(plan$Differences), all_it = TRUE)
  .add_deliverable_sheet(wb, "Listen", .list_frame(.ui_counterpart_lists()))
  .add_list_validation(wb, sheet, objects, .ui_counterpart_lists())

  openxlsx::saveWorkbook(wb, path, overwrite = TRUE)
  message(sprintf("%s written: %s (%d UI objects, %d equal their AOT counterpart).", number, path,
                  plan$Check$OBJECTS, plan$Check$SAME))
  invisible(path)
}

.UI_COUNTERPART_MANUAL <- c("Entscheidung", "Erledigt am", "Status", "Bemerkung")
.UI_COUNTERPART_DATES  <- "Erledigt am"

.UI_RESULT_TEXTS <- c(SAME = "Gleich", DIFFERENT = "Unterschiede", NO_COUNTERPART = "Kein Pendant",
                      SEVERAL = "Mehrere Pendants", NOT_READABLE = "Inhalt nicht lesbar")
.UI_ACTION_TEXTS <- c(SAME = "Durch AOT-Pendant ersetzen", DIFFERENT = "Unterschiede klären, dann ersetzen",
                      NO_COUNTERPART = "AOT-Objekt anlegen, dann ersetzen", SEVERAL = "Pendant wählen, dann ersetzen",
                      NOT_READABLE = "Inhalt prüfen, dann ersetzen")
.UI_MATCH_TEXTS  <- c(NAME = "gleicher Name", MANUAL = "von Hand", NONE = "keins", SEVERAL = "mehrere")
.UI_SIDE_TEXTS   <- c(ONLY_UI = "nur UI", ONLY_AOT = "nur AOT", OTHER_RIGHTS = "andere Rechte")
.UI_ELEMENT_TEXTS <- c(PRIVILEGE = "Recht", ENTRY_POINT = "Einstiegspunkt")
.UI_NOWHERE_ACTION <- "Nirgends verwendet: entfernen"

.ui_counterpart_sheet <- function(objects, type, earlier, number) {
  used   <- objects$IN_ROLES > 0L | dplyr::coalesce(objects$IN_DUTIES, 0L) > 0L
  action <- ifelse(used, unname(.UI_ACTION_TEXTS[objects$RESULT]), .UI_NOWHERE_ACTION)
  sheet  <- data.frame(
    "UI-Bezeichner" = objects$UI_IDENTIFIER, "UI-Name" = objects$UI_NAME, "AOT-Pendant" = objects$AOT_IDENTIFIER,
    "AOT-Pendant (Name)" = objects$AOT_NAME, "Zuordnung" = unname(.UI_MATCH_TEXTS[objects$MATCH]),
    "Ergebnis" = unname(.UI_RESULT_TEXTS[objects$RESULT]),
    "Nur in UI" = objects$ONLY_UI, "Nur in AOT" = objects$ONLY_AOT, check.names = FALSE, stringsAsFactors = FALSE
  )
  if (type == "PRIVILEGE") sheet[["Andere Rechte"]] <- objects$OTHER_RIGHTS
  if (type == "DUTY") sheet[["UI-Rechte über Pendant gezählt (siehe D23)"]] <- objects$VIA_COUNTERPART
  sheet[["In Rollen"]] <- objects$IN_ROLES
  if (type == "PRIVILEGE") sheet[["In Aufgaben"]] <- objects$IN_DUTIES
  sheet[["Maßnahme (Vorschlag)"]] <- action
  keys  <- .deliverable_key(objects$UI_IDENTIFIER)
  sheet <- .carry_over_columns(sheet, keys, earlier, earlier$KEY, .UI_COUNTERPART_MANUAL)
  if (!is.null(earlier)) {
    .warn_on_gone_entries(earlier, keys, .UI_COUNTERPART_MANUAL, "UI objects", "UI-Bezeichner")
    .warn_on_dropped_columns(earlier, names(sheet), number)
  }
  sheet
}

.ui_difference_sheet <- function(differences) {
  data.frame(
    "UI-Bezeichner" = differences$UI_IDENTIFIER, "UI-Name" = differences$UI_NAME, "AOT-Pendant" = differences$AOT_IDENTIFIER,
    "Element" = unname(.UI_ELEMENT_TEXTS[differences$ELEMENT]), "Name" = differences$NAME, "Bezeichnung" = differences$LABEL,
    "Seite" = unname(.UI_SIDE_TEXTS[differences$SIDE]), "Rechte UI" = differences$RIGHTS_UI,
    "Rechte AOT" = differences$RIGHTS_AOT, check.names = FALSE, stringsAsFactors = FALSE
  )
}

.ui_counterpart_lists <- function() {
  list("Entscheidung" = c("Durch Pendant ersetzen", "AOT-Pendant anpassen, dann ersetzen", "AOT-Objekt anlegen",
                          "Entfernen", "Behalten"),
       "Status" = c("offen", "in Arbeit", "erledigt"))
}

.add_ui_counterpart_instructions <- function(wb, check, number) {
  what <- if (check$TYPE == "DUTY") "Aufgaben" else "Rechte"
  compared_by <- if (check$TYPE == "DUTY") {
    "Verglichen werden die Rechte der Aufgabe. Ein UI-Recht in ihr zählt als sein AOT-Pendant, wenn es genau eines hat."
  } else {
    "Verglichen werden die Einstiegspunkte des Rechts mit ihren Zugriffsrechten (Create, Correct, Delete, Invoke, Read, Update)."
  }
  text <- c(
    paste0(number, " UI-", what, " und ihre AOT-Pendants"),
    paste0("Erzeugt am ", format(Sys.Date(), "%d.%m.%Y")),
    "",
    "Worum es geht",
    paste0(what, ", die in der Oberfläche angelegt wurden, haben eine GUID als Bezeichner. Ziel ist, jedes UI-Objekt durch sein AOT-Pendant zu ersetzen. Das Pendant ist das AOT-Objekt mit gleichem Namen. ", compared_by),
    "",
    "Kennzahlen",
    sprintf("%d UI-%s: %d gleich, %d mit Unterschieden, %d ohne Pendant, %d mit mehreren Pendants, %d nicht lesbar; %d werden verwendet.",
            check$OBJECTS, what, check$SAME, check$DIFFERENT, check$NO_COUNTERPART, check$SEVERAL, check$NOT_READABLE, check$USED),
    "",
    "Was zu tun ist",
    "1. „Gleich“: Das UI-Objekt kann überall durch sein AOT-Pendant ersetzt werden. Wo es steckt, zeigt die Inventur (D24).",
    "2. „Unterschiede“: Blatt „Unterschiede“ prüfen. Braucht man, was nur die UI-Fassung hat, wird das AOT-Pendant angepasst; sonst direkt ersetzen.",
    "3. „Kein Pendant“: ein AOT-Objekt anlegen (Entwicklung), dann ersetzen. „Mehrere Pendants“: eines wählen.",
    "4. „Inhalt nicht lesbar“: Das UI-Objekt oder sein AOT-Pendant steckt in keiner Rolle; der Inhalt ist deshalb nicht bekannt. „In Rollen“ = 0 heißt: Das UI-Objekt wird nicht verwendet und kann entfernt werden.",
    if (check$TYPE == "DUTY") "„Gleich“ bei einer Aufgabe heißt: dieselben Rechte, wobei ein UI-Recht als sein AOT-Pendant zählt (Spalte „UI-Rechte über Pendant gezählt“). Ob diese UI-Rechte ihrem Pendant gleichen, steht in D23." else NULL,
    "Reihenfolge von oben nach unten: Rollen (D20), dann Aufgaben (D22), dann Rechte (D23). Wird eine UI-Aufgabe durch ihr Pendant ersetzt, entfallen auch die UI-Rechte in ihr. Entscheidung und Datum in die weißen Spalten eintragen.",
    "",
    "Hinweis für die Weiterverarbeitung",
    "Blau markierte Spalten und Blätter füllt das Werkzeug; die weißen Spalten pflegt das Team. Beim nächsten Lauf übernimmt das Werkzeug die weißen Spalten je UI-Objekt. Blätter und Kopfzeilen bitte nicht umbenennen. Die Datei enthält keine Benutzerdaten."
  )
  .add_instruction_sheet(wb, text, c("Worum es geht", "Kennzahlen", "Was zu tun ist", "Hinweis für die Weiterverarbeitung"))
}
