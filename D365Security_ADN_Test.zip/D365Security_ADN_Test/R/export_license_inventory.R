#' Write the inventory and license analysis as deliverable D03
#'
#' Writes the result of \code{\link{summarize_license_inventory}} as the Excel
#' workbook of the deliverable D03, in German and in the layout of the other
#' deliverables: the key figures and the tables behind the Word summary of
#' D03, counts and sums only.
#'
#' @details
#'
#' **Sheets.** \code{Anleitung}; \code{Kennzahlen} (one row per key figure:
#' the number in \code{Zahl}, a text such as the source, yes or no, or a date
#' in \code{Text}); \code{Abrechnung} (users and costs per kind of billing);
#' \code{Lizenzen} (per license the users who need, have and miss it);
#' \code{Rollen} (the most expensive roles by PPAC and by the license graph);
#' \code{Nutzung} (the users per class of the cleanup plan);
#' \code{Umgebungen} (the comparison of environments). A part without input
#' keeps its sheet, with the headers only.
#'
#' **No user ids.** The workbook holds counts and sums only. The measures per
#' role and user are in D04: the ranking of \code{\link{rank_roles_by_license_cost}}
#' and the cleanup plan of \code{\link{plan_role_license_cleanup}}.
#'
#' **Written anew.** The tool fills every sheet and the team edits nothing
#' here, so each run replaces the file (\code{overwrite = TRUE}); earlier
#' versions stay in Git.
#'
#' @param inventory
#' Result of \code{\link{summarize_license_inventory}}.
#'
#' @param path
#' Path of the workbook to write, in an existing folder, as a rule
#' \code{"Data/Deliverables/D03_Bestands_und_Lizenzanalyse.xlsx"}.
#'
#' @param overwrite
#' \code{TRUE} = replace an existing file at \code{path}. Default \code{FALSE}.
#'
#' @return
#' Invisibly \code{path}.
#'
#' @examples
#' \dontrun{
#'
#' inventory <- summarize_license_inventory(ranking, ranking_graph = ranking_graph, assigned = assigned, plan = plan)
#' export_license_inventory(inventory, "Data/Deliverables/D03_Bestands_und_Lizenzanalyse.xlsx", overwrite = TRUE)
#'
#' }
#'
#' @seealso
#' \code{\link{summarize_license_inventory}}
#' \code{\link{rank_roles_by_license_cost}}
#' \code{\link{plan_role_license_cleanup}}
#'
#' @export
export_license_inventory <- function(inventory, path, overwrite = FALSE) {

  parts <- c("Figures", "Billing", "Licenses", "Roles", "Usage", "Environments")
  if (!is.list(inventory) || !all(parts %in% names(inventory)) || !is.data.frame(inventory$Figures) ||
      nrow(inventory$Figures) != 1L) {
    stop("inventory must be the result of summarize_license_inventory().", call. = FALSE)
  }
  .check_inventory_path(path, overwrite)

  wb <- openxlsx::createWorkbook()
  .add_inventory_instructions(wb, inventory$Figures)
  .add_deliverable_sheet(wb, "Kennzahlen", .inventory_figure_sheet(inventory$Figures), all_it = TRUE)
  .add_deliverable_sheet(wb, "Abrechnung", .inventory_billing_sheet(inventory$Billing), all_it = TRUE)
  .add_deliverable_sheet(wb, "Lizenzen", .inventory_license_sheet(inventory$Licenses), all_it = TRUE)
  .add_deliverable_sheet(wb, "Rollen", .inventory_role_sheet(inventory$Roles), all_it = TRUE)
  .add_deliverable_sheet(wb, "Nutzung", .inventory_usage_sheet(inventory$Usage), all_it = TRUE)
  .add_deliverable_sheet(wb, "Umgebungen", .inventory_environment_sheet(inventory$Environments), all_it = TRUE)

  openxlsx::saveWorkbook(wb, path, overwrite = TRUE)
  message(sprintf("D03 written: %s (%d users, %.2f per month).", path, as.integer(inventory$Figures$USERS),
                  inventory$Figures$COST_MONTH))
  invisible(path)
}

# D03 has no columns of the team: a run replaces the file, but only when asked to.
.check_inventory_path <- function(path, overwrite) {
  if (!.is_single_string(path) || !dir.exists(dirname(path))) {
    stop("path must be a file in an existing folder: '", paste(path, collapse = ", "), "'.", call. = FALSE)
  }
  if (file.exists(path) && !isTRUE(overwrite)) {
    stop("'", path, "' exists; set overwrite = TRUE to replace it.", call. = FALSE)
  }
  invisible(TRUE)
}

.INVENTORY_FIGURE_TEXTS <- c(
  USERS = "Benutzer", ROLES = "Rollen", COST_MONTH = "Lizenzkosten je Monat (€)", COST_YEAR = "Lizenzkosten je Jahr (€)",
  SOURCE = "Quelle der Lizenzen", PRICES_ESTIMATED = "Preise geschätzt",
  REQUIRED_COST = "Verlangt laut Bericht je Benutzer, je Monat (€)", ASSIGNED_COST = "Zugewiesen, je Monat (€)",
  MISSING_COST = "Fehlende Lizenzen, je Monat (€)", SURPLUS_COST = "Mehr als nötig zugewiesen, je Monat (€)",
  USERS_MISSING = "Benutzer, denen eine Lizenz fehlt", USERS_MORE_THAN_NEEDED = "Benutzer mit mehr als nötig",
  ROLE_COST_PPAC = "Kosten nur wegen der Rollen nach PPAC, je Monat (€)",
  ROLE_COST_GRAPH = "Kosten nur wegen der Rollen nach dem Lizenzgraphen, je Monat (€)",
  ROLES_WITH_COST_PPAC = "Rollen mit Kosten nach PPAC", ROLES_WITH_COST_GRAPH = "Rollen mit Kosten nach dem Lizenzgraphen",
  PROVEN_SAVING = "Belegte Einsparung je Monat (€)", SAVING_IF_CONFIRMED = "Einsparung nach Prüfung je Monat (€)",
  USERS_SAVING = "Benutzer mit belegter Einsparung", USERS_WITHOUT_USE = "Benutzer ohne lizenzpflichtige Nutzung",
  COST_WITHOUT_USE = "Deren Lizenzkosten je Monat (€)", TELEMETRY_FROM = "Telemetrie von", TELEMETRY_TO = "Telemetrie bis"
)

.INVENTORY_CLASS_TEXTS <- c(
  SAVES = "sparen, durch die Telemetrie belegt", REVIEW = "sparen erst nach Prüfung durch den Fachbereich",
  KEEPS = "nutzen, was ihre Lizenzen auslöst", NO_TELEMETRY = "haben keine Telemetrie",
  NO_USE = "nutzen nichts Lizenzpflichtiges", GRAPH_DIFFERS = "brauchen laut Graph weniger, als PPAC abrechnet"
)

# A number goes to Zahl; a source, yes or no, or a date to Text.
.inventory_figure_sheet <- function(figures) {
  fields <- intersect(names(.INVENTORY_FIGURE_TEXTS), names(figures))
  values <- lapply(fields, function(field) figures[[field]][[1]])
  number <- function(value) if (is.numeric(value) && !inherits(value, "Date")) as.numeric(value) else NA_real_
  text   <- function(value) {
    if (length(value) == 0L || is.na(value)) return(NA_character_)
    if (inherits(value, "Date")) return(format(value, "%d.%m.%Y"))
    if (is.logical(value)) return(if (value) "Ja" else "Nein")
    if (is.character(value)) value else NA_character_
  }
  data.frame(Kennzahl = unname(.INVENTORY_FIGURE_TEXTS[fields]), Zahl = vapply(values, number, numeric(1)),
             Text = vapply(values, text, character(1)), stringsAsFactors = FALSE)
}

.inventory_billing_sheet <- function(billing) {
  share <- billing$SHARE
  class(share) <- c("percentage", class(share))
  data.frame(
    "Abgerechnet als" = ifelse(is.na(billing$BILLED_AS) | !nzchar(billing$BILLED_AS), "keine Lizenz", billing$BILLED_AS),
    "Benutzer" = billing$USERS, "je Benutzer und Monat (€)" = billing$COST_PER_USER,
    "zusammen je Monat (€)" = billing$COST, "Anteil" = share, check.names = FALSE, stringsAsFactors = FALSE
  )
}

.inventory_license_sheet <- function(licenses) {
  if (ncol(licenses) == 0L) {
    licenses <- tibble::tibble(LICENSE = character(), REQUIRED = integer(), ASSIGNED = integer(), MISSING = integer())
  }
  data.frame(
    "Lizenz" = licenses$LICENSE, "Benutzer, die sie brauchen" = licenses$REQUIRED,
    "Benutzer, die sie haben" = licenses$ASSIGNED, "Benutzer, denen sie fehlt" = licenses$MISSING,
    check.names = FALSE, stringsAsFactors = FALSE
  )
}

.inventory_role_sheet <- function(roles) {
  data.frame(
    "Rolle" = roles$ROLE, "Benutzer" = roles$USERS, "Lizenzkosten ihrer Benutzer je Monat (€)" = roles$USERS_COST,
    "Platz nach PPAC" = roles$RANK_PPAC, "nur wegen der Rolle nach PPAC (€)" = roles$COST_PPAC,
    "Platz nach dem Lizenzgraphen" = roles$RANK_GRAPH, "nur wegen der Rolle nach dem Lizenzgraphen (€)" = roles$COST_GRAPH,
    check.names = FALSE, stringsAsFactors = FALSE
  )
}

.inventory_usage_sheet <- function(usage) {
  data.frame(
    "Benutzer, die …" = dplyr::coalesce(unname(.INVENTORY_CLASS_TEXTS[usage$CLASS]), usage$CLASS),
    "Benutzer" = usage$USERS, "Lizenzkosten heute je Monat (€)" = usage$COST_NOW,
    "belegte Einsparung je Monat (€)" = usage$SAVING, "Einsparung nach Prüfung je Monat (€)" = usage$SAVING_IF_CONFIRMED,
    check.names = FALSE, stringsAsFactors = FALSE
  )
}

.inventory_environment_sheet <- function(environments) {
  data.frame(
    "von" = environments$FROM, "nach" = environments$TO, "Benutzer in beiden" = environments$USERS_BOTH,
    "nur in von" = environments$USERS_FROM_ONLY, "nur in nach" = environments$USERS_TO_ONLY,
    "Kosten in von je Monat (€)" = environments$COST_FROM, "Kosten in nach je Monat (€)" = environments$COST_TO,
    "Unterschied je Monat (€)" = environments$DIFFERENCE, check.names = FALSE, stringsAsFactors = FALSE
  )
}

.add_inventory_instructions <- function(wb, figures) {
  amount <- function(x) if (is.na(x)) "–" else formatC(x, format = "f", digits = 2, big.mark = ".", decimal.mark = ",")
  text <- c(
    "D03 Bestands- und Lizenzanalyse: die Zahlen",
    paste0("Erzeugt am ", format(Sys.Date(), "%d.%m.%Y")),
    "",
    "Worum es geht",
    "Die Zahlen hinter der Word-Fassung von D03: was die Lizenzen heute kosten, was D365 verlangt und was zugewiesen ist, welche Rollen am meisten kosten, was die Benutzer laut Telemetrie nutzen und wie sich die Umgebungen unterscheiden. Nur Anzahlen und Summen, keine Benutzerkennungen. Die Maßnahmen je Rolle und Benutzer stehen in D04 (Rangliste und Bereinigungsplan).",
    "",
    "Kennzahlen",
    sprintf("%d Benutzer kosten %s € im Monat. Belegte Einsparung laut Telemetrie: %s € im Monat; nach Prüfung durch den Fachbereich weitere %s €.",
            as.integer(figures$USERS), amount(figures$COST_MONTH), amount(figures$PROVEN_SAVING),
            amount(figures$SAVING_IF_CONFIRMED)),
    "",
    "So lesen Sie die Blätter",
    "Kennzahlen: je Kennzahl die Zahl oder ein Text (Quelle, Ja/Nein, Datum). Abrechnung: Benutzer und Kosten je Art der Abrechnung. Lizenzen: je Lizenz, wie viele Benutzer sie brauchen, haben und wem sie fehlt. Rollen: die teuersten Rollen, „nur wegen der Rolle“ nach PPAC (Obergrenze) und nach dem Lizenzgraphen. Nutzung: die Benutzer je Klasse des Bereinigungsplans. Umgebungen: dieselben Benutzer in zwei Umgebungen. Ein Blatt ohne Zeilen heißt: Für diesen Teil fehlte die Eingabe.",
    "",
    "Hinweis für die Weiterverarbeitung",
    "Alle Blätter füllt das Werkzeug; jeder Lauf schreibt die Datei neu, frühere Stände liegen in Git. Blätter und Kopfzeilen bitte nicht umbenennen."
  )
  .add_instruction_sheet(wb, text, c("Worum es geht", "Kennzahlen", "So lesen Sie die Blätter", "Hinweis für die Weiterverarbeitung"))
}
