#' Sum up the inventory and license analysis (D03)
#'
#' The key figures and tables of the inventory and license analysis (D03 of
#' the strategy) for CFO, IT management and license management: what the
#' licenses cost today and how the users are billed, the gap between the
#' licenses D365 requires and those assigned, the most expensive roles, what
#' the telemetry shows, and how the environments differ. The function only
#' sums up the results of the other functions; the report
#' \code{D03_Bestands_und_Lizenzanalyse.Rmd} lays them out.
#'
#' @details
#'
#' Only \code{ranking} is needed; every other part stays empty (its figures
#' \code{NA}, its tables without rows) when its result is not given. No table
#' holds user ids.
#'
#' @param ranking
#' \code{\link{rank_roles_by_license_cost}} with \code{basis = "ppac"}: the
#' users, their billing and the ranking by PPAC.
#'
#' @param ranking_graph
#' \code{\link{rank_roles_by_license_cost}} with \code{basis = "graph"}, for
#' the costs only because of a role by the license graph, from the same
#' licenses as \code{ranking} (their total costs must agree); \code{NULL} =
#' none.
#'
#' @param assigned
#' \code{\link{compare_assigned_license_cost}}: required against assigned
#' licenses; \code{NULL} = none.
#'
#' @param plan
#' \code{\link{plan_role_license_cleanup}}: what the telemetry shows;
#' \code{NULL} = none.
#'
#' @param environments
#' A list of results of \code{\link{compare_environment_license_cost}}, for
#' example INT and PRJ against production; empty = none.
#'
#' @param top
#' Number of roles in \code{Roles}.
#'
#' @return
#' List:
#' \describe{
#'   \item{\code{Figures}}{One row: \code{USERS}, \code{ROLES},
#'     \code{COST_MONTH}, \code{COST_YEAR}, \code{SOURCE},
#'     \code{PRICES_ESTIMATED}, \code{REQUIRED_COST} (required by the license
#'     report per user; \code{COST_MONTH} comes from the detailed report and
#'     differs when the two are of different dates), \code{ASSIGNED_COST},
#'     \code{MISSING_COST},
#'     \code{SURPLUS_COST}, \code{USERS_MISSING},
#'     \code{USERS_MORE_THAN_NEEDED}, \code{ROLE_COST_PPAC} and
#'     \code{ROLE_COST_GRAPH} (the costs only because of a role, summed over
#'     the roles), \code{ROLES_WITH_COST_PPAC}, \code{ROLES_WITH_COST_GRAPH},
#'     \code{PROVEN_SAVING}, \code{SAVING_IF_CONFIRMED},
#'     \code{USERS_SAVING}, \code{USERS_WITHOUT_USE},
#'     \code{COST_WITHOUT_USE}, \code{TELEMETRY_FROM}, \code{TELEMETRY_TO}.}
#'   \item{\code{Billing}}{Per kind of billing (\code{BILLED_AS}, empty for
#'     users without license) \code{USERS}, \code{COST_PER_USER},
#'     \code{COST}, \code{SHARE} of all costs; dearest first.}
#'   \item{\code{Licenses}}{\code{assigned$Licenses}: per license the users
#'     who need it, have it and miss it.}
#'   \item{\code{Roles}}{The \code{top} roles: \code{ROLE}, \code{USERS},
#'     \code{USERS_COST}, \code{RANK_PPAC}, \code{COST_PPAC},
#'     \code{RANK_GRAPH}, \code{COST_GRAPH}; by the graph first when given.}
#'   \item{\code{Usage}}{Per class of the plan \code{CLASS}, \code{USERS},
#'     \code{COST_NOW}, \code{SAVING}, \code{SAVING_IF_CONFIRMED}.}
#'   \item{\code{Environments}}{Per comparison \code{FROM}, \code{TO},
#'     \code{USERS_BOTH}, \code{USERS_FROM_ONLY}, \code{USERS_TO_ONLY},
#'     \code{COST_FROM}, \code{COST_TO}, \code{DIFFERENCE}.}
#' }
#'
#' @examples
#' \dontrun{
#'
#' detail   <- read_ppac_license_detail("Input/...Detailed_Report_pseudonymized.csv")
#' prod     <- detail[detail$ENVIRONMENT == "wibu-produktiv", ]
#' prices   <- read_license_prices("Input/Lizenzpreise.xlsx")
#' graph    <- read_license_graph(list.files("Input/Excel/Database", "EXPLODEDGAPH_.*[.]xlsx$", full.names = TRUE))
#' inventory <- summarize_license_inventory(
#'   ranking       = rank_roles_by_license_cost(licenses = prod, prices = prices),
#'   ranking_graph = rank_roles_by_license_cost(licenses = prod, prices = prices, basis = "graph", graph = graph),
#'   assigned      = compare_assigned_license_cost(read_ppac_license_report("Input/...Report_pseudonymized.csv"),
#'                                                 prices = prices),
#'   environments  = list(compare_environment_license_cost(detail, to = "wibu-int", prices = prices))
#' )
#' inventory$Figures
#'
#' }
#'
#' @seealso
#' \code{\link{rank_roles_by_license_cost}}
#' \code{\link{compare_assigned_license_cost}}
#' \code{\link{plan_role_license_cleanup}}
#' \code{\link{compare_environment_license_cost}}
#'
#' @export
summarize_license_inventory <- function(ranking, ranking_graph = NULL, assigned = NULL, plan = NULL,
                                        environments = list(), top = 10L) {

  .check_inventory_ranking(ranking, "ranking", "ppac")
  if (!is.null(ranking_graph)) {
    .check_inventory_ranking(ranking_graph, "ranking_graph", "graph")
    if (abs(ranking_graph$Check$TOTAL_COST - ranking$Check$TOTAL_COST) > .CENT) {
      stop(sprintf(paste("ranking and ranking_graph must come from the same licenses: their total costs differ",
                         "(%.2f against %.2f)."), ranking$Check$TOTAL_COST, ranking_graph$Check$TOTAL_COST),
           call. = FALSE)
    }
  }
  .check_inventory_parts(assigned, plan, top)

  list(
    Figures      = .inventory_figures(ranking, ranking_graph, assigned, plan),
    Billing      = .inventory_billing(ranking$Users),
    Licenses     = if (is.null(assigned)) tibble::tibble() else assigned$Licenses,
    Roles        = .inventory_roles(ranking, ranking_graph, top),
    Usage        = .inventory_usage(plan),
    Environments = .inventory_environments(environments)
  )
}

.check_inventory_ranking <- function(ranking, argument, basis) {
  if (!is.list(ranking) || is.null(ranking$Check$TOTAL_COST) || !is.data.frame(ranking$Ranking) ||
      !is.data.frame(ranking$Users)) {
    stop(argument, " must be the result of rank_roles_by_license_cost().", call. = FALSE)
  }
  if (!identical(dplyr::coalesce(ranking$Check$BASIS, "ppac"), basis)) {
    stop(argument, " must be ranked with basis = \"", basis, "\".", call. = FALSE)
  }
  invisible(ranking)
}

# A wrong result would otherwise give silent gaps (NA) or an error deep in dplyr.
.check_inventory_parts <- function(assigned, plan, top) {
  if (!is.null(assigned) && (!is.list(assigned) || is.null(assigned$Check$MISSING_COST) ||
                             is.null(assigned$Check$REQUIRED_COST) || !is.data.frame(assigned$Licenses))) {
    stop("assigned must be the result of compare_assigned_license_cost().", call. = FALSE)
  }
  if (!is.null(plan) && (!is.list(plan) || is.null(plan$Check$SAVING) || !is.data.frame(plan$Users) ||
                         !"CLASS" %in% names(plan$Users))) {
    stop("plan must be the result of plan_role_license_cleanup().", call. = FALSE)
  }
  if (!is.numeric(top) || length(top) != 1L || is.na(top) || top < 1 || top != round(top)) {
    stop("top must be a positive whole number.", call. = FALSE)
  }
  invisible(NULL)
}

.inventory_figures <- function(ranking, ranking_graph, assigned, plan) {
  check   <- ranking$Check
  of      <- function(result, field, missing) if (is.null(result$Check[[field]])) missing else result$Check[[field]]
  graph   <- if (is.null(ranking_graph)) NULL else ranking_graph$Ranking$COST
  tibble::tibble(
    USERS = check$USERS, ROLES = check$ROLES, COST_MONTH = round(check$TOTAL_COST, 2),
    COST_YEAR = round(12 * check$TOTAL_COST, 2), SOURCE = check$SOURCE, PRICES_ESTIMATED = check$PRICES_ESTIMATED,
    REQUIRED_COST = of(assigned, "REQUIRED_COST", NA_real_),
    ASSIGNED_COST = of(assigned, "ASSIGNED_COST", NA_real_), MISSING_COST = of(assigned, "MISSING_COST", NA_real_),
    SURPLUS_COST = of(assigned, "SURPLUS_COST", NA_real_), USERS_MISSING = of(assigned, "USERS_MISSING", NA_integer_),
    USERS_MORE_THAN_NEEDED = of(assigned, "USERS_MORE_THAN_NEEDED", NA_integer_),
    ROLE_COST_PPAC = round(sum(ranking$Ranking$COST), 2),
    ROLE_COST_GRAPH = if (is.null(graph)) NA_real_ else round(sum(graph), 2),
    ROLES_WITH_COST_PPAC = sum(ranking$Ranking$COST > .CENT),
    ROLES_WITH_COST_GRAPH = if (is.null(graph)) NA_integer_ else sum(graph > .CENT),
    PROVEN_SAVING = of(plan, "SAVING", NA_real_), SAVING_IF_CONFIRMED = of(plan, "SAVING_IF_CONFIRMED", NA_real_),
    USERS_SAVING = if (is.null(plan)) NA_integer_ else sum(plan$Users$CLASS == .CLEANUP_SAVES),
    USERS_WITHOUT_USE = if (is.null(plan)) NA_integer_ else
      as.integer(plan$Check$USERS_WITHOUT_TELEMETRY + plan$Check$USERS_WITHOUT_LICENSED_USE),
    COST_WITHOUT_USE = of(plan, "COST_WITHOUT_USE", NA_real_),
    TELEMETRY_FROM = of(plan, "TELEMETRY_FROM", as.Date(NA)), TELEMETRY_TO = of(plan, "TELEMETRY_TO", as.Date(NA))
  )
}

.inventory_billing <- function(users) {
  billing <- users |>
    dplyr::group_by(BILLED_AS) |>
    dplyr::summarise(USERS = dplyr::n(), COST = round(sum(COST), 2), .groups = "drop") |>
    dplyr::mutate(COST_PER_USER = round(COST / USERS, 2))
  total <- sum(billing$COST)
  billing |>
    dplyr::mutate(SHARE = if (total > 0) COST / total else 0) |>
    dplyr::arrange(dplyr::desc(COST_PER_USER), dplyr::desc(USERS), BILLED_AS) |>
    dplyr::select(BILLED_AS, USERS, COST_PER_USER, COST, SHARE)
}

.inventory_roles <- function(ranking, ranking_graph, top) {
  roles <- dplyr::select(ranking$Ranking, ROLE, USERS, USERS_COST, RANK_PPAC = RANK, COST_PPAC = COST)
  roles <- if (is.null(ranking_graph)) {
    dplyr::mutate(roles, RANK_GRAPH = NA_integer_, COST_GRAPH = NA_real_)
  } else {
    dplyr::left_join(roles, dplyr::select(ranking_graph$Ranking, ROLE, RANK_GRAPH = RANK, COST_GRAPH = COST),
                     by = "ROLE")
  }
  roles |>
    dplyr::arrange(dplyr::coalesce(RANK_GRAPH, RANK_PPAC), RANK_PPAC) |>
    utils::head(top)
}

.INVENTORY_CLASSES <- c("SAVES", "REVIEW", "KEEPS", "NO_TELEMETRY", "NO_USE", "GRAPH_DIFFERS")

.inventory_usage <- function(plan) {
  if (is.null(plan)) {
    return(tibble::tibble(CLASS = character(), USERS = integer(), COST_NOW = numeric(), SAVING = numeric(),
                          SAVING_IF_CONFIRMED = numeric()))
  }
  plan$Users |>
    dplyr::group_by(CLASS) |>
    dplyr::summarise(USERS = dplyr::n(), COST_NOW = round(sum(COST_NOW), 2),
                     SAVING = round(sum(SAVING, na.rm = TRUE), 2),
                     SAVING_IF_CONFIRMED = round(sum(SAVING_IF_CONFIRMED, na.rm = TRUE), 2), .groups = "drop") |>
    dplyr::arrange(match(CLASS, .INVENTORY_CLASSES))
}

.inventory_environments <- function(environments) {
  columns <- c("FROM", "TO", "USERS_BOTH", "USERS_FROM_ONLY", "USERS_TO_ONLY", "COST_FROM", "COST_TO", "DIFFERENCE")
  if (length(environments) == 0L) {
    return(tibble::tibble(FROM = character(), TO = character(), USERS_BOTH = integer(), USERS_FROM_ONLY = integer(),
                          USERS_TO_ONLY = integer(), COST_FROM = numeric(), COST_TO = numeric(), DIFFERENCE = numeric()))
  }
  dplyr::bind_rows(lapply(environments, function(comparison) {
    if (!all(columns %in% names(comparison$Check))) {
      stop("environments must hold results of compare_environment_license_cost().", call. = FALSE)
    }
    tibble::as_tibble(comparison$Check[columns])
  }))
}
