# =============================================================================
# Schluesseldatei der Pseudonymisierung
#
# Verwendet von anonymize_data(), deanonymize_data() und deanonymize_workbook().
#
# Aufbau eines Pseudonyms: <KATEGORIE>_<KENNUNG>_<NUMMER>, z.B. USER_K7QF_0012.
# Die Kennung gehoert zur Schluesseldatei: Pseudonyme aus einem anderen
# Schluessel werden dadurch nicht stillschweigend falschen Werten zugeordnet.
# =============================================================================

.ANONYMIZATION_KEY_SHEET   <- "Key"
.ANONYMIZATION_KEY_COLUMNS <- c("CATEGORY", "ORIGINAL", "PSEUDONYM")

# Mindestbreite der laufenden Nummer.
.PSEUDONYM_DIGITS <- 4L

# Kennung der Schluesseldatei: ohne I, O, 0 und 1, die sich leicht verwechseln.
.KEY_TAG_LENGTH  <- 4L
.KEY_TAG_SYMBOLS <- c(setdiff(LETTERS, c("I", "O")), as.character(2:9))

.PSEUDONYM_PATTERN <- "^([A-Z][A-Z0-9]*)_([A-Z2-9]{4})_([0-9]{4,})$"

.is_single_string <- function(x) {
  is.character(x) && length(x) == 1L && !is.na(x) && nzchar(x)
}

.check_key_path <- function(key_path) {

  if (!.is_single_string(key_path)) {
    stop("key_path muss der Pfad genau einer Schlüsseldatei (.xlsx) sein.")
  }

  invisible(key_path)
}

.empty_anonymization_key <- function() {
  tibble::tibble(
    CATEGORY  = character(),
    ORIGINAL  = character(),
    PSEUDONYM = character()
  )
}

# Liest und prueft die Schluesseldatei; ohne Datei beginnt ein leerer Schluessel.
.read_anonymization_key <- function(key_path) {

  if (!file.exists(key_path)) {
    return(.empty_anonymization_key())
  }

  not_a_key <- paste0(
    key_path, " ist keine lesbare Schlüsseldatei (Blatt '",
    .ANONYMIZATION_KEY_SHEET, "' mit den Spalten ",
    paste(.ANONYMIZATION_KEY_COLUMNS, collapse = ", "),
    "). Die Datei wird nicht verändert."
  )

  sheets <- tryCatch(readxl::excel_sheets(key_path), error = function(e) character())

  if (!.ANONYMIZATION_KEY_SHEET %in% sheets) {
    stop(not_a_key)
  }

  key <- readxl::read_excel(key_path, sheet = .ANONYMIZATION_KEY_SHEET, col_types = "text")

  if (!all(.ANONYMIZATION_KEY_COLUMNS %in% names(key))) {
    stop(not_a_key)
  }

  key <- key[, .ANONYMIZATION_KEY_COLUMNS]
  key <- key[rowSums(!is.na(key)) > 0L, ]   # von Hand eingefuegte Leerzeilen

  .validate_anonymization_key(key, key_path)
}

# Ein von Hand geaenderter Schluessel darf keine Zuordnung verfaelschen.
.validate_anonymization_key <- function(key, key_path) {

  well_formed <- !is.na(key$PSEUDONYM) &
    grepl(.PSEUDONYM_PATTERN, key$PSEUDONYM) &
    sub(.PSEUDONYM_PATTERN, "\\1", key$PSEUDONYM) == key$CATEGORY

  problems <- c(
    if (anyNA(key)) "leere Zellen",
    if (!all(well_formed, na.rm = TRUE) || anyNA(well_formed)) "Pseudonyme mit unerwartetem Aufbau",
    if (length(unique(.pseudonym_tag(key$PSEUDONYM[which(well_formed)]))) > 1L) "mehrere Schlüsselkennungen",
    if (anyDuplicated(key$PSEUDONYM) > 0L) "doppelte Pseudonyme",
    if (anyDuplicated(paste(key$CATEGORY, .identifier_key(key$ORIGINAL))) > 0L) "doppelte Originalwerte"
  )

  if (length(problems) > 0L) {
    stop(
      "Die Schlüsseldatei ", key_path, " ist beschädigt: ",
      paste(problems, collapse = "; "), ". Die Datei wird nicht verändert."
    )
  }

  key
}

# Fuer die Rueckfuehrung muss die Schluesseldatei vorhanden sein.
.read_existing_key <- function(key_path) {

  if (!file.exists(key_path)) {
    stop("Schlüsseldatei nicht gefunden: ", key_path)
  }

  .read_anonymization_key(key_path)
}

# Schreibt erst vollstaendig in eine Datei daneben und ersetzt dann: Ein
# Abbruch mitten im Schreiben zerstoert den bisherigen Schluessel nicht.
.write_anonymization_key <- function(key, key_path) {

  folder <- dirname(key_path)

  if (!dir.exists(folder)) {
    dir.create(folder, recursive = TRUE)
  }

  workbook <- openxlsx::createWorkbook(creator = .WORKBOOK_CREATOR)
  openxlsx::addWorksheet(workbook, .ANONYMIZATION_KEY_SHEET)
  openxlsx::writeData(workbook, .ANONYMIZATION_KEY_SHEET, key)

  temporary <- tempfile(pattern = "key-", tmpdir = folder, fileext = ".xlsx")
  on.exit(unlink(temporary), add = TRUE)

  openxlsx::saveWorkbook(workbook, temporary, overwrite = TRUE)

  if (!file.rename(temporary, key_path)) {
    stop(
      "Die Schlüsseldatei konnte nicht geschrieben werden: ", key_path,
      ". Ist sie in einem anderen Programm geöffnet?"
    )
  }

  invisible(key_path)
}

.pseudonym_tag <- function(pseudonyms) {
  sub(.PSEUDONYM_PATTERN, "\\2", pseudonyms)
}

.key_tag <- function(key) {

  if (nrow(key) > 0L) {
    return(.pseudonym_tag(key$PSEUDONYM[[1]]))
  }

  paste(
    .draw_unseeded(function() sample(.KEY_TAG_SYMBOLS, .KEY_TAG_LENGTH, replace = TRUE)),
    collapse = ""
  )
}

# Zieht Zufallszahlen unabhaengig von einem Seed des Aufrufers und laesst
# dessen Zufallszahlenfolge unveraendert. Mit festem Seed liesse sich die
# Vergabe der Nummern sonst nachrechnen.
.draw_unseeded <- function(draw) {

  had_seed <- exists(".Random.seed", envir = globalenv(), inherits = FALSE)
  old_seed <- if (had_seed) get(".Random.seed", envir = globalenv(), inherits = FALSE)

  on.exit(
    if (had_seed) {
      assign(".Random.seed", old_seed, envir = globalenv())
    } else if (exists(".Random.seed", envir = globalenv(), inherits = FALSE)) {
      rm(".Random.seed", envir = globalenv())
    },
    add = TRUE
  )

  set.seed(NULL)
  draw()
}

# Ergaenzt den Schluessel um Zeilen fuer neue Werte. `candidates` hat die
# Spalten CATEGORY und ORIGINAL.
.extend_anonymization_key <- function(key, candidates) {

  tag <- .key_tag(key)

  new_rows <- lapply(unique(candidates$CATEGORY), function(category) {
    .new_key_rows(
      category,
      candidates$ORIGINAL[candidates$CATEGORY == category],
      key[key$CATEGORY == category, ],
      tag
    )
  })

  dplyr::bind_rows(c(list(key), new_rows)) |>
    dplyr::arrange(CATEGORY, PSEUDONYM)
}

# Schluesselzeilen fuer Werte, die der Schluessel noch nicht kennt.
.new_key_rows <- function(category, values, known, tag) {

  value_keys <- .identifier_key(values)

  is_new <- !value_keys %in% .identifier_key(known$ORIGINAL) &
    !values %in% known$PSEUDONYM &
    !duplicated(value_keys)

  fresh <- values[is_new]

  if (length(fresh) == 0L) {
    return(NULL)
  }

  # Zufaellige Reihenfolge: Die Nummer verraet nichts ueber den echten Wert.
  fresh <- fresh[.draw_unseeded(function() sample.int(length(fresh)))]

  tibble::tibble(
    CATEGORY  = category,
    ORIGINAL  = fresh,
    PSEUDONYM = .format_pseudonym(
      category, tag,
      .last_pseudonym_number(known$PSEUDONYM) + seq_along(fresh)
    )
  )
}

.last_pseudonym_number <- function(pseudonyms) {

  if (length(pseudonyms) == 0L) {
    return(0L)
  }

  max(as.integer(sub(.PSEUDONYM_PATTERN, "\\3", pseudonyms)))
}

.format_pseudonym <- function(category, tag, numbers) {
  paste0(
    category, "_", tag, "_",
    formatC(numbers, width = .PSEUDONYM_DIGITS, flag = "0", format = "d")
  )
}
