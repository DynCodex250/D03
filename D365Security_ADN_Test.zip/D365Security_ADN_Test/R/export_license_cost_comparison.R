# =============================================================================
# Workbooks of compare_assigned_license_cost() and compare_environment_license_cost():
# overview, users, licenses or roles, prices, legend. The sheets of the users hold user
# ids.
# =============================================================================

.assigned_cost_texts <- function(language) {
  list(
    en = list(
      sheets   = c(overview = "Overview", users = "Users", licenses = "Licenses", prices = "Prices", legend = "Legend"),
      title    = "License costs: required against assigned (PPAC license report)",
      facts    = c("Created", "Report as of", "Users", "Costs of the required licenses per month",
                   "Costs of the assigned licenses per month", "Missing licenses add per month", "Users with a missing license",
                   "Licenses beyond the need cost per month", "Users with more than needed", "Prices"),
      users    = c("User", "Required", "Assigned", "Missing according to the report", "Costs required", "Costs assigned",
                   "Difference (required - assigned)", "Status"),
      status   = c(MISSING = "missing", MORE_THAN_NEEDED = "more than needed", OK = "fits"),
      licenses = c("License", "Users who need it", "Users who have it", "Users who miss it"),
      note     = paste("The report covers the production environment. A positive difference is what the missing licenses",
                       "add once they are assigned; a negative one what could be saved. The sheet Users holds user ids;",
                       "do not pass it on.")
    ),
    de = list(
      sheets   = c(overview = "Überblick", users = "Benutzer", licenses = "Lizenzen", prices = "Preise", legend = "Legende"),
      title    = "Lizenzkosten: benötigt gegenüber zugewiesen (PPAC-Lizenzbericht)",
      facts    = c("Erstellt", "Stand des Berichts", "Benutzer", "Kosten der benötigten Lizenzen je Monat",
                   "Kosten der zugewiesenen Lizenzen je Monat", "Fehlende Lizenzen kosten zusätzlich je Monat",
                   "Benutzer mit fehlender Lizenz", "Lizenzen über den Bedarf kosten je Monat", "Benutzer mit mehr als nötig",
                   "Preise"),
      users    = c("Benutzer", "Benötigt", "Zugewiesen", "Fehlt laut Bericht", "Kosten benötigt", "Kosten zugewiesen",
                   "Differenz (benötigt - zugewiesen)", "Status"),
      status   = c(MISSING = "fehlt", MORE_THAN_NEEDED = "mehr als nötig", OK = "passt"),
      licenses = c("Lizenz", "Benutzer, die sie brauchen", "Benutzer, die sie haben", "Benutzer, denen sie fehlt"),
      note     = paste("Der Bericht gilt für die Produktivumgebung. Eine positive Differenz kommt hinzu, sobald die",
                       "fehlenden Lizenzen zugewiesen sind; eine negative ließe sich sparen. Das Blatt Benutzer enthält",
                       "Benutzerkennungen; nicht weitergeben.")
    )
  )[[language]]
}

.environment_cost_texts <- function(language, from, to) {
  list(
    en = list(
      sheets = c(overview = "Overview", users = "Users", roles = "Roles", prices = "Prices", legend = "Legend"),
      title  = "License costs of two environments (detailed PPAC license report)",
      facts  = c("Created", "Compared with", "Its report as of", "Changed environment", "Its report as of", "Users in both",
                 paste("Users only in", from), paste("Users only in", to), paste("License costs per month in", from),
                 paste("License costs per month in", to), "Difference per month", "Prices"),
      users  = c("User", "In", paste("Licenses", from), paste("Licenses", to), paste("Costs", from), paste("Costs", to),
                 sprintf("Difference (%s - %s)", to, from)),
      within = c(BOTH = "both", FROM_ONLY = paste("only", from), TO_ONLY = paste("only", to)),
      roles  = c("Role", paste("Users", from), paste("Users", to), paste("Licenses", from), paste("Licenses", to),
                 paste("Costs only because of the role,", from), paste("Costs only because of the role,", to),
                 "Difference"),
      note   = paste("In a sandbox the report counts no license; compared is the license the role would need in",
                     "production. Totals and roles cover only the users in both environments. The sheet Users holds",
                     "user ids; do not pass it on.")
    ),
    de = list(
      sheets = c(overview = "Überblick", users = "Benutzer", roles = "Rollen", prices = "Preise", legend = "Legende"),
      title  = "Lizenzkosten zweier Umgebungen im Vergleich (detaillierter PPAC-Lizenzbericht)",
      facts  = c("Erstellt", "Verglichen mit", "Stand ihres Berichts", "Geänderte Umgebung", "Stand ihres Berichts",
                 "Benutzer in beiden", paste("Benutzer nur in", from), paste("Benutzer nur in", to),
                 paste("Lizenzkosten je Monat in", from), paste("Lizenzkosten je Monat in", to), "Differenz je Monat",
                 "Preise"),
      users  = c("Benutzer", "In", paste("Lizenzen", from), paste("Lizenzen", to), paste("Kosten", from), paste("Kosten", to),
                 sprintf("Differenz (%s - %s)", to, from)),
      within = c(BOTH = "beiden", FROM_ONLY = paste("nur", from), TO_ONLY = paste("nur", to)),
      roles  = c("Rolle", paste("Benutzer", from), paste("Benutzer", to), paste("Lizenzen", from), paste("Lizenzen", to),
                 paste("Kosten nur wegen der Rolle,", from), paste("Kosten nur wegen der Rolle,", to), "Differenz"),
      note   = paste("In einer Testumgebung zählt der Bericht keine Lizenz; verglichen wird die Lizenz, die die Rolle in",
                     "der Produktion bräuchte. Summen und Rollen nur über die Benutzer in beiden Umgebungen. Das Blatt",
                     "Benutzer enthält Benutzerkennungen; nicht weitergeben.")
    )
  )[[language]]
}

.LICENSE_COST_RULE <- c(
  "Costs", paste("Of the base licenses the first in the order SCM, Finance, Commerce counts at its base price,",
                 "every further one at its attach price (SCM Base + Finance Attach + Commerce Attach). Without a base",
                 "license the dearest light license. Per user and month."),
  "Kosten", paste("Von den Basislizenzen zählt die erste in der Reihenfolge SCM, Finance, Commerce mit ihrem",
                  "Basispreis, jede weitere mit ihrem Attach-Preis (SCM Base + Finance Attach + Commerce Attach). Ohne",
                  "Basislizenz die teuerste leichte Lizenz. Je Benutzer und Monat.")
)

.ASSIGNED_COST_LEGEND <- list(
  c("Required, assigned, missing",
    "As the PPAC license report names them per user: the licenses the roles of the user require, the ones assigned, and the required ones not assigned.",
    "Benötigt, zugewiesen, fehlt",
    "Wie der PPAC-Lizenzbericht sie je Benutzer nennt: die Lizenzen, die die Rollen des Benutzers verlangen, die zugewiesenen und die verlangten, die nicht zugewiesen sind."),
  .LICENSE_COST_RULE,
  c("Status",
    "missing: the report names a missing license; more than needed: nothing is missing and the assigned licenses cost more; fits: otherwise.",
    "Status",
    "fehlt: der Bericht nennt eine fehlende Lizenz; mehr als nötig: nichts fehlt, und die zugewiesenen Lizenzen kosten mehr; passt: sonst.")
)

.ENVIRONMENT_COST_LEGEND <- list(
  c("Not Applicable",
    "In a sandbox the report writes Not Applicable (license): no license counts there. The license in brackets is what the role would need in production; it is compared.",
    "Not Applicable",
    "In einer Testumgebung schreibt der Bericht Not Applicable (Lizenz): Dort zählt keine Lizenz. Die Lizenz in Klammern bräuchte die Rolle in der Produktion; sie wird verglichen."),
  .LICENSE_COST_RULE,
  c("Costs only because of the role",
    "Per user: costs with all roles minus the costs without this role; summed over the users in both environments.",
    "Kosten nur wegen der Rolle",
    "Je Benutzer: Kosten mit allen Rollen minus die Kosten ohne diese Rolle; summiert über die Benutzer in beiden Umgebungen."),
  c("Users in both",
    "Totals and roles take the users in both environments, so that users in one of them only do not count as a change. They are listed in Users.",
    "Benutzer in beiden",
    "Summen und Rollen nehmen die Benutzer in beiden Umgebungen, damit Benutzer, die nur in einer sind, nicht als Änderung zählen. Sie stehen im Blatt Benutzer.")
)

.export_assigned_license_cost <- function(result, export_path, language) {

  texts <- .assigned_cost_texts(language)
  book  <- .cost_workbook()
  check <- result$Check
  .add_cost_overview(book, texts$sheets[["overview"]], texts$title, texts$facts, c(
    format(check$CREATED, "%Y-%m-%d"), check$REFRESHED_ON, check$USERS, .money(check$REQUIRED_COST),
    .money(check$ASSIGNED_COST), .money(check$MISSING_COST), check$USERS_MISSING, .money(check$SURPLUS_COST),
    check$USERS_MORE_THAN_NEEDED, .price_kind(check, language)
  ), texts$note)

  users <- dplyr::mutate(result$Users, STATUS = unname(texts$status[STATUS]))
  .add_cost_table(book, texts$sheets[["users"]], users, texts$users, c(24, 44, 44, 34, 16, 16, 20, 16), 5:7)
  .add_cost_table(book, texts$sheets[["licenses"]], result$Licenses, texts$licenses, c(34, 20, 20, 20))
  .add_cost_prices_and_legend(book, result$Prices, texts$sheets, language, .ASSIGNED_COST_LEGEND)
  .save_cost_workbook(book, export_path)
}

.export_environment_license_cost <- function(result, export_path, language) {

  check <- result$Check
  texts <- .environment_cost_texts(language, check$FROM, check$TO)
  book  <- .cost_workbook()
  .add_cost_overview(book, texts$sheets[["overview"]], texts$title, texts$facts, c(
    format(check$CREATED, "%Y-%m-%d"), check$FROM, check$REFRESHED_FROM, check$TO, check$REFRESHED_TO, check$USERS_BOTH,
    check$USERS_FROM_ONLY, check$USERS_TO_ONLY, .money(check$COST_FROM), .money(check$COST_TO), .money(check$DIFFERENCE),
    .price_kind(check, language)
  ), texts$note)

  users <- dplyr::mutate(result$Users, IN = unname(texts$within[IN]))
  .add_cost_table(book, texts$sheets[["users"]], users, texts$users, c(24, 18, 44, 44, 16, 16, 20), 5:7)
  .add_cost_table(book, texts$sheets[["roles"]], result$Roles, texts$roles, c(44, 14, 14, 40, 40, 20, 20, 16), 6:8)
  .add_cost_prices_and_legend(book, result$Prices, texts$sheets, language, .ENVIRONMENT_COST_LEGEND)
  .save_cost_workbook(book, export_path)
}

.money <- function(amount) format(round(amount, 2), nsmall = 2)

.price_kind <- function(check, language) {
  kinds <- .license_cost_texts(language)$price_kind
  if (isTRUE(check$PRICES_ESTIMATED)) kinds[[1]] else kinds[[2]]
}

.cost_workbook <- function() {
  list(
    workbook = openxlsx::createWorkbook(creator = .WORKBOOK_CREATOR),
    header   = openxlsx::createStyle(textDecoration = "bold", fgFill = "#DDEBF7", border = "bottom", wrapText = TRUE),
    amount   = openxlsx::createStyle(numFmt = "#,##0.00")
  )
}

.add_cost_overview <- function(book, sheet, title, labels, values, note) {
  facts <- data.frame(label = labels, value = as.character(values), stringsAsFactors = FALSE)
  openxlsx::addWorksheet(book$workbook, sheet)
  openxlsx::writeData(book$workbook, sheet, title, startRow = 1L)
  openxlsx::addStyle(book$workbook, sheet, openxlsx::createStyle(textDecoration = "bold", fontSize = 13), rows = 1L, cols = 1L)
  openxlsx::writeData(book$workbook, sheet, facts, startRow = 3L, colNames = FALSE)
  openxlsx::writeData(book$workbook, sheet, note, startRow = nrow(facts) + 4L)
  openxlsx::setColWidths(book$workbook, sheet, cols = 1:2, widths = c(48, 40))
  invisible(book)
}

.add_cost_table <- function(book, sheet, table, labels, widths, money = integer()) {
  named <- stats::setNames(as.data.frame(table, stringsAsFactors = FALSE), labels)
  .add_duty_check_table(book$workbook, sheet, named, book$header, widths)
  if (length(money) > 0L && nrow(table) > 0L) {
    openxlsx::addStyle(book$workbook, sheet, book$amount, rows = seq_len(nrow(table)) + 1L, cols = money, gridExpand = TRUE)
  }
  invisible(book)
}

.add_cost_prices_and_legend <- function(book, prices, sheets, language, legend) {
  .add_cost_table(book, sheets[["prices"]], prices, .license_cost_texts(language)$prices, c(34, 14, 14), 2:3)
  rows <- stats::setNames(as.data.frame(do.call(rbind, legend), stringsAsFactors = FALSE),
                          c("Term", "Meaning", "Begriff", "Bedeutung"))
  .add_duty_check_table(book$workbook, sheets[["legend"]], rows, book$header, .DUTY_CHECK_LEGEND_WIDTHS, wrap = TRUE)
  invisible(book)
}

.save_cost_workbook <- function(book, export_path) {
  dir.create(dirname(export_path), recursive = TRUE, showWarnings = FALSE)
  openxlsx::saveWorkbook(book$workbook, export_path, overwrite = TRUE)
  invisible(export_path)
}
