# =============================================================================
# Workbook of check_duty_against_role()
#
# Five sheets: Overview, Gaps, Privileges, Not closable and Legend. Sheet names,
# headers and values follow the language; the legend shows English and German
# side by side.
# =============================================================================

.DUTY_CHECK_GAP_WIDTHS       <- c(36, 14, 42, 16, 22, 42, 36, 46, 46)
.DUTY_CHECK_PRIVILEGE_WIDTHS <- c(46, 52, 36, 10, 20, 14, 18, 52)
.DUTY_CHECK_LEGEND_WIDTHS    <- c(42, 80, 42, 80)

.export_duty_check <- function(result, export_path, language) {

  texts    <- .duty_check_texts(language)
  license  <- result$Check$LICENSE
  workbook <- openxlsx::createWorkbook(creator = .WORKBOOK_CREATOR)
  header   <- openxlsx::createStyle(textDecoration = "bold", fgFill = "#DDEBF7", border = "bottom", wrapText = TRUE)

  .add_duty_check_overview(workbook, result, texts, header)
  .add_duty_check_table(workbook, texts$sheets[["gaps"]], .duty_check_gaps_sheet(result$Gaps, license, texts),
                        header, .DUTY_CHECK_GAP_WIDTHS)
  .add_duty_check_table(workbook, texts$sheets[["privileges"]], .duty_check_privileges_sheet(result$Privileges, texts),
                        header, .DUTY_CHECK_PRIVILEGE_WIDTHS)
  .add_duty_check_table(workbook, texts$sheets[["not_closable"]], .duty_check_gaps_sheet(result$NotClosable, license, texts),
                        header, .DUTY_CHECK_GAP_WIDTHS)
  .add_duty_check_table(workbook, texts$sheets[["legend"]], .duty_check_legend(license),
                        header, .DUTY_CHECK_LEGEND_WIDTHS, wrap = TRUE)

  if (!dir.exists(dirname(export_path))) {
    dir.create(dirname(export_path), recursive = TRUE)
  }
  openxlsx::saveWorkbook(workbook, export_path, overwrite = TRUE)

  invisible(export_path)
}

.add_duty_check_overview <- function(workbook, result, texts, header) {

  sheet <- texts$sheets[["overview"]]
  check <- result$Check
  facts <- data.frame(
    label = texts$facts,
    value = c(
      check$SOURCE_ROLE, .duty_check_listed(check$DUTIES, texts$none), .duty_check_listed(check$PRIVILEGES, texts$none),
      check$TARGET_ROLE, check$LICENSE, format(check$CREATED, "%Y-%m-%d")
    ),
    stringsAsFactors = FALSE
  )
  lines_row   <- nrow(facts) + 4L
  summary_row <- lines_row + 3L

  openxlsx::addWorksheet(workbook, sheet)
  openxlsx::writeData(workbook, sheet, sub("%s", check$TARGET_ROLE, texts$title, fixed = TRUE), startRow = 1L)
  openxlsx::addStyle(workbook, sheet, openxlsx::createStyle(textDecoration = "bold", fontSize = 13), rows = 1L, cols = 1L)
  openxlsx::writeData(workbook, sheet, facts, startRow = 3L, colNames = FALSE)
  openxlsx::writeData(workbook, sheet, c(.duty_check_result_line(result, texts), texts$read_first), startRow = lines_row)
  openxlsx::writeData(workbook, sheet, .duty_check_summary_sheet(result$Summary, check$LICENSE, texts),
                      startRow = summary_row, headerStyle = header)
  openxlsx::setColWidths(workbook, sheet, cols = 1:4, widths = c(48, 62, 14, 14))

  invisible(workbook)
}

.add_duty_check_table <- function(workbook, sheet, table, header, widths, wrap = FALSE) {

  openxlsx::addWorksheet(workbook, sheet)
  openxlsx::writeData(workbook, sheet, table, headerStyle = header, withFilter = nrow(table) > 0L)
  openxlsx::freezePane(workbook, sheet, firstRow = TRUE)
  openxlsx::setColWidths(workbook, sheet, cols = seq_along(widths), widths = widths)

  if (wrap && nrow(table) > 0L) {
    openxlsx::addStyle(
      workbook, sheet, openxlsx::createStyle(wrapText = TRUE, valign = "top"),
      rows = seq_len(nrow(table)) + 1L, cols = seq_along(widths), gridExpand = TRUE
    )
  }

  invisible(workbook)
}

.duty_check_listed <- function(names, none) {
  if (length(names) == 0L) none else paste(names, collapse = .LIST_SEPARATOR)
}

.duty_check_result_line <- function(result, texts) {

  gaps <- result$Gaps

  sprintf(
    texts$result,
    sum(unlist(result$Summary[.DUTY_CHECK_STATES])), nrow(gaps),
    sum(result$Privileges$ACTION == "ADD"), sum(!is.na(gaps$CLOSED_BY)), sum(is.na(gaps$CLOSED_BY))
  )
}

.duty_check_group_label <- function(group, license, texts) {
  sub("%s", license, unname(texts$groups[group]), fixed = TRUE)
}

.duty_check_no_duty <- function(duties, texts) {
  gsub(.DUTY_CHECK_NO_DUTY, texts$no_duty, duties, fixed = TRUE)
}

.duty_check_summary_sheet <- function(summary, license, texts) {

  table <- data.frame(
    .duty_check_group_label(summary$GROUP, license, texts), summary$IN_ROLE, summary$ONLY_READ, summary$MISSING,
    stringsAsFactors = FALSE
  )
  names(table) <- texts$summary_columns

  table
}

.duty_check_gaps_sheet <- function(gaps, license, texts) {

  table <- data.frame(
    .duty_check_group_label(gaps$GROUP, license, texts),
    unname(texts$states[gaps$STATE]),
    gaps$OBJECT,
    .access_label(gaps$ACCESS),
    .access_label(gaps$TARGET_ACCESS),
    gaps$LICENSE,
    .duty_check_no_duty(gaps$DUTIES, texts),
    gaps$PRIVILEGES,
    gaps$CLOSED_BY,
    stringsAsFactors = FALSE
  )
  names(table) <- texts$gap_columns

  table
}

.duty_check_privileges_sheet <- function(privileges, texts) {

  table <- data.frame(
    privileges$PRIVILEGE,
    privileges$NAME,
    .duty_check_no_duty(privileges$DUTIES, texts),
    privileges$OBJECTS,
    privileges$NOT_COVERED,
    privileges$GAPS,
    ifelse(privileges$IN_ROLE_ALREADY, texts$yes_no[["yes"]], texts$yes_no[["no"]]),
    .duty_check_action_label(privileges, texts),
    stringsAsFactors = FALSE
  )
  names(table) <- texts$privilege_columns

  table
}

# "add: closes 6 gaps", "not possible: 23 objects need another license", ...
.duty_check_action_label <- function(privileges, texts) {

  count <- dplyr::case_when(
    privileges$ACTION == "ADD"          ~ privileges$GAPS,
    privileges$ACTION == "NOT_POSSIBLE" ~ privileges$NOT_COVERED,
    TRUE                                ~ 0L
  )

  vapply(seq_along(count), function(i) {
    forms <- texts$actions[[privileges$ACTION[[i]]]]
    form  <- if (count[[i]] == 1L) forms[["one"]] else forms[["other"]]
    sub("%d", count[[i]], form, fixed = TRUE)
  }, character(1))
}

# Every entry of the legend in English and German, side by side.
.duty_check_legend <- function(license) {

  english <- .duty_check_texts("en")$legend
  german  <- .duty_check_texts("de")$legend[names(english)]
  part    <- function(entries, position) {
    sub("%s", license, vapply(entries, `[[`, character(1), position, USE.NAMES = FALSE), fixed = TRUE)
  }

  data.frame(
    Term      = part(english, 1L),
    Meaning   = part(english, 2L),
    Begriff   = part(german, 1L),
    Bedeutung = part(german, 2L),
    stringsAsFactors = FALSE
  )
}
