# =============================================================================
# Files of build_license_roles()
#
# One AOT role file per license, one AOT privilege file per new privilege, both
# packed into one zip; the roles and new privileges together in the two files for
# the import in the browser; and the workbook. The grants of the new privileges and
# the direct access permissions of the role come from UserSecGovRelatedObjects;
# without it, the grants are derived from the access level of the license graph.
# =============================================================================

.GRANTS <- c("Correct", "Create", "Delete", "Invoke", "Read", "Update")

.write_license_roles <- function(con, result, roles, export_folder, language) {

  dir.create(export_folder, recursive = TRUE, showWarnings = FALSE)
  security  <- .license_role_security(con, result$Check$ROLE)
  role_data <- lapply(roles, .license_role_data, direct = .role_direct_access(security))

  role_files <- vapply(role_data, function(data) {
    .write_metadata_file(export_folder, .AOT_ROLE_FOLDER, data$role_name, function(path) create_d365fo_role_xml(data, path))
  }, character(1))

  privileges      <- .new_privileges(roles, security)
  privilege_files <- vapply(names(privileges), function(name) {
    .write_metadata_file(export_folder, .AOT_PRIVILEGE_FOLDER, name, function(path) {
      xml2::write_xml(privileges[[name]], path, options = "format")
    })
  }, character(1), USE.NAMES = FALSE)

  file_name <- paste0(result$Check$PREFIX, "_license_roles")
  browser   <- .write_browser_files(export_folder, file_name, new_roles = role_data, new_privileges = unname(privileges))

  workbook <- file.path(export_folder, paste0(file_name, ".xlsx"))
  .export_license_roles(result, workbook, language)

  list(
    zip                    = .zip_metadata(export_folder, c(role_files, privilege_files), file_name),
    workbook               = workbook,
    security_governance    = browser[["governance"]],
    security_configuration = browser[["configuration"]]
  )
}

# A license role as create_d365fo_role_xml() takes it. The new roles have no
# sub-roles: they hold the content of the sub-roles of the role.
.license_role_data <- function(role, direct) {
  blocks <- role$blocks
  list(
    role_name   = role$name,
    role_label  = .label_of_name(role$name),
    duties      = blocks$BLOCK_ID[blocks$BLOCK_TYPE == "Duty"],
    privileges  = blocks$BLOCK_ID[blocks$BLOCK_TYPE %in% c("Privilege", "NewPrivilege")],
    subroles    = character(),
    direct_access_permissions = direct
  )
}

# "_WIBU_Verkauf_SCM" is labelled "_WIBU Verkauf SCM".
.label_of_name <- function(name) sub("^ ", "_", gsub("_", " ", name, fixed = TRUE))

# Writes <folder>/<subfolder>/<name>.xml and returns the path below the folder.
.write_metadata_file <- function(folder, subfolder, name, write) {
  file <- file.path(subfolder, paste0(name, ".xml"))
  path <- file.path(folder, file)
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  write(path)
  file
}

.license_role_security <- function(con, role) {
  tryCatch(
    load_sql_security_role_objects_detailed(con, role),
    error = function(e) {
      warning(
        "UserSecGovRelatedObjects could not be read: the new privileges get their grants from the license graph ",
        "and the roles no direct access permissions. ", .without_sql_statement(conditionMessage(e)),
        call. = FALSE
      )
      NULL
    }
  )
}

# The direct access permissions of the role and of its sub-roles: a new role
# holds the content of the sub-roles, so it takes their tables too.
.role_direct_access <- function(security) {
  if (is.null(security) || nrow(security) == 0L) {
    return(.empty_direct_access())
  }
  direct <- .is_blank(security$DUTYIDENTIFIER) & .is_blank(security$PRIVILEGEIDENTIFIER) &
    security$Ebene %in% c("Entity", "Field")
  .as_direct_access(security[direct, ])
}

.empty_direct_access <- function() {
  tibble::tibble(ObjektTyp = character(), Objektname = character(), Ebene = character(), Feldname = character(),
                 Create = character(), Correct = character(), Delete = character(),
                 Invoke = character(), Read = character(), Update = character())
}

# The new privileges of all roles as AxSecurityPrivilege documents, named by
# privilege; a name two roles share, in any spelling, is written once.
.new_privileges <- function(roles, security) {
  documents <- unlist(lapply(unname(roles), .new_privilege_documents, security = security), recursive = FALSE)
  documents[!duplicated(.identifier_key(names(documents)))]
}

.new_privilege_documents <- function(role, security) {
  new <- role$blocks[role$blocks$BLOCK_TYPE == "NewPrivilege", ]
  documents <- lapply(seq_len(nrow(new)), function(i) {
    source  <- new$SOURCE[[i]]
    removed <- role$not_covered$KEY[.identifier_key(role$not_covered$PRIVILEGEIDENTIFIER) == .identifier_key(source)]
    rows    <- .new_privilege_rows(security, source, removed, role$new_privileges[role$new_privileges$PRIVILEGE == source, ])
    .privilege_xml(new$BLOCK_ID[[i]], .label_of_name(new$BLOCK_ID[[i]]), rows)
  })
  stats::setNames(documents, new$BLOCK_ID)
}

# The rows of the privilege without the objects the license does not cover. From
# UserSecGovRelatedObjects when it holds the privilege, else from the plan.
.new_privilege_rows <- function(security, source, removed, planned) {

  if (!is.null(security)) {
    rows <- security[.identifier_key(security$PRIVILEGEIDENTIFIER) %in% .identifier_key(source), ]
    if (nrow(rows) > 0L) {
      return(rows[!.object_key_of(rows) %in% removed, ])
    }
  }

  warning("UserSecGovRelatedObjects holds no rows of privilege '", source,
          "'; the grants of its new privilege are derived from the access level.", call. = FALSE)
  .rows_from_plan(planned)
}

# The name an object has in the license graph: an entity "Data services\NAME" is NAME.
.object_key_of <- function(rows) {
  is_entity <- .resource_kind(rows) == "DataEntity"
  .identifier_key(ifelse(is_entity, sub("^.*\\\\", "", rows$RESOURCE_), rows$RESOURCE_))
}

.PLAN_RESOURCE_TYPES <- c(MenuItemDisplay = "Menu item display", MenuItemAction = "Menu item action",
                          MenuItemOutput = "Menu item output", DataEntity = "Data entity")

# Read for reading; for writing also update, create and delete, and invoke for an action.
.rows_from_plan <- function(planned) {
  write <- as.numeric(planned$ACCESS) >= 2
  tibble::tibble(
    RESOURCETYPE = unname(.PLAN_RESOURCE_TYPES[planned$TYPE]),
    RESOURCE_    = ifelse(planned$TYPE == "DataEntity", paste0("Data services\\", planned$OBJECT), planned$OBJECT),
    Ebene        = unname(.PLAN_RESOURCE_TYPES[planned$TYPE]),
    Create = as.numeric(write), Correct = 0, Delete = as.numeric(write),
    Invoke = as.numeric(planned$TYPE == "MenuItemAction"), Update = as.numeric(write), Read = 1
  )
}

.add_grant <- function(node, flags) {
  grant <- xml2::xml_add_child(node, "Grant")
  for (permission in .GRANTS) {
    if (isTRUE(flags[[permission]] %in% c(1, "1"))) xml2::xml_add_child(grant, permission, "Allow")
  }
  invisible(grant)
}

.max_flags <- function(rows) {
  lapply(stats::setNames(.GRANTS, .GRANTS), function(permission) max(as.numeric(rows[[permission]]), 0, na.rm = TRUE))
}

# An AOT privilege in the order of an exported privilege file: name, label, data
# entity permissions, direct access permissions, entry points.
.privilege_xml <- function(name, label, rows) {

  doc <- xml2::xml_new_root("AxSecurityPrivilege")
  xml2::xml_set_attr(doc, "xmlns", "")
  xml2::xml_add_child(doc, "Name", name)
  xml2::xml_add_child(doc, "Label", label)

  kind        <- .resource_kind(rows)
  is_menu     <- kind %in% names(.PLAN_RESOURCE_TYPES)[1:3] & !grepl("\\", rows$RESOURCE_, fixed = TRUE)
  .warn_about_left_out(name, rows[!(is_menu | kind %in% c("DataEntity", "Table", "TableField")), ])

  entity_node <- xml2::xml_add_child(doc, "DataEntityPermissions")
  entities    <- rows[kind == "DataEntity", ]
  for (entity in unique(sub("^.*\\\\", "", entities$RESOURCE_))) {
    of_entity <- entities[sub("^.*\\\\", "", entities$RESOURCE_) == entity, ]
    node <- xml2::xml_add_child(entity_node, "AxSecurityDataEntityPermission")
    .add_grant(node, .max_flags(of_entity))
    xml2::xml_add_child(node, "IntegrationMode", .integration_mode(of_entity$RESOURCE_))
    xml2::xml_add_child(node, "Name", entity)
    xml2::xml_add_child(node, "Fields")
    xml2::xml_add_child(node, "Methods")
  }

  tables <- rows[kind %in% c("Table", "TableField"), ]
  write_direct_access_permissions(doc, .as_direct_access(tables))

  # UserSecGovRelatedObjects holds a privilege once per duty it sits in: one entry
  # point per object, with the highest grants.
  entry_node <- xml2::xml_add_child(doc, "EntryPoints")
  menu_items <- dplyr::mutate(rows[is_menu, ], KIND = kind[is_menu])
  for (item in split(menu_items, paste(menu_items$KIND, .identifier_key(menu_items$RESOURCE_)))) {
    type <- item$KIND[[1]]
    node <- xml2::xml_add_child(entry_node, "AxSecurityEntryPointReference")
    xml2::xml_add_child(node, "Name", paste0(item$RESOURCE_[[1]], "_", type))
    .add_grant(node, .max_flags(item))
    xml2::xml_add_child(node, "ObjectName", item$RESOURCE_[[1]])
    xml2::xml_add_child(node, "ObjectType", type)
  }

  doc
}

# Form controls, services and other parts a new privilege cannot hold yet.
.warn_about_left_out <- function(name, rows) {
  if (nrow(rows) > 0L) {
    counts <- table(rows$RESOURCETYPE)
    warning("New privilege ", name, " leaves out ", nrow(rows), " row(s): ",
            paste0(names(counts), " (", counts, ")", collapse = ", "), ". Add them by hand if needed.", call. = FALSE)
  }
  invisible(nrow(rows))
}

# DataServices, DataManagement, or All when the entity comes through both.
.integration_mode <- function(resources) {
  modes <- unique(sub("\\\\.*$", "", resources))
  if (length(modes) > 1L) return("All")
  if (identical(tolower(modes), "data management")) "DataManagement" else "DataServices"
}

# One permission per table and field, with the highest grants.
.as_direct_access <- function(rows) {
  if (nrow(rows) == 0L) {
    return(.empty_direct_access())
  }
  grant_text <- function(x) ifelse(x %in% c(1, "1"), "Allow", "")
  rows |>
    dplyr::mutate(Feldname = ifelse(.is_blank(Feldname), "-", Feldname)) |>
    dplyr::group_by(ObjektTyp, Objektname, Ebene, Feldname) |>
    dplyr::summarise(dplyr::across(dplyr::all_of(.GRANTS), function(x) max(as.numeric(x), 0, na.rm = TRUE)), .groups = "drop") |>
    dplyr::mutate(dplyr::across(dplyr::all_of(.GRANTS), grant_text))
}
