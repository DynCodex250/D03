#' Write the consolidation of AOT and UI roles as deliverable D20
#'
#' Writes the result of \code{\link{plan_role_consolidation}} as the Excel
#' workbook of the deliverable D20 (Rollenkonsolidierung), in German and in
#' the layout of the other deliverables: one row per pair of an AOT role and
#' its copy in the user interface, with the result, the proposed action, the
#' change the tool made, and the columns for the further steps.
#'
#' @details
#'
#' **Sheets.** \code{Anleitung}; \code{Rollenpaare} (one row per pair; blue
#' columns are filled by the tool, the white ones by the team:
#' \code{Entscheidung}, \code{Importiert am}, \code{Benutzer umgestellt am},
#' \code{Alte Rollen entfernt am}, \code{Status}, \code{Bemerkung});
#' \code{Unterschiede_Aufbau} (duties, privileges, sub-roles and direct
#' access that only one version holds or that differ in their rights);
#' \code{Unterschiede_Lizenz} (objects of the license comparison that
#' differ); \code{Merge_Rollen} (one row per merged role with its files) and
#' \code{Listen}. The workbook holds no user ids, only counts.
#'
#' **Pairs without differences** read "Keine Unterschiede" and "Nicht
#' anfassen": both versions stay as they are. When the AOT role of such a pair
#' is merged through another pair, the action reads "Benutzer umstellen": the
#' users of this copy move to the merged role as well.
#'
#' **An earlier D20.** With \code{previous}, the white columns carry over by
#' pair (AOT role and UI role, capitals do not count). Pairs of the earlier
#' D20 with entries of the team that are no longer in \code{plan} are named in
#' a warning.
#'
#' @param plan
#' Result of \code{\link{plan_role_consolidation}}.
#'
#' @param path
#' Path of the workbook to write, in an existing folder.
#'
#' @param previous
#' Optional path of an earlier D20 whose white columns carry over.
#'
#' @param overwrite
#' \code{TRUE} = replace an existing file at \code{path}. Default \code{FALSE}:
#' an existing D20 holds the steps of the team.
#'
#' @return
#' Invisibly \code{path}.
#'
#' @examples
#' \dontrun{
#'
#' plan <- plan_role_consolidation(cnn, merge_folder = "Output/D20/Merge_Rollen")
#' export_role_consolidation(plan, "Output/D20/D20_Rollenkonsolidierung.xlsx")
#'
#' # The next run, with the steps of the team carried over:
#' export_role_consolidation(plan, "Output/D20/D20_Rollenkonsolidierung_neu.xlsx",
#'                           previous = "Output/D20/D20_Rollenkonsolidierung.xlsx")
#'
#' }
#'
#' @seealso
#' \code{\link{plan_role_consolidation}}
#'
#' @export
export_role_consolidation <- function(plan, path, previous = NULL, overwrite = FALSE) {

  .check_consolidation_export(plan, path, previous, overwrite)
  pairs <- .d20_pairs(plan, if (is.null(previous)) NULL else .read_previous_d20(previous))

  wb <- openxlsx::createWorkbook()
  .add_d20_instructions(wb, plan$Check)
  .add_deliverable_sheet(wb, "Rollenpaare", pairs, it = setdiff(names(pairs), .D20_MANUAL))
  .add_deliverable_sheet(wb, "Unterschiede_Aufbau", .d20_structure(plan), all_it = TRUE)
  .add_deliverable_sheet(wb, "Unterschiede_Lizenz", .d20_licenses(plan), all_it = TRUE)
  .add_deliverable_sheet(wb, "Merge_Rollen", .d20_merges(plan$Merges), all_it = TRUE)
  .add_deliverable_sheet(wb, "Listen", .d20_lists())
  .add_d20_validation(wb, pairs)

  openxlsx::saveWorkbook(wb, path, overwrite = TRUE)
  message(sprintf("D20 written: %s (%d pairs: %d without difference, %d to merge, %d to check).", path,
                  plan$Check$PAIRS, plan$Check$NO_DIFFERENCE, plan$Check$MERGE, plan$Check$CHECK))
  invisible(path)
}

.D20_MANUAL <- c("Entscheidung", "Importiert am", "Benutzer umgestellt am", "Alte Rollen entfernt am", "Status", "Bemerkung")
.D20_DATES  <- c("Importiert am", "Benutzer umgestellt am", "Alte Rollen entfernt am")

.D20_RESULTS  <- c(NO_DIFFERENCE = "Keine Unterschiede", MERGE = "Unterschiede", CHECK = "Nicht geladen")
.D20_ACTIONS  <- c(NO_DIFFERENCE = "Nicht anfassen", MERGE = "Zusammenführen", CHECK = "Prüfen")
.D20_VERDICTS <- c(
  SAME      = "Gleiche lizenzrelevante Objekte",
  A_IN_B    = "UI-Rolle enthält die AOT-Rolle und mehr",
  B_IN_A    = "AOT-Rolle enthält die UI-Rolle und mehr",
  DIFFERENT = "Jede gewährt etwas, das der anderen fehlt"
)
.D20_ELEMENTS      <- c(DUTY = "Aufgabe", PRIVILEGE = "Recht", SUBROLE = "Unterrolle", DIRECT_ACCESS = "Direkter Zugriff")
.D20_SIDES         <- c(ONLY_AOT = "nur AOT-Rolle", ONLY_UI = "nur UI-Rolle", OTHER_RIGHTS = "andere Rechte")
.D20_LICENSE_SIDES <- c(ONLY_A = "nur AOT-Rolle", ONLY_B = "nur UI-Rolle", ACCESS = "anderer Zugriff", LICENSE = "andere Lizenz")

.check_consolidation_export <- function(plan, path, previous, overwrite) {
  if (!is.list(plan) || !all(c("Pairs", "Differences", "LicenseDifferences", "Merges", "Check") %in% names(plan))) {
    stop("plan must be the result of plan_role_consolidation().", call. = FALSE)
  }
  if (!.is_single_string(path) || !dir.exists(dirname(path))) {
    stop("path must be a file in an existing folder: '", paste(path, collapse = ", "), "'.", call. = FALSE)
  }
  if (file.exists(path) && !isTRUE(overwrite)) {
    stop("'", path, "' exists. An existing D20 holds the steps of the team: pass it as previous and write to another file, ",
         "or set overwrite = TRUE.", call. = FALSE)
  }
  if (!is.null(previous) && (!.is_single_string(previous) || !file.exists(previous))) {
    stop("previous '", paste(previous, collapse = ", "), "' was not found.", call. = FALSE)
  }
  invisible(TRUE)
}

.d20_key <- function(aot, ui) paste(.identifier_key(aot), .identifier_key(ui), sep = "|")

.read_previous_d20 <- function(previous) {
  if (!"Rollenpaare" %in% readxl::excel_sheets(previous)) {
    warning("'", previous, "' has no sheet Rollenpaare; nothing is carried over.", call. = FALSE)
    return(NULL)
  }
  sheet <- as.data.frame(readxl::read_excel(previous, sheet = "Rollenpaare", col_types = "text"), check.names = FALSE)
  if (!all(c("AOT-Rolle (Systemname)", "UI-Rolle (GUID)") %in% names(sheet))) {
    warning("The sheet Rollenpaare of '", previous, "' lacks the columns of the roles; nothing is carried over.", call. = FALSE)
    return(NULL)
  }
  sheet$KEY <- .d20_key(sheet$`AOT-Rolle (Systemname)`, sheet$`UI-Rolle (GUID)`)
  for (column in intersect(.D20_DATES, names(sheet))) sheet[[column]] <- .excel_date_text(sheet[[column]])
  sheet
}

# Per pair the numbers of the other pairs of its AOT role that are merged; NA for none.
.d20_merge_twins <- function(pairs) {
  keys <- .identifier_key(pairs$ROLE_AOT)
  vapply(seq_len(nrow(pairs)), function(i) {
    twins <- pairs$NUMBER[keys == keys[[i]] & pairs$ACTION == "MERGE" & seq_len(nrow(pairs)) != i]
    if (length(twins) == 0L) NA_character_ else paste(twins, collapse = .LIST_SEPARATOR)
  }, character(1))
}

.d20_actions <- function(pairs) {
  actions <- unname(.D20_ACTIONS[pairs$ACTION])
  actions[pairs$ACTION == "NO_DIFFERENCE" & !is.na(.d20_merge_twins(pairs))] <- "Benutzer umstellen"
  actions
}

.d20_errors <- function(pairs) {
  vapply(seq_len(nrow(pairs)), function(i) {
    errors <- c(pairs$ERROR[[i]], pairs$MERGE_ERROR[[i]], pairs$COMPARE_ERROR[[i]])
    errors <- errors[!is.na(errors)]
    if (length(errors) == 0L) NA_character_ else paste(errors, collapse = " | ")
  }, character(1))
}

# What the tool did with each pair, in words.
.d20_change <- function(pairs) {
  date  <- format(Sys.Date(), "%d.%m.%Y")
  twins <- .d20_merge_twins(pairs)
  vapply(seq_len(nrow(pairs)), function(i) {
    switch(pairs$ACTION[[i]],
      NO_DIFFERENCE = if (is.na(twins[[i]])) {
        "Keine Änderung: Beide Versionen sind gleich aufgebaut; die Rollen werden nicht angefasst."
      } else {
        sprintf(paste("Keine Unterschiede zur AOT-Rolle, aber die AOT-Rolle wird über Paar Nr. %s zusammengeführt%s:",
                      "Benutzer dieser Kopie ebenfalls auf die neue Rolle umstellen, danach die Kopie entfernen."),
                twins[[i]], if (is.na(pairs$MERGED_ROLE[[i]])) "" else paste0(" (neue Rolle ", pairs$MERGED_ROLE[[i]], ")"))
      },
      CHECK         = paste0("Keine Änderung: Eine der Versionen konnte nicht geladen werden (Spalte Fehler).",
                             if (is.na(twins[[i]])) "" else
                               sprintf(" Die Merge-Rolle der AOT-Rolle (Paar Nr. %s) enthält diese Kopie nicht.", twins[[i]])),
      MERGE         = if (!is.na(pairs$MERGED_ROLE[[i]])) {
        sprintf("Neue Rolle %s am %s erzeugt (Blatt Merge_Rollen); noch nicht importiert, Benutzer noch nicht umgestellt.",
                pairs$MERGED_ROLE[[i]], date)
      } else if (!is.na(pairs$MERGE_ERROR[[i]])) {
        "Keine Änderung: Die Merge-Rolle konnte nicht erzeugt werden (Spalte Fehler)."
      } else {
        "Keine Änderung: Unterschiede gefunden, aber keine Merge-Rolle erzeugt (Lauf ohne Merge)."
      }
    )
  }, character(1))
}

.d20_pairs <- function(plan, earlier) {
  p <- plan$Pairs
  sheet <- data.frame(
    "Nr" = p$NUMBER, "AOT-Rolle (Systemname)" = p$ROLE_AOT, "AOT-Rolle (Bezeichnung)" = p$NAME_AOT,
    "UI-Rolle (GUID)" = p$ROLE_UI, "UI-Rolle (Bezeichnung)" = p$NAME_UI,
    "Ergebnis" = unname(.D20_RESULTS[p$ACTION]),
    "Lizenzvergleich" = ifelse(is.na(p$VERDICT), "nicht verglichen", unname(.D20_VERDICTS[p$VERDICT])),
    "Aufgaben nur AOT" = p$DUTIES_ONLY_AOT, "Aufgaben nur UI" = p$DUTIES_ONLY_UI,
    "Rechte nur AOT" = p$PRIVILEGES_ONLY_AOT, "Rechte nur UI" = p$PRIVILEGES_ONLY_UI,
    "Unterrollen nur AOT" = p$SUBROLES_ONLY_AOT, "Unterrollen nur UI" = p$SUBROLES_ONLY_UI,
    "Direkte Zugriffe abweichend" = p$DIRECT_ACCESS_DIFFERENT,
    "Lizenzen AOT" = p$LICENSES_AOT, "Lizenzen UI" = p$LICENSES_UI,
    "Benutzer AOT" = p$USERS_AOT, "Benutzer UI" = p$USERS_UI, "Benutzer mit beiden" = p$USERS_BOTH,
    "Maßnahme (Vorschlag)" = .d20_actions(p), "Neue Rolle (Merge)" = p$MERGED_ROLE,
    "Änderung durch das Werkzeug" = .d20_change(p),
    "Fehler" = .d20_errors(p),
    check.names = FALSE, stringsAsFactors = FALSE
  )
  for (column in .D20_MANUAL) {
    sheet[[column]] <- if (column == "Status") rep("offen", nrow(sheet)) else rep(NA_character_, nrow(sheet))
  }
  if (!is.null(earlier)) {
    keys <- .d20_key(p$ROLE_AOT, p$ROLE_UI)
    at   <- match(keys, earlier$KEY)
    for (column in intersect(.D20_MANUAL, names(earlier))) {
      carried <- earlier[[column]][at]
      sheet[[column]] <- ifelse(is.na(at) | is.na(carried), sheet[[column]], carried)
    }
    .warn_on_gone_d20_pairs(earlier, keys)
  }
  sheet
}

# Entries of the team for pairs that the new plan no longer holds would be lost without a word.
.warn_on_gone_d20_pairs <- function(earlier, keys) {
  entries <- earlier[, intersect(setdiff(.D20_MANUAL, "Status"), names(earlier)), drop = FALSE]
  touched <- rowSums(!is.na(entries)) > 0L
  if ("Status" %in% names(earlier)) touched <- touched | (!is.na(earlier$Status) & earlier$Status != "offen")
  gone <- earlier[touched & !earlier$KEY %in% keys, ]
  if (nrow(gone) > 0L) {
    warning(nrow(gone), " pairs of the earlier D20 hold entries of the team but are no longer in the plan; ",
            "their entries are not carried over: ",
            paste(gone$`AOT-Rolle (Systemname)`, gone$`UI-Rolle (GUID)`, sep = " + ", collapse = "; "), call. = FALSE)
  }
  invisible(gone)
}

# The two roles of the pairs with these numbers.
.d20_roles_of <- function(plan, numbers) {
  at <- match(numbers, plan$Pairs$NUMBER)
  list(aot = plan$Pairs$ROLE_AOT[at], ui = plan$Pairs$ROLE_UI[at])
}

.d20_structure <- function(plan) {
  d     <- plan$Differences
  roles <- .d20_roles_of(plan, d$NUMBER)
  data.frame(
    "Nr" = d$NUMBER, "AOT-Rolle" = roles$aot, "UI-Rolle" = roles$ui,
    "Element" = unname(.D20_ELEMENTS[d$ELEMENT]), "Name" = d$NAME, "Seite" = unname(.D20_SIDES[d$SIDE]),
    "Rechte AOT" = d$RIGHTS_AOT, "Rechte UI" = d$RIGHTS_UI, check.names = FALSE, stringsAsFactors = FALSE
  )
}

.EMPTY_LICENSE_DIFFERENCES <- tibble::tibble(
  NUMBER = integer(), SIDE = character(), OBJECT = character(), TYPE = character(),
  ACCESS_A = numeric(), ACCESS_B = numeric(), NEED_A = character(), NEED_B = character()
)

.d20_licenses <- function(plan) {
  d     <- dplyr::bind_rows(.EMPTY_LICENSE_DIFFERENCES, plan$LicenseDifferences)
  roles <- .d20_roles_of(plan, d$NUMBER)
  data.frame(
    "Nr" = d$NUMBER, "AOT-Rolle" = roles$aot, "UI-Rolle" = roles$ui, "Objekt" = d$OBJECT, "Typ" = d$TYPE,
    "Seite" = unname(.D20_LICENSE_SIDES[d$SIDE]), "Zugriff AOT" = .access_label(d$ACCESS_A),
    "Zugriff UI" = .access_label(d$ACCESS_B), "Lizenz AOT" = d$NEED_A, "Lizenz UI" = d$NEED_B,
    check.names = FALSE, stringsAsFactors = FALSE
  )
}

.d20_merges <- function(merges) {
  data.frame(
    "Neue Rolle" = merges$MERGED_ROLE, "AOT-Rolle" = merges$ROLE_AOT, "UI-Rollen" = merges$ROLES_UI,
    "Paare (Nr)" = merges$NUMBERS, "Aufgaben" = merges$DUTIES, "Rechte" = merges$PRIVILEGES,
    "Unterrollen" = merges$SUBROLES, "Direkte Zugriffe" = merges$DIRECT_ACCESS,
    "AOT-Datei (Visual Studio)" = merges$XML, "Zip" = merges$ZIP,
    "Datei Sicherheitskonfiguration" = merges$CONFIGURATION, "Datei Sicherheitsgovernance" = merges$GOVERNANCE,
    "Fehler" = merges$ERROR, check.names = FALSE, stringsAsFactors = FALSE
  )
}

.d20_lists <- function() {
  lists <- list("Entscheidung" = c("Merge übernehmen", "AOT-Rolle behalten", "UI-Rolle behalten", "Nicht anfassen"),
                "Status" = c("offen", "in Arbeit", "erledigt"))
  as.data.frame(lapply(lists, function(x) c(x, rep("", max(lengths(lists)) - length(x)))), check.names = FALSE)
}

.add_d20_validation <- function(wb, pairs) {
  lists <- .d20_lists()
  rows  <- seq_len(max(nrow(pairs), 1L)) + 1L
  for (column in names(lists)) {
    list_col <- which(names(lists) == column)
    letter   <- openxlsx::int2col(list_col)
    value    <- sprintf("'Listen'!$%s$2:$%s$%d", letter, letter, 1L + sum(nzchar(lists[[list_col]])))
    openxlsx::dataValidation(wb, "Rollenpaare", cols = which(names(pairs) == column), rows = rows, type = "list", value = value)
  }
  invisible(wb)
}

.add_d20_instructions <- function(wb, check) {
  text <- c(
    "D20 Rollenkonsolidierung: AOT-Rollen und ihre Kopien in der Oberfläche",
    paste0("Erzeugt am ", format(Sys.Date(), "%d.%m.%Y")),
    "",
    "Worum es geht",
    "Viele Rollen gibt es zweimal: als AOT-Rolle aus der Entwicklung und als Kopie, die in der Oberfläche angelegt wurde (Bezeichner GUID). Beide tun nicht immer dasselbe, und Benutzer haben mal die eine, mal die andere, mal beide. Bevor eine solche Rolle geändert, bereinigt oder neu lizenziert wird, werden beide Versionen zusammengeführt (Strategie, Leitprinzip „Erst konsolidieren, dann ändern“).",
    "",
    "Kennzahlen",
    sprintf("%d Rollenpaare: %d ohne Unterschiede, %d mit Unterschieden, %d nicht geladen; %d neue Rollen (Merge) erzeugt, %d davon fehlgeschlagen.",
            check$PAIRS, check$NO_DIFFERENCE, check$MERGE, check$CHECK, check$MERGED_ROLES, check$MERGE_ERRORS),
    sprintf("%d Paare mit Lizenzvergleich.", check$COMPARED),
    "",
    "So lesen Sie das Blatt „Rollenpaare“",
    "Eine Zeile je Paar aus AOT-Rolle und UI-Kopie. „Keine Unterschiede“ heißt: Beide haben dieselben eigenen Aufgaben, Rechte, Unterrollen und direkten Zugriffsrechte. Diese Rollen werden nicht angefasst. Ausnahme: Hat dieselbe AOT-Rolle noch eine andere Kopie mit Unterschieden, wird sie über dieses andere Paar zusammengeführt; dann heißt die Maßnahme „Benutzer umstellen“, denn auch die Benutzer der gleichen Kopie wechseln auf die neue Rolle.",
    "Bei „Unterschiede“ hat das Werkzeug eine neue Rolle <AOT-Name>_MERGED erzeugt, die alles enthält, was eine der Versionen gewährt (je AOT-Rolle eine, auch wenn es mehrere Kopien gibt). Welche Unterschiede es gibt, steht im Blatt „Unterschiede_Aufbau“; der Lizenzvergleich (Blatt „Unterschiede_Lizenz“) zeigt zusätzlich, ob sich lizenzrelevante Objekte unterscheiden.",
    "„Nicht geladen“ heißt: Eine Version fehlt in der Datenbank oder konnte nicht gelesen werden; der Grund steht in der Spalte „Fehler“.",
    "Die Benutzer sind je Paar gezählt: Hat eine AOT-Rolle zwei Kopien, stehen ihre Benutzer in beiden Zeilen.",
    "",
    "Was zu tun ist",
    "1. Merge-Rolle prüfen: Gewährt sie, was die Benutzer beider Versionen brauchen? Entscheidung in der Spalte „Entscheidung“ eintragen.",
    "2. Importieren: im Browser (Dateien Sicherheitskonfiguration bzw. Sicherheitsgovernance) oder über das Modell (AOT-Datei, Zip); Datum in „Importiert am“.",
    "3. Benutzer der alten Versionen auf die neue Rolle umstellen; Datum in „Benutzer umgestellt am“.",
    "4. Nach dem Test die alten Versionen entziehen und entfernen; Datum in „Alte Rollen entfernt am“, Status „erledigt“.",
    "Erst danach wird die Rolle geändert, bereinigt oder neu lizenziert.",
    "",
    "Hinweis für die Weiterverarbeitung",
    "Blau markierte Spalten und Blätter füllt das Werkzeug; die weißen Spalten pflegt das Team. Beim nächsten Lauf übernimmt das Werkzeug die weißen Spalten je Rollenpaar. Bitte Blätter nicht umbenennen und Kopfzeilen nicht ändern. Die Datei enthält keine Benutzer-IDs, nur Anzahlen."
  )
  openxlsx::addWorksheet(wb, "Anleitung")
  openxlsx::writeData(wb, "Anleitung", text, colNames = FALSE)
  openxlsx::setColWidths(wb, "Anleitung", cols = 1, widths = 120)
  openxlsx::addStyle(wb, "Anleitung", .deliverable_style("body"), rows = seq_along(text), cols = 1)
  openxlsx::addStyle(wb, "Anleitung", openxlsx::createStyle(textDecoration = "bold", fontSize = 14), rows = 1, cols = 1)
  headings <- which(text %in% c("Worum es geht", "Kennzahlen", "So lesen Sie das Blatt „Rollenpaare“", "Was zu tun ist",
                                "Hinweis für die Weiterverarbeitung"))
  openxlsx::addStyle(wb, "Anleitung", openxlsx::createStyle(textDecoration = "bold"), rows = headings, cols = 1)
  invisible(wb)
}
