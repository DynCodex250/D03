#' Build one role per license from the usage of a role
#'
#' Splits a role into roles that each need one license, based on what the
#' users of the role really use. Without licenses, one role is built for every
#' base license the used objects need, for example Commerce, Finance and Supply
#' Chain Management for a sales role. With licenses, only these roles are
#' built. Each role holds everything used the license covers: the objects only
#' it covers, the shared ones and those Operations - Activity or Team Members
#' cover.
#'
#' @details
#'
#' **What counts as used.** The telemetry measures forms (display menu items).
#' A privilege is used when a user opened one of its forms; it then comes in
#' whole, with its actions, data entities and services. A privilege without a
#' form comes in when another privilege of its duty was used; when it sits
#' directly in the role, it stays in as not measurable. Column \code{STATUS} of
#' \code{Privileges}: \code{USED}, \code{WITH_DUTY}, \code{NOT_MEASURABLE},
#' \code{NOT_USED} (left out) or, without usage data, \code{ALL}.
#'
#' **Building blocks.** A duty goes into a role whole when every privilege it
#' holds in the role is kept and the license covers it completely. Other kept
#' privileges the license covers go in one by one. A privilege the license
#' covers only partly becomes a new privilege \code{<privilege>_<suffix>}, for
#' example \code{_SCM}, with the objects the license covers.
#'
#' **Users.** For each user, the roles that cover the forms this user opened,
#' chosen greedily: first the role that covers most of them, the cheaper one on
#' a tie, then the one that covers most of the rest. \code{NOT_COVERED} names forms no built role covers,
#' for example of a license that was not built. \code{LOWEST_LICENSE} is the
#' cheapest single license that covers every form the user opened, for example
#' Team Members; \code{NA} when no single license does or without usage.
#'
#' **Files.** With \code{export_folder}: the roles in
#' \code{AxSecurityRole/}, the new privileges in \code{AxSecurityPrivilege/},
#' both in one zip for Visual Studio; the roles and new privileges together in
#' one file for the import in the browser, twice:
#' \code{SecurityGovernance/<prefix>_license_roles.xml} as the security
#' governance exports it and \code{SecurityConfiguration/<prefix>_license_roles.xml}
#' as the security configuration exports it (see
#' \code{\link{create_d365fo_security_configuration_xml}}; roles and privileges
#' keep their readable names); and a workbook. The grants of the new privileges and the
#' direct access permissions come from \code{UserSecGovRelatedObjects}; each
#' role takes all those of the role and of its sub-roles, because it holds their
#' content; they need no license and are not filtered by usage. Objects without license data (tables, entities) stay in a new
#' privilege; form controls and services are left out with a warning.
#'
#' @param con
#' Database connection. Result of \code{get_connection()}.
#'
#' @param role
#' AOT name or GUID of the role to split.
#'
#' @param usage
#' Telemetry with the columns \code{user_Id}, \code{name} and \code{touches},
#' for example from \code{D365Licensing::load_telemetry_touches()}. \code{NULL}
#' = no usage data: every privilege is kept.
#'
#' @param users
#' User ids whose usage counts. \code{NULL} = every active user of the role.
#'
#' @param licenses
#' Licenses to build roles for, as \code{LicensingAllSkus} names them.
#' \code{NULL} = the fewest base licenses that cover the kept objects (the
#' cheaper one on a tie); Operations - Activity or Team Members when no kept
#' object needs a base license.
#'
#' @param prefer
#' A base license to choose first when \code{licenses} is \code{NULL}, as
#' \code{LicensingAllSkus} names it, for example the target license of a
#' proposal: \code{"Supply Chain Management"}. Other licenses are added only
#' for kept objects it does not cover. Without it, a cheaper license that
#' covers the same objects wins: a role whose objects need "Finance" or
#' "Finance or Supply Chain Management" becomes one Finance role. With
#' \code{prefer = "Supply Chain Management"} it becomes a Supply Chain
#' Management role plus a Finance role for the objects only Finance covers.
#' A preferred license that covers no kept object is not built, with a
#' warning. Name a plain base license (Commerce, Finance, Supply Chain
#' Management): a Premium license counts only for objects no plain base
#' license covers, and Team Members or Operations - Activity never count here.
#' \code{NULL} = no preference. Not together with \code{licenses}.
#'
#' @param name_prefix
#' AOT name the new roles start with; the license suffix follows. \code{NULL}
#' = the AOT name of the role.
#'
#' @param export_folder
#' Folder for XML, zip and workbook. \code{NULL} = no files.
#'
#' @param language
#' Language of the workbook: \code{"de"} or \code{"en"}.
#'
#' @return
#' List with \code{Check} (\code{ROLE}, \code{LICENSES}, \code{PREFER},
#' \code{PREFIX}, \code{USERS}, \code{HAS_USAGE}, \code{CREATED}),
#' \code{Summary} (one row per role), \code{Blocks},
#' \code{NewPrivileges}, \code{Privileges}, \code{Objects}, \code{Users} and
#' \code{Files}: the paths \code{zip}, \code{workbook},
#' \code{security_governance} and \code{security_configuration}, each
#' \code{NA} without \code{export_folder}.
#'
#' @examples
#' \dontrun{
#'
#' usage <- D365Licensing::load_telemetry_touches(D365Licensing::load_config())
#'
#' # One role per base license the users need
#' roles <- build_license_roles(cnn, "_WIBU_VERKAUF_INNENDIENST_MITARBEITER", usage = usage,
#'                              export_folder = "Data/Reports/Klartext/Lizenzrollen")
#' roles$Summary
#'
#' # Supply Chain Management first, other licenses only for what it does not cover
#' build_license_roles(cnn, "_WIBU_VERKAUF_INNENDIENST_MITARBEITER", usage = usage,
#'                     prefer = "Supply Chain Management")
#'
#' # Only an SCM role, from the usage of two users
#' build_license_roles(cnn, "_WIBU_VERKAUF_INNENDIENST_MITARBEITER", usage = usage,
#'                     users = c("user1", "user2"), licenses = "Supply Chain Management")
#'
#' }
#'
#' @seealso
#' \code{\link{plan_single_license_role}}
#' \code{\link{export_role_xml}}
#'
#' @export
build_license_roles <- function(
  con,
  role,
  usage         = NULL,
  users         = NULL,
  licenses      = NULL,
  name_prefix   = NULL,
  export_folder = NULL,
  language      = "de",
  prefer        = NULL
) {

  .license_roles_request(role, users, licenses, name_prefix, export_folder, prefer)
  language <- .check_report_language(language)

  skus <- .load_license_skus(con)
  for (license in c(licenses, prefer)) .check_license_name(license, skus)

  graph <- .load_role_license_graph(con, role)
  if (nrow(graph) == 0L) {
    stop("The license graph holds no rows for role '", role, "'.", call. = FALSE)
  }

  rows       <- .license_role_rows(graph, skus)
  user_ids   <- .license_role_users(con, role, usage, users)
  used       <- .used_keys_by_user(usage, user_ids)
  privileges <- .license_role_privileges(rows, unique(unlist(used)), has_usage = !is.null(usage))
  kept       <- rows[rows$PRIVILEGE_KEY %in% privileges$PRIVILEGE_KEY[privileges$KEPT], ]
  if (nrow(kept) == 0L) {
    stop("No privilege of role '", role, "' was used, so there is no role to build. Check usage and users.", call. = FALSE)
  }

  licenses <- .order_licenses(if (is.null(licenses)) .needed_licenses(kept, skus, prefer) else licenses, skus)
  if (length(licenses) == 0L) {
    stop("No license covers the kept objects of role '", role, "', so there is no role to build.", call. = FALSE)
  }
  prefix   <- .check_aot_name(.license_role_prefix(con, role, graph, name_prefix))
  roles    <- lapply(licenses, function(license) .license_role(kept, rows, skus, license, prefix))
  users    <- .license_role_user_table(used, rows, roles, skus)

  result <- list(
    Check         = list(ROLE = role, LICENSES = licenses, PREFER = if (is.null(prefer)) NA_character_ else prefer,
                         PREFIX = prefix, USERS = length(user_ids), HAS_USAGE = !is.null(usage), CREATED = Sys.Date()),
    Summary       = .license_role_summary(roles, users),
    Blocks        = dplyr::bind_rows(c(list(.license_block_template()), lapply(roles, `[[`, "blocks"))),
    NewPrivileges = dplyr::bind_rows(c(list(.new_privilege_template()), lapply(roles, `[[`, "new_privileges"))),
    Privileges    = dplyr::select(privileges, -PRIVILEGE_KEY),
    Objects       = .license_role_objects(rows, privileges, roles, unique(unlist(used))),
    Users         = users,
    Files         = list(zip = NA_character_, workbook = NA_character_,
                         security_governance = NA_character_, security_configuration = NA_character_)
  )

  if (!is.null(export_folder)) {
    result$Files <- .write_license_roles(con, result, roles, export_folder, language)
  }

  message(.license_roles_message(result))
  result
}

.license_roles_request <- function(role, users, licenses, name_prefix, export_folder, prefer = NULL) {

  if (!.is_single_string(role)) {
    stop("role must name one role: the AOT name, or the GUID of a role created in the user interface.", call. = FALSE)
  }
  if (!is.null(users) && (!is.character(users) || anyNA(users))) {
    stop("users must be a character vector of user ids, or NULL.", call. = FALSE)
  }
  if (!is.null(licenses) && (!is.character(licenses) || length(licenses) == 0L)) {
    stop("licenses must name at least one license, or be NULL.", call. = FALSE)
  }
  if (!is.null(prefer) && !.is_single_string(prefer)) {
    stop("prefer must name one license, or be NULL.", call. = FALSE)
  }
  if (!is.null(prefer) && !is.null(licenses)) {
    stop("Give licenses or prefer, not both: licenses names the roles to build, prefer steers the choice ",
         "when licenses is NULL.", call. = FALSE)
  }
  if (!is.null(name_prefix)) .check_aot_name(name_prefix)
  if (!is.null(export_folder) && !.is_single_string(export_folder)) {
    stop("export_folder must be the path of one folder.", call. = FALSE)
  }

  invisible(TRUE)
}

# Graph rows with a privilege, with the licenses that cover each row. A form
# (display menu item) is measurable.
.license_role_rows <- function(graph, skus) {

  rows <- graph[!.is_blank(graph$PRIVILEGEIDENTIFIER), ]
  .license_covered_rows(rows, skus, .ACTIVITY_SKU) |>
    dplyr::mutate(
      PRIVILEGE_KEY = .identifier_key(PRIVILEGEIDENTIFIER),
      TYPE          = .plan_type_name(SECURABLETYPE),
      MEASURABLE    = grepl(.MEASURABLE_TYPE_PATTERN, TYPE, ignore.case = TRUE)
    )
}

.license_role_users <- function(con, role, usage, users) {

  if (is.null(usage)) {
    return(character())
  }
  ids <- if (is.null(users)) .load_active_role_users(con, role)$ids else unique(users)
  if (length(ids) == 0L) {
    warning("No user counts: users is empty or the role has no active user, so no form counts as used.", call. = FALSE)
  }

  ids
}

# The objects each user opened, as keys; an empty list without usage data.
.used_keys_by_user <- function(usage, user_ids) {

  if (is.null(usage)) {
    return(list())
  }
  .check_required_columns(usage, c("user_Id", "name", "touches"), "usage")
  .check_usage_matches_users(usage, user_ids)

  touched <- usage[dplyr::coalesce(as.numeric(usage$touches), 0) > 0, ]
  keys    <- lapply(user_ids, function(user) unique(.identifier_key(touched$name[tolower(touched$user_Id) == tolower(user)])))
  stats::setNames(keys, user_ids)
}

.LICENSE_ROLE_STATUSES <- c("USED", "WITH_DUTY", "NOT_MEASURABLE", "ALL", "NOT_USED")

.license_role_privileges <- function(rows, used_keys, has_usage) {

  used_privileges <- unique(rows$PRIVILEGE_KEY[rows$MEASURABLE & rows$KEY %in% used_keys])
  used_duties     <- setdiff(unique(rows$DUTY[rows$PRIVILEGE_KEY %in% used_privileges]), .DUTY_CHECK_NO_DUTY)
  with_used_duty  <- unique(rows$PRIVILEGE_KEY[rows$DUTY %in% used_duties])

  # The counts get names of their own: summarise() would let a later line see a
  # count instead of the row flag MEASURABLE.
  rows |>
    dplyr::group_by(PRIVILEGE_KEY) |>
    dplyr::summarise(
      PRIVILEGE    = dplyr::first(PRIVILEGEIDENTIFIER),
      NAME         = dplyr::first(PRIVILEGENAME),
      DUTIES       = .collapse_sorted(DUTY, .LIST_SEPARATOR),
      DIRECT       = any(DUTY == .DUTY_CHECK_NO_DUTY),
      OBJECTS      = dplyr::n_distinct(KEY),
      N_MEASURABLE = dplyr::n_distinct(KEY[MEASURABLE]),
      N_USED       = dplyr::n_distinct(KEY[MEASURABLE & KEY %in% used_keys]),
      .groups      = "drop"
    ) |>
    dplyr::mutate(
      STATUS = dplyr::case_when(
        !has_usage                                             ~ "ALL",
        N_USED > 0L                                            ~ "USED",
        N_MEASURABLE == 0L & PRIVILEGE_KEY %in% with_used_duty ~ "WITH_DUTY",
        N_MEASURABLE == 0L & DIRECT                            ~ "NOT_MEASURABLE",
        TRUE                                                   ~ "NOT_USED"
      ),
      KEPT = STATUS != "NOT_USED"
    ) |>
    dplyr::arrange(match(STATUS, .LICENSE_ROLE_STATUSES), PRIVILEGE) |>
    dplyr::select(PRIVILEGE_KEY, PRIVILEGE, NAME, DUTIES, STATUS, OBJECTS, MEASURABLE = N_MEASURABLE, USED = N_USED, KEPT)
}

# The base licenses, cheapest first; without the Premium ones on request.
.base_license_names <- function(skus, premium = FALSE) {
  base <- skus[.is_base_group(skus$GROUPNAME, "^Base") & (premium | !endsWith(skus$SKUNAME, .PREMIUM_SUFFIX)), ]
  base$SKUNAME[order(base$PRIORITY, base$SKUNAME)]
}

.order_licenses <- function(licenses, skus) {
  unique(licenses[order(skus$PRIORITY[match(licenses, skus$SKUNAME)], licenses)])
}

# The base licenses the kept objects need: the preferred license when it covers
# any of them, every license that is the only choice of some object, then, until
# every object is covered, the license that covers most of the rest (the cheaper
# one on a tie). A Premium license counts only for an object no other base
# license covers. Without any base object, Operations - Activity or Team Members.
.needed_licenses <- function(kept, skus, prefer = NULL) {

  needs_base <- !kept$ACTIVITY_COVERS
  if (!any(needs_base)) {
    .warn_about_unused_preference(prefer)
    return(if (all(kept$TEAM_MEMBERS_COVERS)) skus$SKUNAME[grepl(.LICENSE_FLOOR_PATTERN, skus$SKUNAME)][1] else .ACTIVITY_SKU)
  }

  base         <- .base_license_names(skus)
  with_premium <- .base_license_names(skus, premium = TRUE)
  choices <- lapply(kept$COVERING[needs_base], function(covering) {
    plain <- intersect(covering, base)
    if (length(plain) > 0L) plain else intersect(covering, with_premium)
  })
  covers  <- function(license) vapply(choices, function(x) license %in% x, logical(1))
  chosen  <- unique(unlist(choices[lengths(choices) == 1L]))
  if (!is.null(prefer)) {
    if (any(covers(prefer))) chosen <- unique(c(prefer, chosen)) else .warn_about_unused_preference(prefer)
  }
  open    <- !Reduce(`|`, lapply(chosen, covers), logical(length(choices)))

  while (any(open)) {
    candidates <- intersect(with_premium, unlist(choices[open]))
    if (length(candidates) == 0L) break   # objects no base license covers
    gains  <- vapply(candidates, function(license) sum(covers(license) & open), numeric(1))
    best   <- candidates[which.max(gains)]
    chosen <- c(chosen, best)
    open   <- open & !covers(best)
  }

  if (any(open)) {
    warning("No base license covers these kept objects: ",
            .collapse_sorted(kept$SECURABLENAME[needs_base][open], .LIST_SEPARATOR), call. = FALSE)
  }
  as.character(chosen)
}

.warn_about_unused_preference <- function(prefer) {
  if (!is.null(prefer)) {
    warning("The preferred license ", prefer, " covers no kept object that needs a base license, ",
            "so no role is built for it.", call. = FALSE)
  }
  invisible(prefer)
}

.LICENSE_SUFFIXES <- c(
  "Commerce" = "COM", "Finance" = "FIN", "Supply Chain Management" = "SCM",
  "Finance Premium" = "FINP", "Supply Chain Management Premium" = "SCMP",
  "Human Resources" = "HR", "Project Operations" = "PRJ",
  "Operations - Activity" = "ACT", "Team Members" = "TM"
)

.license_suffix <- function(license) {
  suffix <- unname(.LICENSE_SUFFIXES[license])
  ifelse(is.na(suffix), toupper(gsub("[^A-Za-z0-9]", "", license)), suffix)
}

# "<privilege>_<suffix>"; no name for no privilege.
.new_privilege_name <- function(privilege, suffix) {
  if (length(privilege) == 0L) character() else paste0(privilege, "_", suffix)
}

# The AOT name the new roles start with: the given prefix, the AOT name of the
# role in the spelling of SECURITYROLE, or for a role of the user interface its
# label written as a name.
.license_role_prefix <- function(con, role, graph, name_prefix) {

  if (!is.null(name_prefix)) {
    return(name_prefix)
  }

  stored <- tryCatch(
    .load_stored_role_names(con, role),
    error = function(e) {
      warning("SECURITYROLE could not be read, the new roles are named after '", role, "': ",
              .without_sql_statement(conditionMessage(e)), call. = FALSE)
      NULL
    }
  )
  name   <- if (is.null(stored)) NA_character_ else stored$AOTNAME[match(.identifier_key(role), .identifier_key(stored$AOTNAME))][1]
  name   <- dplyr::coalesce(name, role)
  if (!is_guid_name(name)) {
    return(name)
  }

  label <- .role_xml_names(role, dplyr::first(graph$ROLENAME))$label
  gsub("_+$", "", gsub("[^A-Za-z0-9_]+", "_", label))
}

# One role: its duties, privileges and new privileges for one license.
.license_role <- function(kept, rows, skus, license, prefix) {

  covered   <- .license_covered_rows(kept, skus, license)
  fit       <- .license_fit(covered)
  partial   <- fit[fit$FIT == "PARTIAL", ]
  suffix    <- .license_suffix(license)
  role_name <- paste0(prefix, "_", suffix)

  list(
    license        = license,
    name           = role_name,
    blocks         = dplyr::mutate(.license_blocks(fit, rows, suffix), LICENSE = license, ROLE_NAME = role_name),
    new_privileges = .license_new_privileges(covered[covered$PRIVILEGE_KEY %in% partial$PRIVILEGE_KEY, ], license, suffix),
    keys           = unique(covered$KEY[covered$LICENSE_COVERS]),
    not_covered    = covered[covered$PRIVILEGE_KEY %in% partial$PRIVILEGE_KEY & !covered$LICENSE_COVERS, ]
  )
}

# Per kept privilege: the license covers it fully, partly or not at all.
.license_fit <- function(covered) {
  covered |>
    dplyr::group_by(PRIVILEGE_KEY) |>
    dplyr::summarise(
      PRIVILEGE = dplyr::first(PRIVILEGEIDENTIFIER),
      OBJECTS   = dplyr::n_distinct(KEY[LICENSE_COVERS]),
      FIT       = if (all(LICENSE_COVERS)) "FULL" else if (any(LICENSE_COVERS)) "PARTIAL" else "NONE",
      .groups   = "drop"
    )
}

# Whole duties, single privileges and new privileges. A duty goes in whole when
# every privilege it holds in the role fits fully.
.license_blocks <- function(fit, rows, suffix) {

  full   <- fit$PRIVILEGE_KEY[fit$FIT == "FULL"]
  duties <- rows[rows$DUTY != .DUTY_CHECK_NO_DUTY, ] |>
    dplyr::group_by(DUTY) |>
    dplyr::summarise(WHOLE = all(PRIVILEGE_KEY %in% full), OBJECTS = dplyr::n_distinct(KEY), .groups = "drop")
  whole    <- duties[duties$WHOLE, ]
  in_whole <- unique(rows$PRIVILEGE_KEY[rows$DUTY %in% whole$DUTY])
  single   <- fit[fit$FIT == "FULL" & !fit$PRIVILEGE_KEY %in% in_whole, ]
  partial  <- fit[fit$FIT == "PARTIAL", ]

  dplyr::bind_rows(
    .license_block_template(),
    tibble::tibble(BLOCK_TYPE = "Duty", BLOCK_ID = whole$DUTY, SOURCE = whole$DUTY, OBJECTS = whole$OBJECTS),
    tibble::tibble(BLOCK_TYPE = "Privilege", BLOCK_ID = single$PRIVILEGE, SOURCE = single$PRIVILEGE, OBJECTS = single$OBJECTS),
    tibble::tibble(BLOCK_TYPE = "NewPrivilege", BLOCK_ID = .new_privilege_name(partial$PRIVILEGE, suffix),
                   SOURCE = partial$PRIVILEGE, OBJECTS = partial$OBJECTS)
  )
}

# The objects of the partly covered privileges that the license covers.
.license_new_privileges <- function(partial_rows, license, suffix) {
  new_rows <- partial_rows[partial_rows$LICENSE_COVERS, ] |>
    dplyr::distinct(PRIVILEGEIDENTIFIER, SECURABLENAME, TYPE, ACCESS)
  dplyr::bind_rows(
    .new_privilege_template(),
    tibble::tibble(LICENSE = rep_len(license, nrow(new_rows)), NEW_PRIVILEGE = .new_privilege_name(new_rows$PRIVILEGEIDENTIFIER, suffix),
                   PRIVILEGE = new_rows$PRIVILEGEIDENTIFIER, OBJECT = new_rows$SECURABLENAME,
                   TYPE = new_rows$TYPE, ACCESS = new_rows$ACCESS)
  )
}

.license_block_template <- function() {
  tibble::tibble(LICENSE = character(), ROLE_NAME = character(), BLOCK_TYPE = character(),
                 BLOCK_ID = character(), SOURCE = character(), OBJECTS = integer())
}

.new_privilege_template <- function() {
  tibble::tibble(LICENSE = character(), NEW_PRIVILEGE = character(), PRIVILEGE = character(),
                 OBJECT = character(), TYPE = character(), ACCESS = numeric())
}

# One row per object: used (a form some user opened), kept, and the roles that hold it.
.license_role_objects <- function(rows, privileges, roles, used_keys) {

  kept_privileges <- privileges$PRIVILEGE_KEY[privileges$KEPT]
  licenses <- vapply(roles, `[[`, character(1), "license")
  in_roles <- function(key) {
    paste(licenses[vapply(roles, function(role) key %in% role$keys, logical(1))], collapse = .LIST_SEPARATOR)
  }

  rows |>
    dplyr::group_by(KEY) |>
    dplyr::summarise(
      OBJECT     = dplyr::first(SECURABLENAME),
      TYPE       = dplyr::first(TYPE),
      ACCESS     = max(ACCESS),
      LICENSE    = .collapse_sorted(LICENSE, " / "),
      MEASURABLE = any(MEASURABLE),
      KEPT       = any(PRIVILEGE_KEY %in% kept_privileges),
      .groups    = "drop"
    ) |>
    dplyr::mutate(USED = MEASURABLE & KEY %in% used_keys, ROLES = vapply(KEY, in_roles, character(1), USE.NAMES = FALSE)) |>
    dplyr::relocate(USED, .before = KEPT) |>
    dplyr::arrange(OBJECT) |>
    dplyr::select(-KEY)
}

# Per user: the cheapest single license that covers every form the user opened,
# and the fewest roles that cover them.
.license_role_user_table <- function(used, rows, roles, skus) {

  template <- tibble::tibble(USERID = character(), STATUS = character(), USED_FORMS = integer(),
                             LOWEST_LICENSE = character(), LICENSES = character(), ROLES = character(),
                             NOT_COVERED = character())
  if (length(used) == 0L) {
    return(template)
  }

  forms    <- unique(rows$KEY[rows$MEASURABLE])
  names_of <- function(keys) .collapse_sorted(rows$SECURABLENAME[match(keys, rows$KEY)], .LIST_SEPARATOR)
  role_of  <- function(chosen, field) paste(vapply(roles[chosen], `[[`, character(1), field), collapse = .LIST_SEPARATOR)

  # The licenses that cover an object at the highest access the role grants it
  covering <- lapply(split(rows, rows$KEY), function(r) Reduce(intersect, r$COVERING[r$ACCESS == max(r$ACCESS)]))
  cheapest <- function(keys) {
    licenses <- if (length(keys) == 0L) character() else Reduce(intersect, covering[keys])
    if (length(licenses) == 0L) NA_character_ else licenses[which.min(skus$PRIORITY[match(licenses, skus$SKUNAME)])]
  }

  dplyr::bind_rows(c(list(template), lapply(names(used), function(user) {
    remaining <- intersect(used[[user]], forms)
    count     <- length(remaining)
    lowest    <- cheapest(remaining)
    chosen    <- integer()
    while (length(remaining) > 0L && length(roles) > 0L) {
      gains <- vapply(roles, function(role) length(intersect(remaining, role$keys)), integer(1))
      if (max(gains) == 0L) break
      best      <- which.max(gains)
      chosen    <- c(chosen, best)
      remaining <- setdiff(remaining, roles[[best]]$keys)
    }
    tibble::tibble(
      USERID      = user,
      STATUS      = if (count == 0L) "NO_DATA" else if (length(remaining) > 0L) "NOT_COVERED" else "COVERED",
      USED_FORMS  = count,
      LOWEST_LICENSE = lowest,
      LICENSES    = role_of(chosen, "license"),
      ROLES       = role_of(chosen, "name"),
      NOT_COVERED = names_of(remaining)
    )
  })))
}

.license_role_summary <- function(roles, users) {

  count   <- function(blocks, type) sum(blocks$BLOCK_TYPE == type)
  holders <- strsplit(users$ROLES, .LIST_SEPARATOR, fixed = TRUE)
  tibble::tibble(
    LICENSE        = vapply(roles, `[[`, character(1), "license"),
    ROLE_NAME      = vapply(roles, `[[`, character(1), "name"),
    DUTIES         = vapply(roles, function(role) count(role$blocks, "Duty"), integer(1)),
    PRIVILEGES     = vapply(roles, function(role) count(role$blocks, "Privilege"), integer(1)),
    NEW_PRIVILEGES = vapply(roles, function(role) count(role$blocks, "NewPrivilege"), integer(1)),
    OBJECTS        = vapply(roles, function(role) length(role$keys), integer(1)),
    USERS          = vapply(roles, function(role) sum(vapply(holders, function(x) role$name %in% x, logical(1))), integer(1))
  )
}

.license_roles_message <- function(result) {

  privileges <- result$Privileges
  sprintf(
    "Role %s: %d of %d privileges kept; %d role(s) for %s.",
    result$Check$ROLE, sum(privileges$KEPT), nrow(privileges), length(result$Check$LICENSES),
    paste(result$Check$LICENSES, collapse = ", ")
  )
}
