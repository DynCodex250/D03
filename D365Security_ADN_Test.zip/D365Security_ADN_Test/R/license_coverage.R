# =============================================================================
# License rule of D365FO
#
# Used by build_role_license_report() and build_role_usage_report().
#
# D365FO counts, for a role, a duty or a privilege and for every license, how
# many of its objects the license entitles. A license covers the set when it
# entitles every object. The need of a set is therefore the cheapest license
# that all of its objects have in common. Several base licenses that all cover
# are alternatives: any one of them is enough, whatever group it belongs to.
# =============================================================================

# Need of a set that has no license rows at all.
.NEED_UNKNOWN <- "UNKNOWN"

# Need of a set whose objects have no license in common: several are required.
.NEED_MULTIPLE <- "MULTIPLE"

# Every user needs at least this license; cheaper ones are reported as this
# one. D365FO writes it "Team Members" or "Team Member".
.LICENSE_FLOOR_PATTERN <- "^Team Members?$"

# "Finance Premium" is not listed as an alternative when "Finance" covers too.
.PREMIUM_SUFFIX <- " Premium"

.split_skus <- function(covering_skus) {
  lapply(strsplit(covering_skus, .SKU_SEPARATOR, fixed = TRUE), function(skus) {
    skus[!is.na(skus) & nzchar(skus)]
  })
}

# License SKUs with priority and group, one row per SKU.
.sku_table <- function(license_requirements) {
  license_requirements |>
    dplyr::filter(!is.na(SKUNAME)) |>
    dplyr::distinct(SKUNAME, PRIORITY, GROUPNAME) |>
    dplyr::arrange(PRIORITY, SKUNAME) |>
    dplyr::distinct(SKUNAME, .keep_all = TRUE)
}

.need_row <- function(need, is_base, priority, covered_by = character()) {
  tibble::tibble(
    NEED          = need,
    IS_BASE       = is_base,
    NEED_PRIORITY = as.numeric(priority),
    COVERED_BY    = paste(covered_by, collapse = .SKU_SEPARATOR)
  )
}

# Need of a set of objects. `covering` holds, per object, the SKUs that
# entitle it; `skus` is the table from .sku_table().
.license_need <- function(covering, skus, base_group_pattern = "^Base") {

  if (length(covering) == 0L) {
    return(.need_row(.NEED_UNKNOWN, FALSE, NA_real_))
  }

  by_priority <- skus$SKUNAME[order(skus$PRIORITY, skus$SKUNAME)]
  in_common   <- Reduce(intersect, covering)
  common      <- c(by_priority[by_priority %in% in_common], setdiff(in_common, by_priority))

  if (length(common) == 0L) {
    return(.need_row(.NEED_MULTIPLE, TRUE, Inf))
  }

  priority_of <- function(sku) skus$PRIORITY[match(sku, skus$SKUNAME)]

  floor_sku <- common[grepl(.LICENSE_FLOOR_PATTERN, common)]

  if (length(floor_sku) > 0L) {
    return(.need_row(floor_sku[[1]], FALSE, priority_of(floor_sku[[1]]), common))
  }

  cheapest <- common[[1]]
  is_base  <- .is_base_group(skus$GROUPNAME[match(common, skus$SKUNAME)], base_group_pattern)

  if (!is_base[[1]]) {
    return(.need_row(cheapest, FALSE, priority_of(cheapest), common))
  }

  base_skus    <- common[is_base]
  is_redundant <- endsWith(base_skus, .PREMIUM_SUFFIX) &
    sub(paste0(.PREMIUM_SUFFIX, "$"), "", base_skus) %in% base_skus

  .need_row(
    paste(base_skus[!is_redundant], collapse = .SKU_SEPARATOR),
    TRUE, priority_of(cheapest), common
  )
}

# Need per group of rows. `rows` needs the column COVERING_SKUS; rows without
# a covering SKU make the need of their group MULTIPLE.
.need_per_group <- function(rows, group_columns, skus, base_group_pattern) {

  # summarise() cannot derive the need columns from zero groups
  if (nrow(rows) == 0L) {
    return(dplyr::bind_cols(
      rows[group_columns],
      .need_row(character(), logical(), numeric())
    ))
  }

  rows |>
    dplyr::group_by(dplyr::across(dplyr::all_of(group_columns))) |>
    dplyr::summarise(
      NEED_INFO = list(.license_need(.split_skus(COVERING_SKUS), skus, base_group_pattern)),
      .groups   = "drop"
    ) |>
    tidyr::unnest(NEED_INFO)
}

# TRUE for a need that names exactly one base license: only this one covers.
.is_fixing_need <- function(need, is_base) {
  is_base & need != .NEED_MULTIPLE & !grepl(.SKU_SEPARATOR, need, fixed = TRUE)
}
