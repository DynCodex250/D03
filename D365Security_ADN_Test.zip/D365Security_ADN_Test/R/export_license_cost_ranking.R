# =============================================================================
# Workbook of rank_roles_by_license_cost(): overview, ranking, users, users and
# roles, prices, legend. The sheets of the users hold user ids.
# =============================================================================

.license_cost_texts <- function(language) {

  texts <- list(
    en = list(
      sheets     = c(overview = "Overview", ranking = "Ranking", breakdown = "Calculation", users = "Users",
                     user_roles = "Users and roles", prices = "Prices", legend = "Legend"),
      title      = "Ranking of the roles by the license costs that arise only because of them",
      facts      = c("Created", "Active users", "Roles", "License costs per month, all users", "Prices", "Source",
                     "Basis of the costs only because of a role"),
      basis      = c(ppac = "PPAC (the licenses PPAC names at each role)", graph = "license graph"),
      basis_note = c(
        ppac  = paste("Basis PPAC: PPAC names each license of a user at one of his roles only, so the costs only because",
                      "of a role are an upper bound that can be far too high. Compare with basis = \"graph\"."),
        graph = paste("Basis license graph: without a role counts what the objects of the other roles of a user need.",
                      "Where the graph wants more than PPAC bills, PPAC counts. What the users pay comes from PPAC.")
      ),
      price_kind = c("estimates of the strategy paper (October 2026)", "as given"),
      database   = "database",
      note       = paste("Costs only because of a role: what its users would no longer pay if the role triggered no",
                         "license, given their other roles. An AOT role and its UI role of the same name count as one",
                         "role. The sheets Calculation, Users and Users and roles hold user ids; do not pass them on."),
      ranking    = c("Rank", "Role", "Name", "UI versions of the same name", "WIBU role", "Users",
                     "License costs of its users per month (all roles)", "Users who would pay less",
                     "Licenses the role triggers", "Costs per month only because of the role",
                     "per user who would pay less"),
      breakdown  = c("Rank", "Role", "Users", "Billed with the role", "Calculation with the role",
                     "Billed without the role", "Calculation without the role", "Saving per user", "Saving",
                     "Dropped without the role", "Users affected"),
      no_license = "no license",
      nothing    = "nothing: other roles trigger the same licenses",
      users      = c("User", "Roles", "Licenses", "Billed as", "Calculation", "License costs per month"),
      user_roles = c("User", "Role", "Name", "Costs per month only because of the role"),
      prices     = c("License", "Base price", "Attach price"),
      yes_no     = c("yes", "no")
    ),
    de = list(
      sheets     = c(overview = "Überblick", ranking = "Rangliste", breakdown = "Rechenweg", users = "Benutzer",
                     user_roles = "Benutzer und Rollen", prices = "Preise", legend = "Legende"),
      title      = "Rangliste der Rollen nach den Lizenzkosten, die nur wegen ihnen anfallen",
      facts      = c("Erstellt", "Aktive Benutzer", "Rollen", "Lizenzkosten je Monat, alle Benutzer", "Preise", "Quelle",
                     "Grundlage der Kosten nur wegen einer Rolle"),
      basis      = c(ppac = "PPAC (die Lizenzen, die PPAC je Rolle nennt)", graph = "Lizenzgraph"),
      basis_note = c(
        ppac  = paste("Grundlage PPAC: PPAC nennt jede Lizenz eines Benutzers nur bei einer seiner Rollen. Die Kosten nur",
                      "wegen einer Rolle sind darum eine Obergrenze und können viel zu hoch sein. Zum Vergleich",
                      "basis = \"graph\"."),
        graph = paste("Grundlage Lizenzgraph: Ohne eine Rolle zählt, was die Objekte der übrigen Rollen eines Benutzers",
                      "brauchen. Verlangt der Graph mehr, als PPAC abrechnet, gilt PPAC. Was die Benutzer zahlen, kommt",
                      "aus PPAC.")
      ),
      price_kind = c("Schätzwerte der Strategie (Oktober 2026)", "wie übergeben"),
      database   = "Datenbank",
      note       = paste("Kosten nur wegen einer Rolle: was ihre Benutzer nicht mehr zahlen würden, wenn die Rolle keine",
                         "Lizenz auslöste, bei allen ihren übrigen Rollen. Eine AOT-Rolle und die gleichnamige UI-Rolle",
                         "zählen als eine Rolle. Die Blätter Rechenweg, Benutzer und Benutzer und Rollen enthalten Benutzerkennungen;",
                         "nicht weitergeben."),
      ranking    = c("Platz", "Rolle", "Bezeichnung", "UI-Versionen gleichen Namens", "WIBU-Rolle", "Benutzer",
                     "Lizenzkosten ihrer Benutzer je Monat (alle Rollen)", "Benutzer, die weniger zahlen würden",
                     "Lizenzen, die die Rolle auslöst", "Kosten je Monat nur wegen der Rolle",
                     "je Benutzer, der weniger zahlen würde"),
      breakdown  = c("Platz", "Rolle", "Benutzer", "Abgerechnet mit der Rolle", "Rechnung mit der Rolle",
                     "Abgerechnet ohne die Rolle", "Rechnung ohne die Rolle", "Einsparung je Benutzer", "Einsparung",
                     "Ohne die Rolle entfällt", "Betroffene Benutzer"),
      no_license = "keine Lizenz",
      nothing    = "nichts: andere Rollen lösen dieselben Lizenzen aus",
      users      = c("Benutzer", "Rollen", "Lizenzen", "Abgerechnet als", "Rechnung", "Lizenzkosten je Monat"),
      user_roles = c("Benutzer", "Rolle", "Bezeichnung", "Kosten je Monat nur wegen der Rolle"),
      prices     = c("Lizenz", "Basispreis", "Attach-Preis"),
      yes_no     = c("ja", "nein")
    )
  )
  texts[[language]]
}

.LICENSE_COST_LEGEND <- list(
  c("License costs of its users",
    "What the users of the role pay per month with all their roles. A cleanup of this role alone saves at most the costs only because of it.",
    "Lizenzkosten ihrer Benutzer",
    "Was die Benutzer der Rolle je Monat mit allen ihren Rollen zahlen. Die Bereinigung dieser Rolle allein spart höchstens die Kosten nur wegen der Rolle."),
  c("Calculation",
    "Per role, its users grouped by how they are billed with the role and without it, with the prices. The savings of a role add up to its costs only because of it.",
    "Rechenweg",
    "Je Rolle ihre Benutzer, gruppiert danach, wie sie mit und ohne die Rolle abgerechnet werden, mit den Preisen. Die Einsparungen einer Rolle ergeben zusammen ihre Kosten nur wegen der Rolle."),
  c("Basis",
    "Where the costs only because of a role come from. PPAC: the licenses PPAC names at the other roles of the user; PPAC names each license at one role only, so this is an upper bound. License graph: what the objects of the other roles need; where the graph wants more than PPAC bills, PPAC counts.",
    "Grundlage",
    "Woher die Kosten nur wegen einer Rolle kommen. PPAC: die Lizenzen, die PPAC bei den übrigen Rollen des Benutzers nennt; PPAC nennt jede Lizenz nur bei einer Rolle, das ist darum eine Obergrenze. Lizenzgraph: was die Objekte der übrigen Rollen brauchen; verlangt der Graph mehr, als PPAC abrechnet, gilt PPAC."),
  c("Costs only because of the role",
    "Per user: license costs with all roles minus the costs without this role; summed over the users. What a cleanup of the role saves at most.",
    "Kosten nur wegen der Rolle",
    "Je Benutzer: Lizenzkosten mit allen Rollen minus die Kosten ohne diese Rolle; summiert über die Benutzer. Mehr spart eine Bereinigung der Rolle nicht."),
  c("Users who would pay less",
    "Users for whom the role triggers a license, or a dearer one, that no other role of theirs triggers.",
    "Benutzer, die weniger zahlen würden",
    "Benutzer, bei denen die Rolle eine Lizenz oder eine teurere auslöst, die keine ihrer übrigen Rollen auslöst."),
  c("UI versions of the same name",
    "Roles created in the user interface with the name of the AOT role. They count together with it: users often have both.",
    "UI-Versionen gleichen Namens",
    "In der Oberfläche angelegte Rollen mit dem Namen der AOT-Rolle. Sie zählen mit ihr zusammen, denn Benutzer haben oft beide."),
  c("Base price, attach price",
    "Of the base licenses of a user the first in the order SCM, Finance, Commerce counts at its base price, every further one at its attach price: SCM Base + Finance Attach + Commerce Attach. The sheet Users shows it per user.",
    "Basispreis, Attach-Preis",
    "Von den Basislizenzen eines Benutzers zählt die erste in der Reihenfolge SCM, Finance, Commerce mit ihrem Basispreis, jede weitere mit ihrem Attach-Preis: SCM Base + Finance Attach + Commerce Attach. Das Blatt Benutzer zeigt es je Benutzer."),
  c("Light licenses",
    "Team Members and Operations - Activity count only for users without a base license; then the dearest of them.",
    "Leichte Lizenzen",
    "Team Members und Operations - Activity zählen nur bei Benutzern ohne Basislizenz, dann die teuerste davon."),
  c("Prices",
    "Per user and month as given; without prices the estimates of the strategy paper (October 2026), marked in the overview.",
    "Preise",
    "Je Benutzer und Monat wie übergeben; ohne Preise die Schätzwerte der Strategie (Oktober 2026), im Überblick vermerkt.")
)

.export_license_cost_ranking <- function(result, export_path, language) {

  texts    <- .license_cost_texts(language)
  workbook <- openxlsx::createWorkbook(creator = .WORKBOOK_CREATOR)
  header   <- openxlsx::createStyle(textDecoration = "bold", fgFill = "#DDEBF7", border = "bottom", wrapText = TRUE)
  amount   <- openxlsx::createStyle(numFmt = "#,##0.00")
  named    <- function(table, columns) stats::setNames(as.data.frame(table, stringsAsFactors = FALSE), columns)
  money    <- function(sheet, table, columns) {
    if (nrow(table) > 0L) {
      openxlsx::addStyle(workbook, sheet, amount, rows = seq_len(nrow(table)) + 1L, cols = columns, gridExpand = TRUE)
    }
  }

  .add_license_cost_overview(workbook, result, texts)

  ranking <- dplyr::mutate(result$Ranking, IS_WIBU = ifelse(IS_WIBU, texts$yes_no[[1]], texts$yes_no[[2]]))
  .add_duty_check_table(workbook, texts$sheets[["ranking"]], named(ranking, texts$ranking), header,
                        c(8, 40, 44, 40, 10, 10, 18, 16, 44, 18, 18))
  money(texts$sheets[["ranking"]], ranking, c(7L, 10L, 11L))

  breakdown <- dplyr::mutate(
    result$Breakdown,
    BILLED_WITH    = ifelse(nzchar(BILLED_WITH), BILLED_WITH, texts$no_license),
    BILLED_WITHOUT = ifelse(nzchar(BILLED_WITHOUT), BILLED_WITHOUT, texts$no_license),
    CALC_WITH      = .decimal_sign(CALC_WITH, language),
    CALC_WITHOUT   = .decimal_sign(CALC_WITHOUT, language),
    DROPPED        = ifelse(nzchar(DROPPED), DROPPED, texts$nothing)
  )
  .add_duty_check_table(workbook, texts$sheets[["breakdown"]], named(breakdown, texts$breakdown), header,
                        c(8, 40, 10, 44, 30, 44, 30, 14, 14, 44, 30))
  money(texts$sheets[["breakdown"]], breakdown, 8:9)

  users <- dplyr::mutate(result$Users, CALCULATION = .decimal_sign(CALCULATION, language))
  .add_duty_check_table(workbook, texts$sheets[["users"]], named(users, texts$users), header, c(24, 10, 60, 48, 30, 18))
  money(texts$sheets[["users"]], users, 6L)

  .add_duty_check_table(workbook, texts$sheets[["user_roles"]], named(result$UserRoles, texts$user_roles), header,
                        c(24, 40, 44, 18))
  money(texts$sheets[["user_roles"]], result$UserRoles, 4L)

  .add_duty_check_table(workbook, texts$sheets[["prices"]], named(result$Prices, texts$prices), header, c(34, 14, 14))
  money(texts$sheets[["prices"]], result$Prices, 2:3)

  legend <- stats::setNames(as.data.frame(do.call(rbind, .LICENSE_COST_LEGEND), stringsAsFactors = FALSE),
                            c("Term", "Meaning", "Begriff", "Bedeutung"))
  .add_duty_check_table(workbook, texts$sheets[["legend"]], legend, header, .DUTY_CHECK_LEGEND_WIDTHS, wrap = TRUE)

  dir.create(dirname(export_path), recursive = TRUE, showWarnings = FALSE)
  openxlsx::saveWorkbook(workbook, export_path, overwrite = TRUE)

  invisible(export_path)
}

# "168.50 + 27.30 = 195.80" in German writing: "168,50 + 27,30 = 195,80".
.decimal_sign <- function(calculation, language) {
  if (identical(language, "de")) gsub(".", ",", calculation, fixed = TRUE) else calculation
}

.add_license_cost_overview <- function(workbook, result, texts) {

  sheet <- texts$sheets[["overview"]]
  check <- result$Check
  facts <- data.frame(
    label = texts$facts,
    value = c(format(check$CREATED, "%Y-%m-%d"), check$USERS, check$ROLES, format(round(check$TOTAL_COST, 2), nsmall = 2),
              if (check$PRICES_ESTIMATED) texts$price_kind[[1]] else texts$price_kind[[2]],
              if (identical(check$SOURCE, "database")) texts$database else check$SOURCE,
              texts$basis[[check$BASIS]]),
    stringsAsFactors = FALSE
  )

  openxlsx::addWorksheet(workbook, sheet)
  openxlsx::writeData(workbook, sheet, texts$title, startRow = 1L)
  openxlsx::addStyle(workbook, sheet, openxlsx::createStyle(textDecoration = "bold", fontSize = 13), rows = 1L, cols = 1L)
  openxlsx::writeData(workbook, sheet, facts, startRow = 3L, colNames = FALSE)
  openxlsx::writeData(workbook, sheet, texts$note, startRow = nrow(facts) + 4L)
  openxlsx::writeData(workbook, sheet, texts$basis_note[[check$BASIS]], startRow = nrow(facts) + 5L)
  openxlsx::setColWidths(workbook, sheet, cols = 1:2, widths = c(40, 50))

  invisible(workbook)
}
