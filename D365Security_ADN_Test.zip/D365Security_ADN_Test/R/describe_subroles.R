#' Describe the sub-roles of a role
#'
#' Lists every sub-role of a role with what matters before the role is changed:
#' whether it was created in the AOT or in the user interface, the license it
#' needs, whether it fixes a license of the role, whether a UI sub-role has an
#' AOT role of the same name and how the two compare, in which other roles it
#' sits and how many users have it directly.
#'
#' @details
#'
#' **Why it matters.** A sub-role never needs more than the role it sits in:
#' when the role needs only one license, so do its sub-roles. But a sub-role
#' is a shared building block. When a license driver sits in a sub-role, the
#' sub-role itself must change, and that change reaches every role it sits in
#' (\code{OTHER_ROLES}) and every user who has it directly
#' (\code{DIRECT_USERS}).
#'
#' **UI sub-roles.** A role created in the user interface (its identifier is
#' a GUID) cannot be a sub-role in a Visual Studio project. When an AOT role of
#' the same name exists (\code{\link{load_role_mapping}}), it takes the place
#' of the UI role; \code{\link{export_role_xml}} does that. Both versions are
#' compared with \code{\link{compare_role_versions}} first, because the same
#' name does not mean the same content. \code{NOTE}:
#'
#' \describe{
#'   \item{\code{AOT_ROLE}}{The sub-role is an AOT role; nothing to do.}
#'   \item{\code{SAME}}{The AOT counterpart grants the same.}
#'   \item{\code{AOT_HAS_MORE}}{The AOT counterpart grants more: the users get
#'     more rights, perhaps another license.}
#'   \item{\code{UI_HAS_MORE}}{The UI role grants more: the users would lose
#'     rights. Align the AOT role first.}
#'   \item{\code{DIFFERENT}}{Each grants something the other lacks.}
#'   \item{\code{NO_COUNTERPART}}{No AOT role of the same name. Decide whether
#'     the UI role becomes an AOT role, and under which name.}
#'   \item{\code{SEVERAL_COUNTERPARTS}}{More than one AOT role of the same name.}
#'   \item{\code{NOT_COMPARED}}{The comparison failed; a warning says why. The
#'     UI role stays.}
#' }
#'
#' **Time.** Each UI sub-role with an AOT counterpart is compared with
#' \code{\link{compare_role_versions}}, about half a minute each.
#'
#' @param con
#' Database connection. Result of \code{get_connection()}.
#'
#' @param role
#' AOT name or GUID of the role, for example
#' \code{"_WIBU_VERKAUF_INNENDIENST_LEITUNG"}.
#'
#' @param report
#' The result of \code{\link{analyze_role_license_report}} for this role, when
#' it is already at hand. \code{NULL} = the function builds it, which takes
#' about 15 seconds.
#'
#' @return
#' Tibble, one row per sub-role:
#'
#' \describe{
#'   \item{\code{SUBROLE}, \code{NAME}}{Identifier and label of the sub-role.}
#'   \item{\code{KIND}}{\code{"AOT"} or \code{"UI"}.}
#'   \item{\code{NEED}}{The license its objects need, as in the role license
#'     report, for example \code{"Supply Chain Management"}.}
#'   \item{\code{DRIVES}}{The license it fixes for the role: some of its
#'     objects need exactly this license. Empty when it fixes none.}
#'   \item{\code{OBJECTS}}{Number of its objects.}
#'   \item{\code{COUNTERPART}, \code{NOTE}}{For a UI sub-role: the AOT role of
#'     the same name and the result of the comparison, see Details.}
#'   \item{\code{OTHER_ROLES}}{Names of the other roles that hold the sub-role.}
#'   \item{\code{DIRECT_USERS}}{Users who have the sub-role assigned directly.}
#' }
#'
#' Example for \code{_WIBU_VERKAUF_INNENDIENST_LEITUNG}:
#' \preformatted{
#' SUBROLE                               KIND NEED                    DRIVES                  NOTE
#' TradeSalesClerk                       AOT  Team Members                                    AOT_ROLE
#' 53FAE280-022E-4A30-A5BA-9E79AF7418BA  UI   Supply Chain Management Supply Chain Management NO_COUNTERPART
#' }
#'
#' @examples
#' \dontrun{
#'
#' report    <- analyze_role_license_report(cnn, "_WIBU_VERKAUF_INNENDIENST_LEITUNG")
#' subroles  <- describe_subroles(cnn, "_WIBU_VERKAUF_INNENDIENST_LEITUNG", report = report)
#' subroles[subroles$KIND == "UI", c("SUBROLE", "NAME", "COUNTERPART", "NOTE")]
#'
#' }
#'
#' @seealso
#' \code{\link{export_role_xml}}
#' \code{\link{load_role_mapping}}
#' \code{\link{compare_role_versions}}
#'
#' @export
describe_subroles <- function(con, role, report = NULL) {

  if (!.is_single_string(role)) {
    stop("role must name one role: the AOT name, or the GUID of a role created in the user interface.", call. = FALSE)
  }
  report <- if (is.null(report)) analyze_role_license_report(con, role) else report

  blocks <- report$Blocks[report$Blocks$BLOCK_TYPE == "SubRole", ]
  if (nrow(blocks) == 0L) {
    return(.subrole_template())
  }

  counterparts <- .ui_subrole_counterparts(con, blocks$BLOCK_ID)
  relations    <- get_sql_role_subrole_association(con)
  assignments  <- get_sql_user_role_assignments(con, roles = blocks$BLOCK_ID)
  of_subrole   <- function(table, column, id) table[.identifier_key(table[[column]]) == .identifier_key(id), ]

  tibble::tibble(
    SUBROLE      = blocks$BLOCK_ID,
    NAME         = blocks$BLOCK_NAME,
    KIND         = counterparts$KIND,
    NEED         = blocks$NEED,
    DRIVES       = ifelse(blocks$FIXING_OBJECT_COUNT > 0, blocks$NEED, ""),
    OBJECTS      = blocks$OBJECT_COUNT,
    COUNTERPART  = counterparts$COUNTERPART,
    NOTE         = counterparts$NOTE,
    OTHER_ROLES  = vapply(blocks$BLOCK_ID, function(id) {
      holders <- of_subrole(relations, "SECURITYSUBROLEIDENTIFIER", id)
      holders <- holders[.identifier_key(holders$SECURITYROLEIDENTIFIER) != .identifier_key(role), ]
      .collapse_sorted(holders$SECURITYROLENAME, .LIST_SEPARATOR)
    }, character(1), USE.NAMES = FALSE),
    DIRECT_USERS = vapply(blocks$BLOCK_ID, function(id) {
      dplyr::n_distinct(of_subrole(assignments, "SECURITYROLEIDENTIFIER", id)$USERID)
    }, integer(1), USE.NAMES = FALSE)
  )
}

.subrole_template <- function() {
  tibble::tibble(SUBROLE = character(), NAME = character(), KIND = character(), NEED = character(),
                 DRIVES = character(), OBJECTS = integer(), COUNTERPART = character(), NOTE = character(),
                 OTHER_ROLES = character(), DIRECT_USERS = integer())
}

# compare_role_versions(AOT role, UI role): A_IN_B means the UI role (B) grants more.
.SUBROLE_VERDICT_NOTES <- c(SAME = "SAME", A_IN_B = "UI_HAS_MORE", B_IN_A = "AOT_HAS_MORE", DIFFERENT = "DIFFERENT")

# Per sub-role: AOT or UI, and for a UI role its AOT role of the same name with the
# result of the comparison. look_up = FALSE leaves the UI roles unchecked.
.ui_subrole_counterparts <- function(con, subroles, look_up = TRUE) {

  is_ui <- is_guid_name(subroles)
  plain <- tibble::tibble(
    SUBROLE     = as.character(subroles),
    KIND        = ifelse(is_ui, "UI", "AOT"),
    COUNTERPART = NA_character_,
    NOTE        = ifelse(is_ui, "NOT_CHECKED", "AOT_ROLE")
  )
  if (!isTRUE(look_up) || !any(is_ui)) {
    return(plain)
  }

  mapping <- tryCatch(
    {
      loaded <- load_role_mapping(con)
      .check_required_columns(loaded, c("CONFIDENT", "DEVIDENT"), "role mapping")
      loaded
    },
    error = function(e) {
      warning("The role mapping could not be read, so the UI sub-roles stay as they are: ",
              .without_sql_statement(conditionMessage(e)), call. = FALSE)
      NULL
    }
  )
  if (is.null(mapping)) {
    return(plain)
  }

  rows <- lapply(seq_along(subroles), function(i) {
    if (!is_ui[[i]]) return(plain[i, ])
    .counterpart_row(con, plain[i, ], mapping)
  })
  dplyr::bind_rows(rows)
}

# The AOT role of the same name, compared with the UI role. Without a comparison
# the UI role stays: the same name does not mean the same content.
.counterpart_row <- function(con, row, mapping) {

  matches <- trimws(mapping$DEVIDENT[.identifier_key(mapping$CONFIDENT) == .identifier_key(row$SUBROLE) & !is.na(mapping$DEVIDENT)])
  found   <- matches[!duplicated(.identifier_key(matches))]
  if (length(found) != 1L) {
    return(dplyr::mutate(row, NOTE = if (length(found) == 0L) "NO_COUNTERPART" else "SEVERAL_COUNTERPARTS"))
  }

  note <- tryCatch(
    {
      verdict <- suppressMessages(compare_role_versions(con, found, row$SUBROLE))$Check$VERDICT
      note    <- if (length(verdict) == 1L) unname(.SUBROLE_VERDICT_NOTES[verdict]) else NA_character_
      if (is.na(note)) stop("unexpected result of the comparison: ", paste(verdict, collapse = ", "))
      note
    },
    error = function(e) {
      warning("Sub-role ", row$SUBROLE, " stays as it is: it could not be compared with its AOT counterpart ", found, ": ",
              .without_sql_statement(conditionMessage(e)), call. = FALSE)
      "NOT_COMPARED"
    }
  )
  dplyr::mutate(row, COUNTERPART = if (note == "NOT_COMPARED") NA_character_ else found, NOTE = note)
}
