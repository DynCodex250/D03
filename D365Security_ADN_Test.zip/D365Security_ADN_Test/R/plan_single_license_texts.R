# =============================================================================
# Texts of the workbook of plan_single_license_role()
#
# Used by export_single_license_plan.R. One catalogue per language with the
# same entries in the same order. "{license}" stands for the license of the
# plan, "{others}" for the other licenses that share an object, "{source}" for
# the role the plan starts from; "%d" and "%1$d" are numbers for sprintf().
# =============================================================================

.plan_texts <- function(language = .REPORT_DEFAULT_LANGUAGE) {
  switch(
    language,
    en = .plan_texts_en(),
    de = .plan_texts_de(),
    stop("No texts for language '", language, "'.")
  )
}

.plan_texts_en <- function() {
  list(
    sheets     = c(overview = "Overview", plan = "Building plan", blocks = "Building blocks", outside = "Stays outside", legend = "Legend"),
    title      = "Building plan: role {source} with the license {license} only",
    facts      = c("Role the plan starts from", "Role compared with (target role)", "License the role is to need", "Created on"),
    new_role   = "none: the plan describes a new role",
    no_duty    = "(no duty)",
    result     = "%1$d objects of the role can stay with %2$s, %3$d stay outside (sheet \"Stays outside\").",
    result_target = "The target role has %1$d of them, %2$d only for reading, %3$d are missing. %4$d privileges bring the missing ones in; %5$d objects need a privilege of their own.",
    result_new = "%1$d privileges the license covers bring them in; %2$d objects need a privilege of their own.",
    read_first = "How to read this file: sheet \"Legend\". The colours mark the objects other licenses cover as well.",
    summary_columns = c("Category", "Objects", "In the role", "Only read", "Missing"),
    plan_columns    = c("Category", "Object", "Type", "Access needed", "License (D365)", "In the target role",
                        "Comes in via", "Duties", "Privileges", "Note"),
    block_columns   = c("Kind", "Technical name", "Name", "Objects", "Objects the license does not cover",
                        "Already in the target role", "Assessment"),
    outside_columns = c("Object", "Type", "Access needed", "License (D365)", "Duties", "Privileges",
                        "Readable with the license via", "Target role reads it"),
    categories = c(ONLY = "only {license}", SHARED = "shared with {others}", ACTIVITY = "Operations - Activity is enough",
                   TEAM_MEMBERS = "Team Members or no license is enough", OUTSIDE = "not covered by {license}"),
    category_meanings = c(
      ONLY         = "Only {license} covers the object. These rows have no colour.",
      SHARED       = "The object needs a base license. {license} covers it, and so does {others}. It can go into the {license} role; the colour marks the other license.",
      ACTIVITY     = "Operations - Activity is enough for the object, so {license} covers it as well.",
      TEAM_MEMBERS = "Team Members, or no license at all, is enough for the object; {license} covers it as well.",
      OUTSIDE      = "{license} does not cover the object at the access the role grants. It is on the sheet \"Stays outside\"."
    ),
    states  = c(IN_ROLE = "yes", ONLY_READ = "only read", MISSING = "missing"),
    kinds   = c(DUTY = "Duty", PRIVILEGE = "Privilege"),
    fits    = c(WHOLE = "can go in as a whole", PARTLY = "only single privileges can go in", NONE = "stays outside"),
    actions = list(
      ADD          = c(one = "add: brings %d object in", other = "add: brings %d objects in"),
      NOT_POSSIBLE = c(one = "not possible: %d object needs another license", other = "not possible: %d objects need another license"),
      NOT_NEEDED   = c(one = "not needed: brings nothing new", other = "not needed: brings nothing new"),
      IN_ROLE      = c(one = "already in the role", other = "already in the role")
    ),
    notes  = c(NEW_PRIVILEGE = "only via a privilege of its own (development)"),
    yes_no = c(yes = "yes", no = "no"),
    legend = .plan_legend_en()
  )
}

.plan_legend_en <- function() {
  list(
    sheet_overview = c("Sheet \"Overview\"", "What was planned, the result in a few sentences, and the objects per category."),
    sheet_plan     = c("Sheet \"Building plan\"", "Every object {license} covers: what the {license} role can hold. The colour shows which other license covers the object as well."),
    sheet_blocks   = c("Sheet \"Building blocks\"", "The duties and privileges of the role: which can go into the {license} role as a whole, which only in parts, which not."),
    sheet_outside  = c("Sheet \"Stays outside\"", "The objects {license} does not cover, and whether the role could read them under {license}."),
    category       = c("Category", "Which license the object needs, seen from {license}. The colours of the categories are shown above."),
    in_target      = c("In the target role", "yes: the target role has the object. only read: it reads what the role writes. missing: it does not have it. Empty: no target role."),
    comes_in_via   = c("Comes in via", "The privileges {license} fully covers that bring the missing object in with the access needed. Add them to the target role."),
    note_new       = c("only via a privilege of its own (development)", "No privilege {license} fully covers brings the object in: every privilege that grants it holds an object of another license as well."),
    access         = c("Access needed", "Read or Write: the highest access the role grants."),
    license        = c("License (D365)", "The license text D365 gives for the object. \"Commerce or Supply Chain Management\" means: one of the named licenses is enough."),
    duties         = c("Duties / Privileges", "Where the object comes from in the role. \"(no duty)\": a privilege assigned to the role directly."),
    assessment     = c("Assessment", "For a duty: can go in as a whole / only single privileges can go in / stays outside. For a privilege: the action below."),
    action_add     = c("add: brings n objects in", "{license} covers all objects of the privilege; adding it brings the named number of missing objects in."),
    action_no      = c("not possible: n objects need another license", "The privilege holds objects {license} does not cover; with it the role would need another license."),
    action_none    = c("not needed: brings nothing new", "{license} covers the privilege, but the target role has its objects already."),
    action_in_role = c("already in the role", "The target role holds the privilege."),
    readable_via   = c("Readable with the license via", "Privileges of the role that grant the object for reading under {license}. Empty: the role has no such privilege."),
    comparison     = c("How the plan works", "The role comes from the license graph of D365 (table LicensingSecurityObjectExplodedGraph). Objects are compared by name and judged at the highest access the role grants.")
  )
}

.plan_texts_de <- function() {
  list(
    sheets     = c(overview = "Überblick", plan = "Bauplan", blocks = "Bausteine", outside = "Bleibt draußen", legend = "Legende"),
    title      = "Bauplan: Rolle {source} nur mit der Lizenz {license}",
    facts      = c("Rolle, von der der Plan ausgeht", "Rolle, mit der verglichen wird (Zielrolle)", "Lizenz, die die Rolle brauchen soll", "Erstellt am"),
    new_role   = "keine: der Plan beschreibt eine neue Rolle",
    no_duty    = "(keine Aufgabe)",
    result     = "%1$d Objekte der Rolle können bei %2$s bleiben, %3$d bleiben draußen (Blatt „Bleibt draußen“).",
    result_target = "Die Zielrolle hat %1$d davon, %2$d nur lesend, %3$d fehlen. %4$d Rechte bringen die fehlenden hinein; %5$d Objekte brauchen ein eigenes Recht.",
    result_new = "%1$d Rechte, die die Lizenz deckt, bringen sie hinein; %2$d Objekte brauchen ein eigenes Recht.",
    read_first = "So lesen Sie diese Datei: Blatt „Legende“. Die Farben markieren die Objekte, die auch andere Lizenzen decken.",
    summary_columns = c("Kategorie", "Objekte", "In der Rolle", "Nur lesend", "Fehlt"),
    plan_columns    = c("Kategorie", "Objekt", "Typ", "Benötigter Zugriff", "Lizenz (D365)", "In der Zielrolle",
                        "Kommt hinein über", "Aufgaben", "Rechte", "Hinweis"),
    block_columns   = c("Art", "Technischer Name", "Bezeichnung", "Objekte", "Objekte, die die Lizenz nicht deckt",
                        "Schon in der Zielrolle", "Bewertung"),
    outside_columns = c("Objekt", "Typ", "Benötigter Zugriff", "Lizenz (D365)", "Aufgaben", "Rechte",
                        "Lesend mit der Lizenz über", "Zielrolle liest es"),
    categories = c(ONLY = "nur {license}", SHARED = "Schnittmenge mit {others}", ACTIVITY = "Activity reicht",
                   TEAM_MEMBERS = "Team Members oder keine Lizenz reicht", OUTSIDE = "nicht von {license} gedeckt"),
    category_meanings = c(
      ONLY         = "Nur {license} deckt das Objekt. Diese Zeilen haben keine Farbe.",
      SHARED       = "Das Objekt braucht eine Basislizenz. {license} deckt es, ebenso {others}. Es kann in die {license}-Rolle; die Farbe zeigt die andere Lizenz.",
      ACTIVITY     = "Für das Objekt reicht Operations - Activity, also deckt es auch {license}.",
      TEAM_MEMBERS = "Für das Objekt reicht Team Members oder gar keine Lizenz; auch {license} deckt es.",
      OUTSIDE      = "{license} deckt das Objekt mit dem Zugriff, den die Rolle gewährt, nicht. Es steht auf dem Blatt „Bleibt draußen“."
    ),
    states  = c(IN_ROLE = "ja", ONLY_READ = "nur lesend", MISSING = "fehlt"),
    kinds   = c(DUTY = "Aufgabe", PRIVILEGE = "Recht"),
    fits    = c(WHOLE = "kann ganz hinein", PARTLY = "nur einzelne Rechte können hinein", NONE = "bleibt draußen"),
    actions = list(
      ADD          = c(one = "aufnehmen: bringt %d Objekt hinein", other = "aufnehmen: bringt %d Objekte hinein"),
      NOT_POSSIBLE = c(one = "nicht möglich: %d Objekt braucht eine andere Lizenz", other = "nicht möglich: %d Objekte brauchen eine andere Lizenz"),
      NOT_NEEDED   = c(one = "nicht nötig: bringt nichts Neues", other = "nicht nötig: bringt nichts Neues"),
      IN_ROLE      = c(one = "schon in der Rolle", other = "schon in der Rolle")
    ),
    notes  = c(NEW_PRIVILEGE = "nur über ein eigenes Recht (Entwicklung)"),
    yes_no = c(yes = "ja", no = "nein"),
    legend = .plan_legend_de()
  )
}

.plan_legend_de <- function() {
  list(
    sheet_overview = c("Blatt „Überblick“", "Was geplant wurde, das Ergebnis in wenigen Sätzen und die Objekte je Kategorie."),
    sheet_plan     = c("Blatt „Bauplan“", "Jedes Objekt, das {license} deckt: was die {license}-Rolle enthalten kann. Die Farbe zeigt, welche andere Lizenz das Objekt ebenfalls deckt."),
    sheet_blocks   = c("Blatt „Bausteine“", "Die Aufgaben und Rechte der Rolle: welche ganz in die {license}-Rolle können, welche nur teilweise, welche nicht."),
    sheet_outside  = c("Blatt „Bleibt draußen“", "Die Objekte, die {license} nicht deckt, und ob die Rolle sie unter {license} lesen könnte."),
    category       = c("Kategorie", "Welche Lizenz das Objekt braucht, gesehen von {license}. Die Farben der Kategorien stehen oben."),
    in_target      = c("In der Zielrolle", "ja: Die Zielrolle hat das Objekt. nur lesend: Sie liest, was die Rolle schreibt. fehlt: Sie hat es nicht. Leer: keine Zielrolle."),
    comes_in_via   = c("Kommt hinein über", "Die Rechte, die {license} ganz deckt und die das fehlende Objekt mit dem nötigen Zugriff hineinbringen. Diese Rechte in die Zielrolle aufnehmen."),
    note_new       = c("nur über ein eigenes Recht (Entwicklung)", "Kein Recht, das {license} ganz deckt, bringt das Objekt hinein: Jedes Recht, das es gewährt, enthält auch ein Objekt einer anderen Lizenz."),
    access         = c("Benötigter Zugriff", "Read (lesen) oder Write (schreiben): der höchste Zugriff, den die Rolle gewährt."),
    license        = c("Lizenz (D365)", "Der Lizenztext, den D365 für das Objekt angibt. „Commerce or Supply Chain Management“ heißt: Eine der genannten Lizenzen reicht."),
    duties         = c("Aufgaben / Rechte", "Woher das Objekt in der Rolle kommt. „(keine Aufgabe)“: ein Recht, das der Rolle direkt zugeordnet ist."),
    assessment     = c("Bewertung", "Bei einer Aufgabe: kann ganz hinein / nur einzelne Rechte können hinein / bleibt draußen. Bei einem Recht: die Maßnahme unten."),
    action_add     = c("aufnehmen: bringt n Objekte hinein", "{license} deckt alle Objekte des Rechts; das Recht bringt die genannte Zahl fehlender Objekte hinein."),
    action_no      = c("nicht möglich: n Objekte brauchen eine andere Lizenz", "Das Recht enthält Objekte, die {license} nicht deckt; mit ihm bräuchte die Rolle eine andere Lizenz."),
    action_none    = c("nicht nötig: bringt nichts Neues", "{license} deckt das Recht, aber die Zielrolle hat seine Objekte schon."),
    action_in_role = c("schon in der Rolle", "Die Zielrolle hat das Recht."),
    readable_via   = c("Lesend mit der Lizenz über", "Rechte der Rolle, die das Objekt unter {license} zum Lesen gewähren. Leer: Die Rolle hat kein solches Recht."),
    comparison     = c("So funktioniert der Plan", "Die Rolle stammt aus dem Lizenzgraphen von D365 (Tabelle LicensingSecurityObjectExplodedGraph). Objekte werden über ihren Namen verglichen und mit dem höchsten Zugriff bewertet, den die Rolle gewährt.")
  )
}
