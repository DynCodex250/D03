# This file stands alone: the Rmd files source it before they load the package, because the
# configuration tells them where the package is.

#' Read the central configuration of the project
#'
#' Reads \code{inst/config/config.yml}, which holds the paths and settings of
#' the Rmd files, so that they need no paths of their own.
#'
#' @details
#'
#' **Roots.** The section \code{base_paths} names \code{project_root},
#' \code{input_root}, \code{output_root} and \code{keys_root}. A relative root
#' counts from the project folder, so the file works on every machine with the
#' same folders: \code{../Input} lies next to the project. The result holds the
#' roots as full paths, so \code{file.path(cfg$base_paths$input_root, ...)} can
#' be used directly.
#'
#' **Without the file.** A warning, and the default folders of the project:
#' the roots above and \code{db_credentials.xlsx}. What only the file names,
#' such as the input files of a deliverable, is then empty.
#'
#' @param project
#' The project folder. \code{NULL} = look from the working directory: the
#' project folder itself, or \code{Data/Documentation} below it.
#'
#' @return
#' The section \code{default} of the file as a nested list, the roots as full
#' paths; the default folders when the file is missing.
#'
#' @examples
#' \dontrun{
#'
#' cfg <- load_project_config()
#' get_connection("ADN", file.path(cfg$base_paths$project_root, cfg$connection$credentials_path))
#'
#' }
#'
#' @seealso
#' \code{\link{resolve_path}}
#'
#' @export
load_project_config <- function(project = NULL) {

  path <- .project_config_file(project)
  if (is.na(path)) {
    warning("inst/config/config.yml was not found; the default folders are used.", call. = FALSE)
    return(.with_full_roots(.PROJECT_DEFAULTS, if (is.null(project)) "." else project))
  }
  cfg <- yaml::yaml.load_file(path)$default
  if (is.null(cfg)) stop("'", path, "' has no section default.", call. = FALSE)
  .with_full_roots(cfg, dirname(dirname(dirname(path))))
}

.PROJECT_ROOTS <- c("project_root", "input_root", "output_root", "keys_root")

.PROJECT_DEFAULTS <- list(
  connection = list(credentials_path = "db_credentials.xlsx"),
  pseudonymization = list(key_file = "anonymization_key.xlsx"),
  base_paths = list(project_root = ".", input_root = "../Input", output_root = "../Output", keys_root = "../Keys")
)

# The value of a parameter that switches an optional input off, whatever the configuration says.
.NO_PATH <- "none"

# The telemetry source that is no path: read_usage_telemetry() loads it from Application Insights.
.INSIGHTS_SOURCE <- "insights"

.is_given <- function(value) length(value) == 1L && !is.na(value) && nzchar(trimws(value))

.with_full_roots <- function(cfg, folder) {
  roots <- intersect(.PROJECT_ROOTS, names(cfg$base_paths))
  cfg$base_paths[roots] <- lapply(cfg$base_paths[roots], .full_path, root = folder)
  cfg
}

.project_config_file <- function(project) {
  folders    <- if (is.null(project)) c(".", file.path("..", ".."), "..") else project
  candidates <- file.path(folders, "inst", "config", "config.yml")
  found      <- candidates[file.exists(candidates)]
  if (length(found) == 0L) NA_character_ else normalizePath(found[[1]], winslash = "/")
}

.full_path <- function(path, root) {
  expanded <- path.expand(path)
  if (grepl("^([A-Za-z]:|[/\\\\])", expanded)) return(expanded)
  normalizePath(file.path(root, expanded), winslash = "/", mustWork = FALSE)
}

#' Choose a path from a parameter, the configuration or a fallback
#'
#' An Rmd takes its paths from \code{inst/config/config.yml}; a parameter given
#' to \code{rmarkdown::render()} goes first.
#'
#' @param param_val
#' The value of the parameter. Given, it wins; a relative path counts from
#' \code{project}. \code{"none"} switches the input off, whatever the
#' configuration says.
#'
#' @param config_rel_path
#' The value from the configuration; a relative path counts from
#' \code{base_root}.
#'
#' @param base_root
#' The root of \code{config_rel_path}, as a rule from
#' \code{cfg$base_paths}. Empty = \code{project}.
#'
#' @param project
#' The project folder. Default \code{base_root}.
#'
#' @param fallback
#' Used when neither is set, as when the configuration is missing; a relative
#' path counts from \code{project}.
#'
#' @param optional
#' \code{TRUE} = the input can stay off: a path from the configuration that
#' does not exist gives a warning and \code{""}, as on a machine without the
#' file. A parameter that does not exist still counts: the error must show.
#' Default \code{FALSE}.
#'
#' @return
#' The full path, or \code{""} when nothing is set: an optional input then stays
#' off, and a required one is for the caller to report.
#'
#' @examples
#' \dontrun{
#'
#' cfg <- load_project_config()
#' resolve_path(params$ppac_detail, cfg$d03_bestands_und_lizenzanalyse$inputs$ppac_detail,
#'              cfg$base_paths$input_root, cfg$base_paths$project_root)
#'
#' }
#'
#' @seealso
#' \code{\link{load_project_config}}
#'
#' @export
resolve_path <- function(param_val, config_rel_path, base_root, project = base_root, fallback = "", optional = FALSE) {

  project <- if (.is_given(project)) project else "."
  if (.is_given(param_val)) {
    return(if (tolower(trimws(param_val)) == .NO_PATH) "" else .full_path(param_val, project))
  }
  if (.is_given(config_rel_path)) {
    path <- .full_path(config_rel_path, if (.is_given(base_root)) base_root else project)
    if (!optional || file.exists(path)) return(path)
    warning("'", path, "' from inst/config/config.yml does not exist; this input stays off.", call. = FALSE)
    return("")
  }
  if (.is_given(fallback)) return(.full_path(fallback, project))
  ""
}

#' Choose the source of the telemetry
#'
#' Works like \code{\link{resolve_path}}, and keeps the keyword
#' \code{"insights"}, which is no path: \code{\link{read_usage_telemetry}} then
#' loads the telemetry from Application Insights.
#'
#' @inheritParams resolve_path
#'
#' @return
#' \code{"insights"}, the full path, or \code{""} when nothing is set.
#'
#' @examples
#' \dontrun{
#'
#' quelle <- resolve_telemetry(params$telemetrie, cfg$analyse_rolle_lizenzen$params$telemetrie,
#'                             cfg$base_paths$input_root, cfg$base_paths$project_root)
#' read_usage_telemetry(quelle, user_ids = "real")
#'
#' }
#'
#' @seealso
#' \code{\link{resolve_path}}
#' \code{\link{read_usage_telemetry}}
#'
#' @export
resolve_telemetry <- function(param_val, config_rel_path, base_root, project = base_root, fallback = "", optional = FALSE) {

  chosen <- Find(.is_given, list(param_val, config_rel_path, fallback))
  if (!is.null(chosen) && tolower(trimws(chosen)) == .INSIGHTS_SOURCE) return(.INSIGHTS_SOURCE)
  resolve_path(param_val, config_rel_path, base_root, project, fallback, optional)
}
