#' Compare two versions of a role
#'
#' Many roles exist twice: as an AOT role from development and as a role of
#' the same name created in the user interface (its identifier is a GUID).
#' The function compares two such versions: which building blocks, duties,
#' privileges and objects only one of them has, which objects they grant with
#' different access or license, and what licenses each needs.
#'
#' @details
#'
#' Both roles are analysed as in \code{\link{analyze_role_license_report}},
#' without users. Objects are compared by name, as in the role license report.
#'
#' **Sides** (column \code{SIDE}): \code{ONLY_A}, \code{ONLY_B}, and for
#' elements both versions have \code{ASSIGNMENT} (a duty directly in one role,
#' through a sub-role in the other), \code{LICENSE} (other license need) and
#' \code{ACCESS} (an object granted with other access).
#'
#' For a building block or privilege only one version has, \code{IN_OTHER}
#' counts how many of its \code{OBJECTS} the other version grants as well: when
#' both are equal, the other version holds the same function in another
#' building block.
#'
#' **Verdict** (\code{Check$VERDICT}), on the objects and their access:
#' \code{SAME}, \code{A_IN_B} (B grants everything A grants, and more),
#' \code{B_IN_A}, or \code{DIFFERENT}.
#'
#' @param con
#' Database connection. Result of \code{get_connection()}.
#'
#' @param role_a,role_b
#' AOT name or GUID of the two versions, for example the AOT role and the UI
#' role of the same name.
#'
#' @param export_path
#' Path of the Excel file (\code{.xlsx}). \code{NULL} = no file.
#'
#' @param language
#' Language of the workbook: \code{"en"} or \code{"de"}. The legend is always
#' in both.
#'
#' @return
#' List with \code{Check}, \code{Summary}, \code{Licenses}, \code{Blocks},
#' \code{Duties}, \code{Privileges} and \code{Objects}.
#'
#' @examples
#' \dontrun{
#'
#' versions <- compare_role_versions(
#'   cnn,
#'   role_a      = "_WIBU_VERKAUF_INNENDIENST_MITARBEITER",
#'   role_b      = "32B63442-1415-459D-8FF0-399780947265",
#'   export_path = "Data/Versions_Verkauf_Innendienst.xlsx",
#'   language    = "de"
#' )
#' versions$Check$VERDICT
#'
#' }
#'
#' @seealso
#' \code{\link{compare_role_version_pairs}}
#' \code{\link{load_role_mapping}}
#'
#' @export
compare_role_versions <- function(con, role_a, role_b, export_path = NULL, language = "en") {

  if (!.is_single_string(role_a) || !.is_single_string(role_b)) {
    stop("role_a and role_b must each name one role: the AOT name, or the GUID of a role created in the user interface.",
         call. = FALSE)
  }
  .check_xlsx_path(export_path)
  language <- .check_report_language(language)

  a <- .role_version_part(con, role_a)
  b <- .role_version_part(con, role_b)

  check  <- list(
    ROLE_A = role_a, ROLE_B = role_b, NAME_A = a$NAME, NAME_B = b$NAME,
    KIND_A = .role_kind(role_a), KIND_B = .role_kind(role_b), CREATED = Sys.Date()
  )
  result <- .version_result(a, b, check)

  message(.version_message(result))

  if (!is.null(export_path)) {
    .export_role_versions(result, export_path, language)
  }

  result
}

.VERSION_SIDES <- c("ONLY_A", "ONLY_B", "ASSIGNMENT", "LICENSE", "ACCESS")
.VERSION_ITEMS <- c("BLOCKS", "DUTIES", "PRIVILEGES", "OBJECTS")

.role_kind <- function(role) {
  if (is_guid_name(role)) "UI" else "AOT"
}

# The role part of the license report for one role, with its drivers and name.
.role_version_part <- function(con, role) {

  source  <- .load_role_report_source(con, role, "^Base")
  drivers <- build_role_license_drivers(
    source$role_objects, source$license_requirements,
    base_group_pattern = "^Base", measurable_type_pattern = .MEASURABLE_TYPE_PATTERN
  )
  report <- build_role_license_report(
    drivers, .role_structure(source$role_objects), .sku_table(source$license_requirements), "^Base"
  )
  role_names <- source$role_objects$ROLENAME[!is.na(source$role_objects$ROLENAME) & nzchar(source$role_objects$ROLENAME)]

  c(report, list(Drivers = drivers, NAME = if (length(role_names) > 0L) role_names[[1]] else role))
}

.version_result <- function(a, b, check) {

  blocks     <- .version_blocks(a, b)
  duties     <- .version_duties(a, b)
  privileges <- .version_privileges(a, b)
  objects    <- .version_objects(a, b)

  check$VERDICT <- .version_verdict(objects)

  list(
    Check      = check,
    Summary    = .version_summary(a, b, blocks, duties, privileges, objects),
    Licenses   = .version_licenses(a, b, check),
    Blocks     = blocks,
    Duties     = duties,
    Privileges = privileges,
    Objects    = objects
  )
}

# Building blocks assigned directly that only one version has.
.version_blocks <- function(a, b) {

  key  <- function(part) paste(part$Blocks$BLOCK_TYPE, .identifier_key(part$Blocks$BLOCK_ID))
  only <- function(part, other, side) {
    counts <- part$BlockObjects |>
      dplyr::group_by(BLOCK_TYPE, BLOCK_ID) |>
      dplyr::summarise(
        OBJECTS  = dplyr::n_distinct(ENTRYPOINT_KEY),
        IN_OTHER = dplyr::n_distinct(ENTRYPOINT_KEY[ENTRYPOINT_KEY %in% other$ObjectNeeds$ENTRYPOINT_KEY]),
        .groups  = "drop"
      )
    part$Blocks[!key(part) %in% key(other), ] |>
      dplyr::left_join(counts, by = c("BLOCK_TYPE", "BLOCK_ID")) |>
      dplyr::mutate(SIDE = side, OBJECTS = dplyr::coalesce(OBJECTS, 0L), IN_OTHER = dplyr::coalesce(IN_OTHER, 0L)) |>
      dplyr::select(SIDE, BLOCK_TYPE, BLOCK_ID, BLOCK_NAME, NEED, IS_BASE, OBJECTS, IN_OTHER)
  }

  dplyr::bind_rows(only(a, b, "ONLY_A"), only(b, a, "ONLY_B")) |>
    dplyr::arrange(match(SIDE, .VERSION_SIDES), BLOCK_TYPE, BLOCK_ID)
}

# Duties only one version has, or that both have with another assignment or license.
.version_duties <- function(a, b) {

  side_table <- function(part, suffix) {
    table <- dplyr::transmute(
      part$Duties, KEY = .identifier_key(DUTYIDENTIFIER), DUTY = DUTYIDENTIFIER, NAME = DUTYNAME,
      ASSIGNMENT = ASSIGNMENT, NEED = NEED, IS_BASE = IS_BASE
    )
    names(table)[-1] <- paste0(names(table)[-1], suffix)
    table
  }

  dplyr::full_join(side_table(a, "_A"), side_table(b, "_B"), by = "KEY") |>
    dplyr::mutate(
      DUTY = dplyr::coalesce(DUTY_A, DUTY_B),
      NAME = dplyr::coalesce(NAME_A, NAME_B),
      SIDE = dplyr::case_when(
        is.na(DUTY_B)                ~ "ONLY_A",
        is.na(DUTY_A)                ~ "ONLY_B",
        ASSIGNMENT_A != ASSIGNMENT_B ~ "ASSIGNMENT",
        NEED_A != NEED_B             ~ "LICENSE",
        TRUE                         ~ NA_character_
      )
    ) |>
    dplyr::filter(!is.na(SIDE)) |>
    dplyr::arrange(match(SIDE, .VERSION_SIDES), DUTY) |>
    dplyr::select(SIDE, DUTY, NAME, ASSIGNMENT_A, ASSIGNMENT_B, NEED_A, IS_BASE_A, NEED_B, IS_BASE_B)
}

# Privileges only one version has, with how many of their objects the other grants.
.version_privileges <- function(a, b) {

  table <- function(part) {
    part$Privileges |>
      dplyr::group_by(KEY = .identifier_key(PRIVILEGEIDENTIFIER)) |>
      dplyr::summarise(
        PRIVILEGE = dplyr::first(PRIVILEGEIDENTIFIER), NAME = dplyr::first(PRIVILEGENAME),
        DUTIES = .collapse_sorted(DUTYIDENTIFIER, .LIST_SEPARATOR),
        NEED = dplyr::first(NEED), IS_BASE = dplyr::first(IS_BASE), .groups = "drop"
      )
  }
  only <- function(part, other, side) {
    # only objects with license data, as in ObjectNeeds of the other version
    with_license <- !is.na(part$Drivers$ENTRYPOINT) &
      part$Drivers$LICENSE_STATUS %in% c(.LICENSE_LICENSED, .LICENSE_NOT_ENTITLED)
    counts <- part$Drivers[with_license, ] |>
      dplyr::transmute(KEY = .identifier_key(PRIVILEGEIDENTIFIER), OBJECT_KEY = toupper(ENTRYPOINT)) |>
      dplyr::group_by(KEY) |>
      dplyr::summarise(
        OBJECTS  = dplyr::n_distinct(OBJECT_KEY),
        IN_OTHER = dplyr::n_distinct(OBJECT_KEY[OBJECT_KEY %in% other$ObjectNeeds$ENTRYPOINT_KEY]),
        .groups  = "drop"
      )
    own <- table(part)
    own[!own$KEY %in% table(other)$KEY, ] |>
      dplyr::left_join(counts, by = "KEY") |>
      dplyr::mutate(SIDE = side, OBJECTS = dplyr::coalesce(OBJECTS, 0L), IN_OTHER = dplyr::coalesce(IN_OTHER, 0L))
  }

  dplyr::bind_rows(only(a, b, "ONLY_A"), only(b, a, "ONLY_B")) |>
    dplyr::arrange(match(SIDE, .VERSION_SIDES), PRIVILEGE) |>
    dplyr::select(SIDE, PRIVILEGE, NAME, DUTIES, NEED, IS_BASE, OBJECTS, IN_OTHER)
}

# Objects only one version grants, or that both grant with other access or license.
.version_objects <- function(a, b) {

  side_table <- function(part, suffix) {
    table <- dplyr::transmute(
      part$ObjectNeeds, KEY = ENTRYPOINT_KEY, OBJECT = ENTRYPOINT, TYPE = ENTRYPOINTTYPE,
      ACCESS = as.numeric(ACCESSLEVEL), NEED = NEED, IS_BASE = IS_BASE
    )
    names(table)[-1] <- paste0(names(table)[-1], suffix)
    table
  }

  dplyr::full_join(side_table(a, "_A"), side_table(b, "_B"), by = "KEY") |>
    dplyr::mutate(
      OBJECT = dplyr::coalesce(OBJECT_A, OBJECT_B),
      TYPE   = dplyr::coalesce(TYPE_A, TYPE_B),
      SIDE   = dplyr::case_when(
        is.na(OBJECT_B)     ~ "ONLY_A",
        is.na(OBJECT_A)     ~ "ONLY_B",
        ACCESS_A != ACCESS_B ~ "ACCESS",
        NEED_A != NEED_B     ~ "LICENSE",
        TRUE                 ~ NA_character_
      )
    ) |>
    dplyr::filter(!is.na(SIDE)) |>
    dplyr::arrange(match(SIDE, .VERSION_SIDES), OBJECT) |>
    dplyr::select(SIDE, OBJECT, TYPE, ACCESS_A, ACCESS_B, NEED_A, IS_BASE_A, NEED_B, IS_BASE_B)
}

# Whether one version grants every object of the other with at least its access.
.version_verdict <- function(objects) {

  higher_a <- objects$SIDE == "ACCESS" & objects$ACCESS_A > objects$ACCESS_B
  higher_b <- objects$SIDE == "ACCESS" & objects$ACCESS_B > objects$ACCESS_A
  a_extra  <- any(objects$SIDE == "ONLY_A" | higher_a)
  b_extra  <- any(objects$SIDE == "ONLY_B" | higher_b)

  if (!a_extra && !b_extra) "SAME" else if (!a_extra) "A_IN_B" else if (!b_extra) "B_IN_A" else "DIFFERENT"
}

.version_summary <- function(a, b, blocks, duties, privileges, objects) {

  count <- function(table, side) sum(table$SIDE == side)
  different <- function(table) sum(!table$SIDE %in% c("ONLY_A", "ONLY_B"))
  tables <- list(BLOCKS = blocks, DUTIES = duties, PRIVILEGES = privileges, OBJECTS = objects)

  tibble::tibble(
    ITEM      = .VERSION_ITEMS,
    A         = c(nrow(a$Blocks), nrow(a$Duties), dplyr::n_distinct(a$Privileges$PRIVILEGEIDENTIFIER), nrow(a$ObjectNeeds)),
    B         = c(nrow(b$Blocks), nrow(b$Duties), dplyr::n_distinct(b$Privileges$PRIVILEGEIDENTIFIER), nrow(b$ObjectNeeds)),
    ONLY_A    = vapply(tables, count, integer(1), side = "ONLY_A", USE.NAMES = FALSE),
    ONLY_B    = vapply(tables, count, integer(1), side = "ONLY_B", USE.NAMES = FALSE),
    DIFFERENT = vapply(tables, different, integer(1), USE.NAMES = FALSE)
  )
}

# The base licenses each version needs; the need itself when no base license fixes it.
.version_licenses <- function(a, b, check) {

  licenses <- function(part) {
    fixing <- .fixing_license_names(part$ObjectNeeds)
    if (length(fixing) > 0L) paste(fixing, collapse = .LIST_SEPARATOR) else part$RoleNeed$NEED
  }

  tibble::tibble(
    VERSION  = c("A", "B"),
    ROLE     = c(check$ROLE_A, check$ROLE_B),
    NEED     = c(a$RoleNeed$NEED, b$RoleNeed$NEED),
    LICENSES = c(licenses(a), licenses(b))
  )
}

.version_message <- function(result) {

  check   <- result$Check
  objects <- result$Summary[result$Summary$ITEM == "OBJECTS", ]

  sprintf(
    "%s and %s: %s. Objects only in A: %d, only in B: %d, other access or license: %d.",
    check$ROLE_A, check$ROLE_B, check$VERDICT, objects$ONLY_A, objects$ONLY_B, objects$DIFFERENT
  )
}

#' Compare every AOT role with the UI role of the same name
#'
#' Runs \code{\link{compare_role_versions}} for each pair of versions and
#' collects the result in one table. A pair that cannot be compared does not
#' stop the others: the function warns and gives its reason in \code{ERROR}.
#'
#' @param con
#' Database connection. Result of \code{get_connection()}.
#'
#' @param pairs
#' Table with the columns \code{DEVIDENT} (AOT role) and \code{CONFIDENT}
#' (UI role), optionally \code{DEVROLE} and \code{CONFROLE} (names). Default:
#' every pair \code{\link{load_role_mapping}} finds.
#'
#' @param export_folder
#' Folder for one workbook per pair and the overview
#' \code{Role_versions_overview.xlsx}. \code{NULL} = no files.
#'
#' @param language
#' Language of the workbooks: \code{"en"} or \code{"de"}.
#'
#' @return
#' Tibble with one row per pair: roles, verdict, numbers of differences,
#' licenses of both versions, file and error.
#'
#' @examples
#' \dontrun{
#'
#' overview <- compare_role_version_pairs(cnn, export_folder = "Data/Role_versions", language = "de")
#' overview[overview$VERDICT != "SAME", ]
#'
#' }
#'
#' @seealso
#' \code{\link{compare_role_versions}}
#'
#' @export
compare_role_version_pairs <- function(con, pairs = NULL, export_folder = NULL, language = "en") {

  language <- .check_report_language(language)
  if (!is.null(export_folder) && !.is_single_string(export_folder)) {
    stop("export_folder must be the path of one folder.", call. = FALSE)
  }
  pairs <- .version_pairs(con, pairs)

  if (!is.null(export_folder) && !dir.exists(export_folder)) {
    dir.create(export_folder, recursive = TRUE)
  }

  rows <- lapply(seq_len(nrow(pairs)), function(i) .version_pair_row(con, pairs[i, ], i, export_folder, language))
  overview <- dplyr::bind_rows(c(list(.version_overview_template()), rows))

  if (!is.null(export_folder)) {
    .export_version_overview(overview, file.path(export_folder, "Role_versions_overview.xlsx"), language)
  }

  overview
}

.version_pairs <- function(con, pairs) {

  if (is.null(pairs)) {
    pairs <- load_role_mapping(con)
  }
  .check_required_columns(pairs, c("DEVIDENT", "CONFIDENT"), "pairs")

  pairs <- pairs[!is.na(pairs$DEVIDENT) & !is.na(pairs$CONFIDENT), ]
  if (!"DEVROLE" %in% names(pairs)) pairs$DEVROLE <- pairs$DEVIDENT
  if (!"CONFROLE" %in% names(pairs)) pairs$CONFROLE <- pairs$CONFIDENT

  pairs
}

# The number keeps two pairs of one AOT role apart, for example two UI roles of one name.
.version_pair_row <- function(con, pair, number, export_folder, language) {

  path <- if (is.null(export_folder)) NULL else {
    file.path(export_folder, sprintf("Role_versions_%03d_%s.xlsx", number, gsub("[^A-Za-z0-9_-]", "_", pair$DEVIDENT)))
  }

  tryCatch(
    .version_overview_row(pair, compare_role_versions(con, pair$DEVIDENT, pair$CONFIDENT, path, language), path),
    error = function(e) {
      reason <- .without_sql_statement(conditionMessage(e))
      warning("No comparison of '", pair$DEVIDENT, "' and '", pair$CONFIDENT, "': ", reason, call. = FALSE)
      .version_overview_row(pair, NULL, NA_character_, reason)
    }
  )
}

# The columns of the overview, also when there is no pair to compare.
.version_overview_template <- function() {
  tibble::tibble(
    ROLE_A = character(), NAME_A = character(), ROLE_B = character(), NAME_B = character(), VERDICT = character(),
    BLOCKS_ONLY_A = integer(), BLOCKS_ONLY_B = integer(), DUTIES_ONLY_A = integer(), DUTIES_ONLY_B = integer(),
    OBJECTS_ONLY_A = integer(), OBJECTS_ONLY_B = integer(), OBJECTS_DIFFERENT = integer(),
    LICENSES_A = character(), LICENSES_B = character(), FILE = character(), ERROR = character()
  )
}

.version_overview_row <- function(pair, result, path, error = NA_character_) {

  summary <- if (is.null(result)) NULL else result$Summary
  number  <- function(item, column) if (is.null(summary)) NA_integer_ else summary[[column]][summary$ITEM == item]

  tibble::tibble(
    ROLE_A = pair$DEVIDENT, NAME_A = pair$DEVROLE, ROLE_B = pair$CONFIDENT, NAME_B = pair$CONFROLE,
    VERDICT = if (is.null(result)) NA_character_ else result$Check$VERDICT,
    BLOCKS_ONLY_A = number("BLOCKS", "ONLY_A"), BLOCKS_ONLY_B = number("BLOCKS", "ONLY_B"),
    DUTIES_ONLY_A = number("DUTIES", "ONLY_A"), DUTIES_ONLY_B = number("DUTIES", "ONLY_B"),
    OBJECTS_ONLY_A = number("OBJECTS", "ONLY_A"), OBJECTS_ONLY_B = number("OBJECTS", "ONLY_B"),
    OBJECTS_DIFFERENT = number("OBJECTS", "DIFFERENT"),
    LICENSES_A = if (is.null(result)) NA_character_ else result$Licenses$LICENSES[[1]],
    LICENSES_B = if (is.null(result)) NA_character_ else result$Licenses$LICENSES[[2]],
    FILE = if (is.null(path)) NA_character_ else path, ERROR = error
  )
}
