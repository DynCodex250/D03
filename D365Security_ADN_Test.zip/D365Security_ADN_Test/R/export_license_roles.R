# =============================================================================
# Workbook of build_license_roles()
#
# Overview, Roles (building blocks), New privileges, Privileges, Objects, Users
# and Legend. Values are written as plain words; the legend shows English and
# German side by side.
# =============================================================================

.license_roles_texts <- function(language) {

  texts <- list(
    en = list(
      sheets  = c(overview = "Overview", blocks = "Roles", new = "New privileges", privileges = "Privileges",
                  objects = "Objects", users = "Users", legend = "Legend"),
      title   = "Roles per license from the usage of a role",
      facts   = c("Role", "Licenses", "Usage data", "Users counted", "Created"),
      yes_no  = c("yes", "no"),
      summary = c("License", "Role", "Duties (whole)", "Privileges", "New privileges", "Objects", "Users who need it"),
      blocks  = c("License", "Role", "Kind", "Building block", "Comes from", "Objects"),
      new     = c("License", "New privilege", "From privilege", "Object", "Type", "Access"),
      privileges = c("Privilege", "Name", "Duties", "Status", "Objects", "of them forms", "of them used", "Kept"),
      objects = c("Object", "Type", "Access", "License", "Form", "Used", "Kept", "In the roles"),
      users   = c("User", "Status", "Forms used", "Cheapest single license", "Licenses", "Roles", "Forms no role covers"),
      access  = c("Read", "Write"),
      kinds   = c(Duty = "Duty (whole)", Privilege = "Privilege", NewPrivilege = "New privilege"),
      status  = c(USED = "used", WITH_DUTY = "kept with its duty", NOT_MEASURABLE = "not measurable, kept",
                  ALL = "kept, no usage data", NOT_USED = "not used, left out"),
      user_status = c(COVERED = "covered", NOT_COVERED = "not fully covered", NO_DATA = "no usage data")
    ),
    de = list(
      sheets  = c(overview = "Überblick", blocks = "Rollen", new = "Neue Rechte", privileges = "Rechte",
                  objects = "Objekte", users = "Benutzer", legend = "Legende"),
      title   = "Rollen je Lizenz aus der Nutzung einer Rolle",
      facts   = c("Rolle", "Lizenzen", "Nutzungsdaten", "Gezählte Benutzer", "Erstellt"),
      yes_no  = c("ja", "nein"),
      summary = c("Lizenz", "Rolle", "Aufgaben (ganz)", "Rechte", "Neue Rechte", "Objekte", "Benutzer, die sie brauchen"),
      blocks  = c("Lizenz", "Rolle", "Art", "Baustein", "Stammt aus", "Objekte"),
      new     = c("Lizenz", "Neues Recht", "Aus Recht", "Objekt", "Typ", "Zugriff"),
      privileges = c("Recht", "Bezeichnung", "Aufgaben", "Status", "Objekte", "davon Formulare", "davon genutzt", "Behalten"),
      objects = c("Objekt", "Typ", "Zugriff", "Lizenz", "Formular", "Genutzt", "Behalten", "In den Rollen"),
      users   = c("Benutzer", "Status", "Genutzte Formulare", "Günstigste einzelne Lizenz", "Lizenzen", "Rollen",
                  "Formulare, die keine Rolle abdeckt"),
      access  = c("Lesen", "Schreiben"),
      kinds   = c(Duty = "Aufgabe (ganz)", Privilege = "Recht", NewPrivilege = "Neues Recht"),
      status  = c(USED = "genutzt", WITH_DUTY = "mit der Aufgabe behalten", NOT_MEASURABLE = "nicht messbar, behalten",
                  ALL = "behalten, keine Nutzungsdaten", NOT_USED = "nicht genutzt, entfällt"),
      user_status = c(COVERED = "abgedeckt", NOT_COVERED = "nicht ganz abgedeckt", NO_DATA = "keine Nutzungsdaten")
    )
  )

  texts[[language]]
}

# Term and meaning in English, term and meaning in German.
.LICENSE_ROLES_LEGEND <- list(
  c("used", "A user opened a form of the privilege; it comes in whole.",
    "genutzt", "Ein Benutzer hat ein Formular des Rechts geöffnet; es kommt ganz hinein."),
  c("kept with its duty", "The privilege has no form; another privilege of its duty was used.",
    "mit der Aufgabe behalten", "Das Recht hat kein Formular; ein anderes Recht seiner Aufgabe wurde genutzt."),
  c("not measurable, kept", "The privilege sits directly in the role and has no form; the telemetry cannot judge it.",
    "nicht messbar, behalten", "Das Recht hängt direkt an der Rolle und hat kein Formular; die Telemetrie kann es nicht beurteilen."),
  c("kept, no usage data", "No usage data was given; every privilege is kept.",
    "behalten, keine Nutzungsdaten", "Es gab keine Nutzungsdaten; jedes Recht bleibt."),
  c("not used, left out", "No user opened a form of the privilege; it is left out.",
    "nicht genutzt, entfällt", "Kein Benutzer hat ein Formular des Rechts geöffnet; es entfällt."),
  c("Duty (whole)", "Every privilege of the duty is kept and the license covers it.",
    "Aufgabe (ganz)", "Jedes Recht der Aufgabe bleibt, und die Lizenz deckt es ab."),
  c("New privilege", "Copy of a privilege with only the objects the license covers; written to AxSecurityPrivilege.",
    "Neues Recht", "Kopie eines Rechts nur mit den Objekten, die die Lizenz abdeckt; liegt in AxSecurityPrivilege."),
  c("Users who need it", "Users whose opened forms this role covers, with as few roles per user as possible.",
    "Benutzer, die sie brauchen", "Benutzer, deren geöffnete Formulare diese Rolle abdeckt, mit möglichst wenigen Rollen je Benutzer."),
  c("Cheapest single license", "The cheapest license that alone covers every form the user opened; empty when none does.",
    "Günstigste einzelne Lizenz", "Die günstigste Lizenz, die allein alle geöffneten Formulare abdeckt; leer, wenn keine das tut."),
  c("Forms no role covers", "Forms the user opened that none of the built roles holds, e.g. of a license not built.",
    "Formulare, die keine Rolle abdeckt", "Geöffnete Formulare, die keine der gebauten Rollen enthält, z. B. einer nicht gebauten Lizenz.")
)

.export_license_roles <- function(result, export_path, language) {

  texts    <- .license_roles_texts(language)
  workbook <- openxlsx::createWorkbook(creator = .WORKBOOK_CREATOR)
  header   <- openxlsx::createStyle(textDecoration = "bold", fgFill = "#DDEBF7", border = "bottom", wrapText = TRUE)
  named    <- function(table, columns) stats::setNames(as.data.frame(table, stringsAsFactors = FALSE), columns)
  access   <- function(level) ifelse(as.numeric(level) >= 2, texts$access[[2]], texts$access[[1]])
  yes_no   <- function(x) ifelse(x, texts$yes_no[[1]], texts$yes_no[[2]])

  .add_license_roles_overview(workbook, result, texts, header, named)

  blocks <- dplyr::mutate(result$Blocks, BLOCK_TYPE = unname(texts$kinds[BLOCK_TYPE]))
  .add_duty_check_table(workbook, texts$sheets[["blocks"]], named(blocks, texts$blocks), header, c(24, 40, 18, 46, 46, 10))

  new <- dplyr::mutate(result$NewPrivileges, ACCESS = access(ACCESS))
  .add_duty_check_table(workbook, texts$sheets[["new"]], named(new, texts$new), header, c(24, 46, 40, 40, 20, 12))

  privileges <- dplyr::mutate(result$Privileges, STATUS = unname(texts$status[STATUS]), KEPT = yes_no(KEPT))
  .add_duty_check_table(workbook, texts$sheets[["privileges"]], named(privileges, texts$privileges), header,
                        c(40, 44, 44, 28, 10, 14, 14, 10))

  objects <- dplyr::mutate(result$Objects, ACCESS = access(ACCESS), MEASURABLE = yes_no(MEASURABLE),
                           USED = yes_no(USED), KEPT = yes_no(KEPT))
  .add_duty_check_table(workbook, texts$sheets[["objects"]], named(objects, texts$objects), header,
                        c(40, 18, 12, 40, 10, 10, 10, 40))

  users <- dplyr::mutate(result$Users, STATUS = unname(texts$user_status[STATUS]))
  .add_duty_check_table(workbook, texts$sheets[["users"]], named(users, texts$users), header, c(24, 22, 16, 28, 40, 50, 50))

  legend <- stats::setNames(
    as.data.frame(do.call(rbind, .LICENSE_ROLES_LEGEND), stringsAsFactors = FALSE),
    c("Term", "Meaning", "Begriff", "Bedeutung")
  )
  .add_duty_check_table(workbook, texts$sheets[["legend"]], legend, header, .DUTY_CHECK_LEGEND_WIDTHS, wrap = TRUE)

  dir.create(dirname(export_path), recursive = TRUE, showWarnings = FALSE)
  openxlsx::saveWorkbook(workbook, export_path, overwrite = TRUE)

  invisible(export_path)
}

.add_license_roles_overview <- function(workbook, result, texts, header, named) {

  sheet <- texts$sheets[["overview"]]
  check <- result$Check
  facts <- data.frame(
    label = texts$facts,
    value = c(check$ROLE, paste(check$LICENSES, collapse = ", "),
              if (check$HAS_USAGE) texts$yes_no[[1]] else texts$yes_no[[2]], check$USERS, format(check$CREATED, "%Y-%m-%d")),
    stringsAsFactors = FALSE
  )

  openxlsx::addWorksheet(workbook, sheet)
  openxlsx::writeData(workbook, sheet, texts$title, startRow = 1L)
  openxlsx::addStyle(workbook, sheet, openxlsx::createStyle(textDecoration = "bold", fontSize = 13), rows = 1L, cols = 1L)
  openxlsx::writeData(workbook, sheet, facts, startRow = 3L, colNames = FALSE)
  openxlsx::writeData(workbook, sheet, named(result$Summary, texts$summary), startRow = nrow(facts) + 5L, headerStyle = header)
  openxlsx::setColWidths(workbook, sheet, cols = 1:7, widths = c(28, 46, 16, 12, 14, 12, 18))

  invisible(workbook)
}
