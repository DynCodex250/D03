# =============================================================================
# The Excel workbooks of the deliverables (D07, D20, D21): the layout (grey
# header, blue columns and sheets filled by the tool, white ones by the team),
# the checks before writing, and the columns of the team carried over from an
# earlier version.
# =============================================================================

.DELIVERABLE_STYLES <- list(
  header  = list(fgFill = "#D9D9D9", textDecoration = "bold", wrapText = TRUE, valign = "top", border = "Bottom"),
  it_head = list(fgFill = "#BDD7EE", textDecoration = "bold", wrapText = TRUE, valign = "top", border = "Bottom"),
  it_body = list(fgFill = "#EEF4FA", wrapText = TRUE, valign = "top"),
  body    = list(wrapText = TRUE, valign = "top")
)

.deliverable_style <- function(name) do.call(openxlsx::createStyle, .DELIVERABLE_STYLES[[name]])

.add_deliverable_sheet <- function(wb, name, data, it = character(), all_it = FALSE, width = NULL) {
  openxlsx::addWorksheet(wb, name)
  openxlsx::writeData(wb, name, data, headerStyle = .deliverable_style(if (all_it) "it_head" else "header"))
  rows <- seq_len(max(nrow(data), 1L)) + 1L
  openxlsx::addStyle(wb, name, .deliverable_style(if (all_it) "it_body" else "body"), rows = rows, cols = seq_along(data), gridExpand = TRUE)
  it_cols <- which(names(data) %in% it)
  if (length(it_cols) > 0L && !all_it) {
    openxlsx::addStyle(wb, name, .deliverable_style("it_head"), rows = 1, cols = it_cols, gridExpand = TRUE)
    openxlsx::addStyle(wb, name, .deliverable_style("it_body"), rows = rows, cols = it_cols, gridExpand = TRUE)
  }
  widths <- if (is.null(width)) pmin(pmax(nchar(names(data)) + 2L, 12L), 45L) else c(45, rep(width, length(data) - 1L))
  openxlsx::setColWidths(wb, name, cols = seq_along(data), widths = widths)
  openxlsx::freezePane(wb, name, firstRow = TRUE)
  invisible(wb)
}

# A date typed into Excel comes back as its serial number when read as text: 46331 is 05.11.2026.
.excel_date_text <- function(values) {
  serial <- !is.na(values) & grepl("^[0-9]+(\\.[0-9]+)?$", values)
  values[serial] <- format(as.Date(floor(as.numeric(values[serial])), origin = "1899-12-30"), "%d.%m.%Y")
  values
}

# The file to write and the earlier version: an existing deliverable holds the work of the team.
.check_deliverable_paths <- function(path, previous, overwrite, holds) {
  if (!.is_single_string(path) || !dir.exists(dirname(path))) {
    stop("path must be a file in an existing folder: '", paste(path, collapse = ", "), "'.", call. = FALSE)
  }
  if (file.exists(path) && !isTRUE(overwrite)) {
    stop("'", path, "' exists. ", holds, ": pass it as previous and write to another file, or set overwrite = TRUE.",
         call. = FALSE)
  }
  if (!is.null(previous) && (!.is_single_string(previous) || !file.exists(previous))) {
    stop("previous '", paste(previous, collapse = ", "), "' was not found.", call. = FALSE)
  }
  invisible(TRUE)
}

# One key from one or more columns, capitals and outer spaces left aside: "_WIBU_X|32B6...".
.deliverable_key <- function(...) do.call(paste, c(lapply(list(...), .identifier_key), sep = "|"))

# A sheet of an earlier version, as text, with its KEY from the key columns; NULL, with a
# warning, when the sheet or the key columns are missing.
.read_previous_sheet <- function(previous, sheet, key_columns, dates = character()) {
  if (!sheet %in% readxl::excel_sheets(previous)) {
    warning("'", previous, "' has no sheet ", sheet, "; nothing is carried over.", call. = FALSE)
    return(NULL)
  }
  data <- as.data.frame(readxl::read_excel(previous, sheet = sheet, col_types = "text"), check.names = FALSE)
  if (!all(key_columns %in% names(data))) {
    warning("The sheet ", sheet, " of '", previous, "' lacks the columns ", paste(key_columns, collapse = .LIST_SEPARATOR),
            "; nothing is carried over.", call. = FALSE)
    return(NULL)
  }
  data$KEY <- do.call(.deliverable_key, unname(as.list(data[key_columns])))
  for (column in intersect(dates, names(data))) data[[column]] <- .excel_date_text(data[[column]])
  data
}

# The columns of the team: empty, Status at its default, then filled from the earlier version by key.
.carry_over_columns <- function(sheet, keys, earlier, earlier_keys, columns, status = "offen") {
  for (column in columns) {
    sheet[[column]] <- if (column == "Status") rep(status, nrow(sheet)) else rep(NA_character_, nrow(sheet))
  }
  if (is.null(earlier)) {
    return(sheet)
  }
  at <- match(keys, earlier_keys)
  for (column in intersect(columns, names(earlier))) {
    carried <- earlier[[column]][at]
    sheet[[column]] <- ifelse(is.na(at) | is.na(carried), sheet[[column]], carried)
  }
  sheet
}

# Entries of the team for rows that the new version no longer holds would be lost without a word.
.warn_on_gone_entries <- function(earlier, keys, columns, what, label_columns, status = "offen") {
  entries <- earlier[, intersect(setdiff(columns, "Status"), names(earlier)), drop = FALSE]
  touched <- rowSums(!is.na(entries)) > 0L
  if ("Status" %in% names(earlier)) touched <- touched | (!is.na(earlier$Status) & earlier$Status != status)
  gone <- earlier[touched & !earlier$KEY %in% keys, ]
  if (nrow(gone) > 0L) {
    labels <- do.call(paste, c(unname(as.list(gone[label_columns])), sep = " + "))
    warning(nrow(gone), " ", what, " of the earlier version hold entries of the team but are no longer there; ",
            "their entries are not carried over: ", paste(labels, collapse = "; "), call. = FALSE)
  }
  invisible(gone)
}

# Entries in columns the new version no longer has, for example after a column was renamed, would
# be lost without a word.
.warn_on_dropped_columns <- function(earlier, columns, what) {
  dropped <- setdiff(names(earlier), c(columns, "KEY"))
  dropped <- dropped[vapply(dropped, function(column) any(!is.na(earlier[[column]])), logical(1))]
  if (length(dropped) > 0L) {
    warning("Columns of the earlier ", what, " that the new one does not have hold entries; they are not carried over: ",
            paste(dropped, collapse = .LIST_SEPARATOR), ".", call. = FALSE)
  }
  invisible(dropped)
}

# The sheet Listen: one column per list, filled up with empty texts.
.list_frame <- function(lists) {
  as.data.frame(lapply(lists, function(x) c(x, rep("", max(lengths(lists)) - length(x)))), check.names = FALSE)
}

# A drop-down from the sheet Listen per column; map names the data column and its list.
.add_list_validation <- function(wb, sheet, data, lists, map = stats::setNames(names(lists), names(lists))) {
  frame <- .list_frame(lists)
  rows  <- seq_len(max(nrow(data), 1L)) + 1L
  for (column in names(map)) {
    list_col <- which(names(frame) == map[[column]])
    letter   <- openxlsx::int2col(list_col)
    value    <- sprintf("'Listen'!$%s$2:$%s$%d", letter, letter, 1L + sum(nzchar(frame[[list_col]])))
    openxlsx::dataValidation(wb, sheet, cols = which(names(data) == column), rows = rows, type = "list", value = value)
  }
  invisible(wb)
}

# The sheet Anleitung: the first line as title, the given headings in bold.
.add_instruction_sheet <- function(wb, text, headings) {
  openxlsx::addWorksheet(wb, "Anleitung")
  openxlsx::writeData(wb, "Anleitung", text, colNames = FALSE)
  openxlsx::setColWidths(wb, "Anleitung", cols = 1, widths = 120)
  openxlsx::addStyle(wb, "Anleitung", .deliverable_style("body"), rows = seq_along(text), cols = 1)
  openxlsx::addStyle(wb, "Anleitung", openxlsx::createStyle(textDecoration = "bold", fontSize = 14), rows = 1, cols = 1)
  openxlsx::addStyle(wb, "Anleitung", openxlsx::createStyle(textDecoration = "bold"), rows = which(text %in% headings), cols = 1)
  invisible(wb)
}
