#' Plan a version of a role that needs only one license
#'
#' Sorts every object of a role by the license it needs, seen from one target
#' license, for example Supply Chain Management: which objects the license
#' covers and can stay in the role, which of them other licenses cover as well
#' (shared), which need only Operations - Activity or Team Members, and which
#' stay outside. With a target role, for example an existing SCM version of the
#' role, the plan shows what that role already holds, what it lacks, and
#' through which privilege the missing objects come in.
#'
#' @details
#'
#' **Categories** (column \code{CATEGORY} of \code{Plan})
#'
#' \describe{
#'   \item{\code{ONLY}}{Only the license covers the object.}
#'   \item{\code{SHARED}}{The object needs a base license, and other base
#'     licenses cover it as well; \code{SHARED_WITH} names them, for example
#'     "Commerce" for "Commerce or Supply Chain Management".}
#'   \item{\code{ACTIVITY}}{Operations - Activity is enough.}
#'   \item{\code{TEAM_MEMBERS}}{Team Members, or no license, is enough.}
#'   \item{\code{OUTSIDE}}{The license does not cover the object at the
#'     access the role grants. These objects are in \code{Outside}, with the
#'     privileges that would let the role read them under the license.}
#' }
#'
#' The categories are judged at the highest access the role grants an object.
#' Objects are compared by name, as in the role license report.
#'
#' **States** (column \code{STATE}, only with a target role): \code{IN_ROLE},
#' \code{ONLY_READ} (the target role reads what the role writes) or
#' \code{MISSING}. \code{COMES_IN_VIA} names the privileges the license fully
#' covers that bring a missing object in; \code{NOTE = "NEW_PRIVILEGE"} marks a
#' missing object no such privilege brings in.
#'
#' **Building blocks**: \code{Duties} says per duty whether it can go into the
#' role as a whole (\code{WHOLE}), only with single privileges
#' (\code{PARTLY}) or not at all (\code{NONE}). A duty is judged by the access
#' it grants itself: a duty that only reads an object counts as \code{WHOLE}
#' even when another duty writes the same object and puts it outside.
#' \code{Privileges} holds the action per privilege, as in
#' \code{\link{check_duty_against_role}}. \code{READ_VIA} in \code{Outside}
#' names only privileges the license covers completely.
#'
#' **Workbook**: with \code{export_path} the plan is written to Excel with the
#' sheets Overview, Building plan, Building blocks, Stays outside and Legend.
#' The rows of the plan are coloured by category: no colour for the objects
#' only the license covers, one colour per other license for the shared ones
#' (Commerce orange, Finance green, several purple), light blue for Activity
#' and grey for Team Members. The legend explains every colour, column and
#' value in English and German.
#'
#' @param con
#' Database connection. Result of \code{get_connection()}.
#'
#' @param source_role
#' AOT name of the role the plan starts from.
#'
#' @param license
#' The one license the new version of the role is to need, as
#' \code{LicensingAllSkus} names it. Default: \code{"Supply Chain Management"}.
#'
#' @param target_role
#' AOT name, or GUID, of an existing version of the role to compare with.
#' \code{NULL} = the plan describes a new role.
#'
#' @param export_path
#' Path of the Excel file (\code{.xlsx}). \code{NULL} = no file. An existing
#' file is overwritten.
#'
#' @param language
#' Language of sheet names, headers and values: \code{"en"} or \code{"de"}.
#' The legend is always in both. Default: \code{"en"}.
#'
#' @return
#' List with \code{Check} (what was planned), \code{Summary} (objects per
#' category and state), \code{Plan} (the objects the license covers),
#' \code{Duties}, \code{Privileges} and \code{Outside}.
#'
#' @examples
#' \dontrun{
#'
#' plan <- plan_single_license_role(
#'   con         = cnn,
#'   source_role = "_WIBU_VERKAUF_INNENDIENST_MITARBEITER",
#'   license     = "Supply Chain Management",
#'   target_role = "5CDA51EB-9559-4B27-88C4-14601045B1F0",
#'   export_path = "Data/Plan_Verkauf_Innendienst_SCM.xlsx",
#'   language    = "de"
#' )
#'
#' plan$Summary
#' plan$Privileges[plan$Privileges$ACTION == "ADD", ]
#'
#' }
#'
#' @seealso
#' \code{\link{check_duty_against_role}}
#' \code{\link{analyze_role_license_report}}
#'
#' @export
plan_single_license_role <- function(
  con,
  source_role,
  license     = "Supply Chain Management",
  target_role = NULL,
  export_path = NULL,
  language    = "en"
) {

  .plan_request(source_role, target_role, export_path)
  language <- .check_report_language(language)

  skus <- .load_license_skus(con)
  .check_license_name(license, skus)

  source_graph <- .load_role_license_graph(con, source_role)
  if (nrow(source_graph) == 0L) {
    stop("The license graph holds no rows for role '", source_role, "'.", call. = FALSE)
  }
  target_graph <- .plan_target_graph(con, target_role, source_graph)

  check  <- list(SOURCE_ROLE = source_role, TARGET_ROLE = target_role, LICENSE = license, CREATED = Sys.Date())
  rows   <- .license_covered_rows(source_graph, skus, license)
  result <- .plan_result(rows, target_graph, .plan_other_bases(skus, license), check)

  message(.plan_message(result))

  if (!is.null(export_path)) {
    .export_single_license_plan(result, export_path, language)
  }

  result
}

.PLAN_CATEGORIES <- c("ONLY", "SHARED", "ACTIVITY", "TEAM_MEMBERS", "OUTSIDE")
.PLAN_STATES     <- c("MISSING", "ONLY_READ", "IN_ROLE")
.PLAN_FITS       <- c("WHOLE", "PARTLY", "NONE")

.plan_request <- function(source_role, target_role, export_path) {

  if (!.is_single_string(source_role) || !(is.null(target_role) || .is_single_string(target_role))) {
    stop(
      "source_role must name one role, and target_role one role or NULL: the AOT name, or the GUID ",
      "of a role created in the user interface.",
      call. = FALSE
    )
  }

  .check_xlsx_path(export_path)
}

# The rows of the target role; none when the plan describes a new role.
.plan_target_graph <- function(con, target_role, source_graph) {

  if (is.null(target_role)) {
    return(source_graph[0, ])
  }

  target_graph <- .load_role_license_graph(con, target_role)
  if (nrow(target_graph) == 0L) {
    stop("The license graph holds no rows for role '", target_role, "'.", call. = FALSE)
  }

  target_graph
}

# The other base licenses an object can share with the license; the Premium
# versions are left out, they cover what their base version covers.
.plan_other_bases <- function(skus, license) {
  base <- skus$SKUNAME[.is_base_group(skus$GROUPNAME, "^Base")]
  sort(base[base != license & !endsWith(base, .PREMIUM_SUFFIX)])
}

.plan_type_name <- function(type) {
  type <- as.character(type)
  dplyr::coalesce(unname(.SECURABLE_TYPE_NAMES[type]), paste("SecurableType", type))
}

.plan_result <- function(rows, target_graph, others, check) {

  objects    <- .plan_objects(rows, target_graph, others, has_target = !is.null(check$TARGET_ROLE))
  privileges <- .duty_check_privileges(rows, objects, target_graph)
  closing    <- .duty_check_closing(rows, objects, privileges)

  list(
    Check      = check,
    Summary    = .plan_summary(objects),
    Plan       = .plan_rows(objects, closing),
    Duties     = .plan_duties(rows, target_graph),
    Privileges = privileges,
    Outside    = .plan_outside(rows, objects)
  )
}

# One row per object, judged at the highest access the role grants it.
.plan_objects <- function(rows, target_graph, others, has_target) {

  rows |>
    dplyr::group_by(KEY) |>
    dplyr::filter(ACCESS == max(ACCESS)) |>
    dplyr::summarise(
      OBJECT       = dplyr::first(SECURABLENAME),
      TYPE         = .plan_type_name(dplyr::first(SECURABLETYPE)),
      ACCESS       = dplyr::first(ACCESS),
      LICENSE      = .collapse_sorted(LICENSE, " / "),
      COVERED      = all(LICENSE_COVERS),
      ACTIVITY     = all(ACTIVITY_COVERS),
      TEAM_MEMBERS = all(TEAM_MEMBERS_COVERS),
      SHARED_WITH  = .collapse_sorted(intersect(Reduce(intersect, COVERING), others), .LIST_SEPARATOR),
      DUTIES       = .collapse_sorted(DUTY, .LIST_SEPARATOR),
      PRIVILEGES   = .collapse_sorted(PRIVILEGEIDENTIFIER, .LIST_SEPARATOR),
      .groups      = "drop"
    ) |>
    dplyr::left_join(.duty_check_granted(target_graph), by = "KEY") |>
    dplyr::mutate(
      CATEGORY = dplyr::case_when(
        !COVERED          ~ "OUTSIDE",
        TEAM_MEMBERS      ~ "TEAM_MEMBERS",
        ACTIVITY          ~ "ACTIVITY",
        SHARED_WITH == "" ~ "ONLY",
        TRUE              ~ "SHARED"
      ),
      STATE = if (has_target) {
        dplyr::case_when(is.na(TARGET_ACCESS) ~ "MISSING", TARGET_ACCESS < ACCESS ~ "ONLY_READ", TRUE ~ "IN_ROLE")
      } else {
        NA_character_
      },
      IS_GAP = CATEGORY != "OUTSIDE" & (is.na(STATE) | STATE != "IN_ROLE")
    )
}

.plan_rows <- function(objects, closing) {

  objects[objects$CATEGORY != "OUTSIDE", ] |>
    dplyr::left_join(dplyr::rename(closing, COMES_IN_VIA = CLOSED_BY), by = "KEY") |>
    dplyr::mutate(NOTE = dplyr::if_else(IS_GAP & is.na(COMES_IN_VIA), "NEW_PRIVILEGE", NA_character_)) |>
    dplyr::arrange(match(CATEGORY, .PLAN_CATEGORIES), SHARED_WITH, match(STATE, .PLAN_STATES), OBJECT) |>
    dplyr::select(
      CATEGORY, SHARED_WITH, OBJECT, TYPE, ACCESS, LICENSE, STATE, TARGET_ACCESS,
      COMES_IN_VIA, DUTIES, PRIVILEGES, NOTE
    )
}

# The objects the license does not cover, and the privileges that would let the
# role read them under the license. Only privileges the license covers
# completely count: any other would bring another license into the role.
.plan_outside <- function(rows, objects) {

  covered <- rows |>
    dplyr::group_by(PRIVILEGEIDENTIFIER) |>
    dplyr::summarise(COVERED = all(LICENSE_COVERS), .groups = "drop")
  covered_privileges <- covered$PRIVILEGEIDENTIFIER[covered$COVERED]

  readable <- rows[rows$ACCESS == 1 & rows$PRIVILEGEIDENTIFIER %in% covered_privileges, ] |>
    dplyr::group_by(KEY) |>
    dplyr::summarise(READ_VIA = .collapse_sorted(PRIVILEGEIDENTIFIER, .LIST_SEPARATOR), .groups = "drop")

  objects[objects$CATEGORY == "OUTSIDE", ] |>
    dplyr::left_join(readable, by = "KEY") |>
    dplyr::arrange(OBJECT) |>
    dplyr::select(OBJECT, TYPE, ACCESS, LICENSE, DUTIES, PRIVILEGES, READ_VIA, TARGET_ACCESS)
}

.plan_duties <- function(rows, target_graph) {

  in_target  <- unique(.identifier_key(target_graph$DUTYIDENTIFIER))
  with_duty  <- rows[rows$DUTY != .DUTY_CHECK_NO_DUTY, ]
  privileges <- with_duty |>
    dplyr::group_by(DUTY, PRIVILEGEIDENTIFIER) |>
    dplyr::summarise(COVERED = all(LICENSE_COVERS), .groups = "drop") |>
    dplyr::group_by(DUTY) |>
    dplyr::summarise(PRIVILEGES = dplyr::n(), PRIVILEGES_COVERED = sum(COVERED), .groups = "drop")

  with_duty |>
    dplyr::group_by(DUTY) |>
    dplyr::summarise(
      NAME        = dplyr::first(DUTYNAME),
      OBJECTS     = dplyr::n_distinct(KEY),
      NOT_COVERED = dplyr::n_distinct(KEY[!LICENSE_COVERS]),
      .groups     = "drop"
    ) |>
    dplyr::left_join(privileges, by = "DUTY") |>
    dplyr::mutate(
      IN_ROLE_ALREADY = .identifier_key(DUTY) %in% in_target,
      FIT = dplyr::case_when(NOT_COVERED == 0L ~ "WHOLE", PRIVILEGES_COVERED > 0L ~ "PARTLY", TRUE ~ "NONE")
    ) |>
    dplyr::arrange(match(FIT, .PLAN_FITS), DUTY)
}

# Objects per category, the shared ones per other license, with their states.
.plan_summary <- function(objects) {

  objects |>
    dplyr::mutate(SHARED_WITH = dplyr::if_else(CATEGORY == "SHARED", SHARED_WITH, "")) |>
    dplyr::group_by(CATEGORY, SHARED_WITH) |>
    dplyr::summarise(
      OBJECTS   = dplyr::n(),
      IN_ROLE   = sum(STATE %in% "IN_ROLE"),
      ONLY_READ = sum(STATE %in% "ONLY_READ"),
      MISSING   = sum(STATE %in% "MISSING"),
      .groups   = "drop"
    ) |>
    dplyr::arrange(match(CATEGORY, .PLAN_CATEGORIES), SHARED_WITH)
}

.plan_message <- function(result) {

  check <- result$Check

  sprintf(
    "Role %s with %s only: %d objects can stay, %d stay outside; %d privileges bring the missing ones in, %d objects need a privilege of their own.",
    check$SOURCE_ROLE, check$LICENSE, nrow(result$Plan), nrow(result$Outside),
    sum(result$Privileges$ACTION == "ADD"), sum(result$Plan$NOTE %in% "NEW_PRIVILEGE")
  )
}
