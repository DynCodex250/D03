#' Convert SQL export into a D365 security role
#'
#' Converts the result of a SQL query into a
#' structured D365 security role object.
#'
#' The function extracts all relevant role
#' information from a flattened SQL export and
#' transforms it into a structured list that can
#' be used for further analysis, comparison or
#' XML generation.
#'
#' The following information is extracted:
#'
#' \itemize{
#'   \item Role metadata
#'   \item Duties
#'   \item Privileges
#'   \item Subroles
#'   \item Direct Access Permissions
#' }
#'
#' Permission values are translated into the
#' corresponding security actions:
#'
#' \itemize{
#'   \item 1 = Allow
#'   \item 2 = Deny
#'   \item Other values = empty
#' }
#'
#' @param df A data frame containing the SQL
#'   export of a D365FO security role.
#'
#' @return A list containing the structured
#' security role information.
#'
#' The returned object contains:
#'
#' \itemize{
#'   \item role_name
#'   \item role_description
#'   \item role_label
#'   \item duties
#'   \item privileges
#'   \item subroles
#'   \item duty_count
#'   \item privilege_count
#'   \item subrole_count
#'   \item has_direct_access_permissions
#'   \item direct_access_permissions
#' }
#'
#' @details
#' The function expects the result of
#' \code{\link{load_sql_security_role_objects_detailed}}: one row per path
#' role > sub-role > duty > privilege > object. Only what the role holds
#' itself goes into the role object; what comes through a sub-role stays in
#' the sub-role:
#'
#' \itemize{
#'   \item duties: rows without sub-role;
#'   \item privileges: rows without sub-role and without duty;
#'   \item direct access permissions: rows without sub-role, duty and
#'     privilege.
#' }
#'
#' An AOT role is named by its AOT name, the part in brackets at the end of
#' \code{ROLENAME}, and labelled with the rest. A role created in the user
#' interface is named by its identifier. The source holds no description.
#'
#' Duplicate identifiers are automatically
#' removed using \code{unique()}.
#'
#' Direct Access Permissions are normalized into
#' readable values ("Allow" / "Deny") to simplify
#' downstream processing and XML generation.
#'
#' @examples
#' \dontrun{
#'
#' role <-
#'   convert_sql_to_security_role(
#'     security_sql_export
#'   )
#'
#' role$role_name
#'
#' role$duties
#'
#' role$direct_access_permissions
#'
#' }
#'
#' @export
convert_sql_to_security_role <- function(df){
  role_names <- .role_xml_names(df$ROLEIDENTIFIER[1], df$ROLENAME[1])

  # What the role holds itself: rows without sub-role, then without duty, then without privilege
  own          <- .is_blank(df$SUBROLEIDENTIFIER)
  no_duty      <- .is_blank(df$DUTYIDENTIFIER)
  no_privilege <- .is_blank(df$PRIVILEGEIDENTIFIER)

  duties     <- unique(df$DUTYIDENTIFIER[own & !no_duty])
  privileges <- unique(df$PRIVILEGEIDENTIFIER[own & no_duty & !no_privilege])
  subroles   <- unique(df$SUBROLEIDENTIFIER[!own])

  direct_access_permissions <-
    df[own & no_duty & no_privilege & !.is_blank(df$ObjektTyp), ] |>
    dplyr::distinct(
      ObjektTyp, Objektname, Ebene, Feldname,
      Create, Correct, Delete, Invoke, Read, Update
    ) |>
    dplyr::select(
      ObjektTyp,
      Objektname,
      Ebene,
      Feldname,
      Create,
      Correct,
      Delete,
      Invoke,
      Read,
      Update
    ) |>
    dplyr::mutate(
      Create =
        ifelse(
          Create == 1,
          "Allow",
          ifelse(Create == 2, "Deny", "")
        ),
      Correct =
        ifelse(
          Correct == 1,
          "Allow",
          ifelse(Correct == 2, "Deny", "")
        ),
      Delete =
        ifelse(
          Delete == 1,
          "Allow",
          ifelse(Delete == 2, "Deny", "")
        ),
      Invoke =
        ifelse(
          Invoke == 1,
          "Allow",
          ifelse(Invoke == 2, "Deny", "")
        ),
      Read =
        ifelse(
          Read == 1,
          "Allow",
          ifelse(Read == 2, "Deny", "")
        ),
      Update =
        ifelse(
          Update == 1,
          "Allow",
          ifelse(Update == 2, "Deny", "")
        ),
      Feldname =
        ifelse(
          .is_blank(Feldname),
          "-",
          Feldname
        )
    )

  result <-
    list(
      role_name = role_names$name,
      role_description = "",
      role_label = role_names$label,
      duties = duties,
      privileges = privileges,
      subroles = subroles,
      duty_count = length(duties),
      privilege_count = length(privileges),
      subrole_count = length(subroles),
      has_direct_access_permissions = nrow(direct_access_permissions) > 0,
      direct_access_permissions = direct_access_permissions
    )
  
  return(result)

}

.is_blank <- function(x) is.na(x) | !nzchar(trimws(as.character(x)))

# "_WIBU Verkauf Test (_WIBU_Verkauf_Test)" names the AOT role _WIBU_Verkauf_Test
# with the label "_WIBU Verkauf Test"; a role of the user interface has its GUID
# as identifier and only a label.
.role_xml_names <- function(identifier, name) {
  parts <- regmatches(name, regexec("^(.*?)\\s*\\(([^()]+)\\)\\s*$", name))[[1]]
  if (length(parts) == 3L && .identifier_key(parts[[3]]) == .identifier_key(identifier)) {
    return(list(name = parts[[3]], label = parts[[2]]))
  }
  list(name = identifier, label = name)
}