D365Security - test in ADN: the project in its new structure; D03 writes D03
and D04 as Excel; UI duties and UI privileges against their AOT counterparts
and the inventory of the UI objects (D22 to D24), license profile per user
(D21), consolidation of duplicate roles (D20), matrix of segregation of
duties (D07), and the earlier steps (analysis of a role, role XML, roles per
license, ranking, cleanup plan, test ticket, merge)
==============================================================================

Packed on 2026-10-31 from the branch feat/role-license-decision-tool:
commit 021e85b (everything committed): the structure, D03 with D04,
write_deliverable.
This is the only zip to use: it replaces the zips before. Later updates keep
the name D365Security_ADN_Test.zip.


THE STRUCTURE OF THIS FOLDER (new on 2026-10-31)
-------------------------------------------------

The folder has the structure of the project, the same on every machine:

  R\                        the 77 code files
  Data\Documentation\       the Rmd files and the catalog SoD_Katalog.xlsx
  Data\Deliverables\        the deliverables, Excel and Word, each under its
                            fixed name D<nn>_...
  Data\Deliverables\Sicherung\
                            a copy of a deliverable before a run replaces
                            it; made when needed, not in Git
  Data\SecurityObjects\     AxSecurityRole\, AxSecurityDuty\,
                            AxSecurityPrivilege\ (as in the Visual Studio
                            model), SecurityConfiguration\ and
                            SecurityGovernance\ (the files for the import in
                            the browser), the zips
  Data\Reports\             reports without user ids or with pseudonyms only
  Data\Reports\Klartext\    reports with real user ids from the database;
                            made when needed, never passed on, not in Git
  D365_Exports\             input: the object lists of one role, exported
                            from D365 (step 5 of the playbook)
  D365Security.Rproj        open it in RStudio: the working directory is then
                            this folder, and every path below counts from it

No call needs a full path. Copy your db_credentials.xlsx (the one on the ADN
machine) into this folder, beside READ_ME_FIRST.txt: the Rmd files and the
playbook find it there. The input files (PPAC reports, telemetry, exported
license graph, price list) stay where they are; their paths are parameters.

A deliverable keeps its name. A run copies the existing workbook to
Data\Deliverables\Sicherung, reads it, carries the columns of the team over
and replaces it. The Word file names the copy and the number of notes of the
carry-over (the notes themselves are printed in the console). Before, an
existing workbook stopped the run and needed a new file name; the
parameters datei and bisherige_... still exist but are no longer needed. A
bisherige_... given while the workbook exists stops the run, since it would
replace the newer entries.

Render an Rmd from this folder with output_dir, or open it and press Knit:
the Word file goes to Data\Deliverables (the reports Analyse, Vorschlag and
Merge: Data\Reports). Keep RStudio's Knit Directory at "Document Directory";
otherwise the Rmd stops with "Projekt nicht gefunden".


WHAT TO TEST NOW (the tasks finished last)
------------------------------------------

New in this zip: the structure above, for all steps, and step C writes D03
and D04 as Excel. Steps A, B and D to H are from the zips before; their
calls below are written for the new structure.

Open D365Security.Rproj, load the code as in "LOADING THE CODE" below and
connect: cnn <- get_connection("ADN", "db_credentials.xlsx"). Details in
Data\Documentation\Dokumentation.Rmd: chapter "Before you start" (the
structure), use case 14 (A to C, G), use case 8 (D), use case 5 and the
report D20 (E), use case 15 and the report D07 (F), the report D21 (G), use
case 5 and the report D22 (H), the report D03 (C).

C. The inventory and license analysis D03, and with it D04:
     rmarkdown::render("Data/Documentation/D03_Bestands_und_Lizenzanalyse.Rmd",
       output_dir = "Data/Deliverables",
       params = list(code_laden = "dateien",
                     ppac_detail  = "<...Detailed_Report_pseudonymized.csv>",
                     ppac_bericht = "<...Report_pseudonymized.csv>",
                     preise       = "<your price list>.xlsx",
                     graph_ordner = "<folder of the EXPLODEDGAPH files>",
                     telemetrie   = "<...Telemetrie_pseudonymized.xlsx>"))
   Takes about 80 s. Writes to Data\Deliverables, replacing earlier files:
     D03_Bestands_und_Lizenzanalyse.docx  the report, counts only
     D03_Bestands_und_Lizenzanalyse.xlsx  new: its figures and tables (sheets
                                          Anleitung, Kennzahlen, Abrechnung,
                                          Lizenzen, Rollen, Nutzung,
                                          Umgebungen), no user ids
     D04_Rangliste_PPAC.xlsx              new: the ranking by PPAC (step B)
     D04_Rangliste_Lizenzgraph.xlsx       new: the ranking by the graph
     D04_Bereinigungsplan.xlsx            new: the cleanup plan (step A)
   The D04 files hold the pseudonymized user ids of the reports.
   Expect in the summary: 28.446,40 per month for 191 users, 6.014,30
   missing licenses for 100 users, 2.075,10 proven saving; the same numbers
   in the sheet Kennzahlen of the Excel file; the D04 files as in steps A
   and B.
   Check: does the Excel file show the numbers of the Word file? Does a
   second run replace the five files without a question?

H. The UI duties and UI privileges against their AOT counterparts (D22,
   D23) and the inventory of the UI objects (D24). Roles, duties and
   privileges made in the user interface (identifier GUID) are to be
   replaced everywhere by the AOT object of the same name. Reads only;
   nothing in ADN changes:
     for (rmd in c("D22_UI_Aufgaben", "D23_UI_Rechte", "D24_UI_Inventur")) {
       rmarkdown::render(file.path("Data/Documentation", paste0(rmd, ".Rmd")),
         output_dir = "Data/Deliverables",
         params = list(umgebung = "ADN", code_laden = "dateien"))
     }
   Each writes <name>.xlsx and a Word summary (counts only, no user data)
   to Data\Deliverables. A second run copies the workbook to Sicherung,
   carries the white columns over and replaces it.
   D22 and D23: one row per UI duty or UI privilege with its counterpart and
   the result: "Gleich", "Unterschiede" (sheet Unterschiede), "Kein
   Pendant", "Mehrere Pendants", "Inhalt nicht lesbar". A duty is compared
   by its privileges, a privilege by its entry points with their rights.
   D24: one row per UI object and place (UI role as sub-role of a role, UI
   duty in a role, UI privilege in a duty or directly in a role).
   Expect, after the export of the security configuration of ADN of
   2026-10-25: about 30 UI duties (D22) and 27 UI privileges (D23); D24
   with the places of about 99 UI roles, 30 duties and 27 privileges.
   Check, and please tell me the answers:
   - Many "Inhalt nicht lesbar" for duties or privileges that do sit in
     roles? Then UserSecGovRelatedObjects writes the GUIDs differently from
     SECURITYDUTY and SECURITYPRIVILEGE.
   - D24, a UI role used as sub-role: are the listed roles exactly those
     that hold it directly in D365? A role that holds it only through
     another sub-role means SYSTEMSECURITYSUBROLEENTITY holds indirect
     sub-roles too.
   - One UI duty with "Gleich": open it and its AOT counterpart in D365.
     The same privileges?
   - Type "erledigt" into Status of one row of D24 and run D24 again: is it
     still there, and is there a copy in Data\Deliverables\Sicherung?
   Without the Rmd:
     duties <- plan_ui_counterparts(cnn, "duty")
     write_deliverable("Data/Deliverables/D22_UI_Aufgaben.xlsx", function(previous) {
       export_ui_counterparts(duties, "Data/Deliverables/D22_UI_Aufgaben.xlsx", previous = previous, overwrite = TRUE)
     })
   and the same with "privilege" (D23_UI_Rechte.xlsx) and with
   export_ui_inventory(inventory_ui_objects(cnn), ...) (D24_UI_Inventur.xlsx).

G. The license profile per user (D21): for every user the licenses his work
   needs by the telemetry, against what PPAC expects, has assigned and has
   not yet assigned. No database needed when the graph comes from files:
     rmarkdown::render("Data/Documentation/D21_Lizenzprofil_Benutzer.Rmd",
       output_dir = "Data/Deliverables",
       params = list(code_laden = "dateien",
                     ppac_bericht = "<...Licensing_Report_pseudonymized.csv>",
                     ppac_detail  = "<...Detailed_Report_pseudonymized.csv>",
                     telemetrie   = "<...Telemetrie_pseudonymized.xlsx>",
                     preise       = "<your price list>.xlsx",
                     graph_ordner = "<folder of the EXPLODEDGAPH files>"))
   Without graph_ordner the graph is read from the database of
   graph_umgebung (default ADN). All files must be pseudonymized with the
   same key; otherwise a warning says that only few users match.
   Writes D21_Lizenzprofil_Benutzer.xlsx (sheets Anleitung, Benutzer,
   Ergebnisse, Lizenzen, Preise, Listen) and the Word summary (counts and
   sums only) to Data\Deliverables. The sheet Benutzer holds the
   pseudonymized user ids; do not pass it on.
   Expect with the files of 2026-10-27/28: about the totals of the cleanup
   plan (step A) for the users the telemetry can judge, since both use the
   same rule; "PPAC erwartet" equal to the required licenses of the report
   per user; a few users "Berichte von PPAC weichen ab" (the two reports
   agreed for 212 of 215 users).
   Check: do "Könnte entfallen", "davon bereits zugewiesen" and "davon noch
   nicht zugewiesen" make sense for three users you know? Is a user with
   "Keine Telemetrie" really not working in D365?
   Without the Rmd:
     profile <- build_user_license_profile(read_ppac_license_report("<report>.csv"), detail, graph, usage,
                                           prices = "<your price list>.xlsx")
     export_user_license_profile(profile, "Data/Deliverables/D21_Lizenzprofil_Benutzer.xlsx")

E. The consolidation of duplicate roles (D20). Many roles exist twice: as an
   AOT role and as a copy made in the user interface. Before a role is
   changed, both are brought together (strategy, principle 11):
     rmarkdown::render("Data/Documentation/D20_Rollenkonsolidierung.Rmd",
       output_dir = "Data/Deliverables",
       params = list(umgebung = "ADN", code_laden = "dateien"))
   With the license comparison it takes about half a minute per pair; for a
   quick first run add lizenzvergleich = FALSE.
   Writes D20_Rollenkonsolidierung.xlsx (one row per pair) and the Word
   summary (counts only, no user ids) to Data\Deliverables, and the merged
   roles to Data\SecurityObjects: AxSecurityRole\<AOT name>_MERGED.xml,
   SecurityConfiguration\ and SecurityGovernance\ with the same name, the
   zip beside them. A merged role of the same name is written anew; files
   of other roles stay (new: before, each merged role got a folder of its
   own in Merge_Rollen_<date>).
   Expect: every pair of load_role_mapping() in the sheet Rollenpaare.
   "Keine Unterschiede" / "Nicht anfassen" where both versions hold the same
   duties, privileges, sub-roles and direct access; "Unterschiede" /
   "Zusammenführen" with a role <AOT name>_MERGED; a same copy whose AOT role
   has another, differing copy says "Im Merge enthalten". The column
   Arbeitsgrundlage names the one role to work with: the merged role, or
   the AOT role of a pair without differences. Merging assigns nobody: the
   users keep their roles until the cleaned-up role replaces both versions.
   The pair
   _WIBU_VERKAUF_INNENDIENST_MITARBEITER + 32B63442-1415-459D-8FF0-399780947265
   should be "Unterschiede" (compare_role_versions() gave B_IN_A).
   Check: open one pair "Keine Unterschiede" in D365: really the same? Does a
   merged role hold the duties of both versions (sheet Unterschiede_Aufbau)?
   Then a second run with lizenzvergleich = FALSE, after typing something
   into a white column: the entry carries over. Without the Rmd:
     plan <- plan_role_consolidation(cnn, merge_folder = "Data/SecurityObjects")
     export_role_consolidation(plan, "Data/Deliverables/D20_Rollenkonsolidierung.xlsx")
   The merged roles are imported into INT later, as working basis; do not
   import them into ADN.

F. The matrix of segregation of duties (D07): the general catalog
   SoD_Katalog.xlsx (101 functions, 125 duties, 103 rules) against the roles
   of ADN and the users of production:
     rmarkdown::render("Data/Documentation/D07_Funktionstrennungs_Matrix.Rmd",
       output_dir = "Data/Deliverables",
       params = list(code_laden = "dateien", graph_umgebung = "ADN",
                     ppac_detail = "<...Detailed_Report_pseudonymized.csv>",
                     ppac_umgebung = "wibu-produktiv"))
   The catalog is read from Data\Documentation by default.
   graph_ordner = "<folder of the EXPLODEDGAPH files>" reads the graph from
   the exported files instead of the database.
   Data\Deliverables holds the draft D07_Funktionstrennungs_Matrix.xlsx of
   2026-10-29 (20 rules); the first run copies it to Sicherung, reads it as
   the earlier version and replaces it; notes about its rules or columns are
   expected.
   Expect with the exports of 2026-10-28: 71 of 101 functions active, 74 of
   103 rules apply, 11 cannot be checked, 30 of 64 WIBU roles and 159 of 187
   users in conflict. The summary warns that graph (ADN) and assignments
   (production) come from different environments. The sheet
   Konflikte_Benutzer holds the pseudonymized user ids; do not pass it on.
   Check: does the graph read straight from ADN give the same numbers?

A. The cleanup plan of D04, every saving proven by the telemetry (step C
   writes the same file):
     prices   <- read_license_prices("<your price list>.xlsx")
     detail   <- read_ppac_license_detail("<...Detailed_Report_pseudonymized.csv>",
                                          environment = "wibu-produktiv")
     graph    <- read_license_graph(con = cnn)        # or the exported .xlsx files:
     # graph  <- read_license_graph(list.files("<folder>", "EXPLODEDGAPH_.*[.]xlsx$", full.names = TRUE))
     usage    <- readxl::read_excel("<...Telemetrie_pseudonymized.xlsx>")
     plan     <- plan_role_license_cleanup(detail, graph, usage, prices = prices,
                   export_path = "Data/Deliverables/D04_Bereinigungsplan.xlsx")
   Expect with the exports of 2026-10-28 (graph of ADN, telemetry 27.07. to
   24.10.2026): message "Cleanup plan over 191 users: 2075.10 per month proven
   ..., 1697.30 more after review. 41 users without telemetry or licensed use
   (2992.20 per month) to check; 0 whose license graph differs ...". Two
   warnings name roles only (_WIBU Fibu Rueckvergütungsverwalter is not in the
   graph; two names stand for several roles). Sheet Abweichungen: the 6
   objects of Human Resources Self Service of _WIBU Geschäftsführung, for
   which PPAC decides (billed Activity). Workbook, sheet
   Bereinigungsplan: step 1 _WIBU Verkauf Innendienst Mitarbeiter, 46 users,
   811,20; nine steps of wave 1 add up to 2.075,10. Sheet Aufgaben: the duty
   RetailDiscountOfferMaintain (Commerce) of that role, opened by 14 of its
   65 users, goes for 46. Reading the graph from the files takes about 35 s,
   the plan about 13 s.
   Check: does the role in the plan exist in ADN as described, and does the
   graph read straight from ADN (con = cnn) give the same message?

B. The ranking (D04) with both bases, to compare them yourself (step C
   writes the same files):
     ppac <- rank_roles_by_license_cost(licenses = detail, prices = prices,
               export_path = "Data/Deliverables/D04_Rangliste_PPAC.xlsx")
     objs <- rank_roles_by_license_cost(licenses = detail, prices = prices,
               basis = "graph", graph = graph,
               export_path = "Data/Deliverables/D04_Rangliste_Lizenzgraph.xlsx")
   basis = "ppac" is the default, as before. Expect: sums 16.557,50 (PPAC)
   and 5.026,50 (graph); _WIBU Einkauf Mitarbeiter on rank 1 with 4.036,70
   by PPAC, on rank 5 with 464,10 by the graph. Sheet Überblick, row
   "Grundlage der Kosten nur wegen einer Rolle": PPAC or Lizenzgraph.

D. The merge of the AOT role and its UI copy into one role, whatever
   licenses the merged role needs (Rollen_Vergleich_und_Merge_Szenarien.Rmd,
   German; the guide has the comparison, three scenarios and the import):
     rmarkdown::render("Data/Documentation/Rollen_Vergleich_und_Merge_Szenarien.Rmd",
       output_dir = "Data/Reports",
       params = list(ausfuehren = TRUE, code_laden = "dateien"),
       output_file = "Rollen_Merge_ADN.html")
   Its files go to Data\Reports\Klartext\Rollen_Merge (scenario 3 holds user
   ids). Or the merge alone, into the security objects:
     merged <- export_merged_role_xml(cnn,
                 c("_WIBU_VERKAUF_INNENDIENST_MITARBEITER", "32B63442-1415-459D-8FF0-399780947265"),
                 output_folder = "Data/SecurityObjects")
     merged$sources
   Name: the AOT name with the suffix _MERGED, in the spelling of
   SECURITYROLE, for example _WIBU_Verkauf_Innendienst_Mitarbeiter_MERGED;
   of two AOT roles or two UI roles the first one given. Files:
   AxSecurityRole\<name>.xml, <name>.zip, SecurityGovernance\ and
   SecurityConfiguration\ (the merged role as a new role).
   Expect: merged$sources has one row per role (KIND AOT and UI, counts of
   duties, privileges, sub-roles, direct access); a message when a sub-role
   is left out because it is one of the two roles. In the guide, scenario 1
   stops with "would hold itself" when the UI role holds the AOT role as a
   sub-role: that is the expected stop, scenario 2 is the way then.
   Scenario 3 (users onto the merged role) is meant for after an import;
   its workbook holds user ids, the output only counts.
   Check: are the duties and privileges of both roles in the merged file?
   Only if you want the import test in ADN (it changes ADN): import the file
   of SecurityConfiguration\ (System administration > Security > Security
   configuration, Data > Import) and look whether D365 keeps the name or
   gives a GUID; then compare_role_versions(cnn, <AOT role>, <merged role>)
   and the same with the UI role should say SAME or A_IN_B. Each comparison
   takes about half a minute.

Still open from the zip before (rank, comparisons, ticket):

1. Prices: prices <- read_license_prices("<your price list>.xlsx")
   The list needs the rows "Commerce Base" and "Commerce Attach".
2. D04 ranking from the detailed PPAC report, with AOT names:
     detail  <- read_ppac_license_detail("<...Detailed_Report_pseudonymized.csv>")
     ranking <- rank_roles_by_license_cost(cnn,
                  licenses = detail[detail$ENVIRONMENT == "wibu-produktiv", ],
                  prices = prices, export_path = "Data/Deliverables/D04_Rangliste_PPAC.xlsx")
   Expect: ROLE holds AOT names (from SECURITYROLE), NAME the report's names,
   VERSIONS the UI copies; warnings name roles not found. Sheet Benutzer,
   columns "Abgerechnet als" and "Rechnung": SCM Base + Finance Attach +
   Commerce Attach, 168,50 + 27,30 + 31,20 = 227,00 for Commerce + Finance +
   SCM. Sheet Rangliste, column "Lizenzkosten ihrer Benutzer je Monat (alle
   Rollen)": 14.755,00 for _WIBU Verkauf Innendienst Mitarbeiter, next to its
   1.895,40 "nur wegen der Rolle". Sheet Rechenweg: per role and case how its
   users are billed with and without the role; the savings of a role add up
   to its cost only because of it (2 x 58,50 + 57 x 31,20 + 6 x 0 = 1.895,40).
   Its column "Betroffene Benutzer" names the pseudonymized users of each line.
3. Required against assigned (production):
     users <- read_ppac_license_report("<...Licensing_Report_pseudonymized.csv>")
     compare_assigned_license_cost(users, prices = prices,
                                   export_path = "Data/Reports/Lizenzen_benoetigt_zugewiesen.xlsx")
4. INT against production:
     compare_environment_license_cost(detail, to = "wibu-int", prices = prices,
                                      export_path = "Data/Reports/Lizenzkosten_INT_gegen_Prod.xlsx")
5. Ticket (D11) of a role of the ranking; role as AOT name or as the
   report's name, for example "_WIBU Verkauf Innendienst Mitarbeiter":
     report <- analyze_role_license_report(cnn, "_WIBU_VERKAUF_INNENDIENST_MITARBEITER", usage = usage)
     create_role_test_ticket(cnn, "_WIBU Verkauf Innendienst Mitarbeiter", role_area = "Verkauf_Innendienst",
                             report = report, ranking = ranking,
                             output_folder = "Data/Reports/Tickets")
   Expect: the rank of the role in D04 is filled ("auf Platz 3"), no error.

HISTORY
-------

New in the zip of 2026-10-31:

  - The folder has the structure of the project (see above); no call needs
    a full path. The Rmd files find the project themselves; empty path
    parameters take their place in it.
  - Deliverables keep their names in Data\Deliverables: a run copies the
    workbook to Sicherung, carries the entries of the team over and
    replaces it (deliverable_previous(), backup_deliverable(),
    write_deliverable()).
  - D03_Bestands_und_Lizenzanalyse.Rmd also writes D03 as Excel
    (export_license_inventory()) and D04 (two rankings, cleanup plan).
    See step C.
  - plan_role_consolidation(): the merged roles go straight into the
    folder of the security objects, no folder per role.
  - Reports with real user ids go to Data\Reports\Klartext.
  - 1 more code file: 77 in all (export_license_inventory.R).

New in the second zip of 2026-10-30:

  - plan_ui_counterparts(), export_ui_counterparts(), D22_UI_Aufgaben.Rmd
    and D23_UI_Rechte.Rmd: the UI duties and UI privileges against their
    AOT counterparts (D22, D23). See step H above.
  - inventory_ui_objects(), export_ui_inventory() and D24_UI_Inventur.Rmd:
    where every UI role, duty and privilege sits (D24).
  - Quick role changes in Prod are made in the user interface, then redone
    in the AOT and removed from the user interface; D24 therefore also runs
    in operation (strategy D01, phase 7; D02, rule 10).
  - Dokumentation.Rmd: use case 5 extended, the report D22.
  - Deliverables\: D05 and D06 with the sales positions split into
    STE-008 to STE-011 and their roles ROL-010 to ROL-015.
  - The column "Betroffene Benutzer" (USERIDS) of the sheet Rechenweg of
    the ranking is unchanged since the first zip of 2026-10-29.
  - 5 more code files: 76 in all (ui_security_objects.R,
    plan_ui_counterparts.R, export_ui_counterparts.R,
    inventory_ui_objects.R, export_ui_inventory.R).

New in the first zip of 2026-10-30:

  - build_user_license_profile(), export_user_license_profile() and
    D21_Lizenzprofil_Benutzer.Rmd: the license profile per user (D21).
    See step G above.
  - D20: the merged role is the working basis (column Arbeitsgrundlage,
    "Im Merge enthalten", team columns Bereinigte Rolle and Alte Versionen
    entfernt am; import into INT).
  - deliverable_workbook.R: the layout and carry-over shared by D07, D20
    and D21.
  - Dokumentation.Rmd: use case 14 extended, the report D21.
  - 3 more code files: 71 in all (deliverable_workbook.R,
    build_user_license_profile.R, export_user_license_profile.R).

New in the third zip of 2026-10-29:

  - plan_role_consolidation(), export_role_consolidation() and
    D20_Rollenkonsolidierung.Rmd: the consolidation of duplicate roles
    (D20). See step E above.
  - read_sod_catalog(), build_sod_matrix(), export_sod_matrix(),
    D07_Funktionstrennungs_Matrix.Rmd and the catalog SoD_Katalog.xlsx: the
    matrix of segregation of duties (D07). See step F above.
  - Dokumentation.Rmd: use case 5 extended, use case 15 new, the reports
    D07 and D20.
  - 5 more code files: 68 in all (read_sod_catalog.R, build_sod_matrix.R,
    export_sod_matrix.R, plan_role_consolidation.R,
    export_role_consolidation.R).

New in the second zip of 2026-10-29:

  - export_merged_role_xml(): two or more roles merged into one and written
    as AOT file, zip and the two browser files. See step D above.
  - export_role_xml() stops when the role would hold itself as a sub-role
    (a UI copy that holds the AOT role, written under the AOT name).
  - Rollen_Vergleich_und_Merge_Szenarien.Rmd: comparison, the three
    scenarios and the import; code_laden = "dateien" loads the 63 files.
  - 2 more code files: 63 in all (export_merged_role_xml.R,
    sec_migrate_ui_roles_to_aot.R).

New in the first zip of 2026-10-29:

  - rank_roles_by_license_cost(): parameter basis = "ppac" (default, as
    before) or "graph" (costs only because of a role from the license graph,
    PPAC has priority), and graph. See step B above.
  - The cleanup plan: PPAC has priority where the graph wants more than PPAC
    bills; the sheet Abweichungen lists those objects.
  - summarize_license_inventory() and D03_Bestands_und_Lizenzanalyse.Rmd:
    the inventory and license analysis D03. See step C above.
  - Sheet Rechenweg: column "Betroffene Benutzer" (your change).
  - 2 more code files: 61 in all.

New in the zip of 2026-10-28, evening:

  - read_license_graph(): the license graph (LicensingSecurityObjectExplodedGraph)
    from the exported .xlsx files or from the database.
  - plan_role_license_cleanup(): the cleanup plan of D04. Per user the license
    he needs for what the telemetry shows, the duties of his roles that must
    go for it, the roles in the order that completes the most savings, in
    three waves. See "THE CLEANUP PLAN BY THE TELEMETRY" below.
  - The ranking from the PPAC report is an upper bound: PPAC names a license
    at one role of a user only. See the note under "THE MOST EXPENSIVE ROLES".
  - Dokumentation.Rmd: use case 14.
  - 5 more code files: 59 in all.

New in the zip of 2026-10-28:

  - Base licenses are billed in the order SCM, Finance, Commerce: the first a
    user needs is the base license, every further one an attach license.
  - The PPAC ranking gets AOT names from SECURITYROLE when cnn is given.
  - The ticket takes the role also by its name and finds its rank.
  - Ranking: column USERS_COST (what the users of a role pay with all their
    roles), sheet Rechenweg (calculation per role and case), column Rechnung
    in the sheet Benutzer.

New in the zip of 2026-10-27, second part:

  - License costs from the PPAC license reports, without a database: the
    ranking from the detailed report, required against assigned licenses
    per user, and INT against production. See "LICENSE COSTS FROM THE PPAC
    REPORTS" below.
  - read_license_prices(): reads the price list with SKU / Price
    (Finance Base, Finance Attach, ..., Commerce Base, Commerce Attach).
  - Dokumentation.Rmd: use case 13.
  - 5 more code files: 54 in all.

New in the zip of 2026-10-27, first part:

  - rank_roles_by_license_cost(): the ranking of the most expensive roles
    (D04), see below.
  - create_role_test_ticket(): the test ticket of a cleaned-up role (D11,
    strand A) as text and Word, see below.
  - Dokumentation.Rmd: use cases 11 and 12.

New since D365Security_ADN_2026-10-24_Rollenpaare.zip:

  - Analyse_Rolle_Lizenzen.Rmd: the analysis of a role with ten questions,
    as your version with code and as a Word file for the business department.
  - Vorschlag_Rolle_SCM.Rmd: the proposal to reduce a role to SCM.
  - export_role_xml(): a role from the database as role XML and zip, and as
    two files for the import in the browser (security governance, security
    configuration); a UI sub-role is replaced by the AOT role of the same
    name when one exists. build_license_roles() writes the same three kinds.
  - describe_subroles(): the sub-roles of a role (question 10).
  - build_license_roles(): one role per license from what the users use.
  - Playbook: new steps 10 and 11; "Result" is now step 12.
  - 14 more code files: 46 at the time.


WHAT IS IN THIS FOLDER
----------------------

The Rmd files below are in Data\Documentation.

Playbook_Role_License_Report_Acceptance_ADN.Rmd
    The acceptance test, step by step (run chunk by chunk).

Analyse_Rolle_Lizenzen.Rmd
    The analysis of the role (German). One file, two versions.

Vorschlag_Rolle_SCM.Rmd
    The proposal to reduce a role to SCM (German). One file, two versions.

D03_Bestands_und_Lizenzanalyse.Rmd
    The inventory and license analysis D03 (German Word file and Excel,
    counts only) and D04 (rankings and cleanup plan, Excel; step C).

Rollen_Vergleich_und_Merge_Szenarien.Rmd
    Comparison and merge of an AOT role and its UI copy (German, step D).

D20_Rollenkonsolidierung.Rmd
    The consolidation of duplicate roles D20 (German; Excel, merged roles,
    Word summary with counts only; step E).

D21_Lizenzprofil_Benutzer.Rmd
    The license profile per user D21 (German; Excel and Word summary with
    counts and sums only; step G).

D22_UI_Aufgaben.Rmd, D23_UI_Rechte.Rmd, D24_UI_Inventur.Rmd
    The UI duties and UI privileges against their AOT counterparts and the
    inventory of the UI objects (German; Excel and Word summary with counts
    only; step H).

D07_Funktionstrennungs_Matrix.Rmd, SoD_Katalog.xlsx
    The matrix of segregation of duties D07 (German; step F) and the general
    catalog it reads (functions, duties, rules, sources; no company data).

Dokumentation.Rmd
    The documentation of the package by use case (English): every function
    with call, parameters, results, files and messages. Render it to HTML:
    rmarkdown::render("Data/Documentation/Dokumentation.Rmd", output_dir = "Data/Reports");
    no database.

R\
    The 77 code files. The package does not have to be installed.

Data\Deliverables\
    The deliverables of the repository: D01, D02, D03 (Word), D05, D06, D07
    (the draft of 2026-10-29), D08, D09, D11, D18, D19. D05 and D06 hold the
    sales positions STE-008 to STE-011 with the roles ROL-010 to ROL-015.
    Positions, roles and head counts only; no user data.

D365_Exports\
    The object lists of the role _WIBU_VERKAUF_INNENDIENST_MITARBEITER,
    exported from D365 in ADN on 2026-10-10, one file per license.

The folder holds no user data and no password. db_credentials.xlsx: copy the
file of the ADN machine into this folder.


LOADING THE CODE (playbook)
---------------------------

1. Unzip close to the drive root, for example under Documents\RProjects:
   paths longer than 260 characters are not found. Copy db_credentials.xlsx
   into the unzipped folder and open D365Security.Rproj in RStudio.
2. R packages, once: install.packages(c("DBI", "odbc", "dplyr", "tibble",
   "tidyr", "lubridate", "openxlsx", "readxl", "writexl", "xml2", "knitr",
   "rmarkdown", "zip"))
3. Open Data\Documentation\Playbook_Role_License_Report_Acceptance_ADN.Rmd
   and run the chunks one by one (no "Knit"): "parameters" (it finds the
   folder itself), then "appendix-files" (the last chunk; it loads the 77
   files), then "connection". Skip "code-version" and "setup".
4. Then step 2 (telemetry, it fills `usage`), and steps 9 to 11. Their
   workbooks go to Data\Reports\Klartext\License_Report_Test.
The Rmd files of the steps above load the code themselves
(code_laden = "dateien").


THE ANALYSIS OF THE ROLE
------------------------

The analysis answers ten questions about one role, by default
_WIBU_VERKAUF_INNENDIENST_MITARBEITER:

  1. Which licenses does the role need, and why?
  2. What would have to go so that one license is enough?
  3. Who uses the parts that need a base license?
  4. Does changing only this role save anything (other roles, UI version)?
  5. AOT role against the UI role of the same name.
  6. The role with one license only (building plan).
  7. What is used, what never?
  8. Which roles per license come out of the usage?
  9. Which license would each user need afterwards?
 10. Which sub-roles does the role have, and what follows from them?

Users appear only as counts. In a fresh R session in RStudio, opened with
D365Security.Rproj:

    # Your version, with code; the workbooks go to Data/Reports/Klartext/Analyse_Rolle
    rmarkdown::render(
      "Data/Documentation/Analyse_Rolle_Lizenzen.Rmd", output_dir = "Data/Reports",
      params = list(code_laden = "dateien"),
      output_file = "Analyse_Verkauf_Innendienst.docx"
    )

    # The version for the business department: Word, no code, no files
    rmarkdown::render(
      "Data/Documentation/Analyse_Rolle_Lizenzen.Rmd", output_dir = "Data/Reports",
      params = list(fassung = "fachbereich", code_laden = "dateien"),
      output_file = "Analyse_Verkauf_Innendienst_Fachbereich.docx"
    )

Other parameters (all in the header of the Rmd): rolle, ui_rolle, ziel_lizenz,
ziel_rolle, umgebung, cred_path, telemetrie (empty = load from Insights with
D365Licensing). Each render runs the whole analysis; that takes a few minutes.

Your version writes to Data\Reports\Klartext\Analyse_Rolle (parameter
export_ordner): the license report, the building plan, the comparison of the
two role versions, and in "Lizenzrollen" the roles per license as XML, zip
and workbook. These workbooks hold user ids; do not pass them on. The Word
files go to Data\Reports; the one for the business department holds counts
only.


THE PROPOSAL: ONE ROLE DOWN TO ONE LICENSE
------------------------------------------

Vorschlag_Rolle_SCM.Rmd writes the proposal to reduce a role to Supply Chain
Management (German): where the licenses come from, an SCM base role plus small
add-on roles, the two conditions (UI copy, other roles), and the sub-roles
that fix another license. Every number is computed from the data, so it also
works for other roles: set rolle, ui_rolle (empty when there is none),
ziel_rolle (an existing SCM version; empty when there is none) and
name_bereich, for example "Verkauf_Verkaufsleiter". For a role that exists
only in the user interface, rolle is its GUID and ui_rolle stays empty (the
same GUID in both counts as empty).

    rmarkdown::render(
      "Data/Documentation/Vorschlag_Rolle_SCM.Rmd", output_dir = "Data/Reports",
      params = list(code_laden = "dateien"),
      output_file = "Vorschlag_Verkauf_Innendienst.docx"
    )

With fassung = "fachbereich": text only, no code, no files. Your version
writes to Data\Reports\Klartext\Vorschlag_Rolle (parameter export_ordner)
Vorschlag_<role>.xlsx (sheets Treiber, Prüfung, Objekte der Treiber,
Bleibt draußen, Benutzer, Lizenzquellen, Subrollen; the sheet Benutzer holds
user ids), Bauplan.xlsx, Pruefung_<block>.xlsx per block, Rollenversionen.xlsx
and the folder Lizenzrollen. telemetrie takes an .rds or an .RData file.

The roles in Lizenzrollen are built with the target license first
(prefer = ziel_lizenz): one SCM role, plus a role for another license only
for the objects SCM does not cover, for example SCM and Finance. Before, the
cheapest set won, so a role whose objects Finance covers alone became one
Finance role.


ROLE XML FROM THE DATABASE
--------------------------

    result <- export_role_xml(cnn, "_WIBU_VERKAUF_INNENDIENST_LEITUNG",
                              output_folder = "Data/SecurityObjects")
    result$zip

Writes AxSecurityRole\<name>.xml and <name>.zip: the role with its own
duties, privileges, sub-roles and direct access permissions, in the format of
a Visual Studio project. name = "..." and label = "..." write a copy under
another name.

A sub-role created in the user interface (GUID) is written as the AOT role of
the same name when one exists (load_role_mapping()); both are compared first,
and a warning says when they differ. Without such an AOT role the UI sub-role
stays, with a warning: nothing is created blindly. result$subroles lists what
was done; replace_ui_subroles = FALSE keeps every sub-role as it is.

    describe_subroles(cnn, "_WIBU_VERKAUF_INNENDIENST_LEITUNG")

lists the sub-roles of a role: AOT or UI, license, whether it fixes a license
of the role, AOT counterpart, other roles that hold it, users who have it
directly. The analysis Rmd shows the same as question 10.

The same role also goes into two files for the import in the browser, built
after your two exports from ADN:
  SecurityGovernance\<name>.xml     as the security governance exports it
  SecurityConfiguration\<name>.xml  as the security configuration exports it
Both hold the same role; they differ only in how they write an empty element
(<Forms /> or <Forms/>). An AOT role under its own name goes into the list of
changed roles (an import replaces that role), a copy or a UI role into the
list of new roles. Names stay readable, no GUID. browser_files = FALSE writes
only the AOT file. Do not import the files of step 10 into ADN: both roles
exist there already.

Two or more roles merged into one: export_merged_role_xml() writes the same
files for the merged role (step D above).


ROLES PER LICENSE FROM THE USAGE
--------------------------------

    roles <- build_license_roles(cnn, "_WIBU_VERKAUF_INNENDIENST_MITARBEITER",
                                 usage = usage,
                                 export_folder = "Data/Reports/Klartext/Lizenzrollen")
    roles$Summary

Without licenses: the fewest base licenses that cover the used objects (the
cheaper one on a tie). prefer = "Supply Chain Management": SCM first, other
licenses only for what SCM does not cover. With licenses = "Supply Chain
Management": only that role. users = c("id1", "id2"): only the usage of these
users counts. Without usage: every privilege is kept.

A privilege counts as used when one of its forms was opened; privileges
without a form (actions, entities, services) come in with their duty. A
privilege the license covers only partly becomes a new privilege
<privilege>_<SCM|FIN|COM>. Files: AxSecurityRole\, AxSecurityPrivilege\, one
zip for Visual Studio; SecurityGovernance\ and SecurityConfiguration\ with all
new roles and new privileges in one file each, for the import in the browser;
and a workbook (Überblick, Rollen, Neue Rechte, Rechte, Objekte, Benutzer,
Legende).

Import test, once: import the file of SecurityConfiguration\ in System
administration > Security > Security configuration (Data > Import) and look
whether D365 keeps the readable names of the new roles and privileges.


THE MOST EXPENSIVE ROLES (D04)
------------------------------

    prices <- data.frame(
      LICENSE      = c("Team Members", "Operations - Activity", "Commerce",
                       "Finance", "Supply Chain Management"),
      BASE_PRICE   = c(7.50, 46.80, 164.60, 164.60, 164.60),
      ATTACH_PRICE = c(NA, NA, 31.20, 31.20, 31.20)
    )
    ranking <- rank_roles_by_license_cost(cnn, prices = prices,
                 export_path = "Data/Reports/Klartext/D04_Rangliste.xlsx")
    head(ranking$Ranking, 10)

For every role: the license costs per month its users would no longer have if
the role triggered no license, given all their other roles. An AOT role and
its UI role of the same name count as one role. The prices above are the
estimates of the strategy paper (October 2026); without prices they are used
with a warning. Current prices go in as a table or an .xlsx with the columns
LICENSE, BASE_PRICE, ATTACH_PRICE; every license the users have needs a row.
The sheets Benutzer and Benutzer und Rollen hold user ids; do not pass them on.

Note: the PPAC report names each license of a user at one of his roles
only, and None at the other roles that need it too (26 of 107 roles of
production; _WIBU Einkauf Disposition shows None for all its 36 users). From
the PPAC report, "costs only because of the role" is therefore an upper
bound that can be far too high. What can really go comes from the cleanup
plan below.


THE CLEANUP PLAN BY THE TELEMETRY (D04)
---------------------------------------

    graph <- read_license_graph(con = cnn)    # or the exported .xlsx files
    usage <- readxl::read_excel("<...Telemetrie_pseudonymized.xlsx>")
    plan  <- plan_role_license_cleanup(detail[detail$ENVIRONMENT == "wibu-produktiv", ], graph, usage,
               prices = prices, export_path = "Data/Deliverables/D04_Bereinigungsplan.xlsx")

Rules: a duty is used when the user opened one of its display menu items;
its actions and data entities count with it. A duty without a display menu
item cannot be measured and stays until the business confirms it is unused.
Per user the cheapest licenses for the duties he keeps (from the license
graph, billed SCM, Finance, Commerce as above); today's billing from PPAC.
Users without telemetry, or who opened only what needs no license, are a
check list (wave 2), never a saving. PPAC has priority: where the graph
wants more for an object than PPAC bills, the licenses of PPAC cover it
(sheet Abweichungen); where the graph needs less, no saving counts for the
user (class "Graph weicht ab"). Wave 1: the roles with
proven savings, in the order that completes the most; wave 3: what needs
the review. Sheets: Überblick, Bereinigungsplan, Maßnahmen, Benutzer,
Aufgaben, Ohne Nutzung, Abweichungen, Preise, Legende. Maßnahmen, Benutzer
and Ohne Nutzung hold user ids; do not pass them on. The telemetry covers
only its period; work done once a year may not show in it.


THE TEST TICKET OF A CLEANED-UP ROLE (D11)
------------------------------------------

Before the ticket: the report of the role with usage (step 2 fills usage),
the ranking above, the name part of the new role by the rule
WIBU_<Bereich>_<Funktion>_<Lizenz>, and the proposal agreed with the owner of
the role.

    report <- analyze_role_license_report(cnn, "_WIBU_VERKAUF_INNENDIENST_MITARBEITER",
                                          usage = usage)
    ticket <- create_role_test_ticket(cnn, "_WIBU_VERKAUF_INNENDIENST_MITARBEITER",
                                      role_area = "Verkauf_Innendienst",
                                      report = report, ranking = ranking,
                                      output_folder = "Data/Reports/Tickets")
    cat(ticket$Text)

Fills the template of D11, section 6: the new role in the title, previous and
target license, the number of affected users and their companies, the rank in
D04, and the license drivers that are removed, moved to an add-on role, or
left to clarify. Environment INT, no ticket number. assignee, due_date,
test_user, test_cases (a table with TESTCASE_ID and PROCESS) and blocklist
fill the rest; without them they stay placeholders in [ ]. Writes
Ticket_Strang_A_<role>.md and .docx (Word needs RStudio's pandoc). The ticket
holds counts and companies, no user ids.


LICENSE COSTS FROM THE PPAC REPORTS
-----------------------------------

No database needed. Pseudonymize the two reports first (Dokumentation.Rmd,
use case 13) and write the pseudonymized tables with readr::write_csv().

    prices <- read_license_prices("<your price list>.xlsx")   # sheet skuPrices
    detail <- read_ppac_license_detail(".../Finance_And_Operations_Licensing_Detailed_Report_pseudonymized.csv")
    users  <- read_ppac_license_report(".../Finance_And_Operations_Licensing_Report_pseudonymized.csv")

    # A: ranking of the roles in production (D04). With cnn the roles get their
    #    AOT name from SECURITYROLE, which report_role_license() and
    #    create_role_test_ticket() take; without cnn they keep the report's names.
    ranking <- rank_roles_by_license_cost(cnn, licenses = detail[detail$ENVIRONMENT == "wibu-produktiv", ],
                                          prices = prices, export_path = "Data/Deliverables/D04_Rangliste_PPAC.xlsx")

    # The ticket (D11) of a role of the ranking; role as AOT name or as the name of the report
    create_role_test_ticket(cnn, ranking$Ranking$ROLE[[3]], role_area = "Verkauf_Innendienst",
                            report = report, ranking = ranking, output_folder = "Data/Reports/Tickets")

    # B: required against assigned licenses per user (production)
    compare_assigned_license_cost(users, prices = prices,
                                  export_path = "Data/Reports/Lizenzen_benoetigt_zugewiesen.xlsx")

    # C: INT against production
    compare_environment_license_cost(detail, to = "wibu-int", prices = prices,
                                     export_path = "Data/Reports/Lizenzkosten_INT_gegen_Prod.xlsx")

The price list needs a Base row for every license with an Attach row, also
"Commerce Base" next to "Commerce Attach". The base license is the first of
SCM, Finance, Commerce a user needs, every further one an attach license:
SCM Base + Finance Attach + Commerce Attach = 227.00 (sheet Benutzer, column
"Abgerechnet als"). This holds for the ranking from the database too. In INT the report counts no
license ("Not Applicable (Finance)"); compared is the license in brackets,
the one the role would need in production. The report names roles by their
name only: a role with another name in INT (another language) shows up as two
roles; the totals are not affected. The sheets Benutzer hold user ids.


EARLIER FUNCTIONS, UNCHANGED
----------------------------

plan_single_license_role(), check_duty_against_role(), compare_role_versions()
and compare_role_version_pairs() with load_role_mapping() work as in the
earlier zips; their calls are in the playbook (step 9) and in the Rmd.
