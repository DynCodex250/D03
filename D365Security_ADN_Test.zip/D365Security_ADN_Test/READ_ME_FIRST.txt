D365Security - test in ADN: UI duties and UI privileges against their AOT
counterparts and the inventory of the UI objects (D22 to D24), license
profile per user (D21), consolidation of duplicate roles (D20), matrix of
segregation of duties (D07), and the earlier steps (analysis of a role, role
XML, roles per license, ranking, cleanup plan, test ticket, merge)
==============================================================================

Packed on 2026-10-30 (second zip of the day) from the branch
feat/role-license-decision-tool, commit 7ce8091 (code and Rmds all
committed). Only D05 and D06 in Deliverables\ are the working copy of the
evening of 2026-10-30, not yet committed. This is the only zip to use: it
replaces the zips before. Later updates keep the name
D365Security_ADN_Test.zip.


WHAT TO TEST NOW (the tasks finished last)
------------------------------------------

New in this zip: step H (D22 to D24). Steps A to G are from the zips
before; G (D21) and the change of E came with the first zip of 2026-10-30.

Load the code as in "LOADING THE CODE" below, connect (cnn) and have
export_folder set. Details in Dokumentation.Rmd, use case 14 (A to C, G),
use case 8 (D), use case 5 and the report D20 (E), use case 15 and the
report D07 (F), the report D21 (G), use case 5 and the report D22 (H).

H. The UI duties and UI privileges against their AOT counterparts (D22,
   D23) and the inventory of the UI objects (D24). Roles, duties and
   privileges made in the user interface (identifier GUID) are to be
   replaced everywhere by the AOT object of the same name. Reads only;
   nothing in ADN changes:
     for (rmd in c("D22_UI_Aufgaben", "D23_UI_Rechte", "D24_UI_Inventur")) {
       rmarkdown::render(file.path(folder, paste0(rmd, ".Rmd")),
         params = list(umgebung = "ADN", code_laden = "dateien", repo_path = folder,
                       cred_path = "<db_credentials.xlsx on the ADN machine>",
                       export_ordner = file.path(export_folder, substr(rmd, 1, 3))),
         output_file = paste0(rmd, ".docx"))
     }
   Each writes <name>.xlsx and a Word summary (counts only, no user data)
   into export_folder\D22, \D23 and \D24. An existing workbook stops the run
   on purpose: give a new datei and the old one as bisherige_d22,
   bisherige_d23 or bisherige_d24; the white columns carry over.
   D22 and D23: one row per UI duty or UI privilege with its counterpart and
   the result: "Gleich", "Unterschiede" (sheet Unterschiede), "Kein
   Pendant", "Mehrere Pendants", "Inhalt nicht lesbar". A duty is compared
   by its privileges, a privilege by its entry points with their rights.
   D24: one row per UI object and place (UI role as sub-role of a role, UI
   duty in a role, UI privilege in a duty or directly in a role).
   Expect, after the export of the security configuration of ADN of
   2026-10-25: about 30 UI duties (D22) and 27 UI privileges (D23); D24
   with the places of about 99 UI roles, 30 duties and 27 privileges.
   Check, and please tell me the answers:
   - Many "Inhalt nicht lesbar" for duties or privileges that do sit in
     roles? Then UserSecGovRelatedObjects writes the GUIDs differently from
     SECURITYDUTY and SECURITYPRIVILEGE.
   - D24, a UI role used as sub-role: are the listed roles exactly those
     that hold it directly in D365? A role that holds it only through
     another sub-role means SYSTEMSECURITYSUBROLEENTITY holds indirect
     sub-roles too.
   - One UI duty with "Gleich": open it and its AOT counterpart in D365.
     The same privileges?
   Without the Rmd (the folders must exist):
     duties     <- plan_ui_counterparts(cnn, "duty")
     export_ui_counterparts(duties, file.path(export_folder, "D22", "D22_UI_Aufgaben.xlsx"))
     privileges <- plan_ui_counterparts(cnn, "privilege")
     export_ui_counterparts(privileges, file.path(export_folder, "D23", "D23_UI_Rechte.xlsx"))
     inventory  <- inventory_ui_objects(cnn)
     export_ui_inventory(inventory, file.path(export_folder, "D24", "D24_UI_Inventur.xlsx"))

G. The license profile per user (D21): for every user the licenses his work
   needs by the telemetry, against what PPAC expects, has assigned and has
   not yet assigned. No database needed when the graph comes from files:
     rmarkdown::render(file.path(folder, "D21_Lizenzprofil_Benutzer.Rmd"),
       params = list(code_laden = "dateien", repo_path = folder,
                     ppac_bericht = "<...Licensing_Report_pseudonymized.csv>",
                     ppac_detail  = "<...Detailed_Report_pseudonymized.csv>",
                     telemetrie   = "<...Telemetrie_pseudonymized.xlsx>",
                     preise       = "<your price list>.xlsx",
                     graph_ordner = "<folder of the EXPLODEDGAPH files>",
                     export_ordner = file.path(export_folder, "D21")),
       output_file = "D21_Lizenzprofil_Benutzer.docx")
   Without graph_ordner the graph is read from the database of
   graph_umgebung (default ADN) with cred_path. All files must be
   pseudonymized with the same key; otherwise a warning says that only few
   users match.
   Writes D21_Lizenzprofil_Benutzer.xlsx (sheets Anleitung, Benutzer,
   Ergebnisse, Lizenzen, Preise, Listen) and the Word summary (counts and
   sums only). The sheet Benutzer holds user ids; do not pass it on.
   Expect with the files of 2026-10-27/28: about the totals of the cleanup
   plan (step A) for the users the telemetry can judge, since both use the
   same rule; "PPAC erwartet" equal to the required licenses of the report
   per user; a few users "Berichte von PPAC weichen ab" (the two reports
   agreed for 212 of 215 users).
   Check: do "Könnte entfallen", "davon bereits zugewiesen" and "davon noch
   nicht zugewiesen" make sense for three users you know? Is a user with
   "Keine Telemetrie" really not working in D365?
   Without the Rmd:
     profile <- build_user_license_profile(read_ppac_license_report("<report>.csv"), detail, graph, usage,
                                           prices = "<your price list>.xlsx")
     export_user_license_profile(profile, file.path(export_folder, "D21", "D21_Lizenzprofil_Benutzer.xlsx"))

E. The consolidation of duplicate roles (D20). Many roles exist twice: as an
   AOT role and as a copy made in the user interface. Before a role is
   changed, both are brought together (strategy, principle 11):
     rmarkdown::render(file.path(folder, "D20_Rollenkonsolidierung.Rmd"),
       params = list(umgebung = "ADN", code_laden = "dateien", repo_path = folder,
                     cred_path = "<db_credentials.xlsx on the ADN machine>",
                     export_ordner = file.path(export_folder, "D20")),
       output_file = "D20_Rollenkonsolidierung.docx")
   With the license comparison it takes about half a minute per pair; for a
   quick first run add lizenzvergleich = FALSE.
   Writes to export_ordner: D20_Rollenkonsolidierung.xlsx (one row per pair),
   the folder Merge_Rollen_<date> (one folder per merged role: AOT file, zip,
   SecurityConfiguration\ and SecurityGovernance\), and the Word summary
   (counts only, no user ids).
   Expect: every pair of load_role_mapping() in the sheet Rollenpaare.
   "Keine Unterschiede" / "Nicht anfassen" where both versions hold the same
   duties, privileges, sub-roles and direct access; "Unterschiede" /
   "Zusammenführen" with a role <AOT name>_MERGED; a same copy whose AOT role
   has another, differing copy says "Im Merge enthalten". The column
   Arbeitsgrundlage names the one role to work with: the merged role, or
   the AOT role of a pair without differences. Merging assigns nobody: the
   users keep their roles until the cleaned-up role replaces both versions.
   The pair
   _WIBU_VERKAUF_INNENDIENST_MITARBEITER + 32B63442-1415-459D-8FF0-399780947265
   should be "Unterschiede" (compare_role_versions() gave B_IN_A).
   Check: open one pair "Keine Unterschiede" in D365: really the same? Does a
   merged role hold the duties of both versions (sheet Unterschiede_Aufbau)?
   Then a second run with bisherige_d20 = <the first workbook>, a new datei
   and lizenzvergleich = FALSE: entries in the white columns carry over.
   An existing workbook or a merge folder with files stops the run on
   purpose, before the database is read: on the same day give a new
   merge_ordner. Without the Rmd:
     plan <- plan_role_consolidation(cnn, merge_folder = file.path(export_folder, "D20", "Merge_Rollen"))
     export_role_consolidation(plan, file.path(export_folder, "D20", "D20_Rollenkonsolidierung.xlsx"))
   The merged roles are imported into INT later, as working basis; do not
   import them into ADN.

F. The matrix of segregation of duties (D07): the general catalog
   SoD_Katalog.xlsx (101 functions, 125 duties, 103 rules) against the roles
   of ADN and the users of production:
     rmarkdown::render(file.path(folder, "D07_Funktionstrennungs_Matrix.Rmd"),
       params = list(code_laden = "dateien", repo_path = folder,
                     katalog = file.path(folder, "SoD_Katalog.xlsx"),
                     graph_umgebung = "ADN",
                     cred_path = "<db_credentials.xlsx on the ADN machine>",
                     ppac_detail = "<...Detailed_Report_pseudonymized.csv>",
                     ppac_umgebung = "wibu-produktiv",
                     export_ordner = file.path(export_folder, "D07")),
       output_file = "D07_Funktionstrennungs_Matrix.docx")
   graph_ordner = "<folder of the EXPLODEDGAPH files>" reads the graph from
   the exported files instead of the database.
   Expect with the exports of 2026-10-28: 71 of 101 functions active, 74 of
   103 rules apply, 11 cannot be checked, 30 of 64 WIBU roles and 159 of 187
   users in conflict. The summary warns that graph (ADN) and assignments
   (production) come from different environments. The sheet
   Konflikte_Benutzer holds user ids; do not pass it on.
   Check: does the graph read straight from ADN give the same numbers?

A. The cleanup plan of D04, every saving proven by the telemetry:
     prices   <- read_license_prices("<your price list>.xlsx")
     detail   <- read_ppac_license_detail("<...Detailed_Report_pseudonymized.csv>",
                                          environment = "wibu-produktiv")
     graph    <- read_license_graph(con = cnn)        # or the exported .xlsx files:
     # graph  <- read_license_graph(list.files("<folder>", "EXPLODEDGAPH_.*[.]xlsx$", full.names = TRUE))
     usage    <- readxl::read_excel("<...Telemetrie_pseudonymized.xlsx>")
     plan     <- plan_role_license_cleanup(detail, graph, usage, prices = prices,
                   export_path = file.path(export_folder, "D04_Bereinigungsplan.xlsx"))
   Expect with the exports of 2026-10-28 (graph of ADN, telemetry 27.07. to
   24.10.2026): message "Cleanup plan over 191 users: 2075.10 per month proven
   ..., 1697.30 more after review. 41 users without telemetry or licensed use
   (2992.20 per month) to check; 0 whose license graph differs ...". Two
   warnings name roles only (_WIBU Fibu Rueckvergütungsverwalter is not in the
   graph; two names stand for several roles). Sheet Abweichungen: the 6
   objects of Human Resources Self Service of _WIBU Geschäftsführung, for
   which PPAC decides (billed Activity). Workbook, sheet
   Bereinigungsplan: step 1 _WIBU Verkauf Innendienst Mitarbeiter, 46 users,
   811,20; nine steps of wave 1 add up to 2.075,10. Sheet Aufgaben: the duty
   RetailDiscountOfferMaintain (Commerce) of that role, opened by 14 of its
   65 users, goes for 46. Reading the graph from the files takes about 35 s,
   the plan about 13 s.
   Check: does the role in the plan exist in ADN as described, and does the
   graph read straight from ADN (con = cnn) give the same message?

B. The ranking (D04) with both bases, to compare them yourself:
     ppac <- rank_roles_by_license_cost(licenses = detail, prices = prices,
               export_path = file.path(export_folder, "D04_Rangliste_PPAC.xlsx"))
     objs <- rank_roles_by_license_cost(licenses = detail, prices = prices,
               basis = "graph", graph = graph,
               export_path = file.path(export_folder, "D04_Rangliste_Graph.xlsx"))
   basis = "ppac" is the default, as before. Expect: sums 16.557,50 (PPAC)
   and 5.026,50 (graph); _WIBU Einkauf Mitarbeiter on rank 1 with 4.036,70
   by PPAC, on rank 5 with 464,10 by the graph. Sheet Überblick, row
   "Grundlage der Kosten nur wegen einer Rolle": PPAC or Lizenzgraph.

C. The inventory and license analysis D03 (Word, for CFO and IT management):
     rmarkdown::render(file.path(folder, "D03_Bestands_und_Lizenzanalyse.Rmd"),
       params = list(code_laden = "dateien", repo_path = folder,
                     ppac_detail = "<...Detailed_Report_pseudonymized.csv>",
                     ppac_bericht = "<...Report_pseudonymized.csv>",
                     preise = "<your price list>.xlsx",
                     graph_ordner = "<folder of the EXPLODEDGAPH files>",
                     telemetrie = "<...Telemetrie_pseudonymized.xlsx>"),
       output_file = "D03_Bestands_und_Lizenzanalyse.docx")
   Takes about 80 s. Expect in the summary: 28.446,40 per month for 191
   users, 6.014,30 missing licenses for 100 users, 2.075,10 proven saving.
   The report holds counts only, no user ids.

D. The merge of the AOT role and its UI copy into one role, whatever
   licenses the merged role needs (Rollen_Vergleich_und_Merge_Szenarien.Rmd,
   German; the guide has the comparison, three scenarios and the import):
     rmarkdown::render(file.path(folder, "Rollen_Vergleich_und_Merge_Szenarien.Rmd"),
       params = list(ausfuehren = TRUE, code_laden = "dateien", repo_path = folder,
                     cred_path = "<db_credentials.xlsx on the ADN machine>",
                     ausgabe = file.path(export_folder, "Rollen_Merge")),
       output_file = "Rollen_Merge_ADN.html")
   Or the merge alone:
     merged <- export_merged_role_xml(cnn,
                 c("_WIBU_VERKAUF_INNENDIENST_MITARBEITER", "32B63442-1415-459D-8FF0-399780947265"),
                 output_folder = file.path(export_folder, "Rollen_Merge"))
     merged$sources
   Name: the AOT name with the suffix _MERGED, in the spelling of
   SECURITYROLE, for example _WIBU_Verkauf_Innendienst_Mitarbeiter_MERGED;
   of two AOT roles or two UI roles the first one given. Files:
   AxSecurityRole\<name>.xml, <name>.zip, SecurityGovernance\ and
   SecurityConfiguration\ (the merged role as a new role).
   Expect: merged$sources has one row per role (KIND AOT and UI, counts of
   duties, privileges, sub-roles, direct access); a message when a sub-role
   is left out because it is one of the two roles. In the guide, scenario 1
   stops with "would hold itself" when the UI role holds the AOT role as a
   sub-role: that is the expected stop, scenario 2 is the way then.
   Scenario 3 (users onto the merged role) is meant for after an import;
   its workbook holds user ids, the output only counts.
   Check: are the duties and privileges of both roles in the merged file?
   Only if you want the import test in ADN (it changes ADN): import the file
   of SecurityConfiguration\ (System administration > Security > Security
   configuration, Data > Import) and look whether D365 keeps the name or
   gives a GUID; then compare_role_versions(cnn, <AOT role>, <merged role>)
   and the same with the UI role should say SAME or A_IN_B. Each comparison
   takes about half a minute.

Still open from the zip before (rank, comparisons, ticket):

1. Prices: prices <- read_license_prices("<your price list>.xlsx")
   The list needs the rows "Commerce Base" and "Commerce Attach".
2. D04 ranking from the detailed PPAC report, with AOT names:
     detail  <- read_ppac_license_detail("<...Detailed_Report_pseudonymized.csv>")
     ranking <- rank_roles_by_license_cost(cnn,
                  licenses = detail[detail$ENVIRONMENT == "wibu-produktiv", ],
                  prices = prices, export_path = file.path(export_folder, "D04_Rangliste.xlsx"))
   Expect: ROLE holds AOT names (from SECURITYROLE), NAME the report's names,
   VERSIONS the UI copies; warnings name roles not found. Sheet Benutzer,
   columns "Abgerechnet als" and "Rechnung": SCM Base + Finance Attach +
   Commerce Attach, 168,50 + 27,30 + 31,20 = 227,00 for Commerce + Finance +
   SCM. Sheet Rangliste, column "Lizenzkosten ihrer Benutzer je Monat (alle
   Rollen)": 14.755,00 for _WIBU Verkauf Innendienst Mitarbeiter, next to its
   1.895,40 "nur wegen der Rolle". Sheet Rechenweg: per role and case how its
   users are billed with and without the role; the savings of a role add up
   to its cost only because of it (2 x 58,50 + 57 x 31,20 + 6 x 0 = 1.895,40).
3. Required against assigned (production):
     users <- read_ppac_license_report("<...Licensing_Report_pseudonymized.csv>")
     compare_assigned_license_cost(users, prices = prices,
                                   export_path = file.path(export_folder, "Lizenzen_benoetigt_zugewiesen.xlsx"))
4. INT against production:
     compare_environment_license_cost(detail, to = "wibu-int", prices = prices,
                                      export_path = file.path(export_folder, "Lizenzkosten_INT_gegen_Prod.xlsx"))
5. Ticket (D11) of a role of the ranking; role as AOT name or as the
   report's name, for example "_WIBU Verkauf Innendienst Mitarbeiter":
     report <- analyze_role_license_report(cnn, "_WIBU_VERKAUF_INNENDIENST_MITARBEITER", usage = usage)
     create_role_test_ticket(cnn, "_WIBU Verkauf Innendienst Mitarbeiter", role_area = "Verkauf_Innendienst",
                             report = report, ranking = ranking,
                             output_folder = file.path(export_folder, "Tickets"))
   Expect: the rank of the role in D04 is filled ("auf Platz 3"), no error.


HISTORY
-------

New in the second zip of 2026-10-30:

  - plan_ui_counterparts(), export_ui_counterparts(), D22_UI_Aufgaben.Rmd
    and D23_UI_Rechte.Rmd: the UI duties and UI privileges against their
    AOT counterparts (D22, D23). See step H above.
  - inventory_ui_objects(), export_ui_inventory() and D24_UI_Inventur.Rmd:
    where every UI role, duty and privilege sits (D24).
  - Quick role changes in Prod are made in the user interface, then redone
    in the AOT and removed from the user interface; D24 therefore also runs
    in operation (strategy D01, phase 7; D02, rule 10).
  - Dokumentation.Rmd: use case 5 extended, the report D22.
  - Deliverables\: D05 and D06 with the sales positions split into
    STE-008 to STE-011 and their roles ROL-010 to ROL-015.
  - The column "Betroffene Benutzer" (USERIDS) of the sheet Rechenweg of
    the ranking is unchanged since the first zip of 2026-10-29.
  - 5 more code files: 76 in all (ui_security_objects.R,
    plan_ui_counterparts.R, export_ui_counterparts.R,
    inventory_ui_objects.R, export_ui_inventory.R).

New in the first zip of 2026-10-30:

  - build_user_license_profile(), export_user_license_profile() and
    D21_Lizenzprofil_Benutzer.Rmd: the license profile per user (D21).
    See step G above.
  - D20: the merged role is the working basis (column Arbeitsgrundlage,
    "Im Merge enthalten", team columns Bereinigte Rolle and Alte Versionen
    entfernt am; import into INT).
  - deliverable_workbook.R: the layout and carry-over shared by D07, D20
    and D21.
  - Dokumentation.Rmd: use case 14 extended, the report D21.
  - 3 more code files: 71 in all (deliverable_workbook.R,
    build_user_license_profile.R, export_user_license_profile.R).

New in the third zip of 2026-10-29:

  - plan_role_consolidation(), export_role_consolidation() and
    D20_Rollenkonsolidierung.Rmd: the consolidation of duplicate roles
    (D20). See step E above.
  - read_sod_catalog(), build_sod_matrix(), export_sod_matrix(),
    D07_Funktionstrennungs_Matrix.Rmd and the catalog SoD_Katalog.xlsx: the
    matrix of segregation of duties (D07). See step F above.
  - Dokumentation.Rmd: use case 5 extended, use case 15 new, the reports
    D07 and D20.
  - 5 more code files: 68 in all (read_sod_catalog.R, build_sod_matrix.R,
    export_sod_matrix.R, plan_role_consolidation.R,
    export_role_consolidation.R).

New in the second zip of 2026-10-29:

  - export_merged_role_xml(): two or more roles merged into one and written
    as AOT file, zip and the two browser files. See step D above.
  - export_role_xml() stops when the role would hold itself as a sub-role
    (a UI copy that holds the AOT role, written under the AOT name).
  - Rollen_Vergleich_und_Merge_Szenarien.Rmd: comparison, the three
    scenarios and the import; code_laden = "dateien" loads the 63 files.
  - 2 more code files: 63 in all (export_merged_role_xml.R,
    sec_migrate_ui_roles_to_aot.R).

New in the first zip of 2026-10-29:

  - rank_roles_by_license_cost(): parameter basis = "ppac" (default, as
    before) or "graph" (costs only because of a role from the license graph,
    PPAC has priority), and graph. See step B above.
  - The cleanup plan: PPAC has priority where the graph wants more than PPAC
    bills; the sheet Abweichungen lists those objects.
  - summarize_license_inventory() and D03_Bestands_und_Lizenzanalyse.Rmd:
    the inventory and license analysis D03. See step C above.
  - Sheet Rechenweg: column "Betroffene Benutzer" (your change).
  - 2 more code files: 61 in all.

New in the zip of 2026-10-28, evening:

  - read_license_graph(): the license graph (LicensingSecurityObjectExplodedGraph)
    from the exported .xlsx files or from the database.
  - plan_role_license_cleanup(): the cleanup plan of D04. Per user the license
    he needs for what the telemetry shows, the duties of his roles that must
    go for it, the roles in the order that completes the most savings, in
    three waves. See "THE CLEANUP PLAN BY THE TELEMETRY" below.
  - The ranking from the PPAC report is an upper bound: PPAC names a license
    at one role of a user only. See the note under "THE MOST EXPENSIVE ROLES".
  - Dokumentation.Rmd: use case 14.
  - 5 more code files: 59 in all.

New in the zip of 2026-10-28:

  - Base licenses are billed in the order SCM, Finance, Commerce: the first a
    user needs is the base license, every further one an attach license.
  - The PPAC ranking gets AOT names from SECURITYROLE when cnn is given.
  - The ticket takes the role also by its name and finds its rank.
  - Ranking: column USERS_COST (what the users of a role pay with all their
    roles), sheet Rechenweg (calculation per role and case), column Rechnung
    in the sheet Benutzer.

New in the zip of 2026-10-27, second part:

  - License costs from the PPAC license reports, without a database: the
    ranking from the detailed report, required against assigned licenses
    per user, and INT against production. See "LICENSE COSTS FROM THE PPAC
    REPORTS" below.
  - read_license_prices(): reads the price list with SKU / Price
    (Finance Base, Finance Attach, ..., Commerce Base, Commerce Attach).
  - Dokumentation.Rmd: use case 13.
  - 5 more code files: 54 in all.

New in the zip of 2026-10-27, first part:

  - rank_roles_by_license_cost(): the ranking of the most expensive roles
    (D04), see below.
  - create_role_test_ticket(): the test ticket of a cleaned-up role (D11,
    strand A) as text and Word, see below.
  - Dokumentation.Rmd: use cases 11 and 12.

New since D365Security_ADN_2026-10-24_Rollenpaare.zip:

  - Analyse_Rolle_Lizenzen.Rmd: the analysis of a role with ten questions,
    as your version with code and as a Word file for the business department.
  - Vorschlag_Rolle_SCM.Rmd: the proposal to reduce a role to SCM.
  - export_role_xml(): a role from the database as role XML and zip, and as
    two files for the import in the browser (security governance, security
    configuration); a UI sub-role is replaced by the AOT role of the same
    name when one exists. build_license_roles() writes the same three kinds.
  - describe_subroles(): the sub-roles of a role (question 10).
  - build_license_roles(): one role per license from what the users use.
  - Playbook: new steps 10 and 11; "Result" is now step 12.
  - 14 more code files: 46 at the time.


WHAT IS IN THIS FOLDER
----------------------

Playbook_Role_License_Report_Acceptance_ADN.Rmd
    The acceptance test, step by step (run chunk by chunk).

Analyse_Rolle_Lizenzen.Rmd
    The analysis of the role (German). One file, two versions.

Vorschlag_Rolle_SCM.Rmd
    The proposal to reduce a role to SCM (German). One file, two versions.

D03_Bestands_und_Lizenzanalyse.Rmd
    The inventory and license analysis D03 (German Word file, counts only).

Rollen_Vergleich_und_Merge_Szenarien.Rmd
    Comparison and merge of an AOT role and its UI copy (German, step D).

D20_Rollenkonsolidierung.Rmd
    The consolidation of duplicate roles D20 (German; Excel, merged roles,
    Word summary with counts only; step E).

D21_Lizenzprofil_Benutzer.Rmd
    The license profile per user D21 (German; Excel and Word summary with
    counts and sums only; step G).

D22_UI_Aufgaben.Rmd, D23_UI_Rechte.Rmd, D24_UI_Inventur.Rmd
    The UI duties and UI privileges against their AOT counterparts and the
    inventory of the UI objects (German; Excel and Word summary with counts
    only; step H).

D07_Funktionstrennungs_Matrix.Rmd, SoD_Katalog.xlsx
    The matrix of segregation of duties D07 (German; step F) and the general
    catalog it reads (functions, duties, rules, sources; no company data).

Dokumentation.Rmd
    The documentation of the package by use case (English): every function
    with call, parameters, results, files and messages. Render it to HTML:
    rmarkdown::render(file.path(folder, "Dokumentation.Rmd")); no database.

R\
    The 76 code files. The package does not have to be installed.

Deliverables\
    D05_Rollenkatalog.xlsx and D06_Stellen_Rollen.xlsx as of 2026-10-30,
    evening: the sales positions split into STE-008 to STE-011, with the
    roles ROL-010 to ROL-015. Positions, roles and head counts only; the
    code does not read them.

D365_Exports\
    The object lists of the role _WIBU_VERKAUF_INNENDIENST_MITARBEITER,
    exported from D365 in ADN on 2026-10-10, one file per license.

The folder holds no user data and no password. db_credentials.xlsx: use the
file on the ADN machine.


LOADING THE CODE (playbook)
---------------------------

1. Unzip close to the drive root, for example under Documents\RProjects.
   The folder that contains R\ is your repo_path.
2. R packages, once: install.packages(c("DBI", "odbc", "dplyr", "tibble",
   "tidyr", "lubridate", "openxlsx", "readxl", "writexl", "xml2", "knitr",
   "rmarkdown", "zip"))
3. Open the playbook in RStudio and run the chunks one by one (no "Knit"):
   "parameters", then "appendix-files" (the last chunk; it loads the 76
   files), then "connection". Skip "code-version" and "setup".
4. Then step 2 (telemetry, it fills `usage`), and steps 9 to 11.


THE ANALYSIS OF THE ROLE
------------------------

The analysis answers ten questions about one role, by default
_WIBU_VERKAUF_INNENDIENST_MITARBEITER:

  1. Which licenses does the role need, and why?
  2. What would have to go so that one license is enough?
  3. Who uses the parts that need a base license?
  4. Does changing only this role save anything (other roles, UI version)?
  5. AOT role against the UI role of the same name.
  6. The role with one license only (building plan).
  7. What is used, what never?
  8. Which roles per license come out of the usage?
  9. Which license would each user need afterwards?
 10. Which sub-roles does the role have, and what follows from them?

Users appear only as counts. In a fresh R session in RStudio:

    folder <- "C:/Users/CKAM/Documents/RProjects/D365Security_ADN_Test"   # where you unzipped

    # Your version, with code; the workbooks go to export_ordner
    rmarkdown::render(
      file.path(folder, "Analyse_Rolle_Lizenzen.Rmd"),
      params = list(code_laden = "dateien", repo_path = folder,
                    export_ordner = "C:/Users/CKAM/Documents/RProjects/Output/Analyse_Rolle"),
      output_file = "Analyse_Verkauf_Innendienst.docx"
    )

    # The version for the business department: Word, no code, no files
    rmarkdown::render(
      file.path(folder, "Analyse_Rolle_Lizenzen.Rmd"),
      params = list(fassung = "fachbereich", code_laden = "dateien", repo_path = folder),
      output_file = "Analyse_Verkauf_Innendienst_Fachbereich.docx"
    )

Other parameters (all in the header of the Rmd): rolle, ui_rolle, ziel_lizenz,
ziel_rolle, umgebung, cred_path, telemetrie (empty = load from Insights with
D365Licensing). Each render runs the whole analysis; that takes a few minutes.

Your version writes to export_ordner: the license report, the building plan,
the comparison of the two role versions, and in "Lizenzrollen" the roles per
license as XML, zip and workbook. These workbooks hold user ids; do not pass
them on. The Word file for the business department holds counts only.


THE PROPOSAL: ONE ROLE DOWN TO ONE LICENSE
------------------------------------------

Vorschlag_Rolle_SCM.Rmd writes the proposal to reduce a role to Supply Chain
Management (German): where the licenses come from, an SCM base role plus small
add-on roles, the two conditions (UI copy, other roles), and the sub-roles
that fix another license. Every number is computed from the data, so it also
works for other roles: set rolle, ui_rolle (empty when there is none),
ziel_rolle (an existing SCM version; empty when there is none) and
name_bereich, for example "Verkauf_Verkaufsleiter". For a role that exists
only in the user interface, rolle is its GUID and ui_rolle stays empty (the
same GUID in both counts as empty).

    rmarkdown::render(
      file.path(folder, "Vorschlag_Rolle_SCM.Rmd"),
      params = list(code_laden = "dateien", repo_path = folder,
                    export_ordner = "C:/Users/CKAM/Documents/RProjects/Output/Vorschlag_SCM"),
      output_file = "Vorschlag_Verkauf_Innendienst.docx"
    )

With fassung = "fachbereich": text only, no code, no files. Your version
writes Vorschlag_<role>.xlsx (sheets Treiber, Prüfung, Objekte der Treiber,
Bleibt draußen, Benutzer, Lizenzquellen, Subrollen; the sheet Benutzer holds
user ids), Bauplan.xlsx, Pruefung_<block>.xlsx per block, Rollenversionen.xlsx
and the folder Lizenzrollen. telemetrie takes an .rds or an .RData file.

The roles in Lizenzrollen are built with the target license first
(prefer = ziel_lizenz): one SCM role, plus a role for another license only
for the objects SCM does not cover, for example SCM and Finance. Before, the
cheapest set won, so a role whose objects Finance covers alone became one
Finance role.


ROLE XML FROM THE DATABASE
--------------------------

    result <- export_role_xml(cnn, "_WIBU_VERKAUF_INNENDIENST_LEITUNG",
                              output_folder = file.path(export_folder, "Rollen_XML"))
    result$zip

Writes AxSecurityRole\<name>.xml and <name>.zip: the role with its own
duties, privileges, sub-roles and direct access permissions, in the format of
a Visual Studio project. name = "..." and label = "..." write a copy under
another name.

A sub-role created in the user interface (GUID) is written as the AOT role of
the same name when one exists (load_role_mapping()); both are compared first,
and a warning says when they differ. Without such an AOT role the UI sub-role
stays, with a warning: nothing is created blindly. result$subroles lists what
was done; replace_ui_subroles = FALSE keeps every sub-role as it is.

    describe_subroles(cnn, "_WIBU_VERKAUF_INNENDIENST_LEITUNG")

lists the sub-roles of a role: AOT or UI, license, whether it fixes a license
of the role, AOT counterpart, other roles that hold it, users who have it
directly. The analysis Rmd shows the same as question 10.

The same role also goes into two files for the import in the browser, built
after your two exports from ADN:
  SecurityGovernance\<name>.xml     as the security governance exports it
  SecurityConfiguration\<name>.xml  as the security configuration exports it
Both hold the same role; they differ only in how they write an empty element
(<Forms /> or <Forms/>). An AOT role under its own name goes into the list of
changed roles (an import replaces that role), a copy or a UI role into the
list of new roles. Names stay readable, no GUID. browser_files = FALSE writes
only the AOT file. Do not import the files of step 10 into ADN: both roles
exist there already.

Two or more roles merged into one: export_merged_role_xml() writes the same
files for the merged role (step D above).


ROLES PER LICENSE FROM THE USAGE
--------------------------------

    roles <- build_license_roles(cnn, "_WIBU_VERKAUF_INNENDIENST_MITARBEITER",
                                 usage = usage,
                                 export_folder = file.path(export_folder, "Lizenzrollen"))
    roles$Summary

Without licenses: the fewest base licenses that cover the used objects (the
cheaper one on a tie). prefer = "Supply Chain Management": SCM first, other
licenses only for what SCM does not cover. With licenses = "Supply Chain
Management": only that role. users = c("id1", "id2"): only the usage of these
users counts. Without usage: every privilege is kept.

A privilege counts as used when one of its forms was opened; privileges
without a form (actions, entities, services) come in with their duty. A
privilege the license covers only partly becomes a new privilege
<privilege>_<SCM|FIN|COM>. Files: AxSecurityRole\, AxSecurityPrivilege\, one
zip for Visual Studio; SecurityGovernance\ and SecurityConfiguration\ with all
new roles and new privileges in one file each, for the import in the browser;
and a workbook (Überblick, Rollen, Neue Rechte, Rechte, Objekte, Benutzer,
Legende).

Import test, once: import the file of SecurityConfiguration\ in System
administration > Security > Security configuration (Data > Import) and look
whether D365 keeps the readable names of the new roles and privileges.


THE MOST EXPENSIVE ROLES (D04)
------------------------------

    prices <- data.frame(
      LICENSE      = c("Team Members", "Operations - Activity", "Commerce",
                       "Finance", "Supply Chain Management"),
      BASE_PRICE   = c(7.50, 46.80, 164.60, 164.60, 164.60),
      ATTACH_PRICE = c(NA, NA, 31.20, 31.20, 31.20)
    )
    ranking <- rank_roles_by_license_cost(cnn, prices = prices,
                 export_path = file.path(export_folder, "D04_Rangliste.xlsx"))
    head(ranking$Ranking, 10)

For every role: the license costs per month its users would no longer have if
the role triggered no license, given all their other roles. An AOT role and
its UI role of the same name count as one role. The prices above are the
estimates of the strategy paper (October 2026); without prices they are used
with a warning. Current prices go in as a table or an .xlsx with the columns
LICENSE, BASE_PRICE, ATTACH_PRICE; every license the users have needs a row.
The sheets Benutzer and Benutzer und Rollen hold user ids; do not pass them on.

Note: the PPAC report names each license of a user at one of his roles
only, and None at the other roles that need it too (26 of 107 roles of
production; _WIBU Einkauf Disposition shows None for all its 36 users). From
the PPAC report, "costs only because of the role" is therefore an upper
bound that can be far too high. What can really go comes from the cleanup
plan below.


THE CLEANUP PLAN BY THE TELEMETRY (D04)
---------------------------------------

    graph <- read_license_graph(con = cnn)    # or the exported .xlsx files
    usage <- readxl::read_excel("<...Telemetrie_pseudonymized.xlsx>")
    plan  <- plan_role_license_cleanup(detail[detail$ENVIRONMENT == "wibu-produktiv", ], graph, usage,
               prices = prices, export_path = file.path(export_folder, "D04_Bereinigungsplan.xlsx"))

Rules: a duty is used when the user opened one of its display menu items;
its actions and data entities count with it. A duty without a display menu
item cannot be measured and stays until the business confirms it is unused.
Per user the cheapest licenses for the duties he keeps (from the license
graph, billed SCM, Finance, Commerce as above); today's billing from PPAC.
Users without telemetry, or who opened only what needs no license, are a
check list (wave 2), never a saving. PPAC has priority: where the graph
wants more for an object than PPAC bills, the licenses of PPAC cover it
(sheet Abweichungen); where the graph needs less, no saving counts for the
user (class "Graph weicht ab"). Wave 1: the roles with
proven savings, in the order that completes the most; wave 3: what needs
the review. Sheets: Überblick, Bereinigungsplan, Maßnahmen, Benutzer,
Aufgaben, Ohne Nutzung, Abweichungen, Preise, Legende. Maßnahmen, Benutzer
and Ohne Nutzung hold user ids; do not pass them on. The telemetry covers
only its period; work done once a year may not show in it.


THE TEST TICKET OF A CLEANED-UP ROLE (D11)
------------------------------------------

Before the ticket: the report of the role with usage (step 2 fills usage),
the ranking above, the name part of the new role by the rule
WIBU_<Bereich>_<Funktion>_<Lizenz>, and the proposal agreed with the owner of
the role.

    report <- analyze_role_license_report(cnn, "_WIBU_VERKAUF_INNENDIENST_MITARBEITER",
                                          usage = usage)
    ticket <- create_role_test_ticket(cnn, "_WIBU_VERKAUF_INNENDIENST_MITARBEITER",
                                      role_area = "Verkauf_Innendienst",
                                      report = report, ranking = ranking,
                                      output_folder = file.path(export_folder, "Tickets"))
    cat(ticket$Text)

Fills the template of D11, section 6: the new role in the title, previous and
target license, the number of affected users and their companies, the rank in
D04, and the license drivers that are removed, moved to an add-on role, or
left to clarify. Environment INT, no ticket number. assignee, due_date,
test_user, test_cases (a table with TESTCASE_ID and PROCESS) and blocklist
fill the rest; without them they stay placeholders in [ ]. Writes
Ticket_Strang_A_<role>.md and .docx (Word needs RStudio's pandoc). The ticket
holds counts and companies, no user ids.


LICENSE COSTS FROM THE PPAC REPORTS
-----------------------------------

No database needed. Pseudonymize the two reports first (Dokumentation.Rmd,
use case 13) and write the pseudonymized tables with readr::write_csv().

    prices <- read_license_prices("C:/Data/Lizenzpreise.xlsx")   # sheet skuPrices
    detail <- read_ppac_license_detail(".../Finance_And_Operations_Licensing_Detailed_Report_pseudonymized.csv")
    users  <- read_ppac_license_report(".../Finance_And_Operations_Licensing_Report_pseudonymized.csv")

    # A: ranking of the roles in production (D04). With cnn the roles get their
    #    AOT name from SECURITYROLE, which report_role_license() and
    #    create_role_test_ticket() take; without cnn they keep the report's names.
    ranking <- rank_roles_by_license_cost(cnn, licenses = detail[detail$ENVIRONMENT == "wibu-produktiv", ],
                                          prices = prices, export_path = file.path(export_folder, "D04_Rangliste.xlsx"))

    # The ticket (D11) of a role of the ranking; role as AOT name or as the name of the report
    create_role_test_ticket(cnn, ranking$Ranking$ROLE[[3]], role_area = "Verkauf_Innendienst",
                            report = report, ranking = ranking, output_folder = file.path(export_folder, "Tickets"))

    # B: required against assigned licenses per user (production)
    compare_assigned_license_cost(users, prices = prices,
                                  export_path = file.path(export_folder, "Lizenzen_benoetigt_zugewiesen.xlsx"))

    # C: INT against production
    compare_environment_license_cost(detail, to = "wibu-int", prices = prices,
                                     export_path = file.path(export_folder, "Lizenzkosten_INT_gegen_Prod.xlsx"))

The price list needs a Base row for every license with an Attach row, also
"Commerce Base" next to "Commerce Attach". The base license is the first of
SCM, Finance, Commerce a user needs, every further one an attach license:
SCM Base + Finance Attach + Commerce Attach = 227.00 (sheet Benutzer, column
"Abgerechnet als"). This holds for the ranking from the database too. In INT the report counts no
license ("Not Applicable (Finance)"); compared is the license in brackets,
the one the role would need in production. The report names roles by their
name only: a role with another name in INT (another language) shows up as two
roles; the totals are not affected. The sheets Benutzer hold user ids.


EARLIER FUNCTIONS, UNCHANGED
----------------------------

plan_single_license_role(), check_duty_against_role(), compare_role_versions()
and compare_role_version_pairs() with load_role_mapping() work as in the
earlier zips; their calls are in the playbook (step 9) and in the Rmd.
